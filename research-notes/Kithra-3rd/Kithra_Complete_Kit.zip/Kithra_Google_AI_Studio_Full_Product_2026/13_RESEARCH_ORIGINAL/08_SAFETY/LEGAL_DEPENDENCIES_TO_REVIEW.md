# LEGAL DEPENDENCIES TO REVIEW (counsel required)

**This is not legal advice.** Every item below is a **dependency to verify**,
not a claim of compliance. Kithra must not state or imply legal immunity.

## 1. India — DPDP Act & Rules
- Commencement is **staged**. The kit cites G.S.R. 843(E) (Act notification) and
  G.S.R. 846(E) (Rules): certain provisions commenced at publication, selected
  provisions after one year, and central operational duties after eighteen
  months — **subject to amendment and interpretation**.
  https://egazette.gov.in/WriteReadData/2025/267647.pdf ·
  https://egazette.gov.in/WriteReadData/2025/267650.pdf
- **Action:** counsel classifies Kithra as data fiduciary/processor, confirms
  which obligations are in force at launch, and signs the notice + retention
  schedule. Do **not** assert "DPDP-compliant" until counsel signs.

## 2. Intermediary rules & grievance
- IT (Intermediary Guidelines and Digital Media Ethics Code) Rules and their
  amendments define grievance-officer and removal/acknowledgement duties.
  https://www.meity.gov.in/
- **Action:** counsel determines whether Kithra is a social-media intermediary
  at its actual scale/features, and confirms currently notified timelines.

## 3. CERT-In incident reporting
- CERT-In directions reference **6-hour** reporting for specified incidents.
  https://www.cert-in.org.in/Directions70B.jsp
- **Action:** incident runbook + on-call coverage + evidence preservation before
  launch; verify current requirements.

## 4. Consumer & payment
- Refund/cancellation, auto-renewal disclosure, GST treatment and payment
  reconciliation. Razorpay terms: https://razorpay.com/pricing/
- **Action:** accountant + counsel confirm tax handling and consumer-law wording;
  payment webhooks authoritative; no card data stored.

## 5. Age & child safety
- 18+ enrolment, suspected-minor handling, and CSAM escalation path (never the
  general moderation queue).
- **Action:** counsel confirms reporting duties and process.

## 6. Data residency / processors
- Firebase, Cloudflare, email, SMS, payments are processors/sub-processors.
- **Action:** do **not** claim "stored only in India" without proof; document
  actual regions and transfer basis.

## 7. Advertising & claims
- No "scientifically guaranteed", "soulmate", "100% match" claims; the
  deterministic engine's output is described as an **agreement index**.
- **Action:** counsel reviews marketing claims; trademark/domain clearance for
  "Kithra" and the brand line before publication.

## 8. Accessibility law
- WCAG 2.2 AA is adopted as the engineering target; any applicable
  accessibility legislation/obligation to be confirmed per market.

## 9. Release blockers (from the kit, retained)

Mocked deletion, fake E2EE, mandatory unreviewed intimate questions, unguarded
admin login, no reporting escalation, or unsupported marriage-guarantee claims
must **block release**.
