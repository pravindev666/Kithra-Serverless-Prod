# CONSENT, PRIVACY & ACCESSIBILITY UX

## 1. Consent model (granular, revocable, uncheckable-by-default)

Separate, purpose-specific consent — **never** a single "accept everything"
box, **never** pre-checked:

```
[ ] I want my Friendship profile to be discoverable by eligible members in Friendship.
[ ] I separately want to appear in Dating.
[ ] I separately want to appear in Matrimony.
[ ] I understand my answers build my private behavioural-pattern report.
[ ] Show selected derived explanations to a person after I accept their connection request.
[ ] Optional: allow phone verification for recovery (carrier SMS charges may apply).
```

- Each consent shows **purpose, scope, and how to withdraw** on the same screen.
- Withdrawal is one action, propagates to match cache, Circles, notifications.
- Consent **version + timestamp** recorded; material changes require re-consent.
- **No dark patterns**: reject is as easy as accept; no false urgency; no
  "are you sure" loops (FTC 2022 alignment).

## 2. Mode-boundary privacy (the core promise)

- A mode's persona, photos, answers and visibility are **isolated**.
- Enabling one mode never exposes another; matrimony is never inferred from
  friendship.
- Cross-mode message access is impossible.
- Admins do **not** get cross-mode or raw-answer access by default.

## 3. Anti-abuse & safety UX

- Block (bilateral, silent to the blocked party, removes them from discovery),
  mute, report — all **free, in every mode, at every tier**.
- Report always returns a **case id + safety guidance**.
- Meeting-safety guidance (public place, share plans) surfaced where relevant —
  informational, not surveillance; **no live location sharing**.
- Identity safety for women and marginalised users: no forced photo, blur
  option, screenshot deterrence (honestly labelled).
- Anti-impersonation: verification is optional and only claimed when real.

## 4. Accessibility (WCAG 2.2 AA)

| Requirement | Implementation |
|---|---|
| Contrast | computed AA+ for all text roles; clay accent decoration-only |
| Target size | ≥44 px effective (exceeds SC 2.5.8's 24 px min) |
| Keyboard | full operation; visible focus ring; skip links |
| Screen reader | semantic roles, `aria-live` async, labelled controls |
| Motion | reduced-motion honoured everywhere (§07) |
| Error handling | identified + instruction + focus move (SC 3.3.1/3.3.3) |
| Language | `lang` attribute; tested script shaping; per-script fallbacks |
| Low-data | text-first, lazy images, low-data mode flag |
| Resize/zoom | usable to 400% zoom / 320 px width |

**Testing:** automated (axe) **plus** manual screen-reader (TalkBack/VoiceOver)
and keyboard-only sessions with disabled users — automated alone is insufficient.

## 5. Multilingual & cross-cultural

- UI translation ≠ psychometric translation. UI strings localise freely;
  question items require cognitive interviews + measurement-equivalence
  analysis before use (see QRD).
- Right-to-left-ready primitives even though no RTL locale launches initially.
- No culturally biased labels; no fabricated member photos; no assumed family
  authority in matrimony.

## 6. Honest copy patterns (use these, not hype)

| Avoid | Use |
|---|---|
| "We read your mind" | "We compare the answers you chose to share" |
| "100% soulmate" | "100% agreement across the answers compared" |
| "Guaranteed match" | "A clearer introduction, no guarantees" |
| "Unbreakable privacy" | "Private by default; you control each mode" |
| "Verified identity" (if not) | "Self-declared" or "Verified (provider, date)" |
| "Signal E2EE" | "Encrypted in transit and at rest" (accurate) |

## 7. Acceptance criteria

- [ ] No pre-checked consent boxes anywhere.
- [ ] Withdrawal works and is reflected in discovery.
- [ ] Block/report free in every mode/tier (proven by test).
- [ ] WCAG 2.2 AA verified by automated + manual audit.
- [ ] All Indic scripts shape correctly at 320 px.
- [ ] No claim beyond what is implemented.
