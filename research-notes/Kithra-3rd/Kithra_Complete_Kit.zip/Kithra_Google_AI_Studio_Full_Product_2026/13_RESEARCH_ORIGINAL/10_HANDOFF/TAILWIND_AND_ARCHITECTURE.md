# FRONTEND ARCHITECTURE & TAILWIND THEME

Bridges the design tokens to a working React 19 + TypeScript + Vite + Tailwind
setup. **Runtime-agnostic** — nothing here assumes Cloudflare or Node; both
deployment targets consume the same UI.

---

## 1. Folder architecture

```
src/
  app/
    main.tsx             # entry
    App.tsx              # providers + router
    providers/           # ThemeProvider, QueryProvider, AuthProvider, I18nProvider
    routes/              # route table (lazy-loaded per feature)
  components/
    ui/                  # primitives — tokens only, no business logic
      Button.tsx Input.tsx Checkbox.tsx Select.tsx SegmentedControl.tsx
      Card.tsx Modal.tsx Sheet.tsx Toast.tsx Skeleton.tsx Avatar.tsx
    domain/              # Kithra-specific, composed from ui/
      ModeChip.tsx ModeSwitcher.tsx ConsentBlock.tsx
      QuestionItem.tsx QuizProgress.tsx PatternDimension.tsx
      MatchCard.tsx MatchExplanation.tsx RequestButton.tsx
      MessageThread.tsx SafetyMenu.tsx PhotoUploader.tsx PhotoCropper.tsx
      PlanCard.tsx CancelFlow.tsx RightsRequestForm.tsx
    admin/               # admin console components (deny-by-default)
      CaseQueue.tsx CaseDetail.tsx EvidencePanel.tsx AuditTimeline.tsx
      RoleEditor.tsx RefundPanel.tsx QuestionBankEditor.tsx
  features/              # one folder per route group
    discover/ quiz/ match/ messages/ circles/ billing/ settings/ admin/
  lib/
    api/                 # typed clients generated from OpenAPI
    permissions/         # UI hints only — server re-checks everything
    i18n/                # message catalogs + per-script font loading
    motion/              # shared variants + reduced-motion helpers
  styles/
    tokens.css           # import of 03_BRAND/design-tokens.css
    index.css            # @tailwind layers + base
  types/
```

**Rules**
- `components/ui` may import **only** tokens and React — no API, no router.
- `features/*` may import `components/*` and `lib/*`, never another feature's
  internals.
- The client **never** enforces authorization; it only hides affordances.
- One source of truth for motion variants in `lib/motion`.

---

## 2. Tailwind configuration (CSS-first tokens, Tailwind v4 style)

```ts
// tailwind.config.ts — maps Kithra tokens to utility names
import type { Config } from "tailwindcss";

export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  darkMode: ["selector", '[data-theme="dark"]'],
  theme: {
    extend: {
      colors: {
        canvas:  "var(--k-canvas)",
        surface: "var(--k-surface)",
        surfaceAlt: "var(--k-surface-alt)",
        ink:     "var(--k-text)",
        muted:   "var(--k-text-muted)",
        subtle:  "var(--k-text-subtle)",
        primary: { DEFAULT: "var(--k-primary)", hover: "var(--k-primary-hover)",
                   active: "var(--k-primary-active)", subtle: "var(--k-primary-subtle)",
                   fg: "var(--k-on-primary)" },
        accent:  { DEFAULT: "var(--k-accent)", text: "var(--k-accent-text)",
                   subtle: "var(--k-accent-subtle)" },
        support: { DEFAULT: "var(--k-support)", subtle: "var(--k-support-subtle)" },
        line:    { DEFAULT: "var(--k-border)", strong: "var(--k-border-strong)" },
        danger:  { DEFAULT: "var(--k-danger)", subtle: "var(--k-danger-subtle)" },
        warning: { DEFAULT: "var(--k-warning)", subtle: "var(--k-warning-subtle)" },
        success: { DEFAULT: "var(--k-success)", subtle: "var(--k-success-subtle)" },
        mode:    { friendship: "var(--k-mode-friendship)",
                   dating: "var(--k-mode-dating)",
                   matrimony: "var(--k-mode-matrimony)" },
      },
      fontFamily: {
        display: "var(--k-font-display)",
        body: "var(--k-font-body)",
        mono: "var(--k-font-mono)",
      },
      borderRadius: {
        chip: "var(--k-r-chip)", input: "var(--k-r-input)",
        card: "var(--k-r-card)", sheet: "var(--k-r-sheet)",
        editorial: "var(--k-r-editorial)",
      },
      boxShadow: {
        xs: "var(--k-shadow-xs)", sm: "var(--k-shadow-sm)",
        md: "var(--k-shadow-md)", lg: "var(--k-shadow-lg)",
      },
      spacing: {
        1: "var(--k-s1)", 2: "var(--k-s2)", 3: "var(--k-s3)", 4: "var(--k-s4)",
        5: "var(--k-s5)", 6: "var(--k-s6)", 8: "var(--k-s8)", 10: "var(--k-s10)",
        12: "var(--k-s12)", 16: "var(--k-s16)", 20: "var(--k-s20)", 24: "var(--k-s24)",
      },
      transitionDuration: {
        micro: "var(--k-dur-micro)", ui: "var(--k-dur-ui)",
        hero: "var(--k-dur-hero)", admin: "var(--k-dur-admin)",
      },
      transitionTimingFunction: {
        standard: "var(--k-ease-standard)",
        enter: "var(--k-ease-enter)",
        exit: "var(--k-ease-exit)",
      },
      maxWidth: {
        container: "var(--k-container-max)",
        content: "var(--k-content-max)",
        admin: "var(--k-admin-max)",
      },
      minHeight: { touch: "var(--k-touch-min)" },
      zIndex: {
        sticky: "var(--k-z-sticky)", dropdown: "var(--k-z-dropdown)",
        drawer: "var(--k-z-drawer)", modal: "var(--k-z-modal)",
        toast: "var(--k-z-toast)", tooltip: "var(--k-z-tooltip)",
      },
    },
  },
  plugins: [],
} satisfies Config;
```

## 3. `styles/index.css`

```css
@import "./tokens.css";           /* 03_BRAND/design-tokens.css */
@tailwind base;
@tailwind components;
@tailwind utilities;

@layer base {
  html { -webkit-text-size-adjust: 100%; }
  body {
    background: var(--k-canvas);
    color: var(--k-text);
    font-family: var(--k-font-body);
    font-size: var(--k-fs-body);
    line-height: var(--k-lh-body);
  }
  h1,h2,h3 { font-family: var(--k-font-display); letter-spacing: -0.01em; }
  :focus-visible { outline: none; box-shadow: var(--k-focus-ring); border-radius: var(--k-r-chip); }
  .numeric { font-variant-numeric: tabular-nums; }
  @media (prefers-reduced-motion: reduce) { html { scroll-behavior: auto; } }
}
```

## 4. Theming contract

- Theme is a **single attribute**: `<html data-theme="light|dark">`.
- Default follows `prefers-color-scheme`; a user setting overrides and persists.
- Switching theme touches **zero** components — only the attribute.
- Direction swap (D2↔D5↔D1) replaces the token blocks only.

## 5. Performance wiring

- Route-level code splitting (`React.lazy`) per feature folder.
- Fonts: preload only hero weights for the active locale; per-script stacks via
  `:lang()` (already in tokens).
- Lists > 30 rows: virtualise (e.g. TanStack Virtual) **before** applying motion.
- Images: `srcset` with the 4:5/1:1/16:9 derivatives; LQIP placeholders.

## 6. Accessibility wiring

- One `<main>` per route; skip link first in `<body>`.
- Live regions centralised in `components/ui/Toast.tsx`.
- Focus management on route change moves to the `<h1>`.
- Every interactive element ≥44 px via `min-h-touch` utility.

## 7. Definition of done (frontend)

- [ ] Components reference tokens only — a grep for `#` hex in
      `components/` returns nothing.
- [ ] Light + dark verified per component.
- [ ] 320 px width verified per screen.
- [ ] Reduced-motion verified per animated component.
- [ ] Every domain component has loading/empty/error/success states.
- [ ] Every protected action re-checked server-side.
