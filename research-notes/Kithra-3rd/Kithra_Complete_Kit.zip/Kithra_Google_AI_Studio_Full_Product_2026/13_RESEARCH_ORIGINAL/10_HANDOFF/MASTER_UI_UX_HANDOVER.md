# MASTER UI/UX HANDOVER

**Can this be implemented without guessing about colours, fonts, screen
behaviour, photos, motion, admin permissions or empty states?** Yes — every one
of those is pinned below, with the exact file.

---

## 1. Read order for an engineer

1. `00_START/README_AND_EXECUTIVE_DECISIONS.md` — scope + decisions.
2. `00_START/FILE_INVENTORY_AND_CONFLICTS.md` — what is superseded.
3. `03_BRAND/design-tokens.json` + `design-tokens.css` — the system.
4. `05_USER_UX/*` — screens, flows, states.
5. `06_ADMIN/*` — staff console + RBAC.
6. `07_MOTION/*` — animation.
7. `10_HANDOFF/DEVELOPER_COMPONENT_CONTRACTS.md` — API/perm contracts.

## 2. Colour — fully pinned

Use **only** the tokens in `design-tokens.css`. Light and dark values are fixed;
mode accents are fixed; the clay accent (`--k-accent`) is **decoration only**,
use `--k-accent-text` for text. Contrast is pre-verified (light and dark).

## 3. Typography — fully pinned

Fraunces (display) + Inter (body), Noto Sans per-script for Indic. Scale,
measure, weights and fallback stacks are in the tokens and
`03_BRAND/FONT_RESEARCH.md`. Load 2 Latin families + one Indic family per
active locale; metric-matched fallbacks required.

## 4. Touch targets & states

≥44 px effective targets; focus ring = `--k-focus-ring`; every interactive
element defined for default/hover/active/focus/disabled/loading/error.

## 5. Stack constraints (unchanged from the kit)

React 19 + TypeScript (strict) + Vite + Tailwind (CSS-first tokens) + Motion for
React. Cloudflare (Workers/Hono/D1/R2/DO/Queues) **and** portable
Node/Postgres/Redis/Docker/Caddy parity. Firebase identity adapter retained.
**No AI runtime. No LLM matching. No inference billing.** This UX work does not
authorise replacing infrastructure.

## 6. Photo pipeline

Client downscale → signed PUT to **private** R2 → ingest (type/size/AV/
moderation) → **server-side EXIF strip** → derivatives (4:5 / 1:1 / 16:9) →
signed GET scoped to viewer authorization → access logged. No public URLs.

## 7. Motion

`motion/react` only; budgets and per-screen triggers in
`07_MOTION/MOTION_FOR_REACT_COMPLETE_MATRIX.md`; reduced motion mandatory.

## 8. Admin

Separate surface; deny-by-default RBAC; MFA mandatory; JIT case-scoped evidence;
hash-chained audit; no raw quiz access by default.

## 9. What is explicitly NOT included

- No AI twins/LLM matching (removed).
- No mode-based subscription silos (removed).
- No E2EE claim, no biometric-ID claim, no guaranteed-outcome claim.
- No fabricated testimonials, member counts or success statistics.

## 10. Honest status of this package

- **Research + design + specs:** delivered (this folder).
- **Running app / Figma file / deployed site:** **not** delivered.
- **Brand tokens:** provisional pending founder sign-off (D2 recommended).
- **Legal:** dependencies listed for counsel; no compliance claimed.
- **Visuals:** original mock tiles in `11_VISUALS/`; label proposed vs implemented.
