# DEVELOPER COMPONENT CONTRACTS

Component inventory with: props, states, a11y, and required API/perm. Every
component consumes design tokens only — no hard-coded colour or size.

## Primitives

| Component | Props | States | A11y | API |
|---|---|---|---|---|
| `Button` | `variant(primary/secondary/ghost/danger)`, `size`, `loading`, `disabled`, `iconStart` | default/hover/active/focus/disabled/loading | `<button>`, `aria-busy` when loading | — |
| `Input` | `label`, `hint`, `error`, `type`, `autocomplete` | default/focus/error/disabled | `<label for>`, `aria-describedby`, `aria-invalid` | — |
| `Checkbox` | `checked`, `indeterminate`, `label`, `required` | default/focus/checked/disabled | never pre-check consent | — |
| `Select`, `SegmentedControl` | `options`, `value` | — | keyboard roving tabindex | — |
| `Card` | `elevation`, `as` | — | — | — |
| `Modal` / `Sheet` | `open`, `onClose`, `title` | — | focus trap, Esc, `role=dialog`, returns focus | — |
| `Toast` / `LiveRegion` | `kind`, `message` | — | `aria-live` polite/assertive | — |
| `Skeleton` | `shape`, `lines` | — | `aria-busy` on parent, no shimmer under reduced motion | — |
| `Avatar` | `src|initials`, `size`, `blur` | loaded/fallback/processing | alt text or `aria-hidden` + label | signed GET |

## Domain components

| Component | Props | Required API | Permission |
|---|---|---|---|
| `ModeChip` | `mode` | — | — |
| `ModeSwitcher` | `activeModes`, `onChange` | `GET /v1/me` | per-mode consent |
| `ConsentBlock` | `purpose`, `noticeVersion`, `onGrant` | `POST /v1/me/modes` | — |
| `QuestionItem` | `item`, `value`, `onAnswer`, `onSkip` | `PUT /v1/quiz/attempts/{id}/answers` | quiz consent |
| `QuizProgress` | `answered`, `total`, `coverage` | — | — |
| `PatternDimension` | `label`, `value`, `coverage`, `onWithdraw` | `GET/DELETE /v1/patterns/me` | owner only |
| `MatchCard` | `candidate`, `band`, `coverage`, `lens` | `GET /v1/discovery?mode=` | eligibility gate |
| `MatchExplanation` | `dimensions`, `frictions`, `modelVersion`, `coverage` | `GET /v1/matches/{id}/explanation` | mutual consent |
| `RequestButton` | `personaId`, `quotaLeft` | `POST /v1/introductions` | rate-limited |
| `MessageThread` | `conversationId` | `GET/POST /v1/conversations/{id}/messages` | member only |
| `SafetyMenu` | `subjectId`, `mode` | `POST /v1/blocks`, `POST /v1/reports` | **free, all tiers** |
| `PhotoUploader` | `mode`, `max`, `onDone` | signed PUT + `POST /v1/media` | media enabled flag |
| `PhotoCropper` | `aspect(4:5)`, `onCrop` | — | — |
| `PlanCard` | `plan`, `term` | `GET /v1/plans` | — |
| `CancelFlow` | `subscriptionId` | `POST /v1/subscriptions/{id}/cancel` | owner + reauth |
| `RightRequestForm` | `type(export/delete)` | `POST /v1/rights/{type}` | reauth |

## Admin components (deny-by-default)

| Component | Required API | Permission |
|---|---|---|
| `CaseQueue` | `GET /v1/admin/cases` | `cases.list` + scope |
| `CaseDetail` | `GET /v1/admin/cases/{id}` | `cases.read` |
| `EvidencePanel` | `POST /v1/admin/cases/{id}/evidence-access` | `cases.evidence.read_sensitive` (JIT + approval) |
| `AuditTimeline` | `GET /v1/admin/audit` | `audit.read` |
| `RoleEditor` | `POST /v1/admin/invitations`, `POST /v1/admin/staff/{id}/role` | `staff.role.grant` (2-person) |
| `RefundPanel` | `POST /v1/admin/payments/{id}/refund` | `billing.refund.limited|high_value` |
| `QuestionBankEditor` | `POST /v1/admin/question-banks` | `questionnaire.publish` + psychometric reviewer |

## Folder architecture guidance

```
src/
  app/            routes, providers, theme
  components/ui/  primitives (tokens only)
  components/     domain components above
  features/       discover, quiz, match, messages, circles, billing, admin
  lib/api/        typed clients generated from OpenAPI
  lib/permissions/ server-mirrored permission checks (UI hints only)
  styles/         design-tokens.css import + Tailwind layer
```

**Rule:** the client never enforces authorization — it only *hints*. Every
protected action is re-checked server-side (the kit's security contract).

## Contract test expectations

- Every component renders in light + dark, at 320 px, with reduced motion.
- Every domain component has explicit loading/empty/error/success states.
- Every list >30 rows virtualises before animating.
