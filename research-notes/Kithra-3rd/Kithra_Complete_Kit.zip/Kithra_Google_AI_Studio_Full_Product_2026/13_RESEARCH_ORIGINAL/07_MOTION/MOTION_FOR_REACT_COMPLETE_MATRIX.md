# MOTION FOR REACT — COMPLETE MATRIX

**API note.** Uses the current `motion/react` package (`import { motion,
AnimatePresence, useReducedMotion } from "motion/react"`). The legacy
`framer-motion` package is **not** shipped alongside; the kit's FRS already
warns against shipping both. Presets extend the kit's
`09_SCAFFOLDS/contracts/motion-presets.ts`.

**Motion budget (hard limits).**
- UI transitions ≤ 220 ms; hero ≤ 520 ms; micro ≤ 140 ms; admin ≤ 140 ms.
- Max **one** hero-scale animation per page.
- No scroll-jacking. No autoplay loops. No flashing (>3 Hz forbidden).
- **Urgent safety actions are never delayed by animation.**
- Long lists are virtualised; stagger is capped (≤ 8 items animate, rest appear).

---

## 1. Screen-by-screen inventory

| # | Screen / element | Trigger | Duration | Easing / spring | Stagger | Enter → Exit | Reduced-motion alternative |
|---|---|---|---|---|---|---|---|
| 1 | Landing hero headline | mount | 520 ms | `ease-enter` | 40 ms/line | fade + 8 px rise → none | static fade (120 ms) or none |
| 2 | Hero photograph | mount (after H1) | 520 ms | `ease-enter` | — | fade + 12 px → none | static |
| 3 | Relationship-map glyph | mount (once) | 600 ms | `ease-standard` | line draw | path draw → none | static drawn |
| 4 | Mode cards | scroll-into-view (once) | 220 ms | `ease-standard` | 60 ms | rise 12 px + fade → none | static |
| 5 | How-it-works stepper | scroll-into-view | 220 ms | `ease-standard` | 60 ms | line draw left→right | static |
| 6 | Interactive demo node | hover/tap | 200 ms | `ease-standard` | — | scale 1→1.03 + label reveal | label toggles instantly |
| 7 | Pricing card focus | focus/hover | 140 ms | `ease-standard` | — | border + shadow | same (non-motion) |
| 8 | FAQ accordion | toggle | 200 ms | `ease-standard` | — | height auto (layout) | instant open |
| 9 | Auth form validation | error | 140 ms | `ease-standard` | — | fade + 4 px shake (≤1×) → none | static error text |
| 10 | Auth → app transition | route change | 220 ms | `ease-enter` | — | fade through | none |
| 11 | Mode select card | select | 200 ms | spring `layout` | — | scale + check icon | instant state |
| 12 | Quiz question change | next/prev | 200 ms | `ease-standard` | — | slide 16 px in direction of travel | fade or instant |
| 13 | Quiz progress bar | answer | 200 ms | `ease-standard` | — | width tween | width instant |
| 14 | Pattern results reveal | scored | 220 ms | `ease-standard` | 50 ms | dimension rows rise | all visible |
| 15 | Match card list | data load | 220 ms | `ease-standard` | 40 ms (cap 8) | fade + rise | instant |
| 16 | Match explanation expand | tap | 200 ms | `ease-standard` | — | height auto | instant |
| 17 | Photo gallery / carousel | swipe | 220 ms | `ease-standard` / drag | — | slide | instant |
| 18 | Photo upload progress | upload | live | linear | — | ring fill | percentage text only |
| 19 | Modal / dialog | open | 180 ms | `ease-enter` | — | scale .98→1 + fade; backdrop fade | instant |
| 20 | Drawer / sheet | open | 180 ms | `ease-enter` | — | slide from edge | instant |
| 21 | Toast | show | 140 ms | `ease-enter` | — | slide + fade | instant, auto-dismiss |
| 22 | New message arrival | message | 140 ms | `ease-standard` | — | fade + rise 4 px | instant |
| 23 | Notification badge | count change | 140 ms | `ease-standard` | — | scale pulse (once) | static |
| 24 | Admin queue row update | data | 140 ms | `ease-standard` | — | background flash (subtle) | static |
| 25 | Admin drawer | open | 180 ms | `ease-enter` | — | slide | instant |
| 26 | Admin SLA timer | tick | none | — | — | static text | static |

**Parallax policy:** allowed **only** where it aids comprehension (e.g. the hero
photograph at ≤8 % offset, disabled on mobile and under reduced motion). No
parallax on text.

---

## 2. Component patterns (verified APIs)

```tsx
// Hero: mount-only, reduced-motion aware
import { motion, useReducedMotion } from "motion/react";

const EASE_ENTER = [0.16, 1, 0.3, 1] as const;

export function HeroHeading({ children }: { children: React.ReactNode }) {
  const reduce = useReducedMotion();
  return (
    <motion.h1
      initial={reduce ? { opacity: 0 } : { opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: reduce ? 0.12 : 0.52, ease: EASE_ENTER }}
    >
      {children}
    </motion.h1>
  );
}
```

```tsx
// List with capped stagger (long lists stay performant)
import { motion } from "motion/react";
const CAP = 8;
export function MatchList({ items }: { items: { id: string }[] }) {
  return (
    <ul role="list">
      {items.map((it, i) => (
        <motion.li
          key={it.id}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.22, delay: Math.min(i, CAP) * 0.04 }}
        >
          {/* row */}
        </motion.li>
      ))}
    </ul>
  );
}
```

```tsx
// Quiz: directional slide
import { AnimatePresence, motion } from "motion/react";
export function QuizStep({ step, direction, children }:
  { step: number; direction: 1 | -1; children: React.ReactNode }) {
  return (
    <AnimatePresence mode="wait" initial={false}>
      <motion.div
        key={step}
        initial={{ opacity: 0, x: 16 * direction }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -16 * direction }}
        transition={{ duration: 0.2, ease: [0.2, 0.7, 0.2, 1] }}
      >
        {children}
      </motion.div>
    </AnimatePresence>
  );
}
```

*(These patterns use documented `motion/react` APIs — `motion`, `AnimatePresence`,
`useReducedMotion`, `transition` with `ease`/`delay`. They are written to be
tested in the project; they are not claimed as already-shipped code.)*

---

## 3. What to avoid (documented)

- Full-page slide transitions between routes (damages perceived speed).
- Animating layout in long lists without virtualisation.
- Parallax on text; scroll-jacking; autoplay carousels.
- Motion on safety-critical confirmations, report submission, or block actions.
- More than one hero-scale animation per page.
