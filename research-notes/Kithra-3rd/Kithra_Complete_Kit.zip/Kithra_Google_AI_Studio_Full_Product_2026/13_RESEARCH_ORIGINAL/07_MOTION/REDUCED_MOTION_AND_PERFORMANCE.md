# REDUCED MOTION & PERFORMANCE

## 1. Reduced-motion contract

Kithra honours `prefers-reduced-motion: reduce` at three levels:

1. **Token level** (already in `design-tokens.css`): all `--k-dur-*` collapse to
   0 ms and a global `transition/animation-duration: 0.001ms` override applies.
2. **Component level:** `useReducedMotion()` gates every non-essential animation;
   only ≤120 ms opacity fades remain permitted (orientation, not decoration).
3. **Content level:** any information conveyed by motion is also conveyed
   statically (e.g. the relationship map renders its final state).

**Never** disable, delay or gate a safety action behind motion. Report, block
and cancel are instant regardless of motion settings.

## 2. Reduced-motion matrix

| Element | Full motion | Reduced motion |
|---|---|---|
| Hero headline/photograph | fade + rise, 520 ms | static (or 120 ms fade) |
| Relationship map | line draw | final state, static |
| Mode/match cards | staggered rise | all visible |
| Quiz transitions | directional slide 200 ms | instant swap |
| Modal/drawer | scale/slide 180 ms | instant |
| Toasts | slide 140 ms | static, auto-dismiss |
| Parallax | ≤8 % hero | off |
| Admin flash | subtle bg | off |

## 3. Performance budget & rules

- **LCP** ≤ 2.5 s mid-range Android; **CLS** ≤ 0.1 (metric-matched font
  fallbacks, explicit media dimensions); **INP** ≤ 200 ms.
- Initial JS ≤ 180 KB gz; LCP image ≤ 120 KB; fonts preloaded = hero weights
  only, `font-display: swap`.
- Animate **transform and opacity only**; avoid layout-affecting properties
  (width/top/height) except inside `layout` with small lists.
- **Virtualise** any list > 30 rows (Discover, Inbox, all admin queues) before
  applying stagger.
- Cap stagger at 8 animated items; the remainder render immediately.
- Pause/abort animations on route change; no orphaned timers.
- Test on a throttled 4× CPU profile; motion must not push INP over budget.

## 4. Mobile-specific

- Disable parallax and heavy blur on low-end devices (`deviceMemory`/reduced
  motion heuristics); keep shadow elevation instead of animated elevation.
- Image carousels: preload adjacent image only.

## 5. Acceptance criteria

- [ ] All animations respect `prefers-reduced-motion`.
- [ ] No animation blocks an urgent action.
- [ ] CLS ≤ 0.1 with fonts and images.
- [ ] Long lists virtualised before stagger.
- [ ] INP ≤ 200 ms on throttled mobile.
- [ ] No animation exceeds the motion budget in §1 of the matrix doc.
