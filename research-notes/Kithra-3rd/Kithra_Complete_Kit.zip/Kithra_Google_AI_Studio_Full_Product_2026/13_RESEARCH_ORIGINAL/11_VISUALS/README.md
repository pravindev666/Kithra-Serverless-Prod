# 11_VISUALS — index

All files here are **original work produced for this package**. Nothing is
copied from another company's app. Every file is labelled
**"proposed, not implemented"**.

| File | What it is |
|---|---|
| `01_FIVE_DIRECTIONS_TILES.html` | Side-by-side palette + hero + match-card tiles for **all five** directions, with **computed** contrast ratios. Open in a browser. |
| `01_FIVE_DIRECTIONS_TILES.png` | Rendered screenshot of the above (captured 2026-11-01). |
| `02_D2_SCREEN_MOCKUPS.html` | 9 tabbed high-fidelity mock screens under the recommended direction **D2**: landing, sign-in, mode picker, quiz, photo gallery, match detail, messaging, pricing, admin. Open in a browser. |
| `02_D2_SCREEN_MOCKUPS.png` | Rendered screenshot of the above (captured 2026-11-01). |

## Comparison set (required by the brief)

`01_FIVE_DIRECTIONS_TILES.html` shows the **same screen** (hero + a match card)
under D1–D5 so the decision is like-for-like. D4's coral is visibly flagged as
failing AA for normal text — a decision input, not a claim.

## Status honesty

- These are **static HTML mock-ups**, not a React implementation.
- They are **not** an approved brand; the founder sign-off gate is still open.
- No real member photographs are used. Photo areas are labelled placeholders.
- Admin sample case IDs are explicitly marked as invented for illustration.

## Rendering to PNG (optional)

If a headless browser is available, the HTML files can be screenshotted; if not,
they render in any browser. **No PNG render is claimed here unless a file is
present in this folder.**
