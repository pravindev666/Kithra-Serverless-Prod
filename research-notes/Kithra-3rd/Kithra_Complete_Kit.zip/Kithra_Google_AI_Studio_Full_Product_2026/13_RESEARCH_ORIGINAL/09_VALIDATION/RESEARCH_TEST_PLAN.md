# RESEARCH & VALIDATION TEST PLAN

**Ethics:** consenting adults only, 18+; informed consent; no deception beyond
standard first-impression methodology (which is disclosed post-test); data
minimised; participants may withdraw; no sensitive-trait inference tested.

---

## 1. Studies

| # | Study | Method | Participant sample (proposed) | Output |
|---|---|---|---|---|
| S1 | Qualitative interviews | moderated, 45 min | 20–30 per segment (India T1, India T2, intl.) | needs, fears, language |
| S2 | Task-based usability | moderated, think-aloud | 12–16 (mixed ability) | task completion, errors |
| S3 | Unmoderated usability | remote | 30–60 | completion, time, SUS |
| S4 | Accessibility sessions | screen-reader + keyboard | 6–10 disabled users | a11y defect list |
| S5 | Five-second first-impression | timed exposure | 60–120 | comprehension, recall |
| S6 | Palette preference test | 3–5 variants, blind order | 80–150 | preference + contrast notes |
| S7 | Hero message comprehension | 3 narratives (H-A/B/C) | 90–180 | which narrative wins |
| S8 | Mode-separation comprehension | scenario questions | 60–100 | confusion rate |
| S9 | Photo-privacy comprehension | scenario questions | 60–100 | what-is-visible accuracy |
| S10 | Quiz abandonment | instrumented prototype | 50–100 | fatigue curve |
| S11 | Pricing comprehension + fairness | comprehension + WTP | 40–60 | plan comprehension |
| S12 | Report-flow completion | task | 20–30 | time-to-report |

Sample sizes are **proposals** based on standard usability practice (5–8 per
round for qualitative; larger for attitudinal). They are not statistically
powered for population inference and this is stated in every report.

---

## 2. Metrics

Task completion rate · task time · error rate · mode-separation comprehension ·
match-meaning clarity · consent comprehension · photo-upload success ·
accessibility defect count · self-reported trust · sign-up completion ·
question-set completion · report-flow completion · plan comprehension ·
**repeat-contact intent** (never claimed as actual outcomes).

---

## 3. Anti-vanity rule

Do **not** optimise or report: session length, daily active streaks, swipe
volume, or message count as success. Kithra's north-star is **mutually confirmed
continued connection at day 30** (per mode), and safety metrics.

---

## 4. Limitations (stated in every report)

- Qualitative samples are not representative.
- Prototype testing ≠ production behaviour.
- Self-reported preference ≠ measured conversion.
- Indian and international samples must be analysed **separately**, not pooled.
