# DECISION THRESHOLDS

Thresholds are **proposals** for go/change/stop decisions. They are experiment
targets, not market benchmarks (the kit's own BRD states this).

| Decision | Metric | Threshold | If missed |
|---|---|---|---|
| Ship primary hero | 5-second comprehension | ≥70 % name ≥2 modes | iterate copy, retest |
| Freeze brand | preference + accessibility | top-2 on both | founder override with recorded reason |
| Ship mode model | mode-separation comprehension | ≥85 % correct | redesign switcher/consent copy |
| Ship score UI | match-meaning clarity | ≥85 % say "not a promise" | strengthen caveat + coverage display |
| Ship pricing | fairness comprehension | ≥85 % correct; 0 % believe best matches paywalled | redesign paywall |
| Ship quiz | completion ≥60 %; fatigue curve flat to ~60 items | below → shorten default set, raise gate |
| Ship sign-in | sign-up completion ≥70 % of starts | below → reduce fields / fix friction |
| Ship report flow | median ≤45 s; 100 % acknowledgement | below → simplify steps |
| Accessibility gate | 0 critical WCAG 2.2 AA defects | any → block release |
| Safety gate | 100 % of critical incidents acknowledged within policy SLA | any miss → pause launch |

## Go / Change / Stop rules (from the kit, retained)

- **GO to secured beta:** user demand + positive evidence of *safe repeat
  interactions* without exaggerated claims.
- **CHANGE matching:** questionnaire burden increases abandonment with no
  credible lift over a simple interests/availability baseline.
- **CHANGE niche:** no local active compatible density despite reasonable
  acquisition → narrower age/community/language pool.
- **STOP/PAUSE:** unmanaged abuse, inability to staff legal safety response,
  unmitigable privacy risks, or dependence on deceptive model explanation.

## Statistical caution

Small usability samples cannot prove population-level effects. Any quantitative
claim requires the appropriate powered study with pre-registration, and
confidence intervals — never a single point estimate presented as proof.
