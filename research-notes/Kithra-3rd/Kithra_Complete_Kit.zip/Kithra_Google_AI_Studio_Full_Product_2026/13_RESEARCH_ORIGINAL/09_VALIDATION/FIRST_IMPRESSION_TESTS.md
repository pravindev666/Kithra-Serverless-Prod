# FIRST-IMPRESSION TESTS

## 1. Five-second test (landing hero)

**Method.** Show the hero (headline + sub + one image) for exactly 5 seconds,
then hide it and ask: *What is this product? Who is it for? What can you do
next?* Disclose the time limit afterwards.

**What we measure:** correct identification of (a) three modes, (b) that it is
not solely a dating app, (c) the primary action.

**Pass threshold:** ≥70 % name at least two modes; ≥60 % identify a next action;
≤15 % mistake it for a purely romantic app.

## 2. Hero narrative head-to-head

Three narratives (H-A friendship-first, H-B "your kind of people", H-C three
journeys) tested blind, order randomised.

| Metric | H-A | H-B | H-C |
|---|---|---|---|
| Recall of "three modes" | high | med | high |
| Warmth rating | high | high | med |
| Mode-neutrality | low | high | high |
| SEO/feature clarity | med | med | high |

**Recommendation:** ship **H-B** as primary; keep H-C as an SEO landing variant;
keep H-A for a friendship-specific campaign page. Confirm by test.

## 3. Palette preference tests (blind)

Show the **same** mock screen under D1/D2/D3/D4/D5 (original mock tiles, no real
member data), order randomised, names hidden.

Collect: preference rank, warmth rating, trust rating, "feels for all three
modes?" rating, and free-text objections. Pairs with the **objective** contrast
data already computed (D2 and D5 lead on accessibility; D4's coral fails AA).

**Decision rule:** the winning direction must rank top-2 on both *preference*
and *accessibility*, or the founder overrides explicitly with a recorded reason.

## 4. Mode-separation comprehension

Scenario: *"Meera only enabled Friendship. Can her profile appear in
Matrimony?"* Measure correct answers.

**Pass threshold:** ≥85 % correct.

## 5. Photo-privacy comprehension

Show the photo-privacy screen; ask what a member of each mode can see.

**Pass threshold:** ≥80 % correct per mode; **0 %** should believe a photo can
be hidden from a mode it was enabled for.

## 6. Match-meaning clarity

Show a match card with "82% compared agreement · based on 68/100 answers".
Ask: *Does this mean the app is sure you'll be friends?*

**Pass threshold:** ≥85 % correctly say **no**; ≥70 % can explain what the
number describes.

## 7. Pricing fairness + comprehension

Ask: what is free? what does ₹149 add? can you cancel easily? is your best
match hidden behind payment?

**Pass threshold:** ≥85 % comprehension; **0 %** should believe best matches are
paywalled (that is the fairness test).

## 8. Report-flow

Time to complete a report from a match screen; confirm case id is shown.

**Pass threshold:** median ≤45 s; 100 % see an acknowledgement.
