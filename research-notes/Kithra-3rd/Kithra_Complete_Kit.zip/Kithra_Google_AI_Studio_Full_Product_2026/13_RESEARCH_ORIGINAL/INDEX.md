# KITHRA_UX_RESEARCH_REDESIGN_2026 — NAVIGATION INDEX

Start here → **`00_START/README_AND_EXECUTIVE_DECISIONS.md`**

```
00_START/       README_AND_EXECUTIVE_DECISIONS.md
                FILE_INVENTORY_AND_CONFLICTS.md / .csv
01_RESEARCH/    EVIDENCE_REGISTER.csv
                COMPETITOR_UX_MATRIX.md / .csv
                COMPETITOR_UX_MATRIX_DEEP_PASS.md   (22 services, 2 capture rounds)
                ACADEMIC_LITERATURE_REVIEW.md
                ANNOTATED_BIBLIOGRAPHY.md
                PINTEREST_DRIBBBLE_BEHANCE_MOODBOARD.md
                REDDIT_COMMUNITY_RESEARCH.md
                raw_captures/            (verbatim scrapling captures, 26 pages)
02_STRATEGY/    USER_PERSONAS_JTBD_CULTURAL_RESEARCH.md
                PERSONA_SCREEN_MAP.csv
                PALANTIR_TRANSFER_MATRIX.md
                PRICING_BIG_CAT_SMALL_CAT_DECISION.md
                FINANCIAL_MODEL_SCENARIOS.md   (computed, incl. break-even)
                ENTITLEMENT_MATRIX.csv
03_BRAND/       FIVE_VISUAL_DIRECTIONS.md  PALETTE_SCORECARD.csv
                FONT_RESEARCH.md  BRAND_RECOMMENDATION.md
                BRAND_STYLE_GUIDE.md
                ALTERNATIVE_TOKEN_SETS.md  (D5 + D1, light & dark, computed)
                design-tokens.json  design-tokens.css
04_LANDING/     LANDING_CONTENT_AND_MOTION_BLUEPRINT.md
                LANDING_SECTION_SPEC_TABLE.md
05_USER_UX/     SIGNIN_ONBOARDING_FULL_UX.md  PHOTO_MEDIA_SYSTEM.md
                COMPLETE_MEMBER_SCREEN_INVENTORY.md  USER_FLOWS.md
                WIREFRAMES_MEMBER.md
                SCREEN_TRACEABILITY.csv   (screen→API→perm→a11y→acceptance)
                UX_STATES_AND_ACCEPTANCE.csv
06_ADMIN/       ADMIN_DESIGN_AND_RBAC.md  CASE_MANAGEMENT.md
                ADMIN_SCREEN_INVENTORY.md  WIREFRAMES_ADMIN.md (12+sign-in)
07_MOTION/      MOTION_FOR_REACT_COMPLETE_MATRIX.md
                REDUCED_MOTION_AND_PERFORMANCE.md
08_SAFETY/      CONSENT_PRIVACY_ACCESSIBILITY_UX.md
                LEGAL_DEPENDENCIES_TO_REVIEW.md
09_VALIDATION/  RESEARCH_TEST_PLAN.md  FIRST_IMPRESSION_TESTS.md
                DECISION_THRESHOLDS.md
10_HANDOFF/     MASTER_UI_UX_HANDOVER.md
                DEVELOPER_COMPONENT_CONTRACTS.md
                TAILWIND_AND_ARCHITECTURE.md
                COMPONENT_STATE_MATRIX.csv
                FINAL_CHECKLIST.md
11_VISUALS/     README.md
                01_FIVE_DIRECTIONS_TILES.html / .png
                02_D2_SCREEN_MOCKUPS.html / .png
```

## The five final questions — answered in

1. What Kithra should feel like in 5 seconds → `03_BRAND/BRAND_RECOMMENDATION.md`
   + `04_LANDING/…BLUEPRINT.md` §2–3 + `09_VALIDATION/FIRST_IMPRESSION_TESTS.md`.
2. Strongest palette/font/photography → `03_BRAND/FIVE_VISUAL_DIRECTIONS.md`,
   `PALETTE_SCORECARD.csv`, `FONT_RESEARCH.md`.
3. What appears on every screen → `04_LANDING/`, `05_USER_UX/`, `06_ADMIN/`.
4. Which Motion for React effects help / hurt → `07_MOTION/`.
5. Palantir transfer → `02_STRATEGY/PALANTIR_TRANSFER_MATRIX.md`.
6. Big-cat/small-cat pricing → `02_STRATEGY/PRICING_BIG_CAT_SMALL_CAT_DECISION.md`.
7. Missing requirements → `08_SAFETY/`, `09_VALIDATION/`, `10_HANDOFF/FINAL_CHECKLIST.md`.
8. Implementable without guessing → `10_HANDOFF/MASTER_UI_UX_HANDOVER.md` +
   `DEVELOPER_COMPONENT_CONTRACTS.md` + `03_BRAND/design-tokens.*`.
