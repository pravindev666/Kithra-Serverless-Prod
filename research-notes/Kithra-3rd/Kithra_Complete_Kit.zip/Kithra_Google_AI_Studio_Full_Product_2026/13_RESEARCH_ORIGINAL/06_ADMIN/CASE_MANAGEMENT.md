# ADMIN CASE MANAGEMENT

Ops model for reports, moderation, appeals, privacy rights and finance. SLA
timers are **grounded in applicable law — to be verified by counsel**, never
invented.

> **Legal note (verify, do not assert).** Indian intermediary rules impose
> acknowledgement/removal timelines that have been amended over time; CERT-In
> directions reference **6-hour** incident reporting for specified incidents.
> The kit's own compliance doc (`05_SECURITY`) instructs re-checking current
> notified rules and platform classification before release. This document
> therefore expresses SLAs as **configurable policy** with the regulatory values
> marked *"confirm with counsel"*, rather than hard-coding an unverified number.

---

## 1. Case lifecycle

```mermaid
stateDiagram-v2
  [*] --> Open: report/ticket created
  Open --> Triaged: severity + queue assigned
  Triaged --> Investigating
  Investigating --> AwaitingEvidence
  AwaitingEvidence --> Investigating
  Investigating --> Actioned
  Investigating --> NoAction
  Actioned --> Appealed
  Appealed --> Upheld
  Appealed --> Reversed
  Actioned --> Resolved
  NoAction --> Resolved
  Upheld --> Resolved
  Reversed --> Resolved
```

**Rules:** immutable case id; acknowledgement always sent (`case id` + safety
guidance); reporter identity never disclosed to the reported party; adverse
actions require policy reason, affected data, actor, time, notification and
appeal rights; append-only action log.

---

## 2. Queues, priority, ownership

| Queue | Entry criteria | Priority | Owner |
|---|---|---|---|
| **Urgent safety** | NCII, impersonation, threats, stalking, minors, suspected trafficking | P0 | Trust & safety lead |
| **Moderation** | harassment, hate, spam, photo violations | P1 | Moderator |
| **Appeals** | contested actions | P1 | Independent reviewer |
| **Payments** | disputes, chargebacks, refunds | P2 | Finance operator |
| **Privacy rights** | export, rectify, delete, consent | P2 | Privacy officer |
| **Support** | access, help, non-safety | P3 | Support agent |

Assignment by **skill + scope + availability**; SLA clock starts at creation and
pauses only on documented "awaiting external party"; SLA values are
**configuration**, not code constants.

---

## 3. Evidence handling & chain of custody

- Evidence items are **case-scoped** references (photo id, message id, report
  text) — never bulk copies.
- Access to `cases.evidence.read_sensitive` is **JIT**: purpose recorded,
  supervisor-approved, auto-expiring.
- Every read/write produces an **append-only, hash-chained** audit event.
- Redaction is applied by default; unredacted view is a distinct, justified,
  audited permission.
- Retention per schedule; legal holds are explicit, approved, time-bound.

```mermaid
flowchart LR
  R[Report] --> E[Evidence refs]
  E --> J[JIT access request]
  J --> S[Supervisor approval]
  S --> A[Access granted + purpose]
  A --> L[(Immutable audit log)]
  A --> D[Disposition]
```

---

## 4. Bulk actions

Allowed only with: a visible count, an **explicit confirmation** naming what
changes, a reason field, and audit capture. Bulk destructive actions require
2-person approval. **No silent bulk suspension.**

---

## 5. Emergency suspension

A documented, narrow path for credible imminent harm: suspend → notify per
policy → mandatory **retrospective review within a short window** → appeal
rights preserved. Emergency pathways **do not promise a live emergency service**
— public police/emergency resources are surfaced.

---

## 6. Appeals

- Reviewer **cannot be the original actioning officer** for critical cases.
- Structured disposition + outcome notification; reversal propagates to
  entitlements, access and any downstream effects.
- Appeal outcomes feed a **fairness monitor** (aggregate, de-identified).

---

## 7. Audit event structure (immutable)

```
audit_event {
  event_id, schema_version,
  actor_id, actor_role, actor_scope,
  action, target_ref (case/entity),
  reason_code, purpose_record_id,
  metadata_redacted (NO raw answers, NO message bodies),
  at (ISO-8601 UTC),
  prev_hash, hash       // hash chain for tamper-evidence
}
```
Exports are tamper-evident and access-controlled; auditors see de-identified
metrics by default.

---

## 8. Data-rights workflow (DPDP-shaped, verify timing)

Authenticated request → proportional identity re-verification → scope report →
legal-hold check → export/rectify/delete action → job trace → confirmation.
Self-service preferred; users are **not** forced to phone a line for routine
actions. Retention exceptions disclosed.

---

## 9. Acceptance criteria

- [ ] Unauthorized role cannot open an unassigned case (proven by test).
- [ ] Sensitive evidence requires JIT + approval + auto-expiry.
- [ ] Every case action is auditable and hash-chained.
- [ ] Reporter identity never leaks to the reported party.
- [ ] SLA values are configuration, not hard-coded, and cite counsel sign-off.
- [ ] Appeals by an independent reviewer.
- [ ] Bulk actions require confirmation + reason + audit.
