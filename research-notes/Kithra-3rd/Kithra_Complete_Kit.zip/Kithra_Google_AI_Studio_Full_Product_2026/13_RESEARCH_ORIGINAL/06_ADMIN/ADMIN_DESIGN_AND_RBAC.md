# ADMIN DESIGN & RBAC — separate staff console

**Entry is restricted to explicitly provisioned staff identities**, enforced by
server-side permissions and MFA. A "secret email and password" is **not**
security, and a URL secret is **not** authentication. Admin typography may share
the brand; density, navigation and motion optimise operational performance.

**Visual tone:** calm, light-first, data-dense but never a "command centre".
Explicitly banned: dark surveillance aesthetics, militaristic imagery, threat
iconography, and any persistent graph of member identities.

---

## 1. Admin sign-in (separate surface)

- Host: `admin.kithra.<tld>` only; **no public admin signup**.
- Steps: staff email → password → **mandatory MFA** (passkey/TOTP preferred,
  phishing-resistant where supported) → server checks staff account, role,
  status, session risk and scope.
- A persistent **environment banner** (`PRODUCTION` / `STAGING`) is always
  visible; production is visually distinct and cannot be mistaken for staging.
- Optional additional perimeter (e.g. Cloudflare Access) — documented, not
  relied upon as the sole control.
- Idle + absolute timeouts; **re-auth for privileged actions**; device/IP anomaly
  review; CSRF protection; session audit.

State machine:
```mermaid
stateDiagram-v2
  [*] --> Unauthenticated
  Unauthenticated --> MFARequired: valid staff password
  MFARequired --> Scoped: MFA verified + role/scope checked
  MFARequired --> Unauthenticated: MFA failed (rate-limited)
  Scoped --> ReauthRequired: privileged action
  ReauthRequired --> Scoped: reauth ok
  Scoped --> Locked: idle/absolute timeout
  Locked --> Unauthenticated
```

---

## 2. Roles and default permissions (deny-by-default)

| Role | Purpose | Default permissions | Explicitly NOT allowed |
|---|---|---|---|
| Platform owner | accountability | staff roster, policy oversight | **no default raw assessment reading** |
| Security lead | threat/incident | security events, credential resets, emergency suspension | browsing member profiles by default |
| Trust & safety lead | high-risk escalation | escalations, case decisions, **staffed** evidence access | raw quiz answers |
| Moderator | report triage | assigned **redacted** cases; warn/restrict within policy | unassigned cases; raw quizzes |
| Support agent | help/appeals intake | tickets, account state labels | raw messages by default |
| Privacy officer | rights | export/deletion/consent workflows | scoring keys |
| Finance operator | money | ledger, scoped refund limits | quiz content; entitlement edits |
| Research reviewer | instrument review | anonymised/consented aggregates | identifying member data |
| Community operator | Circles | circle moderation within assignment | global admin |
| Auditor | control evidence | read-only audit + de-identified metrics | member content |
| Infrastructure operator | deploy/health | service health | member content by default |

Permission namespace (examples): `cases.list`, `cases.assign`,
`cases.evidence.read_redacted`, `cases.evidence.read_sensitive`,
`cases.action.warn`, `cases.action.suspend`, `cases.action.permanent_ban`,
`staff.invite`, `staff.role.grant`, `privacy.export.approve`,
`privacy.delete.execute`, `billing.refund.limited`, `billing.refund.high_value`,
`questionnaire.publish`, `matching.release`, `audit.read`, `infra.deploy`.

**Rules:** all default deny; scope by queue/geography/mode/incident id; JIT for
sensitive evidence with supervisor approval + auto-expiry + purpose record;
**2-person approval** for critical grants; terminate on offboarding; quarterly
access review. **Staff cannot read raw questionnaire answers merely by becoming
superadmin.**

---

## 3. Layout & responsive patterns

- **Desktop:** 3-pane. Left nav 264 px → list pane → detail pane. Top bar with
  global search, environment banner, staff identity, SLA clock.
- **Tablet:** 2-pane; detail opens as a slide-over.
- **Mobile (ops on the move):** single column; sticky context bar; **progressive
  disclosure** — never a cramped desktop copy. Palantir-like density is bounded
  (36 px compact rows on desktop, 48 px touch rows on mobile).

**Motion:** minimal (`--k-dur-admin: 140ms`), state changes only; **no motion on
urgent safety actions**; drawers/sheets open ≤180 ms; reduced-motion → instant.

---

## 4. Accessibility & auditability

- Keyboard-first: every queue, filter and drilldown is fully operable; command
  palette for power users; visible focus.
- Every PII read is **audited** at appropriate granularity; audit events carry
  **redacted** metadata only (no raw answers, no message bodies).
- Linked views (select case → panels update) are keyboard-navigable and
  announce updates via live regions.
- Colour is never the sole severity signal — icon + label always.

---

## 5. Explicit refusals

- No unrestricted moderator access to intimate questionnaires.
- No member-identity surveillance graph.
- No fabricated dashboard numbers; every tile shows **owner + freshness**, and
  where data is not yet instrumented the tile says so.
