# ADMIN SCREEN INVENTORY (14 screens + sign-in)

Wireframe descriptors: `[L]` left nav · `[C]` list/centre · `[R]` detail/right.
Mobile = single column with sticky context bar. All screens keyboard-operable;
all lists virtualised for long sets.

| # | Screen | Layout (desktop) | Key components | Critical states |
|---|---|---|---|---|
| 0 | **Admin sign-in** | centered card | email → password → MFA; env banner | rate-limited, MFA-failed, locked |
| 1 | **Overview / health** | [L][C tiles][R alerts] | tiles each with **owner + freshness**; open urgent; % within SLA; median first response | empty (no cases), stale data flagged |
| 2 | **User Search & Profiles** | [L][C results][R profile] | case-scoped search; account state; **no raw quizzes** | no access, invisible target (404) |
| 3 | **Trust / Verification** | [L][C queue][R detail] | verification states; provider refs; self-declared vs verified | not-available (service off) |
| 4 | **Photo Moderation** | [L][C grid][R review] | approval/reject with reason; escalation to CSAM path | processing, held, rejected |
| 5 | **Reports & Urgent Safety** | [L][C queue][R case] | priority, SLA clock, assignment | conflicting action, stale evidence |
| 6 | **Anti-Spam / Fraud** | [L][C signals][R entity] | velocity/anomaly signals; **no shadow-bans without record** | signal-noise, false positive |
| 7 | **Messaging Abuse Evidence** | [L][C case][R evidence] | **JIT, justified, case-scoped** message refs | reauth required, access expired |
| 8 | **Circles & Events** | [L][C list][R detail] | circle review, membership, content policy | pending review, archived |
| 9 | **Assessments / Question Banks** | [L][C versions][R editor] | draft→review→publish→version pin; **psychometric reviewer required** | draft, in review, pinned, rolled back |
| 10 | **Matching / Scoring & Versioning** | [L][C versions][R audit] | scoring version release, rollback, fairness report | release blocked without sign-off |
| 11 | **Support Inbox** | [L][C tickets][R thread] | ticket states, canned replies, escalation | SLA breach warning |
| 12 | **Payments / Refunds** | [L][C ledger][R txn] | reconciliation; scoped refund; 2-person for high value | webhook failure, partial payment |
| 13 | **Subscriptions / Entitlements** | [L][C subs][R detail] | plan version immutability; entitlement grants | grace period, expired |
| 14 | **Staff / RBAC / Invitations** | [L][C staff][R roles] | invite, grant (2-person), revoke, quarterly review | pending approval, revoked |
| 15 | **Privacy / Consent / Data Requests** | [L][C requests][R job] | export/delete jobs, consent history, legal holds | job running, hold active |
| 16 | **Grievance Handling** | [L][C grievances][R detail] | statutory grievance queue + officer contact | pending officer assignment |
| 17 | **Compliance Reports** | [L][C reports][R export] | tamper-evident exports | unavailable |
| 18 | **Audit Logs** | [L][C events][R detail] | hash-chained events; redacted metadata | unverifiable chain (alert) |
| 19 | **Analytics** | [L][C charts][R controls] | **cohort-safe**; suppresses re-identifying small cohorts | insufficient data |
| 20 | **System Health** | [L][C services][R traces] | latency, errors, queue depth | degraded, outage |
| 21 | **Incident Response** | [L][C incidents][R timeline] | runbook, comms templates, CERT-In 6-hr path (verify) | open, contained, closed |
| 22 | **Feature Flags / Config** | [L][C flags][R audit] | no hardcoded toggles; every change audited | flag conflict |
| 23 | **Operational Settings / Appeals** | [L][C settings][R appeals] | SLA config, queue rules, appeal dispositions | invalid config |

---

## Indicative wireframe (screen 5 — Reports & Urgent Safety)

```
┌──────────────┬───────────────────────────┬──────────────────────────────┐
│ kithra admin │  Reports & Urgent Safety  │  KT-2041 · Impersonation     │
│ ──────────── │  [ All | Urgent | Mine ]  │  Severity: URGENT   SLA 03:12│
│ Overview     │  ───────────────────────  │  State: Investigating         │
│ Safety  (4)  │ ▸ KT-2041 Impersonation   │  Owner: Trust lead            │
│ Moderation   │   URGENT  ▸ 03:12   TL    │  ───────────────────────────  │
│ Appeals      │ ▸ KT-2040 Account safety  │  Evidence (case-scoped)       │
│ Accounts     │   HIGH    ▸ 1d 04h  MOD   │   · photo ref  ✔ redacted     │
│ Circles      │ ▸ KT-2039 Data deletion   │   · message refs (JIT)        │
│ Assessments  │   STD     ▸ 3d      PO    │  ───────────────────────────  │
│ Matching     │ ▸ KT-2038 Sub dispute     │  Actions: [Warn] [Restrict]   │
│ Billing      │   STD     ▸ 2d      FIN   │           [Suspend]* [Close]  │
│ Privacy      │                           │  * requires reason + approval │
│ Staff/RBAC   │                           │  ── Audit (append-only) ───── │
│ Audit        │                           │  12:04 assign → trust_lead    │
│ System       │                           │  12:06 evidence.view_redacted │
└──────────────┴───────────────────────────┴──────────────────────────────┘
```

## Acceptance criteria (admin)

- [ ] Every screen enforces deny-by-default permissions server-side.
- [ ] No screen surfaces raw questionnaire answers to any role by default.
- [ ] Every tile shows owner + freshness; uninstrumented data says so.
- [ ] Analytics suppresses re-identifying small cohorts.
- [ ] All actions append to the hash-chained audit log.
- [ ] Mobile = progressive disclosure, ≥44 px targets.
- [ ] No surveillance imagery, no persistent member graph.
