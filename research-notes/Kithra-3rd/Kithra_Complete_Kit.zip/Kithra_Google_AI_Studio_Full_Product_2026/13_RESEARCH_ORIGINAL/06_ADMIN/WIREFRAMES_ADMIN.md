# WIREFRAMES — 12 ADMIN SCREENS (+ sign-in)

Density: 36 px compact rows desktop, 48 px touch mobile. Light-first, calm.
`▓` = media, `▸` = row, `[ ]` = control. All actions audited. Deny-by-default.

---

## 0. Admin sign-in

```
┌──────────────────────────────────────────────┐
│            kithra admin   [PRODUCTION]       │
│  ┌────────────────────────────────────────┐  │
│  │ Staff email   [____________________]   │  │
│  │ Password      [____________________]   │  │
│  │ [ Continue ]                           │  │
│  │ MFA: passkey / TOTP (required)         │  │
│  │ ⓘ Provisioned staff only. No signup.   │  │
│  └────────────────────────────────────────┘  │
└──────────────────────────────────────────────┘
```

## 1. Overview / health

```
┌────────────┬──────────────────────────────────────────────┐
│ ▣ Overview │ [ All ▾ | Last 24h ]                         │
│ ⚑ Urgent 4 │ ┌─Urgent open─┐ ┌─Within SLA─┐ ┌─Privacy──┐ │
│ ≡ Moderation│ │ 4           │ │ 96%        │ │ 7       │ │
│ ◎ Appeals  │ │ trust · 12s │ │ ops · 30s  │ │ priv · 1m│ │
│ ◇ Accounts │ └─────────────┘ └────────────┘ └─────────┘ │
│ ◌ Circles  │ ┌─Median first human response──────────┐   │
│ ────────── │ │  38 min  (owner: ops · 45s ago)      │   │
│ Question   │ └──────────────────────────────────────┘   │
│ Matching   │ ⓘ Tiles without data are labelled "not      │
│ Privacy    │   yet instrumented" — never a fake number.  │
│ Billing    │                                              │
│ Staff/RBAC │                                              │
│ Audit      │                                              │
│ System     │                                              │
└────────────┴──────────────────────────────────────────────┘
```

## 2. User Search & Profiles

```
┌────────────┬──────────────────────────────────────────────┐
│            │ Search: [ KT-____ or @handle ]  [Scope: case]│
│            │ ┌──────────────────────────────────────────┐ │
│            │ │ ▸ A. K.  · active   · friend   · verified│ │
│            │ │ ▸ R. M.  · active   · dating   · self-dec│ │
│            │ │ ▸ S. N.  · restricted· —       · —       │ │
│            │ └──────────────────────────────────────────┘ │
│            │ RIGHT PANE: account state, consent log,      │
│            │ links to OPEN CASES only.                    │
│            │ ⛔ No raw questionnaire answers. Ever.        │
└────────────┴──────────────────────────────────────────────┘
```

## 3. Trust / Verification

```
┌──────────────────────────────────────────────────────────┐
│ Trust & Verification                                     │
│ [ Pending (12) | Verified | Rejected | Not available ]   │
│ ┌──────────────────────────────────────────────┐         │
│ │ ▸ A. K.  provider: —      status: self-decl. │         │
│ │ ▸ R. M.  provider: X      verified 12 Oct     │         │
│ │ ▸ S. N.  provider: X      pending            │         │
│ └──────────────────────────────────────────────┘         │
│ ⓘ If no verification service is running, the console     │
│   says "Not available" — it never fakes a badge.          │
└──────────────────────────────────────────────────────────┘
```

## 4. Photo Moderation

```
┌──────────────────────────────────────────────────────────┐
│ Photo Moderation  [ Pending 34 | Flagged 8 | Appeals 2 ] │
│ ┌────┐ ┌────┐ ┌────┐ ┌────┐                              │
│ │▓▓▓▓│ │▓▓▓▓│ │▓▓▓▓│ │▓▓▓▓│   ← grid, keyboard-navigable │
│ └────┘ └────┘ └────┘ └────┘                              │
│ Selected: [ Approve ] [ Reject ▾ reason ] [ Escalate ⚠ ] │
│ ⚠ CSAM path is separate and never in the general queue.  │
└──────────────────────────────────────────────────────────┘
```

## 5. Reports & Urgent Safety

```
┌──────────────┬───────────────────────────┬───────────────────┐
│ kithra admin │ Reports & Urgent Safety   │ KT-2041           │
│ ──────────── │ [All|Urgent|Mine]         │ Impersonation     │
│ Safety  (4)  │ ▸ KT-2041 URGENT ▸ 03:12  │ URGENT   SLA 03:12│
│ Moderation   │   Impersonation     TL    │ State:Investigating│
│ Appeals      │ ▸ KT-2040 HIGH  ▸ 1d 04h  │ Owner: Trust lead │
│ Accounts     │   Account safety    MOD   │ ── Evidence ──    │
│ Circles      │ ▸ KT-2039 STD   ▸ 3d      │  · photo ✔ redacted│
│              │   Data deletion     PO    │  · msgs (JIT req) │
│              │ ▸ KT-2038 STD   ▸ 2d      │ ── Actions ──     │
│              │   Sub dispute       FIN   │ [Warn][Restrict]  │
│              │                           │ [Suspend]* [Close]│
│              │                           │ * reason+approval │
│              │                           │ ── Audit ──       │
│              │                           │ 12:04 assign      │
│              │                           │ 12:06 ev.view_red │
└──────────────┴───────────────────────────┴───────────────────┘
```

## 6. Messaging Abuse Evidence (JIT)

```
┌──────────────────────────────────────────────────────────┐
│ Case KT-2041 · Evidence                                  │
│ ⚠ Sensitive access requires: reason + supervisor approval │
│ ┌──────────────────────────────────────────────────────┐ │
│ │ ▸ msg#812  08 Oct 21:14  [ redacted preview ]        │ │
│ │ ▸ msg#813  08 Oct 21:16  [ redacted preview ]        │ │
│ └──────────────────────────────────────────────────────┘ │
│ Reason: [____________________]  [ Request access ]       │
│ Grant auto-expires in 4h · every view is logged.         │
└──────────────────────────────────────────────────────────┘
```

## 7. Question bank governance

```
┌──────────────────────────────────────────────────────────┐
│ Assessments · Question Banks                             │
│ ┌──────────────────────────────────────────────────────┐ │
│ │ CONNECT-v1-setA   draft     80/100 authored          │ │
│ │ COMPASS-v1-setA   in_review 100 placeholder          │ │
│ │ SPARK-v1-setA     published 21 Oct  pinned  ✅       │ │
│ └──────────────────────────────────────────────────────┘ │
│ Pipeline: author → psychometric reviewer → privacy →     │
│           translation → staging → sign-off → publish     │
│ ⛔ A moderator cannot edit scoring keys.                  │
└──────────────────────────────────────────────────────────┘
```

## 8. Matching / scoring versioning

```
┌──────────────────────────────────────────────────────────┐
│ Matching · Scoring versions                              │
│ v1.2  live      released 12 Oct   fairness: reviewed     │
│ v1.1  retired   released 01 Sep                          │
│ v1.3  candidate BLOCKED — awaiting psychometric sign-off │
│ [ Release v1.3 ] [ Rollback to v1.1 ]                    │
│ ⓘ Every visible match logs its model version.            │
└──────────────────────────────────────────────────────────┘
```

## 9. Billing / Refunds

```
┌──────────────────────────────────────────────────────────┐
│ Payments & Refunds                                       │
│ ┌──────────────────────────────────────────────────────┐ │
│ │ Txn      Plan   Amt     Result      Refund           │ │
│ │ pay_881  Plus   ₹149    settled     [ Limited ]      │ │
│ │ pay_880  Con    ₹249    settled     [ Limited ]      │ │
│ │ pay_879  Plus   ₹1,399  chargedback [ High — 2PA ]   │ │
│ └──────────────────────────────────────────────────────┘ │
│ ⛔ Operators cannot edit original payment events.         │
│ Webhook is authoritative; redirect params never grant.    │
└──────────────────────────────────────────────────────────┘
```

## 10. Staff / RBAC

```
┌──────────────────────────────────────────────────────────┐
│ Staff & RBAC                                             │
│ ┌──────────────────────────────────────────────────────┐ │
│ │ Staff      Role            Scope        MFA          │ │
│ │ A. R.      Trust lead      cases:all    ✓ passkey    │ │
│ │ P. M.      Moderator       cases:queue1 ✓ totp       │ │
│ │ S. K.      Finance         billing      ✓            │ │
│ └──────────────────────────────────────────────────────┘ │
│ [ Invite staff ] [ Grant role* ] [ Revoke ]              │
│ * critical grants require 2-person approval              │
│ Quarterly access review due: 01 Feb                      │
└──────────────────────────────────────────────────────────┘
```

## 11. Audit trail

```
┌──────────────────────────────────────────────────────────┐
│ Audit trail            Chain status: ✅ verified          │
│ ┌──────────────────────────────────────────────────────┐ │
│ │ time     actor    action           target    reason  │ │
│ │ 12:06    a.r.     ev.view_redacted KT-2041   triage  │ │
│ │ 12:04    p.m.     case.assign      KT-2041   skill   │ │
│ │ 11:58    s.k.     refund.limited   pay_881   dup     │ │
│ └──────────────────────────────────────────────────────┘ │
│ Export (tamper-evident) — metadata redacted only.        │
└──────────────────────────────────────────────────────────┘
```

## 12. Privacy / Consent / Data requests

```
┌──────────────────────────────────────────────────────────┐
│ Privacy & Data Requests                                  │
│ [ Open 7 | Legal holds 1 | Completed ]                   │
│ ┌──────────────────────────────────────────────────────┐ │
│ │ ▸ EXP-220  export   running   due 02 Nov             │ │
│ │ ▸ DEL-118  delete   HOLD ⚖    basis: dispute         │ │
│ │ ▸ REC-044  rectify  done                            │ │
│ └──────────────────────────────────────────────────────┘ │
│ ⛔ Delete blocked while a lawful hold is active.          │
│ Self-service is preferred; users are not forced to phone.│
└──────────────────────────────────────────────────────────┘
```

---

## Responsive rule for all admin screens

Desktop 3-pane → tablet 2-pane (detail becomes slide-over) → mobile
single-column with sticky context bar. **Never** a cramped desktop copy. All
queues virtualised. All actions keyboard-reachable.
