# WIREFRAMES — ALL MEMBER SCREENS

ASCII wireframes at mobile (≤480) and desktop (≥1024). `▓` = image/photo,
`▤` = card, `▸` = list row, `[ ]` = control. Originals for Kithra.

---

## 1. Desktop shell (all authenticated screens)

```
┌────────────┬──────────────────────────────────────────────────────────────┐
│ kithra.    │ [ Friendship ▾ ]  Discover        🔔 3        (avatar) A. K.   │  ← top bar 56
├────────────┼──────────────────────────────────────────────────────────────┤
│ ◈ Overview │                                                               │
│ ◇ Discover │                                                               │
│ ◌ Patterns │                    CONTENT (max 1240)                         │
│ ♡ Matches  │                                                               │
│ ▤ Messages │                                                               │
│ ◎ Circles  │                                                               │
│ ─────────  │                                                               │
│ Assessments│                                                               │
│ Membership │                                                               │
│ Safety     │                                                               │
│ Settings   │                                                               │
│ (240px)    │                                                               │
└────────────┴──────────────────────────────────────────────────────────────┘
```

## 2. Mobile shell

```
┌──────────────────────────┐
│ kithra.   [Friend ▾]  🔔 │
├──────────────────────────┤
│                          │
│        CONTENT           │
│                          │
│                          │
├──────────────────────────┤
│ ⌂    ◇    ◎    ▤    ◉    │  ← bottom tabs ≥44px
│Home Disc Circ Msg Profile│
└──────────────────────────┘
```

---

## 3. Discover (the core screen)

```
DESKTOP                                              MOBILE
┌──────────────────────────────────────────┐   ┌────────────────────┐
│ Discover · Friendship                    │   │ Friendship ▾       │
│ Lens: (Echo) Counterpoint  Mosaic        │   │ (Echo) (Counter)  ›│
│ Band: ├────●────────┤ 70–79   ⓘ          │   │ Band 70–79  ⓘ      │
│ ┌──────┐ ┌──────┐ ┌──────┐               │   │ ┌────────────────┐ │
│ │▓▓▓▓▓▓│ │▓▓▓▓▓▓│ │▓▓▓▓▓▓│               │   │ │▓▓▓ 4:5 photo ▓▓│ │
│ │▓▓▓▓▓▓│ │▓▓▓▓▓▓│ │▓▓▓▓▓▓│               │   │ ├────────────────┤ │
│ ├──────┤ ├──────┤ ├──────┤               │   │ │A. K. · Chennai │ │
│ │A. K. │ │R. M. │ │S. N. │               │   │ │Warm...rhythm   │ │
│ │Warm… │ │Calm… │ │Dry…  │               │   │ │82% agreement   │ │
│ │82% 68│ │79% 54│ │76% 61│               │   │ │based on 68/100 │ │
│ └──────┘ └──────┘ └──────┘               │   │ └────────────────┘ │
│ ⓘ Agreement index, not a prediction.     │   │ ⓘ not a prediction │
└──────────────────────────────────────────┘   └────────────────────┘
```

**Rule:** every card carries band **+ coverage (n/100) + a caveat**. Coverage
below the gate hides the band and shows "not enough shared answers yet".

---

## 4. Match detail / "why you align"

```
┌─────────────────────────────────────────────┐
│ ← Back                    [Block] [Report]  │
│ ┌────┐  A. K. · Chennai                     │
│ │▓▓▓▓│  Friendship · [Echo · similar]       │
│ └────┘                                      │
├─────────────────────────────────────────────┤
│ Why you might connect                       │
│  • Similar communication pace               │
│  • Shared preferred activities              │
│  • Comparable availability                  │
│ Possible friction (neutral)                 │
│  • You plan weekends; they lean spontaneous │
│ Coverage  ████████████░░░░  68 / 100        │
│ Based on 68 of 100 comparable answers ·     │
│ model v1.2 — agreement, not a prediction.   │
│ What we have NOT measured:  ▸               │
├─────────────────────────────────────────────┤
│ [ Request an introduction ]                 │
└─────────────────────────────────────────────┘
```

---

## 5. Mode picker

```
┌──────────────────────────────────────────────┐
│ What are you here for?                       │
│ Choose one, two or all three.                │
│ ┌────────┐ ┌────────┐ ┌────────┐             │
│ │   ◌    │ │   ♡    │ │   ◇    │             │
│ │Friend  │ │Dating  │ │Matrim. │             │
│ │  ✓     │ │        │ │        │             │
│ └────────┘ └────────┘ └────────┘             │
│ ☐ I want my Friendship profile to be         │
│   discoverable by eligible members.          │
│   Enabling one mode never enables another.   │
│ [ Continue ]                                 │
└──────────────────────────────────────────────┘
```

---

## 6. Quiz item

```
┌──────────────────────────────────────────────┐
│ ████████░░░░░░░░  37/100 · ~12 min           │
│ Conversation & Conflict · item 37            │
│                                              │
│ When plans change at the last minute,        │
│ what helps you most?                         │
│                                              │
│ ○ A quick explanation and a new time         │
│ ○ Some space, then we re-plan together       │
│ ○ Just carry on without the plan             │
│ ○ It genuinely doesn't bother me             │
│ [Back]  [Skip]                 [Continue]    │
└──────────────────────────────────────────────┘
```

---

## 7. Photo gallery

```
┌──────────────────────────────────────────────┐
│ Your photos                                  │
│ Drag to reorder · each mode has its own set  │
│ ┌────────┐ ┌────────┐ ┌────────┐             │
│ │▓▓▓▓▓▓▓▓│ │▓▓▓▓▓▓▓▓│ │        │             │
│ │▓ 4:5 ▓▓│ │▓▓▓▓▓▓▓▓│ │   +    │             │
│ │▓▓▓▓▓▓▓▓│ │▓▓▓▓▓▓▓▓│ │ Add    │             │
│ │[Friend]│ │        │ │        │             │
│ └────────┘ └────────┘ └────────┘             │
│ ⓘ We discourage screenshots but can't        │
│   guarantee they're impossible elsewhere.    │
└──────────────────────────────────────────────┘
```

---

## 8. Messaging (with safety bar)

```
┌──────────────────────────────────────────────┐
│ ← A. K.                     [Friendship]     │
│ [Mute] [Block] [Report]                      │
├──────────────────────────────────────────────┤
│  A: Hi! Your activities list had hiking —   │
│     do you go often?                         │
│                    You: Most weekends when   │
│                    it isn't raining.         │
│  A: Same — trail near the lake if you ever   │
│     want a walking buddy.                    │
├──────────────────────────────────────────────┤
│ [ Message… ]                    [ Send ]     │
└──────────────────────────────────────────────┘
```

---

## 9. Pricing

```
┌──────────────────────────────────────────────┐
│ Fair, simple membership                      │
│ We never hide your most compatible people.   │
│ ┌────────┐ ┌──────────┐ ┌────────┐           │
│ │ Free   │ │  Plus    │ │Connect │           │
│ │ ₹0     │ │₹149/mo   │ │₹249/mo │           │
│ │        │ │RECOMMEND │ │        │           │
│ └────────┘ └──────────┘ └────────┘           │
│ Blocking & reporting are always free.        │
│ Cancel in one step · access to period end.   │
└──────────────────────────────────────────────┘
```

---

## 10. Report flow

```
Step 1        Step 2            Step 3         Step 4
┌────────┐   ┌──────────────┐  ┌──────────┐  ┌─────────────────┐
│What    │   │ Harassment   │  │ Add      │  │ Case: KT-2041   │
│happened│ → │ Impersonation│→ │ evidence │→ │ We'll review.   │
│  [▸]   │   │ Spam / scam  │  │(optional)│  │ Safety guidance │
└────────┘   └──────────────┘  └──────────┘  └─────────────────┘
```
Acknowledged with a case id **100% of the time**, free at every tier.

---

## 11–12. Common empty / error states

```
EMPTY (no matches yet)          ERROR (fetch failed)
┌───────────────────────┐      ┌────────────────────────┐
│  No matches in your   │      │  We couldn't load this.│
│  city for Friendship  │      │  [ Try again ]         │
│  yet.                 │      │  Code: DISC_503        │
│  We'll tell you when  │      └────────────────────────┘
│  that changes.        │
│  [ Join a Circle ]    │
└───────────────────────┘
```
**Never invent candidates.** Never show a stack trace.
