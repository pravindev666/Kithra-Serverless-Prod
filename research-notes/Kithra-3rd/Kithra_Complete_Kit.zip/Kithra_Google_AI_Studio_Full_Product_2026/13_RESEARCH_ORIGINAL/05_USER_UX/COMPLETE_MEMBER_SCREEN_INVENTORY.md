# COMPLETE MEMBER SCREEN INVENTORY

Every screen: purpose · layout · components · microcopy · states · a11y ·
motion · analytics. Naming follows the kit's vocabulary (Persona, Assessment,
Lens, Introduction, Circle, Case) but the UI uses plain language (Echo,
Counterpoint, Mosaic, My Patterns).

**Global shell**
- Desktop: left rail (icon+label) 240 px, top bar 56 px, content max 1240 px.
- Tablet: rail collapses to 72 px icons; top bar keeps mode switcher.
- Mobile: bottom tab bar (5: Home, Discover, Circles, Messages, Profile) +
  a top **mode switcher chip**.
- Mode switcher is **always visible** and shows active modes; switching never
  changes the account, only the visible context.

| # | Screen | Purpose / key components | Notable states |
|---|---|---|---|
| 1 | **Home** | Summary of all active modes; pattern progress; pending requests; next action | new / partial / all-modes-on / paused-mode |
| 2 | **Discover** | Candidate list in current mode; lens toggle (Echo/Counterpoint/Mosaic); band filter; why-shown line | loading skeleton / empty-waitlist / filtered-to-zero |
| 3 | **Search & Filters** | Region, age band, activity; advanced filters (Plus+) | none permitted / too-narrow |
| 4 | **Compatibility Compare** | Side-by-side of 2 members on shared dimensions; coverage shown | Connect-tier only |
| 5 | **Echo (similar)** | High-similarity list with per-dimension explanation | insufficient coverage |
| 6 | **Counterpoint (contrasting)** | Intentional contrasts, opt-in, neutrally framed | opt-in required |
| 7 | **Mosaic Fit (complementary)** | Predefined complementary pairings, mutual consent | "not evaluated" default |
| 8 | **Personality Profile ("My Patterns")** | Own derived dimensions; coverage; what is not measured; edit/withdraw | no data / low coverage / withdrawn |
| 9 | **Questions / Assessments** | Theme catalog; evidence status labels; time estimate | none published / draft only |
| 10 | **Questionnaire Progress** | Per-theme progress; save & resume; skip; withdraw | in-progress / paused / submitted |
| 11 | **Quiz item** | One item; progress; back; skip; save dot | offline queue / conflict (ETag) |
| 12 | **Results** | Banded summary with model version + coverage + caveat | not enough data |
| 13 | **Interests** | Optional interest tags (not a proxy for traits) | empty / limit reached |
| 14 | **Relationship Mode Switcher** | Enable/pause/close each mode with per-mode consent | last-mode guard |
| 15 | **Friendship mode** | Mode home: activity-led discovery, platonic boundary reminder | no local pool |
| 16 | **Dating mode** | Mode home: intent-clarity card, mutual-intent gate | orientation prefs opt-in |
| 17 | **Matrimony mode** | Mode home: life-plan compare, family-invite opt-in | family invited / not |
| 18 | **Connection Requests** | Incoming/outgoing; accept/decline; expiry | empty / expired / blocked |
| 19 | **Mutual Matches** | Accepted connections; conversation entry | none yet |
| 20 | **Inbox** | Conversation list; per-mode filter | empty |
| 21 | **1:1 Messaging** | Thread; attach (gated); report/block in header; retention note | offline / blocked / reported |
| 22 | **Group Chats** | Circle threads; @mentions; moderation controls | locked / archived |
| 23 | **Circles / Communities** | Browse, join, rules gate | invite-only |
| 24 | **Circle Creation** | Name, mode scope, visibility, rules; review status | pending review |
| 25 | **Notifications** | Grouped: safety, connections, circles, product | all read |
| 26 | **Profile Edit** | Per-mode persona fields; field-level visibility | unsaved / validation |
| 27 | **Photo Gallery** | Upload, crop, reorder, captions, privacy per mode | no photos / processing |
| 28 | **Privacy** | Consent dashboard; per-mode visibility; withdrawal | withdrawn state |
| 29 | **Safety** | Block list, mute, safety guidance, meeting tips | none blocked |
| 30 | **Reports / Block** | Report flow: category, evidence, submit, case id | submitted / under review |
| 31 | **Appeals** | Appeal status and outcome | none / pending / decided |
| 32 | **Subscriptions** | Current plan, entitlements, change | none / expiring |
| 33 | **Receipts** | Transaction history | empty |
| 34 | **Plan Change** | Upgrade/downgrade with exact proration shown | confirmation |
| 35 | **Cancel / Refund** | One-step cancel; refund request + policy | cancelled / refund pending |
| 36 | **Help / Support** | Ticket create + status; FAQ | open / resolved |
| 37 | **Accessibility / Language** | Language picker; reduced motion; text size; low-data mode | saved |
| 38 | **Export / Delete** | Data export; delete account with retention disclosure | job running / done |
| 39 | **Verification** | Only if a real service exists | not available (labelled) |

---

## Detailed specs for the highest-value screens

### 2. Discover (mode-scoped)
- **Purpose:** show eligible, consented candidates with an explanation.
- **Components:** mode chip, lens segmented control, band slider, candidate
  cards (`4:5` photo or monogram, display name, region, 1-line "why you might
  connect", band + coverage), empty-state prompt.
- **Microcopy (card):** *"Similar communication pace · shared preferred
  activities. Based on 68 of 100 comparable answers · model v1.2 — agreement,
  not a prediction."*
- **Hard rules (from the engine spec):** never show a blocked, ineligible or
  non-discoverable member; never show caste/religion as a ranking axis; never
  show another person's raw answers.
- **States:** loading (skeletons), empty (transparent waitlist + Circle
  suggestion), filtered-to-zero (explain which filter emptied it, offer reset),
  error (retry).
- **A11y:** cards are a list (`role="list"`); band is text, not colour; focus
  order = DOM order; filter changes announce result count.
- **Analytics:** `search`/`view_list`, `filter_change`, `card_impression`,
  `match_explanation_open`.

### 3. Match detail / "why you align"
- **Purpose:** explain the band honestly and give the CTA to request.
- **Shows:** top 3 shared dimensions (words), 1–2 neutral "possible friction"
  notes, coverage bar, `What we have not measured`, model version, block/report
  always visible.
- **Never:** other person's raw answers; a certainty claim; a hidden trait.
- **States:** coverage below gate → explanation suppressed with *"Not enough
  shared answers yet to explain this."*

### 8. My Patterns
- **Purpose:** the member's own picture, with control.
- **Components:** dimension list (ranked), each with a one-line description, a
  **confidence/coverage** indicator, and an **Edit/Withdraw** action; a visible
  **"What we don't measure"** block; a *"scores change when you change answers"*
  note.
- **Withdraw flow:** withdrawing removes derived snapshots and updates indexed
  candidates; the member is told what will change and when.

### 21. Messaging
- **Rules:** chat is possible **only after a mutual request is accepted**
  (unless a consented Circle policy allows group chat). No message previews on
  lock screens for Dating/Matrimony by default.
- **Header actions:** mute, block, report — all one tap, all free.
- **States:** sending (optimistic), sent, delivered, seen (only if the member
  enabled read receipts), failed (retry), blocked (composer disabled with
  explanation).
- **Evidence:** when a report is filed, only the **case-scoped** evidence is
  visible to an authorized operator (see admin), never to all moderators.

### 30. Report flow
- **Steps:** what happened → category → optional evidence → submit → **case id
  + safety guidance**. Acknowledgement always given.
- **Free at every tier, in every mode** — including after a block. This is
  non-negotiable (entitlement matrix rule 1).

### 35. Cancel / Refund
- **One step:** "Cancel renewal" → confirm → renewal stops; access continues to
  period end (stated). Refund request form with policy link; status tracking.
  No retention dark patterns, no "are you sure ×3".

---

## Cross-cutting acceptance criteria

- [ ] All 39 screens have explicit loading / empty / error / success states.
- [ ] Mode isolation proven by test on every screen that shows another member.
- [ ] Safety actions reachable in ≤2 taps from any member-visible surface.
- [ ] Every screen fully keyboard- and screen-reader-operable.
- [ ] Reduced-motion honoured everywhere.
- [ ] No screen claims a capability that is not implemented.
- [ ] Every derived score carries band + coverage + model version + caveat.
