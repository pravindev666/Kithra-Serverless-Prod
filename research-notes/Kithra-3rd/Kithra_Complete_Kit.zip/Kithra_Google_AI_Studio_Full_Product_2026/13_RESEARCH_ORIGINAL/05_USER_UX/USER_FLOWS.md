# USER FLOWS (Mermaid)

## F1 — Arrive → first value
```mermaid
flowchart TD
  A[Landing] --> B{Returning?}
  B -- yes --> C[Sign in]
  B -- no --> D[Create account]
  D --> E[Verify email]
  C --> F[Home]
  E --> F
  F --> G[Choose intentions 1..3]
  G --> H[Per-mode consent]
  H --> I[Persona basics per mode]
  I --> J[Quiz intro]
  J --> K[Answer items: save/resume/skip]
  K --> L{Coverage >= gate?}
  L -- yes --> M[Pattern summary + caveat]
  L -- no --> N[Ask for more / explain limits]
  M --> O[Discover in mode]
  N --> K
```

## F2 — Discover → mutual connection → chat
```mermaid
flowchart TD
  A[Discover] --> B[Open candidate]
  B --> C[Why you align + coverage]
  C --> D[Request introduction]
  D --> E{Receiver responds}
  E -- accept --> F[Chat authorised]
  E -- decline --> G[No contact; no notification of who]
  E -- expiry --> H[Request expires]
  F --> I[1:1 messaging]
  I --> J[At any point: block / mute / report]
  J --> K[Case created; safety preserved]
```

## F3 — Mode change / consent withdrawal
```mermaid
flowchart TD
  A[Mode switcher] --> B{Action}
  B -- enable --> C[Consent notice -> persona onboarding]
  B -- pause --> D[Removed from discovery; existing chats policy shown]
  B -- close --> E[Persona closed; derived snapshots scheduled for deletion]
  B -- withdraw answers --> F[Delete snapshots; invalidate match cache]
  F --> G[Tell member what changed and when]
```

## F4 — Upgrade / cancel
```mermaid
flowchart TD
  A[Pricing] --> B[Tier compare + what's always free]
  B --> C[Checkout signed webhook]
  C --> D[Entitlement granted from webhook only]
  D --> E[Receipt + next renewal date visible]
  E --> F{Cancel?}
  F -- yes --> G[One step: stop renewal; access to period end]
  F -- no --> H[Continue]
  G --> I[Refund request optional; policy shown]
```

## F5 — Report → case → appeal
```mermaid
flowchart TD
  A[Report] --> B[Category + optional evidence]
  B --> C[Case id + acknowledgement]
  C --> D[Queue triage by severity]
  D --> E[Human reviewer: case-scoped evidence only]
  E --> F{Disposition}
  F -- action --> G[Notify + appeal rights]
  F -- no action --> H[Close with reason]
  G --> I[Appeal -> independent reviewer]
```
