# PHOTO, PROFILE & MEDIA SYSTEM

Covers the upload experience, framing, privacy, moderation and the exact
frontend↔backend/R2 contract. No client-only privacy promises.

---

## 1. Photo steps in the member journey

1. **Add photos** (Profile → Photos). Skippable; a **no-photo path** exists and
   is first-class (see §6).
2. **Pick source:** `Take a photo` · `Choose from library` · drag-and-drop on
   desktop.
3. **Crop & frame:** default target **4:5 portrait** for primary cards, with a
   safe-frame overlay (a real "what will the card show" mask, not a blind crop).
   Rotate; free reposition; snap to a face-agnostic *thirds* guide.
4. **Order & captions:** drag to reorder; optional 1-line caption per photo;
   optional prompt attached to one photo.
5. **Review & confirm** → upload with progress.

**Aspect-ratio outputs generated server-side:**

| Use | Ratio | Export |
|---|---|---|
| Primary card | 4:5 | 1080×1350 |
| Thumbnail / grid | 1:1 | 320×320 |
| Header / banner | 16:9 | 1600×900 |
| Blurred preview (privacy/LQIP) | 1:1 | 16×16 upscaled |

---

## 2. Upload states (explicit)

| State | UI |
|---|---|
| Selecting | local preview, "nothing uploaded yet" |
| Compressing | local, e.g. "Optimising…" (client-side downscale) |
| Uploading | determinate progress ring, cancel available |
| Processing | "Checking your photo…" (server moderation) |
| Approved | photo appears in profile with caption |
| Rejected | reason + retry; never a silent drop |
| Offline | queued, "we'll upload when you're back online" |
| Failed | retry button + error code |
| Sensitive flagged | held for human review, member informed |

---

## 3. Resolution, compression & performance

- Recommend ≥1080 px on the short edge; warn (do not block) below 600 px.
- Client-side downscale to ≤2048 px and re-encode before upload to cut mobile
  data cost (matters on Indian 3G/4G).
- Server re-encodes to the export sizes above (never trust client formats).
- Low-data mode: skip non-primary images; serve 320 px first, upgrade on demand.

---

## 4. Privacy controls (mode-scoped)

- **Per-mode photo visibility.** A photo enabled for Dating is **never**
  auto-visible in Friendship or Matrimony. Each mode has: `public`,
  `matches-only`, `hidden`.
- **Private photos:** only viewable after a mutual connection grants access;
  access is logged.
- **Blur-until-approved:** privacy-conscious members can show a blurred avatar
  to non-connections.
- **No-photo path** (§6) exists so photos are never mandatory.
- **Screenshot risk is stated honestly:** *"We can discourage screenshots but
  can't guarantee they're impossible on someone else's device."* We do **not**
  promise impossible protection. (TrulyMadly/ Aisle-style screenshot deterrence
  is adopted as a *deterrent*, labelled as such.)

---

## 5. Verification states (only if actually supported)

`unverified` → `pending` → `verified` / `rejected` → `re-verify required`.
- The **verified badge is only rendered when a real verification service is
  running**. Until then no badge, no claim.
- Claims are labelled: `self-declared` vs `verified (provider, date)`.
- Never claim biometric/government-ID verification without a real, lawful,
  consented process.

---

## 6. No-photo / low-photo members

- Fallback = **initials monogram** on `--k-primary-subtle` (never a fake face,
  never a random stock portrait).
- Optional **illustrated avatar** set (abstract shapes, not people).
- Benefits stated honestly: "Members with a photo usually get more replies —
  but a photo is your choice."
- Moderation note: no-photo profiles raise impersonation risk, so text
  verification and a lower request cap apply until a photo or verification is
  added.

---

## 7. Frontend ↔ backend ↔ R2 contract

| Layer | Responsibility |
|---|---|
| Client | downscale, EXIF-strip attempt, request signed upload URL |
| API (Hono) | authz check, issue **short-lived signed PUT** to a **private** R2 bucket, record `media` row `state:'pending'` |
| Ingest worker | content-type verify, size limit, **AV scan**, image moderation queue, **strip EXIF/GPS server-side**, generate derivatives |
| R2 | **private bucket only**; **no public URLs ever**; all reads via short-lived signed GET |
| Reads | signed GET scoped to viewer authorization (mode + connection + visibility) |
| Logging | every media access logged (viewer, subject, time, purpose) |
| Deletion | unpublish → derivative removal → original removal on retention schedule |
| Restore | within retention window where technically feasible; documented |

**Truthfulness rules:** TLS + server-side encryption ≠ E2EE. No E2EE claim.
Client-side claims are avoided; all enforcement is server-side.

---

## 8. Moderation & content safety

- Automated scan → **human review queue** for nudity/violence/minors/CSAM
  escalation (CSAM goes to the designated escalation path, not the general
  queue).
- Member-facing: report a photo (free, always), request removal, block.
- Retention: rejected/original media removed per a **declared** schedule;
  moderation evidence retained only under lawful hold with access control.
- Public avatars: allowed only from the approved derivative set; no re-use of a
  member's private photos anywhere public.

---

## 9. Art direction (marketing & member cards)

- Natural light, unretouched, real texture (aligned with the "too hot to trust"
  evidence).
- Indian + international adults **interleaved**, not segregated into strips.
- Friendship = activity/group context; Dating = a good conversation; Matrimony
  = planning a life. **No bridal clichés; no forced intimacy; no fake
  testimonials.**
- Licensed or consented imagery only; illustrative imagery always captioned
  `Illustrative`.

---

## 10. Acceptance criteria

- [ ] Upload works on flaky 3G with resume/retry.
- [ ] 4:5/1:1/16:9 derivatives generated server-side.
- [ ] EXIF/GPS stripped server-side and verified.
- [ ] R2 bucket is private; a public URL is impossible.
- [ ] Mode-scoped visibility enforced by API, proven by test.
- [ ] Blurred preview available pre-approval.
- [ ] No-photo path fully functional.
- [ ] Screenshot copy is honest (deterrence, not guarantee).
- [ ] All media reads logged.
- [ ] Keyboard + screen-reader operable crop/reorder controls.
