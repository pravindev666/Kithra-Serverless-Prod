# SIGN-IN, ONBOARDING & IDENTITY UX — full specification

All screens specified for **desktop / tablet / mobile**. Firebase is treated as
an *integration to validate*, not a reason to skip UX. No fabricated social
buttons — the Google button is only rendered when the provider is configured.

---

## 1. Screen: Auth entry (desktop)

**Layout:** 12-col. Left 6 cols = **brand panel**; right 6 cols = **form card**.

**Brand panel (replaces the clichéd split-screen).**
- A single 4:5 photograph (same editorial set as landing), a short line:
  *"Understand your patterns. Meet people who make sense to you."*
- A rotating pair of **honest** facts (not testimonials):
  *"Your answers are private by default."* / *"Blocking and reporting are always
  free."*
- Never shows fake member counts.

**Form card (right).**
> **H1:** Welcome back
> **Sub:** Sign in to continue.
> `[ G  Continue with Google ]`
> `──── or ────`
> `[ Email address        ]`
> `[ Password    👁 ]`
> `[ Sign in ]`
> *Forgot password?*   ·   *New to Kithra? Create an account*

**States & microcopy**
| State | Message | Behaviour |
|---|---|---|
| Idle | — | autofocus email; `autocomplete="email"` |
| Invalid email | "Enter a valid email address." | inline, `aria-describedby`, red text + icon |
| Wrong credentials | "Email or password is incorrect." | generic (no account enumeration) |
| Rate-limited (429) | "Too many attempts. Try again in 60 s." | live region, countdown |
| Unverified email | "Verify your email — we sent a link to a***@mail.com." | resend, rate-limited |
| Suspicious login | "We blocked a sign-in from a new location. Was this you?" | email + in-app prompt |
| Provider failure | "Google sign-in is unavailable right now. Use email instead." | never a dead button |
| Session expired | "You've been signed out for security. Sign in again." | preserves intended route |
| Success | redirect to intended route or Home | |

**Mobile-first alternative (≤480 px).** No split screen: a compact 16:9
photographic band (≈140 px, LQIP) sits above the form; the form is the first
interactive paint; the brand panel facts move *below* the form. No decorative
onboarding slides before the form — a known friction source.

**Tablet (768–1023).** Form centred at max 420 px; photo becomes a slim top
banner rather than a half-screen panel (avoids a stranded half-image).

---

## 2. Screen: Create account

`[ Full name ]  [ Email ]  [ Password (strength meter, no shaming copy) ]`
`[ ] I'm 18 or older  (required, unchecked)`
`[ Create account ]`
`By continuing you agree to the Terms and Privacy Notice.`

- Password meter = neutral guidance ("add a number"), **not** a red "weak".
- Age gate is a real checkbox, unchecked; under-18 path routes to a clear
  "not yet eligible" screen, never a dark-pattern dead end.
- Exactly one primary CTA.

## 3. Screen: Verify email
> "Check your inbox — we sent a verification link to a***@mail.com."
> `[ Resend email (59s) ]` `[ Change email ]` `[ I've verified — continue ]`
States: sent / resend-limited / expired-link / already-verified.

## 4. Screen: Password reset
Request → *"If that email exists, we've sent reset instructions."* (no
enumeration) → Set new password (with show/hide, strength guidance) → Success →
Sign in. Errors: expired token, reused token, mismatch.

## 5. Optional phone verification (cost-aware)
- **Off by default.** Explicitly optional; explains *why* (recovery/trust) and
  the **SMS cost** implication honestly.
- Country code picker with search; E.164; OTP 6 digits; resend with backoff;
  abuse controls (per-number and per-IP rate limits); clear "didn't get it?"
  help. Only offered where a provider is contracted.

## 6. MFA (staff + optional members)
- TOTP and/or passkey where supported; **phishing-resistant preferred** for
  staff. Recovery codes shown once, downloadable. Enrolment is skippable for
  members, **mandatory** for admin (see `06_ADMIN/`).

## 7. Session, logout, deletion
- Idle timeout surfaced gently ("You've been inactive — sign in to continue").
- Logout everywhere; per-device session list.
- Delete account: explains exactly what is deleted vs retained (lawful holds),
  requires re-auth, offers export-before-delete, shows a job status.

---

## 8. Relationship-intent selection (the heart of Kithra)

> **H1:** What are you here for?
> **Sub:** Choose one, two or all three. Each stays private to itself — you can
> change this any time.

Three large toggle cards (icon + label + one line), each **independently**
activatable:
- **Friendship** — *"People for company, conversation and shared interests."*
- **Dating** — *"Meeting with clear, mutual romantic intent."*
- **Matrimony** — *"Serious, long-term partnership — family only if you invite
  them."*

**Rules baked into the UI:**
- Enabling one mode **never** enables another.
- Each mode shows a **separate consent line** (unchecked): *"I want my
  Friendship profile to be discoverable by eligible members in Friendship."*
- A persistent **mode switcher** shows which modes are on and lets a member
  pause/close each one independently.

```mermaid
stateDiagram-v2
  [*] --> SignedIn
  SignedIn --> IntentSelect
  IntentSelect --> ModeOnboarding: enable >=1 mode
  IntentSelect --> IntentSelect: enable/disable another
  ModeOnboarding --> QuizIntro
  QuizIntro --> QuizInProgress: start
  QuizInProgress --> QuizPaused: leave (save & resume)
  QuizPaused --> QuizInProgress: resume (same assignment)
  QuizInProgress --> Scored: submit
  Scored --> Discover: coverage gate passed
  Scored --> MoreQuestions: coverage below gate
  Discover --> [*]
  ModeOnboarding --> IntentSelect: back
```

---

## 9. Onboarding (progressive, value-before-commitment)

1. **Intent** (above).
2. **Public persona basics** (per mode): display name, region (coarse), one-line
   bio. *"You can change any of this later."*
3. **Photo step** — optional at onboarding; explicitly skippable; group-first
   alternative offered for privacy-conscious members (see `PHOTO_MEDIA_SYSTEM.md`).
4. **Quiz intro** — sets expectations honestly:
   > "About 12 minutes for this set. You can stop and come back — we'll remember
   > exactly where you were. Skipping is allowed; it just lowers how much we can
   > compare."
   Buttons: `Start` · `Do this later` · `Why questions?`
5. **First value moment** — after a minimum coverage threshold is met (proposal:
   ≥70% of the set's weight, **to be validated**), show the **pattern summary**
   with caveats, before demanding the full set.
6. **Welcome / empty state** — if there are no eligible matches yet:
   > "You're set up. There aren't enough people in your city for {mode} yet —
   > here's what we'll do: we'll tell you the moment that changes, and you can
   > join a themed Circle in the meantime."
   Never invent candidates.

**Save & resume:** server-assigned, version-pinned, idempotent; resuming shows
the *identical* item order (no reshuffle on back-navigation, locale switch or
retry).

---

## 10. Developer state contract (every auth/onboarding branch)

| Surface | loading | empty | error | success | permission |
|---|---|---|---|---|---|
| Sign in | button spinner | — | inline + live region | redirect | — |
| Sign up | button spinner | — | field-level + form-level | verify screen | age checkbox |
| Verify email | resend spinner | — | expired/limited | continue enabled | — |
| Intent select | — | "enable at least one mode" | save failed → retry | mode chip on | per-mode consent |
| Quiz intro | — | — | — | start | quiz consent |
| Quiz item | optimistic save dot | "no more items" | offline → queued save | saved check | per-item sensitivity |
| Scored | skeleton | "not enough data" | scoring failed → retry | summary + caveat | — |
| Discover | skeleton cards | transparent waitlist | fetch error | candidate list | eligibility gate |

**Error taxonomy** follows the kit's RFC-7807-style contract (400/401/403/404/
409/429/503) with a stable `code`, user-safe `title`, correlation id, and
`retry_after` where relevant — never a stack trace.

**Accessibility for every screen above:** labelled inputs, `aria-live` for
async messages, focus moved to the first error, visible focus rings, ≥44 px
targets, full keyboard operation, and no reliance on colour alone.
