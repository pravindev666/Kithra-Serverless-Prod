/** Pure, illustrative scoring reference. Not a validated psychological instrument. */
export type Dimension = { id: string; a: number | null; b: number | null; weight: number; min: number; max: number };
export function echoAgreement(dimensions: Dimension[]): { score: number | null; coverage: number } {
  const possible = dimensions.reduce((s, d) => s + Math.max(0, d.weight), 0);
  const comparable = dimensions.filter(d => d.a !== null && d.b !== null && d.max > d.min && d.weight > 0);
  const knownWeight = comparable.reduce((s, d) => s + d.weight, 0);
  if (possible <= 0 || knownWeight <= 0) return { score: null, coverage: 0 };
  const raw = comparable.reduce((s,d) => s + d.weight * (1 - Math.abs(d.a! - d.b!) / (d.max-d.min)), 0) / knownWeight;
  return { score: Math.max(0, Math.min(100, 100 * raw)), coverage: knownWeight / possible };
}
// IMPORTANT: Callers must impose min-coverage, eligibility/consent and version gates.
