-- Baseline relational model only; never use as final production migration without proper FK/constraints/review.
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  firebase_uid TEXT NOT NULL UNIQUE,
  email_hash TEXT NOT NULL UNIQUE,
  age_asserted_at TEXT,
  account_status TEXT NOT NULL DEFAULT 'active'
);

CREATE TABLE IF NOT EXISTS user_sessions (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  user_id TEXT NOT NULL,
  identity_session_id TEXT NOT NULL UNIQUE,
  revoked_at TEXT
);

CREATE TABLE IF NOT EXISTS user_modes (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  user_id TEXT NOT NULL,
  mode TEXT NOT NULL,
  status TEXT NOT NULL,
  consent_version TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS user_profiles (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  user_id TEXT NOT NULL,
  mode TEXT NOT NULL,
  display_name TEXT NOT NULL,
  region TEXT,
  bio TEXT,
  visibility TEXT NOT NULL DEFAULT 'private'
);

CREATE TABLE IF NOT EXISTS user_mode_preferences (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  user_id TEXT NOT NULL,
  mode TEXT NOT NULL,
  preferences_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS consent_events (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  user_id TEXT NOT NULL,
  mode TEXT,
  purpose TEXT NOT NULL,
  policy_version TEXT NOT NULL,
  granted INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS blocks (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  actor_id TEXT NOT NULL,
  target_id TEXT NOT NULL,
  reason_category TEXT
);

CREATE TABLE IF NOT EXISTS media_assets (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  owner_id TEXT NOT NULL,
  object_key TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL,
  mime TEXT,
  bytes INTEGER,
  primary_flag INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS media_visibility (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  media_id TEXT NOT NULL,
  mode TEXT NOT NULL,
  visibility TEXT NOT NULL DEFAULT 'private'
);

CREATE TABLE IF NOT EXISTS media_moderation (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  media_id TEXT NOT NULL,
  case_id TEXT,
  status TEXT NOT NULL,
  decision_by TEXT
);

CREATE TABLE IF NOT EXISTS question_banks (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  theme TEXT NOT NULL,
  edition TEXT NOT NULL,
  version TEXT NOT NULL,
  status TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS questions (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  bank_id TEXT NOT NULL,
  question_key TEXT NOT NULL UNIQUE,
  question_text TEXT,
  status TEXT NOT NULL DEFAULT 'placeholder'
);

CREATE TABLE IF NOT EXISTS question_translations (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  question_id TEXT NOT NULL,
  locale TEXT NOT NULL,
  text TEXT NOT NULL,
  review_status TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS scoring_versions (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  name TEXT NOT NULL,
  version TEXT NOT NULL UNIQUE,
  definition_json TEXT NOT NULL,
  status TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS assessment_sessions (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  user_id TEXT NOT NULL,
  mode TEXT NOT NULL,
  bank_id TEXT NOT NULL,
  scoring_version_id TEXT NOT NULL,
  seed_hash TEXT NOT NULL,
  state TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS assessment_answers (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  session_id TEXT NOT NULL,
  question_id TEXT NOT NULL,
  answer_json TEXT,
  skipped INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS pattern_scores (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  user_id TEXT NOT NULL,
  mode TEXT NOT NULL,
  scoring_version_id TEXT NOT NULL,
  coverage REAL NOT NULL,
  dimensions_json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS complementarity_rules (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  version_id TEXT NOT NULL,
  rule_key TEXT NOT NULL,
  predicate_json TEXT NOT NULL,
  status TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS match_results (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  user_a TEXT NOT NULL,
  user_b TEXT NOT NULL,
  mode TEXT NOT NULL,
  lens TEXT NOT NULL,
  score REAL,
  coverage REAL NOT NULL,
  scoring_version_id TEXT NOT NULL,
  explanation_json TEXT
);

CREATE TABLE IF NOT EXISTS connection_requests (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  from_user TEXT NOT NULL,
  to_user TEXT NOT NULL,
  mode TEXT NOT NULL,
  state TEXT NOT NULL,
  expires_at TEXT
);

CREATE TABLE IF NOT EXISTS conversations (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  mode TEXT NOT NULL,
  kind TEXT NOT NULL,
  state TEXT NOT NULL,
  next_sequence INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS conversation_members (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  conversation_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  state TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  conversation_id TEXT NOT NULL,
  sender_id TEXT NOT NULL,
  sequence INTEGER NOT NULL,
  message_kind TEXT NOT NULL,
  body_ciphertext_ref TEXT,
  removed_at TEXT
);

CREATE TABLE IF NOT EXISTS circles (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  owner_id TEXT NOT NULL,
  mode TEXT NOT NULL,
  name TEXT NOT NULL,
  visibility TEXT NOT NULL,
  state TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS circle_members (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  circle_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  role TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS circle_posts (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  circle_id TEXT NOT NULL,
  author_id TEXT NOT NULL,
  body_ref TEXT NOT NULL,
  state TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS notifications (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  user_id TEXT NOT NULL,
  kind TEXT NOT NULL,
  payload_ref TEXT,
  read_at TEXT
);

CREATE TABLE IF NOT EXISTS plans (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  code TEXT NOT NULL UNIQUE,
  version TEXT NOT NULL,
  currency TEXT NOT NULL,
  amount_minor INTEGER NOT NULL,
  period_months INTEGER NOT NULL,
  status TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS subscriptions (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  user_id TEXT NOT NULL,
  plan_id TEXT NOT NULL,
  provider_subscription_id TEXT UNIQUE,
  state TEXT NOT NULL,
  renewal_at TEXT
);

CREATE TABLE IF NOT EXISTS payments (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  user_id TEXT NOT NULL,
  provider TEXT NOT NULL,
  provider_payment_id TEXT NOT NULL UNIQUE,
  amount_minor INTEGER NOT NULL,
  state TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS webhook_events (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  provider TEXT NOT NULL,
  provider_event_id TEXT NOT NULL UNIQUE,
  event_hash TEXT NOT NULL,
  processed_at TEXT
);

CREATE TABLE IF NOT EXISTS refunds (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  payment_id TEXT NOT NULL,
  amount_minor INTEGER NOT NULL,
  state TEXT NOT NULL,
  reviewer_id TEXT
);

CREATE TABLE IF NOT EXISTS moderation_cases (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  subject_user_id TEXT,
  reporter_id TEXT,
  priority TEXT NOT NULL,
  state TEXT NOT NULL,
  assignee_id TEXT,
  due_at TEXT
);

CREATE TABLE IF NOT EXISTS reports (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  case_id TEXT NOT NULL,
  reporter_id TEXT NOT NULL,
  category TEXT NOT NULL,
  object_ref TEXT,
  state TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS case_evidence_grants (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  case_id TEXT NOT NULL,
  staff_id TEXT NOT NULL,
  reason TEXT NOT NULL,
  expires_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS appeals (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  case_id TEXT NOT NULL,
  appellant_id TEXT NOT NULL,
  state TEXT NOT NULL,
  decision_ref TEXT
);

CREATE TABLE IF NOT EXISTS support_tickets (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  user_id TEXT NOT NULL,
  category TEXT NOT NULL,
  state TEXT NOT NULL,
  assigned_to TEXT
);

CREATE TABLE IF NOT EXISTS grievances (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  user_id TEXT,
  category TEXT NOT NULL,
  received_at TEXT NOT NULL,
  due_at TEXT,
  state TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS privacy_requests (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  user_id TEXT NOT NULL,
  request_type TEXT NOT NULL,
  state TEXT NOT NULL,
  hold_reason TEXT
);

CREATE TABLE IF NOT EXISTS staff_memberships (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  identity_uid TEXT NOT NULL UNIQUE,
  staff_email_hash TEXT NOT NULL,
  state TEXT NOT NULL,
  mfa_assurance TEXT
);

CREATE TABLE IF NOT EXISTS role_grants (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  staff_id TEXT NOT NULL,
  role_name TEXT NOT NULL,
  scope_json TEXT NOT NULL DEFAULT '{}',
  expires_at TEXT
);

CREATE TABLE IF NOT EXISTS audit_events (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  actor_id TEXT NOT NULL,
  event_kind TEXT NOT NULL,
  resource_ref TEXT NOT NULL,
  reason TEXT,
  prev_hash TEXT,
  event_hash TEXT
);

CREATE TABLE IF NOT EXISTS outbox_events (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  event_kind TEXT NOT NULL,
  aggregate_ref TEXT NOT NULL,
  payload_ref TEXT,
  state TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS idempotency_keys (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  scope TEXT NOT NULL,
  dedupe_key TEXT NOT NULL,
  result_ref TEXT,
  expires_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_user_modes_lookup ON user_modes (user_id, mode);
CREATE INDEX IF NOT EXISTS idx_user_profiles_lookup ON user_profiles (user_id, mode);
CREATE INDEX IF NOT EXISTS idx_assessment_answers_lookup ON assessment_answers (session_id, question_id);
CREATE INDEX IF NOT EXISTS idx_pattern_scores_lookup ON pattern_scores (user_id, mode, scoring_version_id);
CREATE INDEX IF NOT EXISTS idx_match_results_lookup ON match_results (user_a, user_b, mode, lens);
CREATE INDEX IF NOT EXISTS idx_connection_requests_lookup ON connection_requests (to_user, state);
CREATE INDEX IF NOT EXISTS idx_messages_lookup ON messages (conversation_id, sequence);
CREATE INDEX IF NOT EXISTS idx_media_visibility_lookup ON media_visibility (media_id, mode);
CREATE INDEX IF NOT EXISTS idx_moderation_cases_lookup ON moderation_cases (state, priority, due_at);
CREATE INDEX IF NOT EXISTS idx_audit_events_lookup ON audit_events (actor_id, created_at);
CREATE INDEX IF NOT EXISTS idx_notifications_lookup ON notifications (user_id, created_at);
CREATE INDEX IF NOT EXISTS idx_role_grants_lookup ON role_grants (staff_id, role_name);