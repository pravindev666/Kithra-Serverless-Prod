# Engineering templates — NOT a working application

The files here demonstrate target configuration and contracts. They require generated actual app code and vetted secrets/resources. Their syntax may validate but does **not** mean Cloudflare, Firebase, Razorpay or Jenkins is deployed. The example GH Actions command expects workspace scripts to be created. Do not publish them as operational until each environment has real account IDs, policies, configs and green deployment + recovery tests.

- `wrangler.jsonc`: placeholder D1/R2/DO/Queues bindings; do not deploy before real IDs.
- `compose.yaml`: infrastructure topology; registry image names and secrets are placeholders, healthchecks are stubs to adapt to actual routes.
- `Jenkinsfile`: protected-server workflow skeleton; verify secrets, image provenance and rollout commands.
- `openapi.yaml`: high-level endpoint starter; extend required schemas and error map per API-RD.
- `schema_sqlite.sql`: relational baseline for D1 prototype migrations, not final security/compliance schema.
- `schema_postgres.sql`: logical parity example; real migrations must be versioned and tested.
- `.github/workflows`: CI / deployment scaffolds; no fake "green" if scripts aren't created.
