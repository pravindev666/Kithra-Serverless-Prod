import { FAQItem } from '../types';

export const FAQ_ITEMS: FAQItem[] = [
  {
    category: 'Science & Methodology',
    question: 'How is compatibility calculated on Kithra?',
    answer: 'Kithra calculates compatibility across 8 foundational psychological domains: Communication, Core Values, Lifestyle Rhythms, Emotional Regulation, Long-term Goals, Family Alignment, Conflict Resolution, and Existential Purpose. Rather than matching superficial traits, our algorithm maps behavioral models to evaluate how two people navigate stress, financial decisions, boundaries, and growth together.'
  },
  {
    category: 'Science & Methodology',
    question: 'Why does Kithra emphasize self-understanding before introducing matches?',
    answer: 'Relationships rarely fail due to lack of initial attraction; they fail when unexamined expectations and conflicting communication styles collide under pressure. By understanding your own psychological baseline first, you enter the matching process with clarity about what you truly need versus what you superficially desire.'
  },
  {
    category: 'Science & Methodology',
    question: 'Can compatibility scores change over time?',
    answer: 'Yes. Humans evolve. You can retake or refine specific sections of your 100-question assessment at any time as your life circumstances, priorities, or self-awareness deepen. Your compatibility graph updates dynamically.'
  },
  {
    category: 'Science & Methodology',
    question: 'How is Kithra different from traditional matrimony or dating apps?',
    answer: 'Traditional apps rely on superficial filters (height, photo aesthetics, income, immediate location) and addictive swiping loops. Kithra is a Human Compatibility Operating System. There is zero swiping, no public catalog browsing, and no gamified retention loops. Every introduction is backed by evidence and psychometric alignment.'
  },
  {
    category: 'Science & Methodology',
    question: 'What psychometric frameworks power the Kithra Assessment?',
    answer: 'The assessment synthesizes proven clinical research from Big Five personality traits, Gottman Method relationship science, Attachment Theory (Bowlby/Ainsworth), Cognitive Behavioral Therapy (CBT) conflict models, and non-violent communication (NVC) frameworks.'
  },
  {
    category: 'Privacy & Security',
    question: 'Who can view my full psychological profile and answers?',
    answer: 'Nobody without your explicit consent. Your raw assessment answers are end-to-end encrypted and completely private. Compatible matches only see high-level synthesized compatibility summaries and shared alignment dimensions—never your individual question responses.'
  },
  {
    category: 'Privacy & Security',
    question: 'How do you prevent fake profiles and fraudulent accounts?',
    answer: 'Every member undergoes multi-step verification: Government Photo ID (Aadhaar / Passport), 3D Biometric Liveness check, AI Fraud Detection, and Human Moderation. Profiles without 100% verification cannot send or receive compatibility requests.'
  },
  {
    category: 'Privacy & Security',
    question: 'Is Kithra compliant with India’s Digital Personal Data Protection (DPDP) Act?',
    answer: 'Yes, fully. Kithra adheres strictly to DPDP Act standards and global data privacy regulations. You retain 100% ownership of your data, can export your full data archive in CSV/JSON anytime, or permanently purge your account with a single click.'
  },
  {
    category: 'Privacy & Security',
    question: 'Are messages between matches encrypted?',
    answer: 'All direct messaging on Kithra uses Signal-protocol end-to-end encryption. Neither Kithra employees, third parties, nor automated bots can read your private conversations.'
  },
  {
    category: 'Privacy & Security',
    question: 'Can I hide my profile or take a break from matching?',
    answer: 'Yes. You can toggle "Incognito Mode" or "Pause Matching" at any time in your Settings. Your profile will be hidden immediately while preserving your full self-discovery report and assessment history.'
  },
  {
    category: 'Matches & Platform',
    question: 'How long does the assessment take to complete?',
    answer: 'The full 100-question assessment takes approximately 20 to 30 minutes. It is structured into 8 calm modules. You can pause and resume at any time—your progress is automatically saved.'
  },
  {
    category: 'Matches & Platform',
    question: 'How many matches will I receive at once?',
    answer: 'Kithra prioritizes quality over volume. Instead of hundreds of superficial profiles, you receive a curated selection of highly compatible humans (typically 3 to 7 active introductions at a time) with whom you share genuine psychological alignment.'
  },
  {
    category: 'Matches & Platform',
    question: 'Can I search or browse profiles manually?',
    answer: 'No. Manual catalog browsing encourages superficial shopping behavior and objectification. Matches are introduced strictly based on double-blind psychometric compatibility thresholds.'
  },
  {
    category: 'Matches & Platform',
    question: 'What if I receive a match with a lower percentage (e.g., 60% or Opposite)?',
    answer: 'Kithra explicitly highlights "Complementary Alignment" profiles where core values and ethics are 100% aligned, but personality styles differ. These matches often foster profound long-term growth for individuals seeking dynamic contrast.'
  },
  {
    category: 'Matches & Platform',
    question: 'Can family members or parents manage a profile on Kithra?',
    answer: 'No. Kithra is strictly designed for self-directed individuals. While family alignment is measured in the assessment, the account holder must personally complete the assessment and communicate directly.'
  },
  {
    category: 'Matches & Platform',
    question: 'What languages are supported on Kithra?',
    answer: 'Kithra currently supports English along with identical visual rhythm fallbacks for major Indian scripts including Hindi (Devanagari), Tamil, Telugu, Kannada, and Malayalam.'
  },
  {
    category: 'Pricing & Account',
    question: 'Is the Kithra Compatibility Assessment free?',
    answer: 'Yes! The 100-question assessment, your foundational self-awareness score, and basic compatibility summary are 100% free forever. Understanding yourself should never be paywalled.'
  },
  {
    category: 'Pricing & Account',
    question: 'What is included in the ₹369 Essential Tier?',
    answer: 'The ₹369 plan unlocks your complete downloadable 18-page Psychometric Report, deep domain-by-domain narrative breakdowns, conflict style blueprints, and up to 5 verified compatibility introductions per month.'
  },
  {
    category: 'Pricing & Account',
    question: 'What is included in the ₹696 Lifetime Master OS Tier?',
    answer: 'The ₹696 plan provides lifetime access to unlimited compatibility matches, deep Signal-encrypted messaging, third-party profile verifications (Apple Health & Spotify sync), relationship journal tools, and dedicated human moderation support.'
  },
  {
    category: 'Pricing & Account',
    question: 'Can I delete my account and all associated data permanently?',
    answer: 'Yes. In your Settings tab under "Security", clicking "Delete Account & Purge Data" permanently erases all assessment responses, messages, verifications, and report history from our servers immediately.'
  },
  {
    category: 'Pricing & Account',
    question: 'Are there hidden fees, wedding marketplace ads, or commission charges?',
    answer: 'Never. Kithra is an independent product team. We do not accept advertisements, sell user data, or take commissions from wedding vendors. Our only revenue comes directly from transparent user subscriptions.'
  }
];
