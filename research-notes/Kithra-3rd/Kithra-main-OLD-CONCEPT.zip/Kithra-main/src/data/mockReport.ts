import { PsychometricReport } from '../types';

export const DEFAULT_REPORT: PsychometricReport = {
  overallSelfAwareness: 94,
  communicationStyle: 'Direct, Empathetic & Time-Bound',
  conflictStyle: 'Pause-and-Reflect then De-escalate',
  stressResponse: 'Grounded Self-Containment with Structured Recovery',
  loveLanguagePrimary: 'Quality Time & Words of Intentional Affirmation',
  attachmentStyle: 'Secure with Autonomous Orientation',
  financialBehavior: 'Prudent Wealth Stewardship & Conscious Allocation',
  growthMindsetScore: 92,
  domainScores: [
    {
      domain: 'Communication',
      score: 96,
      label: 'Exceptional',
      summary: 'High emotional attunement paired with explicit verbal boundaries.',
      details: 'You articulate internal emotional states clearly without projecting blame on your partner. You value quiet processing breaks (15-20 minutes) during friction and excel at returning to conversations with calm vulnerability.'
    },
    {
      domain: 'Values',
      score: 92,
      label: 'Very Strong',
      summary: 'Deep commitment to personal integrity, truth-telling, and financial prudence.',
      details: 'Your core compass prioritizes long-term peace of mind over superficial luxury. You seek an equal partnership where both individuals actively champion each other’s personal and professional growth.'
    },
    {
      domain: 'Lifestyle',
      score: 88,
      label: 'Very Strong',
      summary: 'Intentional daily rhythms centered on health, order, and quiet sanctuary.',
      details: 'You prefer a clean, uncluttered living environment and value structured morning routines. You thrive on a balance of shared activities (70%) and sacred individual space (30%).'
    },
    {
      domain: 'Emotions',
      score: 95,
      label: 'Exceptional',
      summary: 'High emotional containment and capacity for non-defensive listening.',
      details: 'You remain grounded when your partner expresses intense emotion, providing a safe container rather than absorbing volatility or offering unsolicited advice prematurely.'
    },
    {
      domain: 'Goals',
      score: 90,
      label: 'Very Strong',
      summary: 'Clear 10-year horizon focused on generational stability and continuous learning.',
      details: 'You sequence life milestones methodically—establishing emotional and financial security before taking major collective leaps. You view partnership as a joint masterclass in character building.'
    },
    {
      domain: 'Family',
      score: 89,
      label: 'Strong Alignment',
      summary: 'Clear marital unit prioritization with respectful extended family boundaries.',
      details: 'You value family heritage and elder care while maintaining firm, loving boundaries that protect the privacy and decision-making autonomy of your primary marital union.'
    },
    {
      domain: 'Conflict',
      score: 94,
      label: 'Exceptional',
      summary: 'Zero tolerance for contempt or stonewalling; strong commitment to repair.',
      details: 'You treat disagreements as collaborative problems to be solved together rather than battles to be won. You excel at post-conflict repair through warmth, touch, and clear ownership of errors.'
    },
    {
      domain: 'Purpose',
      score: 93,
      label: 'Exceptional',
      summary: 'Grounded teleological drive focused on service, mastery, and inner peace.',
      details: 'Your existential anchor is rooted in self-knowledge, meaningful contribution, and creating a home sanctuary that radiates peace to everyone who enters.'
    }
  ],
  keyStrengths: [
    'Non-defensive receptivity during difficult feedback',
    'Ability to provide emotional containment during partner stress',
    'High clarity regarding financial and lifestyle non-negotiables',
    'Consistent commitment to post-conflict repair and clean slate practices'
  ],
  growthAreas: [
    'Tendency to over-analyze emotional nuances before expressing immediate needs',
    'May benefit from expressing spontaneous playfulness during high-routine periods'
  ]
};
