import { Question, QuestionDomain } from '../types';

export const DOMAINS: QuestionDomain[] = [
  'Communication',
  'Values',
  'Lifestyle',
  'Emotions',
  'Goals',
  'Family',
  'Conflict',
  'Purpose'
];

const domainTemplates: Record<QuestionDomain, { q: string; sub: string; opts: [string, string, string, string] }[]> = {
  Communication: [
    {
      q: "When a disagreement arises, what is your immediate instinctual reaction?",
      sub: "Understanding your immediate response to tension helps predict relationship stability.",
      opts: [
        "Address it immediately to resolve the underlying tension before moving on.",
        "Take 15-30 minutes alone to process my thoughts before initiating dialogue.",
        "Internalize it initially and wait to see if it becomes a repeating pattern.",
        "Use gentle humor or de-escalation to soften the atmosphere before discussing."
      ]
    },
    {
      q: "How do you express vulnerability when you feel overwhelmed?",
      sub: "Vulnerability dynamics are central to long-term trust and emotional intimacy.",
      opts: [
        "I explicitly state my exact emotional needs and request specific support.",
        "I express it through body language and appreciate subtle emotional attunement.",
        "I tend to withdraw temporarily until I can articulate my feelings logically.",
        "I channel it into action and appreciate practical problem-solving help."
      ]
    },
    {
      q: "In high-stress conversations, what communication tone do you expect from a partner?",
      sub: "Alignment in vocal tone and composure during friction prevents escalation.",
      opts: [
        "Calm, measured, and strictly logical without emotional volatility.",
        "Empathetic, validating, and focused on shared emotional connection.",
        "Direct, transparent, and concise without sugarcoating issues.",
        "Patient, listening-heavy, allowing space for both to express fully."
      ]
    },
    {
      q: "How do you prefer to receive feedback or constructive criticism?",
      sub: "Feedback receptivity directly correlates with relationship evolution.",
      opts: [
        "In a scheduled, quiet private setting with concrete examples and solutions.",
        "In real-time gently, framed with warmth and mutual affection.",
        "Via written message or note so I can process without instant pressure.",
        "Through open, interactive dialogue focused on collaborative growth."
      ]
    },
    {
      q: "What is your stance on non-verbal communication during quiet moments?",
      sub: "Shared comfort with silence is a key measure of emotional security.",
      opts: [
        "Silent companionship is deeply nourishing; words are not always necessary.",
        "I prefer frequent verbal check-ins and active ongoing conversation.",
        "I enjoy shared activities or music during quiet moments together.",
        "I value physical presence and gentle touch over spoken dialogue."
      ]
    },
    {
      q: "How do you share daily small wins and micro-struggles?",
      sub: "Daily bid-response cycles form the bedrock of partnership longevity.",
      opts: [
        "I love micro-updates throughout the day via text or quick calls.",
        "I save updates for an uninterrupted evening debrief over tea or dinner.",
        "I share selectively when a topic holds significant emotional depth.",
        "I express through shared laughter, stories, and reflective conversations."
      ]
    },
    {
      q: "When your partner is venting about work, what is your default listening mode?",
      sub: "Distinguishing between emotional validation and advice-giving.",
      opts: [
        "Pure empathetic listening and emotional validation without unsolicited advice.",
        "Analytical problem-solving and offering actionable strategic steps.",
        "Asking clarifying questions to help them process their own thoughts.",
        "Offering physical comfort, tea, and a safe relaxing environment."
      ]
    },
    {
      q: "How do you articulate implicit boundary crossings?",
      sub: "Boundary negotiation is key to preventing resentment accumulation.",
      opts: [
        "Directly, clearly, and calmly the moment I recognize the boundary.",
        "I reflect overnight to ensure my response is objective and fair.",
        "I bring it up gently during our regular relationship check-ins.",
        "I use 'I feel' statements to center emotional safety."
      ]
    },
    {
      q: "What role does written communication play during emotional misunderstandings?",
      sub: "Written vs spoken processing styles.",
      opts: [
        "I prefer spoken conversation; text easily leads to misinterpretation.",
        "Writing down thoughts first helps me structure complex emotional nuances.",
        "A combination: brief text to acknowledge, followed by deep face-to-face talk.",
        "I write letters or long notes when topics are particularly sensitive."
      ]
    },
    {
      q: "How do you handle apologies after a breach of trust or mistake?",
      sub: "Reparative capacity measures psychological maturity.",
      opts: [
        "Immediate accountability, clear ownership, and actionable behavioral change.",
        "Deep emotional reflection, sincere expression of remorse, and listening.",
        "Giving space first, followed by a thorough analytical breakdown of what happened.",
        "Rebuilding through steady, reliable micro-actions over extended time."
      ]
    },
    {
      q: "How frequently do you expect deep, reflective meta-conversations about your relationship?",
      sub: "Meta-communication appetite.",
      opts: [
        "Weekly structured relationship check-ins to stay proactive.",
        "Monthly organic reflections when both feel relaxed and inspired.",
        "As needed whenever significant transitions or feelings emerge.",
        "Continuously in real-time through subtle ongoing awareness."
      ]
    },
    {
      q: "When you feel misunderstood, what is your secondary attempt at connection?",
      sub: "Persistence in communication repair.",
      opts: [
        "Reframe my words using alternative analogies or simpler language.",
        "Pause the conversation and revisit after a calming break.",
        "Ask my partner to restate what they heard to find the gap.",
        "Shift from verbal explanation to emotional feeling expression."
      ]
    },
    {
      q: "How do you react when a partner expresses strong negative emotions?",
      sub: "Emotional containment ability.",
      opts: [
        "I remain grounded and provide a safe container without taking it personally.",
        "I feel deeply affected and seek to rapidly soothe or resolve their pain.",
        "I analyze the root cause logically to help de-escalate the intensity.",
        "I give them quiet space and physical comfort until the storm passes."
      ]
    }
  ],
  Values: [
    {
      q: "How do you define financial security and wealth stewardship?",
      sub: "Financial values align closely with long-term marital stability.",
      opts: [
        "Prioritizing high savings, conservative investments, and long-term peace of mind.",
        "Balancing prudent investments with funding memorable experiences and growth.",
        "Investing aggressively in entrepreneurial endeavors and calculated risks.",
        "Living simply, minimizing material excess, and giving generously."
      ]
    },
    {
      q: "What is your fundamental stance on personal ambition versus relational harmony?",
      sub: "Career momentum vs relational priority balance.",
      opts: [
        "Equal partnership where both actively champion each other's career ambitions.",
        "Relational harmony and family rhythm take strict precedence over work.",
        "Dynamic phases: supporting one partner's push now, alternating later.",
        "Shared entrepreneurial or creative mission built together."
      ]
    },
    {
      q: "How do you view integrity when no one is watching?",
      sub: "Ethical alignment forms foundational trust.",
      opts: [
        "Uncompromising adherence to moral principles in all micro-decisions.",
        "Pragmatic integrity balanced with deep empathy and context sensitivity.",
        "Commitment to truthfulness and radical honesty with self and partner.",
        "Focus on community impact, kindness, and doing no harm."
      ]
    },
    {
      q: "What role does personal independence play within a committed life partnership?",
      sub: "Autonomy vs interdependence spectrum.",
      opts: [
        "Strong individual autonomy with separate hobbies, friendships, and goals.",
        "Deep interdependence where almost all major pursuits are shared.",
        "A healthy balance: 70% shared life foundation, 30% sacred individual space.",
        "Fluid autonomy that shifts depending on life stages and children."
      ]
    },
    {
      q: "How do you approach spiritual, philosophical, or ethical frameworks?",
      sub: "Existential orientation and core worldview.",
      opts: [
        "Grounded in rational humanism, scientific inquiry, and secular ethics.",
        "Deeply rooted in traditional spiritual or religious practices and heritage.",
        "Personalized spiritual awareness focused on mindfulness and connection.",
        "Open-minded philosophical exploration without rigid dogmatic beliefs."
      ]
    },
    {
      q: "What is your philosophy on personal growth and self-examination?",
      sub: "Psychological evolution trajectory.",
      opts: [
        "Continuous deliberate self-improvement through therapy, study, and feedback.",
        "Organic life learning through experience, relationships, and natural evolution.",
        "Structured goal-setting across physical, mental, and spiritual domains.",
        "Acceptance of self and partner as whole without constant pressure to optimize."
      ]
    },
    {
      q: "How do you prioritize material simplicity versus luxury and comfort?",
      sub: "Consumption habits and aesthetic values.",
      opts: [
        "Minimalist: valuing quality over quantity, clutter-free spaces, conscious spending.",
        "Comfort-oriented: investing in high-quality living environments and fine living.",
        "Frugal & resource-conscious: prioritizing sustainability and low footprint.",
        "Experience-focused: spending on travel and learning rather than objects."
      ]
    },
    {
      q: "What does honor and loyalty mean to you in a long-term union?",
      sub: "Core loyalty expectations under pressure.",
      opts: [
        "Standing united publicly and working through all conflicts privately.",
        "Unwavering honesty even when truth is difficult or uncomfortable.",
        "Fierce protection of partner's dignity, energy, and well-being.",
        "Sacred commitment to joint growth across decades."
      ]
    },
    {
      q: "How do you view social responsibility and civic contribution?",
      sub: "Altruistic and social values.",
      opts: [
        "Active involvement in social causes, volunteering, and systemic change.",
        "Focus on lifting family, local community, and immediate network first.",
        "Quiet personal charity and ethical daily consumption choices.",
        "Mentorship, teaching, and passing wisdom to future generations."
      ]
    },
    {
      q: "What is your attitude toward truth-telling versus soft white lies to preserve feelings?",
      sub: "Truth vs tact continuum.",
      opts: [
        "Radical transparency: total truth delivered with respect is always superior.",
        "Compassionate honesty: truth filtered with kindness to avoid unnecessary pain.",
        "Tactful discretion: protecting partner's emotional state when details are trivial.",
        "Contextual honesty: absolute truth on core matters, gentleness on superficial ones."
      ]
    },
    {
      q: "How do you view the stewardship of time and energy?",
      sub: "Temporal resource allocation.",
      opts: [
        "Time is precious; daily life should be intentional, organized, and focused.",
        "Flow and spontaneity: rigid schedules diminish the beauty of present moments.",
        "Structured priority blocks for work, relationship, family, and rest.",
        "Deep focus on high-impact meaningful projects over busywork."
      ]
    },
    {
      q: "What value do you place on intellectual curiosity and conversation?",
      sub: "Cognitive compatibility.",
      opts: [
        "Essential: need a partner who loves deep debates, reading, and learning.",
        "Important, but secondary to emotional warmth and practical reliability.",
        "Focused on creative exploration, artistic expression, and ideas.",
        "Valued when grounded in practical real-world application."
      ]
    }
  ],
  Lifestyle: [
    {
      q: "What is your ideal daily living rhythm and routine structure?",
      sub: "Daily micro-rhythms prevent chronic friction.",
      opts: [
        "Early riser, structured morning routine, disciplined and predictable hours.",
        "Night owl, flexible open hours, spontaneous energy flows.",
        "Balanced rhythm adaptively tailored around current projects and seasons.",
        "Calm, unhurried pace prioritizing rest, home cooking, and peace."
      ]
    },
    {
      q: "How do you approach health, physical wellness, and nutrition?",
      sub: "Physical lifestyle alignment.",
      opts: [
        "Active daily fitness, clean nutrition, tracking health metrics, energetic life.",
        "Balanced approach: enjoying good food, movement, without strict obsession.",
        "Outdoors-oriented: hiking, nature immersion, movement integrated into fun.",
        "Mindful wellness: yoga, rest, mental wellbeing taking primary focus."
      ]
    },
    {
      q: "What does your home sanctuary feel like in terms of order and aesthetics?",
      sub: "Domestic environment compatibility.",
      opts: [
        "Pristine, hyper-organized, clutter-free minimal aesthetic at all times.",
        "Cozy, lived-in warmth with artistic personality and comfortable relaxed spaces.",
        "Functional, practical, low-maintenance home tailored for efficiency.",
        "Serene, nature-infused, quiet sanctuary with warm natural lighting."
      ]
    },
    {
      q: "How do you prefer to spend weekends and extended rest periods?",
      sub: "Recreational synchronization.",
      opts: [
        "Quiet home relaxation, reading, gardening, deep culinary creation.",
        "Social gatherings, hosting dinner parties, community engagement.",
        "Outdoor adventures, travel, exploring new places and active sports.",
        "Mix of creative solo hobbies and relaxed quality time together."
      ]
    },
    {
      q: "What is your approach to digital device consumption at home?",
      sub: "Digital boundaries and presence.",
      opts: [
        "Strict phone-free zones (dining table, bedroom) to foster deep presence.",
        "Moderate usage with intentional screen-free times together.",
        "Flexible usage while maintaining open communication and awareness.",
        "Tech-integrated lifestyle with shared digital media, gaming, or movies."
      ]
    },
    {
      q: "How do you navigate hospitality, social entertaining, and home guests?",
      sub: "Social energy expenditure.",
      opts: [
        "Love frequent hosting: our home is an open hub for friends and family.",
        "Prefer intimate 1-on-1 or small gathering hosting occasionally.",
        "Home is a private sanctuary; external social meetings outside preferred.",
        "Seasonal hosting depending on holidays and special milestones."
      ]
    },
    {
      q: "What is your preferred travel style and exploration philosophy?",
      sub: "Exploration compatibility.",
      opts: [
        "Immersive cultural exploration, off-the-beaten-path, slow local living.",
        "Luxury, seamless comfort, curated relaxation, and fine dining.",
        "Structured itineraries packed with historical, nature, and educational spots.",
        "Spontaneous road trips and unplanned exploratory adventures."
      ]
    },
    {
      q: "How do you handle domestic chores and household maintenance equity?",
      sub: "Domestic labor balance.",
      opts: [
        "Explicit chore split based on preferences, strengths, and clear schedules.",
        "Fluid, intuitive teamwork where both jump in when something needs doing.",
        "Hiring professional help for cleaning/maintenance to save relationship time.",
        "Alternating weekly responsibilities to maintain complete fairness."
      ]
    },
    {
      q: "What is your relationship with alcohol, substances, or social night life?",
      sub: "Substance and nightlife alignment.",
      opts: [
        "Completely alcohol/substance-free life; preferring quiet, clear mornings.",
        "Occasional social wine or craft drinks during celebrations or dining.",
        "Enjoy vibrant social nightlife, music events, and late evening dining.",
        "Mindful conscious consumption focused strictly on health impact."
      ]
    },
    {
      q: "How do you prefer to manage pets and animal companion integration?",
      sub: "Domestic companion preferences.",
      opts: [
        "Pets are full family members who sleep on furniture and join outings.",
        "Enjoy pets with clear trained boundaries and structured care.",
        "Prefer a pet-free living space for travel freedom and cleanliness.",
        "Open to outdoor pets or low-maintenance home companions."
      ]
    },
    {
      q: "How do you navigate dietary preferences and meal sharing?",
      sub: "Culinary lifestyle integration.",
      opts: [
        "Shared dietary philosophy (e.g. plant-based, organic) cooked together.",
        "Flexible culinary styles; happy to cook distinct meals side-by-side.",
        "Food is a major passion: exploring diverse cuisines and cooking together.",
        "Simple, functional eating with quick preparation and efficiency."
      ]
    },
    {
      q: "What is your relationship with personal solitude versus constant togetherness?",
      sub: "Solitude appetite.",
      opts: [
        "Require daily solo time (1-2 hours) to recharge my battery.",
        "Thrive on constant togetherness and doing daily activities side by side.",
        "Need occasional solo weekend days or trips to reconnect with self.",
        "Comfortable existing in parallel play (same room, separate activities)."
      ]
    }
  ],
  Emotions: [
    {
      q: "How do you process intense personal grief, disappointment, or emotional pain?",
      sub: "Emotional regulation baseline.",
      opts: [
        "Internal processing in quiet solitude before verbalizing to others.",
        "Immediate emotional expression through crying, talking, and seeking comfort.",
        "Channeling energy into physical activity, work, or constructive reflection.",
        "Seeking professional therapy or somatic practices to move through it."
      ]
    },
    {
      q: "What is your primary emotional attachment style under threat or uncertainty?",
      sub: "Attachment security indicator.",
      opts: [
        "Secure: confident in my worth and trusting in my partner's care.",
        "Anxious-leaning: seeking frequent reassurance and rapid connection.",
        "Avoidant-leaning: needing distance to regain self-regulation.",
        "Disorganized-leaning: oscillating between longing for closeness and fear."
      ]
    },
    {
      q: "How do you cultivate joy, gratitude, and lightness in daily life?",
      sub: "Emotional positivity maintenance.",
      opts: [
        "Micro-mindfulness, nature walks, gratitude journaling, quiet beauty.",
        "Shared humor, playfulness, banter, and lighthearted silliness.",
        "Deep intellectual conversation, learning, and meaningful achievements.",
        "Acts of service, pampering loved ones, and creating comforting rituals."
      ]
    },
    {
      q: "What triggers your emotional defensiveness most rapidly?",
      sub: "Self-awareness of emotional vulnerabilities.",
      opts: [
        "Feeling unappreciated or having my effort overlooked.",
        "Feeling controlled, micromanaged, or restricted in my freedom.",
        "Feeling misunderstood, unfairly judged, or mischaracterized.",
        "Feeling dismissed, ignored, or emotionally shut out."
      ]
    },
    {
      q: "How do you handle your partner's sudden mood swings or emotional distress?",
      sub: "Interpersonal emotional regulation.",
      opts: [
        "Offer steady, grounded calm without absorbing their emotional state.",
        "Empathize deeply and mirror their feelings, sometimes getting swept up.",
        "Provide immediate practical comfort (water, blanket, listening ear).",
        "Give them gentle space while letting them know I am ready when needed."
      ]
    },
    {
      q: "How comfortable are you expressing anger or anger-adjacent emotions?",
      sub: "Anger processing and safety.",
      opts: [
        "Uncomfortable: I prefer to cool down completely before speaking.",
        "Expressive: I voice frustration directly in real-time, then let it pass fast.",
        "Constructive: I name the boundary violation without shouting or harshness.",
        "Somatic: I move my body or exercise to discharge physical tension first."
      ]
    },
    {
      q: "How do you view emotional intimacy compared to physical intimacy?",
      sub: "Intimacy duality balance.",
      opts: [
        "Emotional intimacy is the prerequisite that unlocks deep physical desire.",
        "Physical touch and closeness create the safe doorway for emotional vulnerability.",
        "Both are deeply interwoven and must be nurtured simultaneously.",
        "Intellectual and philosophical bond drives both emotional and physical closeness."
      ]
    },
    {
      q: "How do you practice self-compassion when you make a mistake in a relationship?",
      sub: "Internal emotional dialogue.",
      opts: [
        "Acknowledge the mistake, make prompt repair, and avoid shame loops.",
        "Tend to hold guilt for a while until my partner fully reassures me.",
        "Analyze why it happened systematically to ensure it never recurs.",
        "Reflect in my journal and practice self-forgiveness."
      ]
    },
    {
      q: "What role does empathy play when you disagree morally with a partner?",
      sub: "Cognitive vs emotional empathy flexibility.",
      opts: [
        "I can deeply understand their emotional perspective even while disagreeing.",
        "I struggle if the disagreement violates a core ethical value of mine.",
        "I focus on finding the shared underlying need behind their stance.",
        "I ask questions until I map out the psychological root of their view."
      ]
    },
    {
      q: "How do you communicate love and appreciation day-to-day?",
      sub: "Love language orientation.",
      opts: [
        "Words of affirmation: specific, written, or spoken genuine praise.",
        "Acts of service: anticipating needs and lightening daily burdens.",
        "Quality time: undivided attention, deep presence, screen-free talks.",
        "Physical affection: spontaneous hugs, holding hands, touch."
      ]
    },
    {
      q: "How do you respond when feeling emotionally neglected?",
      sub: "Proactive emotional bid capacity.",
      opts: [
        "Initiate a calm, clear discussion stating my need for connection.",
        "Withdraw slightly to see if my partner notices the distance.",
        "Plan a special date or shared activity to re-ignite warmth.",
        "Express my sadness directly and ask for a cuddle or check-in."
      ]
    },
    {
      q: "What is your emotional resilience baseline after a major life setback?",
      sub: "Psychological hardiness.",
      opts: [
        "High: rapid re-framing, finding purpose in adversity, moving forward.",
        "Moderate: need time to grieve deeply, rely on partner support, then rebuild.",
        "Methodical: break the challenge into micro-steps to gain control.",
        "Relational: lean heavily into team unity and shared strength."
      ]
    }
  ],
  Goals: [
    {
      q: "What is your 10-year vision regarding geographical permanence versus mobility?",
      sub: "Geographic flexibility alignment.",
      opts: [
        "Rooted in one permanent home location near family/community long-term.",
        "Global mobility: open to living in multiple countries or frequent relocations.",
        "Dual-base living: splitting time between city and peaceful countryside.",
        "Flexible adaptation dependent on career and educational opportunities."
      ]
    },
    {
      q: "How do you align career trajectories with family milestones?",
      sub: "Temporal life planning.",
      opts: [
        "Sequenced: establishing financial/career foundation firmly before children/family.",
        "Integrated: pursuing career growth alongside starting and raising a family.",
        "Partner-prioritized: supporting one primary career while the other manages home rhythm.",
        "Child-free life: directing life energy toward creative, societal, or career goals."
      ]
    },
    {
      q: "What are your primary wealth generation and legacy objectives?",
      sub: "Long-term financial vision.",
      opts: [
        "Building generational wealth, assets, and real estate for future family.",
        "Achieving Financial Independence / Early Retirement (FIRE) to buy back time.",
        "Funding philanthropic initiatives, community projects, and research.",
        "Prioritizing high quality of life today over excessive asset accumulation."
      ]
    },
    {
      q: "How do you view long-term education and skill acquisition?",
      sub: "Lifelong learning orientation.",
      opts: [
        "Continuous formal or informal masteries (degrees, books, certifications).",
        "Experiential learning through world travel, ventures, and diverse hobbies.",
        "Spiritual and personal development mastery through retreats and study.",
        "Practical skill-building geared directly toward family resilience."
      ]
    },
    {
      q: "What is your stance on retirement lifestyle and golden years?",
      sub: "Late-life vision.",
      opts: [
        "Active, continuous creation and work; never retiring completely.",
        "Peaceful homestead living, gardening, reading, and quiet nature.",
        "World travel, volunteering, and exploring artistic passions.",
        "Mentoring younger generations and spending time with grandchildren."
      ]
    },
    {
      q: "How do you evaluate risk when pursuing major life goals?",
      sub: "Risk tolerance continuum.",
      opts: [
        "Calculated high-risk high-reward: entrepreneurial leaps and bold changes.",
        "Prudent moderate risk: steady progress with fallback safety nets.",
        "Conservative risk: security, stability, and tested pathways prioritized.",
        "Collaborative risk: decisions made only with unanimous partner commitment."
      ]
    },
    {
      q: "What role does public or community legacy play in your aspirations?",
      sub: "Public vs private contribution motivation.",
      opts: [
        "High: aspiring to make a noticeable mark in my field, industry, or society.",
        "Private: legacy is measured purely by the love and character of my inner circle.",
        "Local: deep impact on my local neighborhood, school, or community.",
        "Creative/Intellectual: leaving behind works of art, writing, or innovation."
      ]
    },
    {
      q: "How do you approach goal modification when unexpected circumstances occur?",
      sub: "Strategic adaptability.",
      opts: [
        "High agility: pivoting rapidly without lingering regret or frustration.",
        "Methodical recalibration: taking time to analyze options before shifting.",
        "Persistence: holding firm to the vision while adjusting only tactics.",
        "Relational alignment: re-evaluating goals together from square one."
      ]
    },
    {
      q: "How do you define success in a life partnership?",
      sub: "Ultimate relationship metric.",
      opts: [
        "Decades of emotional safety, deep friendship, mutual growth, and peace.",
        "Building a thriving family unit and raising resilient, kind children.",
        "Creating extraordinary shared impact, achievements, and adventures.",
        "Weathering all life storms with unwavering loyalty and integrity."
      ]
    },
    {
      q: "What is your perspective on joint business or creative ventures with your partner?",
      sub: "Co-creation dynamics.",
      opts: [
        "Enthusiastic: I would love to build a venture or creative project together.",
        "Cautious: Prefer keeping professional endeavors strictly separate from marriage.",
        "Open if roles are clearly defined with zero domain overlap.",
        "Interested in advisory support rather than active co-management."
      ]
    },
    {
      q: "How do you view physical health goals as a couple?",
      sub: "Couples wellness synergy.",
      opts: [
        "Vital: working out together, cooking healthily, holding each other accountable.",
        "Individual: supporting each other's individual health pursuits without pressure.",
        "Lifestyle-based: active daily living rather than structured fitness routines.",
        "Wellness-focused: prioritizing sleep, stress reduction, and mental peace."
      ]
    },
    {
      q: "What is your vision for holiday traditions and celebratory milestones?",
      sub: "Cultural and familial ritual creation.",
      opts: [
        "Creating unique, original traditions custom to our immediate partnership.",
        "Preserving and honoring traditional family rituals passed down from elders.",
        "Minimalist celebrations focused on quiet presence rather than commercial gifts.",
        "Travel-based celebrations in new destinations each year."
      ]
    }
  ],
  Family: [
    {
      q: "What is your stance on having and raising children?",
      sub: "Parenthood alignment is a fundamental non-negotiable.",
      opts: [
        "Definite desire for children; central to my life purpose and vision.",
        "Open to children if conditions, partner alignment, and timing feel right.",
        "Prefer a child-free life to focus on partnership, creative work, and freedom.",
        "Already have or desire to adopt/foster children."
      ]
    },
    {
      q: "How do you view boundary-setting with extended family and parents?",
      sub: "In-law dynamics and family boundary clarity.",
      opts: [
        "Our marital unit comes first; strong boundaries with extended family when needed.",
        "Deeply integrated extended family living; parents play an active daily role.",
        "Respectful harmony balancing family traditions with private marital autonomy.",
        "Geographic distance preferred to maintain healthy independence."
      ]
    },
    {
      q: "What child-rearing philosophy resonates most with your values?",
      sub: "Parenting style alignment.",
      opts: [
        "Authoritative & Mindful: high warmth, clear boundaries, emotional regulation.",
        "Traditional & Disciplined: respect for elders, academic focus, strong structure.",
        "Progressive & Experiential: fostering curiosity, self-expression, global exposure.",
        "Collaborative: treating children as young individuals with voice and autonomy."
      ]
    },
    {
      q: "How do you envision elder care and supporting aging parents?",
      sub: "Filial responsibility expectations.",
      opts: [
        "Welcoming aging parents to live in our home as honored family members.",
        "Providing close local housing or professional assisted care while staying daily involved.",
        "Financial support and organizing top professional healthcare teams.",
        "Navigating collaboratively with siblings and partner based on circumstance."
      ]
    },
    {
      q: "What family rituals from your upbringing do you wish to pass on or modify?",
      sub: "Intergenerational pattern continuity.",
      opts: [
        "Passing down rich cultural traditions, language, and spiritual heritage.",
        "Intentionally breaking dysfunctional patterns and building fresh healthy norms.",
        "Blending the best traditions from both our family backgrounds seamlessly.",
        "Creating simple, secular, love-centered home routines."
      ]
    },
    {
      q: "How do you handle family conflict or interference from relatives?",
      sub: "Extended family loyalty alignment.",
      opts: [
        "Directly protecting my partner and speaking with my own family privately.",
        "Encouraging open, multi-generational dialogue to preserve family peace.",
        "Maintaining gentle emotional distance while fulfilling essential duties.",
        "Relying on strict mutual ground rules established with my partner beforehand."
      ]
    },
    {
      q: "What role should grandparents play in the daily lives of future children?",
      sub: "Grandparent involvement depth.",
      opts: [
        "Daily or weekly active involvement in childcare and moral guidance.",
        "Regular warm visits during weekends, holidays, and family milestones.",
        "Loving background presence respecting parents' primary decisions.",
        "Dependent on geographic proximity and healthy boundary alignment."
      ]
    },
    {
      q: "How do you view religious or cultural education for future children?",
      sub: "Cultural transmission values.",
      opts: [
        "Immersing them deeply in our spiritual, cultural, or religious faith.",
        "Exposing them to global spiritual and philosophical traditions objectively.",
        "Raising them in a purely secular, science-backed, ethical environment.",
        "Allowing them total freedom to choose their beliefs when mature."
      ]
    },
    {
      q: "How do you manage financial contributions or aid to extended family members?",
      sub: "Family financial boundaries.",
      opts: [
        "Generous support: family in need is always our shared financial priority.",
        "Budgeted support: clear pre-agreed limits discussed openly between partners.",
        "Emergency support only: reserving funds primarily for nuclear family security.",
        "Independent finances: extended family manages their own financial affairs."
      ]
    },
    {
      q: "What is your vision for family meal gatherings and home connection?",
      sub: "Home culture anchor.",
      opts: [
        "Sacred daily family dinners at the table without screens or distractions.",
        "Flexible shared meals around work schedules, making weekends special.",
        "Festive weekly feasts with extended family, cousins, and friends.",
        "Simple, casual eating rhythm centered on ease and comfort."
      ]
    },
    {
      q: "How do you approach screen time and technology access for children?",
      sub: "Digital parenting philosophy.",
      opts: [
        "Strictly delayed tech access; emphasis on outdoor play, books, and crafts.",
        "Balanced, monitored access focusing on educational media and skills.",
        "Early digital literacy with clear safety filters and time limits.",
        "Adaptive guidance teaching healthy self-regulation."
      ]
    },
    {
      q: "How do you handle differences in parenting opinions between partners?",
      sub: "United parental front capacity.",
      opts: [
        "Always present a 100% united front to children; debate differences in private.",
        "Openly discuss perspectives in front of children to model healthy negotiation.",
        "Assign primary lead on specific domains based on expertise.",
        "Seek advice from child psychologists or trusted literature together."
      ]
    }
  ],
  Conflict: [
    {
      q: "When an argument reaches an emotional impasse, how do you handle a pause?",
      sub: "De-escalation mechanics during acute friction.",
      opts: [
        "Request a time-bound break (e.g., 20 mins) with a promise to return calmly.",
        "Dislike pauses; prefer staying at the table until resolution is reached.",
        "Pivot to physical touch or a comforting gesture to reset emotional tone.",
        "Write down key points to separate emotion from core issue."
      ]
    },
    {
      q: "How do you recover after an intense argument has concluded?",
      sub: "Post-conflict repair protocol.",
      opts: [
        "A warm physical embrace, explicit reassurance of love, and moving on.",
        "A quiet period of integration before engaging in normal light activities.",
        "A brief debrief analyzing what triggered the reaction to prevent repetition.",
        "Doing a shared pleasant activity like walking or making tea together."
      ]
    },
    {
      q: "What is your relationship with defensiveness when called out on a fault?",
      sub: "Ego regulation in intimate partnership.",
      opts: [
        "Pause, breathe, and look for the 10% truth in their statement immediately.",
        "Feel initial defensive heat, take a moment, then respond thoughtfully.",
        "Ask clarifying questions to understand their perspective before explaining mine.",
        "Explain my intentions clearly to correct misinterpretations."
      ]
    },
    {
      q: "How do you handle subtle micro-resentments before they build into anger?",
      sub: "Proactive emotional hygiene.",
      opts: [
        "Bring them up gently within 24 hours using light, non-judgmental language.",
        "Process them internally to see if they are my own projection first.",
        "Schedule regular relationship state-of-the-union check-ins.",
        "Use humor or affection to dissipate minor daily irritations."
      ]
    },
    {
      q: "What is your response if your partner uses harsh words during a moment of anger?",
      sub: "Conflict boundary defense and grace.",
      opts: [
        "Calmly halt the conversation immediately: 'I value us too much to speak harshly.'",
        "Express my hurt clearly and request an apology before continuing.",
        "Recognize their pain, hold space, but address the language after they cool down.",
        "Give immediate space to allow emotional regulation."
      ]
    },
    {
      q: "How do you approach compromise on non-core preferences?",
      sub: "Flexibility and surrender capacity.",
      opts: [
        "Eagerly yield on non-core matters to bring joy and harmony to my partner.",
        "Trade-off constructively: 'You lead this choice, I’ll lead the next.'",
        "Evaluate based on who cares more deeply about the outcome.",
        "Seek creative win-win solutions that satisfy both preferences."
      ]
    },
    {
      q: "What role does humor play during relationship friction?",
      sub: "Levity as a repair mechanism.",
      opts: [
        "Invaluable: gentle, self-deprecating humor breaks tension instantly.",
        "Use with caution: ensure it is never weaponized or dismissive of feelings.",
        "Prefer serious issues to be addressed with sober earnestness.",
        "Great once the initial emotional storm has cleared."
      ]
    },
    {
      q: "How do you process conflict that stems from stress outside the relationship?",
      sub: "Stress spillover containment.",
      opts: [
        "Explicitly name it: 'I am stressed about work, please don't take my tone personally.'",
        "Take solo decompression time before entering the home environment.",
        "Ask partner for a listening ear specifically regarding the external stress.",
        "Engage in joint somatic grounding (exercise, shower, cooking)."
      ]
    },
    {
      q: "What is your stance on bringing past resolved arguments into current discussions?",
      sub: "Clean slate conflict practice.",
      opts: [
        "Strict rule: past resolved issues are locked; only current issue is addressed.",
        "Allowed only if an unresolved pattern is clearly repeating.",
        "Focus purely on present feelings and future actionable behavior.",
        "Use historic context to understand root behavioral triggers."
      ]
    },
    {
      q: "How do you navigate conflict when both partners are exhausted or hungry?",
      sub: "HALT (Hungry, Angry, Lonely, Tired) awareness.",
      opts: [
        "Enforce a mandatory pause for food, sleep, or rest before any discussion.",
        "Acknowledge the physical fatigue and agree to talk tomorrow morning.",
        "Keep words minimal and prioritize physical comfort.",
        "Take quick physiological resets together."
      ]
    },
    {
      q: "How do you handle situations where there is no objective 'right' answer?",
      sub: "Subjective difference acceptance.",
      opts: [
        "Agree to disagree with grace, validating partner's valid perspective.",
        "Find a middle path or alternate turn-taking.",
        "Experiment with one approach temporarily, then review results.",
        "Prioritize the option that honors the deeper emotional need."
      ]
    },
    {
      q: "What is your willingness to seek professional couples counseling if stuck?",
      sub: "External feedback openness.",
      opts: [
        "Proactive: eager to use therapy/coaching early as preventive maintenance.",
        "Open if we hit an ongoing persistent roadblock we cannot solve alone.",
        "Prefer resolving issues internally through books, talks, and reflection.",
        "View counseling as a trusted, objective catalyst for growth."
      ]
    }
  ],
  Purpose: [
    {
      q: "How do you articulate your ultimate life mission or calling?",
      sub: "Teleological orientation and life purpose.",
      opts: [
        "To alleviate suffering, serve humanity, and leave a better world.",
        "To master my craft, create timeless work, and achieve excellence.",
        "To build a warm, loving family and cultivate deep human connections.",
        "To explore the depth of consciousness, truth, and spiritual growth."
      ]
    },
    {
      q: "What role does a romantic partner play in your existential purpose?",
      sub: "Relational role in personal calling.",
      opts: [
        "A co-adventurer and equal champion in our shared and individual missions.",
        "My primary sanctuary, home, and source of emotional grounding.",
        "A mirror helping me refine my character and grow spiritually.",
        "A partner with whom I build a thriving family and legacy."
      ]
    },
    {
      q: "How do you relate to mortality, impermanence, and the passage of time?",
      sub: "Perspective on life's brevity.",
      opts: [
        "Deeply aware of time's brevity, driving intentional daily living.",
        "Grounded in faith and trust in a higher order or cosmic continuity.",
        "Focused on creating lasting legacy through art, family, or work.",
        "Embracing the present moment with gratitude and peaceful presence."
      ]
    },
    {
      q: "What drives your decision-making when facing a major life crossroads?",
      sub: "Inner compass orientation.",
      opts: [
        "Alignment with my core values and long-term ethical purpose.",
        "Impact on my family's wellbeing, security, and happiness.",
        "Intuitive inner knowing combined with rational analysis.",
        "Seeking wisdom from mentors, texts, and quiet reflection."
      ]
    },
    {
      q: "How do you cultivate a sense of awe, wonder, and sacredness?",
      sub: "Transcendent experience engagement.",
      opts: [
        "Immersion in natural wilderness, starry skies, and ocean expanses.",
        "Deep artistic, musical, architectural, or literary experiences.",
        "Mindful presence in simple daily moments and human warmth.",
        "Spiritual contemplation, meditation, and sacred rituals."
      ]
    },
    {
      q: "How do you view suffering, hardship, and life setbacks in the grander narrative?",
      sub: "Meaning-making capacity.",
      opts: [
        "As crucial crucibles for character transformation, empathy, and wisdom.",
        "As natural challenges to be solved with resilience and team unity.",
        "As reminders to stay humble, adaptable, and compassionate.",
        "As opportunities to re-evaluate priorities and refine direction."
      ]
    },
    {
      q: "What legacy do you hope to leave in the hearts of those closest to you?",
      sub: "Relational legacy vision.",
      opts: [
        "That I loved unconditionally, listened deeply, and brought unwavering peace.",
        "That I inspired courage, truth, and high standards of integrity.",
        "That I built a joyful, safe home filled with warmth and laughter.",
        "That I gave selflessly to lift others and empower potential."
      ]
    },
    {
      q: "How do you balance individual self-actualization with joint marital commitment?",
      sub: "Self-actualization vs union integration.",
      opts: [
        "Our union is the fertile soil out of which both individuals blossom.",
        "Joint commitment is paramount; individual desires adjust to serve the union.",
        "Dynamic dance: periods of deep focus on individual craft alternating with joint focus.",
        "Seamless alignment: choosing a partner whose purpose mirrors my own."
      ]
    },
    {
      q: "What place does quiet contemplation or meditation have in your routine?",
      sub: "Interiority practice.",
      opts: [
        "Essential daily anchor: morning meditation, prayer, or quiet reflection.",
        "Regular practice: walks in nature, journaling, or contemplative hobbies.",
        "Occasional reset during periods of high noise or transition.",
        "Integrated awareness throughout active daily tasks."
      ]
    },
    {
      q: "How do you define a life well-lived when looking back from old age?",
      sub: "Ultimate life reflection criteria.",
      opts: [
        "I lived authentically, loved courageously, and left no unsaid truths.",
        "I raised happy, grounded children and nurtured a loving lifelong bond.",
        "I created meaningful work and served my community with honor.",
        "I mastered peace of mind, experienced beauty, and grew in wisdom."
      ]
    },
    {
      q: "How do you approach contribution beyond your immediate family?",
      sub: "Transpersonal contribution drive.",
      opts: [
        "Dedicated to mentoring, teaching, and passing torch to future leaders.",
        "Creating sustainable systems, businesses, or non-profits that endure.",
        "Quiet daily acts of kindness, hospitality, and lifting neighbors.",
        "Writing, speaking, or sharing insights that elevate human understanding."
      ]
    },
    {
      q: "What gives you ultimate hope when the world feels turbulent?",
      sub: "Existential optimism source.",
      opts: [
        "The enduring human capacity for love, resilience, and scientific progress.",
        "My faith in spiritual truth and the innate goodness of human hearts.",
        "The sacred sanctuary of intimate partnership and family safety.",
        "Nature's eternal cycles and the historical arc toward justice."
      ]
    }
  ]
};

// Generate 100 questions cleanly distributed across the 8 domains
export const PSYCHOMETRIC_QUESTIONS: Question[] = [];

let questionId = 1;

DOMAINS.forEach((domain) => {
  const templates = domainTemplates[domain];
  templates.forEach((t) => {
    PSYCHOMETRIC_QUESTIONS.push({
      id: questionId++,
      domain,
      questionText: t.q,
      subtext: t.sub,
      options: t.opts.map((optText, idx) => ({
        id: `${questionId-1}_${idx}`,
        text: optText,
        traitWeight: {
          [domain]: (idx + 1) * 25
        }
      }))
    });
  });
});

// Ensure exactly 100 questions by supplementing additional high-depth questions if needed
while (PSYCHOMETRIC_QUESTIONS.length < 100) {
  const domIdx = PSYCHOMETRIC_QUESTIONS.length % DOMAINS.length;
  const domain = DOMAINS[domIdx];
  const qNum = PSYCHOMETRIC_QUESTIONS.length + 1;
  PSYCHOMETRIC_QUESTIONS.push({
    id: qNum,
    domain,
    questionText: `Under pressure, how do you align your ${domain.toLowerCase()} commitments with your long-term relationship vision?`,
    subtext: `Reflecting on your consistency in ${domain.toLowerCase()} when unexpected life events occur.`,
    options: [
      { id: `${qNum}_0`, text: "I maintain explicit, clear structure and re-negotiate agreements openly.", traitWeight: { [domain]: 100 } },
      { id: `${qNum}_1`, text: "I rely on intuitive empathy and emotional check-ins with my partner.", traitWeight: { [domain]: 75 } },
      { id: `${qNum}_2`, text: "I take time to reflect independently before taking corrective action.", traitWeight: { [domain]: 50 } },
      { id: `${qNum}_3`, text: "I adapt flexibly in the moment, prioritizing immediate peace.", traitWeight: { [domain]: 25 } }
    ]
  });
}
