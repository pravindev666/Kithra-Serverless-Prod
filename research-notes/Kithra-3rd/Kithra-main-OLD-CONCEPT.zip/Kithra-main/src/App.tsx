import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ActiveTab, AppMode, MatchUser, PsychometricReport } from './types';
import { DEFAULT_REPORT } from './data/mockReport';
import { MOCK_MATCHES } from './data/mockMatches';

// Components
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { LandingPage } from './components/LandingPage';
import { LoginPage } from './components/LoginPage';
import { SignupPage } from './components/SignupPage';
import { AssessmentView } from './components/AssessmentView';
import { CompatibilityReportView } from './components/CompatibilityReportView';
import { MatchesView } from './components/MatchesView';
import { MessagingView } from './components/MessagingView';
import { JournalView } from './components/JournalView';
import { ProfileView } from './components/ProfileView';
import { SettingsView } from './components/SettingsView';
import { AdminView } from './components/AdminView';
import { AuthModal } from './components/AuthModal';

// User Workspace Shell Components
import { UserSidebar } from './components/UserSidebar';
import { UserTopHeader } from './components/UserTopHeader';
import { HomeDashboardView } from './components/HomeDashboardView';
import { InsightsView } from './components/InsightsView';
import { BillingView } from './components/BillingView';
import { SecurityView } from './components/SecurityView';
import { KeyboardShortcutsOverlay } from './components/KeyboardShortcutsOverlay';
import { CommandPalette } from './components/CommandPalette';
import { useToast } from './components/ToastProvider';

export default function App() {
  const [appMode, setAppMode] = useState<AppMode>('public'); // Default to Public Marketing Site
  const [activeTab, setActiveTab] = useState<ActiveTab>('landing');
  const [isDarkMode, setIsDarkMode] = useState<boolean>(false);
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(true);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState<boolean>(false);
  const [isShortcutsOverlayOpen, setIsShortcutsOverlayOpen] = useState<boolean>(false);

  const [userReport, setUserReport] = useState<PsychometricReport>(DEFAULT_REPORT);
  const [activeChatMatch, setActiveChatMatch] = useState<MatchUser | null>(MOCK_MATCHES[0]);

  const { showToast } = useToast();

  // Sync Dark Mode class on document element
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Global Keyboard Shortcuts
  useEffect(() => {
    let pendingGKey = false;
    let gKeyTimeout: any = null;

    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if user is typing in an input field
      const target = e.target as HTMLElement;
      if (
        target.tagName === 'INPUT' ||
        target.tagName === 'TEXTAREA' ||
        target.isContentEditable ||
        target.tagName === 'SELECT'
      ) {
        return;
      }

      // Cmd+K / Ctrl+K -> Command Palette
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsCommandPaletteOpen(prev => !prev);
        return;
      }

      // ? -> Shortcuts overlay
      if (e.key === '?' && !e.metaKey && !e.ctrlKey) {
        e.preventDefault();
        setIsShortcutsOverlayOpen(prev => !prev);
        return;
      }

      // D -> Toggle Dark mode
      if (e.key.toLowerCase() === 'd' && !pendingGKey && !e.metaKey && !e.ctrlKey) {
        setIsDarkMode(prev => {
          const next = !prev;
          showToast(next ? 'Dark Canvas Activated' : 'Light Canvas Activated', 'info');
          return next;
        });
        return;
      }

      // Handle G + [key] navigation sequence
      if (e.key.toLowerCase() === 'g' && appMode === 'user') {
        pendingGKey = true;
        clearTimeout(gKeyTimeout);
        gKeyTimeout = setTimeout(() => {
          pendingGKey = false;
        }, 1000);
        return;
      }

      if (pendingGKey && appMode === 'user') {
        pendingGKey = false;
        clearTimeout(gKeyTimeout);
        const key = e.key.toLowerCase();

        const tabMap: Record<string, ActiveTab> = {
          h: 'home',
          a: 'assessment',
          r: 'report',
          m: 'matches',
          c: 'messages',
          j: 'journal',
          i: 'insights',
          p: 'profile',
          s: 'settings',
          b: 'billing',
          x: 'security',
        };

        if (tabMap[key]) {
          setActiveTab(tabMap[key]);
          showToast(`Navigated to ${tabMap[key].toUpperCase()}`, 'info');
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [appMode, showToast]);

  const handleCompleteAssessment = (report: PsychometricReport) => {
    setUserReport(report);
    setActiveTab('report');
    showToast('Assessment Completed! Diagnostic Dossier Generated', 'success');
  };

  const handleStartChatWithMatch = (match: MatchUser) => {
    setActiveChatMatch(match);
    setActiveTab('messages');
    showToast(`Signal E2E Chat Session Opened with ${match.name}`, 'info');
  };

  // MODE 1: Mission Control Admin Portal (Isolated Enterprise Dark App)
  if (appMode === 'admin') {
    return <AdminView setAppMode={setAppMode} />;
  }

  // MODE 2: Authenticated User Workspace Shell (Persistent Left Sidebar + Top Bar)
  if (appMode === 'user') {
    return (
      <div className="min-h-screen bg-kithra text-kithra font-body flex flex-col md:flex-row transition-colors duration-300">
        
        {/* Persistent Left Sidebar - Never unmounts or moves */}
        <UserSidebar 
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          setAppMode={setAppMode}
          onOpenUpgradeModal={() => setIsAuthModalOpen(true)}
        />

        {/* Workspace Right Pane */}
        <div className="flex-1 flex flex-col min-w-0 min-h-screen">
          
          {/* Top Bar Header */}
          <UserTopHeader 
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            isDarkMode={isDarkMode}
            setIsDarkMode={setIsDarkMode}
            setAppMode={setAppMode}
            onOpenCommandPalette={() => setIsCommandPaletteOpen(true)}
            onOpenShortcuts={() => setIsShortcutsOverlayOpen(true)}
          />

          {/* Dynamic Content Pane with Smooth Framer Motion Fade */}
          <main className={`flex-1 overflow-y-auto ${activeTab === 'messages' ? 'p-0 flex flex-col h-[calc(100vh-4rem)]' : 'p-4 sm:p-6 lg:p-8'}`}>
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2, ease: [0.2, 0, 0, 1] }}
                className="h-full"
              >
                {activeTab === 'home' && (
                  <HomeDashboardView 
                    setActiveTab={setActiveTab}
                    onStartChat={handleStartChatWithMatch}
                  />
                )}

                {activeTab === 'landing' && (
                  <LandingPage 
                    setActiveTab={setActiveTab}
                    onOpenAuth={() => setIsAuthModalOpen(true)}
                  />
                )}

                {activeTab === 'assessment' && (
                  <AssessmentView 
                    onCompleteAssessment={handleCompleteAssessment}
                  />
                )}

                {activeTab === 'report' && (
                  <CompatibilityReportView 
                    report={userReport}
                    onExploreMatches={() => setActiveTab('matches')}
                  />
                )}

                {activeTab === 'matches' && (
                  <MatchesView 
                    onStartChat={handleStartChatWithMatch}
                  />
                )}

                {activeTab === 'messages' && (
                  <MessagingView 
                    activeMatch={activeChatMatch}
                  />
                )}

                {activeTab === 'journal' && (
                  <JournalView />
                )}

                {activeTab === 'insights' && (
                  <InsightsView />
                )}

                {activeTab === 'profile' && (
                  <ProfileView />
                )}

                {activeTab === 'settings' && (
                  <SettingsView 
                    isDarkMode={isDarkMode}
                    setIsDarkMode={setIsDarkMode}
                  />
                )}

                {activeTab === 'billing' && (
                  <BillingView />
                )}

                {activeTab === 'security' && (
                  <SecurityView />
                )}
              </motion.div>
            </AnimatePresence>
          </main>

        </div>

        {/* Global Modals */}
        <AuthModal 
          isOpen={isAuthModalOpen}
          onClose={() => setIsAuthModalOpen(false)}
          onSuccessLogin={() => setIsLoggedIn(true)}
        />

        <CommandPalette 
          isOpen={isCommandPaletteOpen}
          onClose={() => setIsCommandPaletteOpen(false)}
          setActiveTab={setActiveTab}
          isDarkMode={isDarkMode}
          setIsDarkMode={setIsDarkMode}
        />

        <KeyboardShortcutsOverlay 
          isOpen={isShortcutsOverlayOpen}
          onClose={() => setIsShortcutsOverlayOpen(false)}
        />

      </div>
    );
  }

  // MODE 3: Public Unauthenticated Marketing Site
  return (
    <div className="min-h-screen bg-kithra text-kithra font-body transition-colors duration-300 flex flex-col justify-between relative z-0">
      <div className="ambient-bg" />
      
      {/* Public Header Navbar */}
      <Navbar 
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        appMode={appMode}
        setAppMode={setAppMode}
        isDarkMode={isDarkMode}
        setIsDarkMode={setIsDarkMode}
        onOpenAuth={() => setIsAuthModalOpen(true)}
        isLoggedIn={isLoggedIn}
      />

      {/* Main Public Page Pane */}
      <main className="flex-1">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.25, ease: [0.2, 0, 0, 1] }}
          >
            {activeTab === 'login' ? (
              <LoginPage 
                setActiveTab={setActiveTab}
                setAppMode={setAppMode}
                onLoginSuccess={() => {
                  setIsLoggedIn(true);
                  showToast('Welcome back, Dr. Ananya! Authenticated into Kithra OS.', 'success');
                }}
              />
            ) : activeTab === 'signup' ? (
              <SignupPage 
                setActiveTab={setActiveTab}
                setAppMode={setAppMode}
                onSignupSuccess={() => {
                  setIsLoggedIn(true);
                  showToast('Account Created! Welcome to Kithra OS.', 'success');
                }}
              />
            ) : (
              <LandingPage 
                setActiveTab={(tab) => {
                  if (tab === 'login' || tab === 'signup') {
                    setActiveTab(tab);
                  } else {
                    setAppMode('user');
                    setActiveTab(tab);
                  }
                }}
                onOpenAuth={() => setIsAuthModalOpen(true)}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Footer */}
      <Footer 
        setActiveTab={(tab) => {
          if (tab === 'login' || tab === 'signup') {
            setActiveTab(tab);
          } else {
            setAppMode('user');
            setActiveTab(tab);
          }
        }}
      />

      {/* Auth Modal */}
      <AuthModal 
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onSuccessLogin={() => {
          setIsLoggedIn(true);
          showToast('Successfully logged in', 'success');
        }}
      />

      <KeyboardShortcutsOverlay 
        isOpen={isShortcutsOverlayOpen}
        onClose={() => setIsShortcutsOverlayOpen(false)}
      />

    </div>
  );
}

