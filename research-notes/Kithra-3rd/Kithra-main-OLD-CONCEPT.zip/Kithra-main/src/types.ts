export type ActiveTab = 
  | 'home'
  | 'landing' 
  | 'assessment' 
  | 'report' 
  | 'matches' 
  | 'messages' 
  | 'journal' 
  | 'insights' 
  | 'profile' 
  | 'settings'
  | 'billing'
  | 'security' 
  | 'admin';

export type AppMode = 'public' | 'user' | 'admin';

export type ProfileSubTab = 
  | 'Identity'
  | 'Verification'
  | 'Values'
  | 'Lifestyle'
  | 'Career'
  | 'Religion'
  | 'Family'
  | 'Habits'
  | 'Photos'
  | 'Compatibility DNA';

export type ReportSubTab = 
  | 'Overview'
  | 'Communication'
  | 'Lifestyle'
  | 'Family'
  | 'Conflict'
  | 'Growth'
  | 'Financial'
  | 'Parenting'
  | 'Summary'
  | 'Recommendations';

export type QuestionDomain = 
  | 'Communication'
  | 'Values'
  | 'Lifestyle'
  | 'Emotions'
  | 'Goals'
  | 'Family'
  | 'Conflict'
  | 'Purpose';

export interface QuestionOption {
  id: string;
  text: string;
  traitWeight: Record<string, number>;
}

export interface Question {
  id: number;
  domain: QuestionDomain;
  questionText: string;
  subtext?: string;
  options: QuestionOption[];
}

export interface DomainScore {
  domain: QuestionDomain;
  score: number; // 0 to 100
  label: string; // e.g., 'Exceptional', 'Very Strong', 'Moderate'
  summary: string;
  details: string;
}

export interface PsychometricReport {
  overallSelfAwareness: number;
  communicationStyle: string;
  conflictStyle: string;
  stressResponse: string;
  loveLanguagePrimary: string;
  attachmentStyle: string;
  financialBehavior: string;
  growthMindsetScore: number;
  domainScores: DomainScore[];
  keyStrengths: string[];
  growthAreas: string[];
}

export interface MatchUser {
  id: string;
  name: string;
  age: number;
  location: string;
  avatarUrl: string;
  isVerified: boolean;
  matchPercentage: number; // 100, 90, 80, 70, 60, etc.
  tagline: string;
  profession: string;
  communicationStyle: string;
  conflictStyle: string;
  topSharedValues: string[];
  whyYouAlign: string;
  potentialFrictionPoint: string;
  verifiedBadges: string[];
  bio: string;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  text: string;
  timestamp: string;
  isEncrypted: boolean;
  isVoiceNote?: boolean;
  voiceDuration?: string;
  image?: string;
}

export interface JournalEntry {
  id: string;
  date: string;
  title: string;
  content: string;
  domain: QuestionDomain;
  insight: string;
}

export interface FAQItem {
  question: string;
  answer: string;
  category: 'Science & Methodology' | 'Privacy & Security' | 'Matches & Platform' | 'Pricing & Account';
}
