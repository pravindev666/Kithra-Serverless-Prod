import React from 'react';

interface WordmarkProps {
  className?: string;
  showTagline?: boolean;
}

export const Wordmark: React.FC<WordmarkProps> = ({ className = '', showTagline = false }) => {
  return (
    <div className={`inline-flex items-center gap-3.5 ${className}`}>
      <span className="relative grid h-8 w-8 place-items-center rounded-full border border-[var(--accent-sage)]/60 bg-[var(--surface-main)] shadow-xs">
        <span className="h-2.5 w-2.5 rounded-full bg-[var(--coral-error)]" />
        <span className="absolute inset-0 rounded-full border border-[var(--gold-verify)] opacity-30 animate-pulse" />
      </span>
      <div className="flex flex-col">
        <span className="text-xl font-bold tracking-tight text-kithra font-heading lowercase">
          kithra
        </span>
        {showTagline && (
          <span className="text-[10px] font-mono tracking-widest text-kithra-muted uppercase -mt-1 font-data">
            Human Compatibility OS
          </span>
        )}
      </div>
    </div>
  );
};
