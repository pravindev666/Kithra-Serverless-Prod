import React, { useState } from 'react';
import { ActiveTab, AppMode } from '../types';
import { Heart, Compass, ShieldCheck, ArrowRight, Smartphone, Mail, Lock } from 'lucide-react';

interface LoginPageProps {
  setActiveTab: (tab: ActiveTab) => void;
  setAppMode: (mode: AppMode) => void;
  onLoginSuccess: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ setActiveTab, setAppMode, onLoginSuccess }) => {
  const [authMethod, setAuthMethod] = useState<'email' | 'mobile'>('email');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLoginSuccess();
    setAppMode('user');
    setActiveTab('home');
  };

  return (
    <div className="min-h-[calc(100vh-80px)] w-full grid grid-cols-1 lg:grid-cols-2 bg-[var(--bg-main)]">
      
      {/* Left Column - Calming Brand Panel */}
      <div className="hidden lg:flex flex-col items-center justify-center p-12 bg-[#E1E6DC] text-[#17181C] relative border-r border-[#D0D7CA]">
        <div className="max-w-md text-center space-y-6">
          <div className="w-20 h-20 rounded-full border-2 border-[#0D9488]/40 flex items-center justify-center mx-auto text-[#0D9488] shadow-xs bg-white/40">
            <Heart className="w-10 h-10 stroke-[1.5]" />
          </div>

          <div className="space-y-3">
            <h1 className="font-heading font-extrabold text-3xl sm:text-4xl text-[#17181C] tracking-tight leading-tight">
              Welcome back to Kithra.
            </h1>
            <p className="font-body text-sm sm:text-base text-[#4A5043] leading-relaxed">
              Continue your journey of self-discovery and meaningful connection.
            </p>
          </div>

          <div className="pt-8 flex items-center justify-center gap-6 text-xs text-[#5C6354] font-data">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-[#0D9488]" />
              Government Verified
            </span>
            <span>•</span>
            <span className="flex items-center gap-1.5">
              <Compass className="w-4 h-4 text-[#0D9488]" />
              Psychometric Alignment
            </span>
          </div>
        </div>

        {/* Bottom subtle copyright */}
        <div className="absolute bottom-6 font-data text-[11px] text-[#7A8272]">
          KITHRA • Human Compatibility Operating System
        </div>
      </div>

      {/* Right Column - Login Credentials Form */}
      <div className="flex flex-col justify-center items-center p-6 sm:p-12 lg:p-16 bg-[var(--surface-main)]">
        <div className="w-full max-w-md space-y-8">
          
          {/* Header */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h2 className="font-heading font-extrabold text-2xl sm:text-3xl text-kithra tracking-tight">
                Log in
              </h2>
              <div className="flex rounded-lg border border-kithra p-0.5 bg-[var(--bg-main)] text-[11px] font-data">
                <button
                  type="button"
                  onClick={() => setAuthMethod('email')}
                  className={`px-2.5 py-1 rounded-md transition-colors ${authMethod === 'email' ? 'bg-[#0D9488] text-white font-bold' : 'text-kithra-muted'}`}
                >
                  Email
                </button>
                <button
                  type="button"
                  onClick={() => setAuthMethod('mobile')}
                  className={`px-2.5 py-1 rounded-md transition-colors ${authMethod === 'mobile' ? 'bg-[#0D9488] text-white font-bold' : 'text-kithra-muted'}`}
                >
                  Mobile OTP
                </button>
              </div>
            </div>
            <p className="text-xs sm:text-sm text-kithra-muted">
              Enter your credentials to continue.
            </p>
          </div>

          {/* Form */}
          {authMethod === 'email' ? (
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-1.5">
                <label className="font-data text-xs font-semibold text-kithra uppercase block">
                  Email
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="w-full px-4 py-3 rounded-xl bg-[var(--bg-main)] border border-kithra text-xs font-body text-kithra focus:outline-none focus:border-[var(--accent-sage)] transition-colors"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="font-data text-xs font-semibold text-kithra uppercase block">
                    Password
                  </label>
                  <a href="#forgot" onClick={(e) => { e.preventDefault(); alert("Password reset link sent to your email!"); }} className="text-[11px] font-data text-kithra-muted hover:text-[var(--accent-sage)]">
                    Forgot password?
                  </a>
                </div>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full px-4 py-3 rounded-xl bg-[var(--bg-main)] border border-kithra text-xs font-body text-kithra focus:outline-none focus:border-[var(--accent-sage)] transition-colors"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full py-3.5 rounded-xl bg-[#17181C] hover:bg-black text-white font-heading font-bold text-xs uppercase tracking-wider shadow-sm transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <span>Continue</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          ) : (
            <form onSubmit={otpSent ? handleSubmit : (e) => { e.preventDefault(); setOtpSent(true); }} className="space-y-5">
              {!otpSent ? (
                <div className="space-y-1.5">
                  <label className="font-data text-xs font-semibold text-kithra uppercase block">
                    Mobile Number (+91 India)
                  </label>
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-3 rounded-xl bg-[var(--bg-main)] border border-kithra font-data text-xs text-kithra font-bold">
                      +91
                    </span>
                    <input
                      type="tel"
                      value={mobileNumber}
                      onChange={(e) => setMobileNumber(e.target.value)}
                      placeholder="98765 43210"
                      className="flex-1 px-4 py-3 rounded-xl bg-[var(--bg-main)] border border-kithra text-xs font-data text-kithra focus:outline-none focus:border-[var(--accent-sage)]"
                      required
                    />
                  </div>
                </div>
              ) : (
                <div className="space-y-1.5">
                  <label className="font-data text-xs font-semibold text-kithra uppercase block">
                    Enter 6-Digit OTP Code
                  </label>
                  <input
                    type="text"
                    value={otpCode}
                    onChange={(e) => setOtpCode(e.target.value)}
                    placeholder="123456"
                    maxLength={6}
                    className="w-full px-4 py-3 rounded-xl bg-[var(--bg-main)] border border-kithra text-center font-data text-lg tracking-widest text-kithra focus:outline-none focus:border-[var(--accent-sage)]"
                    required
                  />
                  <p className="text-[11px] font-data text-kithra-muted">
                    Test OTP: <span className="font-bold text-kithra">123456</span>
                  </p>
                </div>
              )}

              <button
                type="submit"
                className="w-full py-3.5 rounded-xl bg-[#0D9488] hover:bg-[#0B7C72] text-white font-heading font-bold text-xs uppercase tracking-wider shadow-sm transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <span>{otpSent ? 'Verify & Enter Workspace OS' : 'Send Mobile Verification Code'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {/* Social Auth Separator */}
          <div className="relative py-2">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-kithra" />
            </div>
            <div className="relative flex justify-center text-xs uppercase font-data">
              <span className="bg-[var(--surface-main)] px-3 text-kithra-muted text-[11px]">
                Or continue with
              </span>
            </div>
          </div>

          {/* Social OAuth Buttons */}
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={handleSubmit}
              className="py-2.5 px-4 rounded-xl border border-kithra bg-[var(--bg-main)] text-kithra font-heading font-semibold text-xs hover:border-kithra-muted transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
              </svg>
              <span>Google</span>
            </button>

            <button
              type="button"
              onClick={handleSubmit}
              className="py-2.5 px-4 rounded-xl border border-kithra bg-[var(--bg-main)] text-kithra font-heading font-semibold text-xs hover:border-kithra-muted transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <svg className="w-4 h-4 fill-current text-kithra" viewBox="0 0 24 24">
                <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 6.32c.67-.82 1.12-1.97.99-3.12-1.01.04-2.24.67-2.95 1.5-.62.72-1.15 1.89-1 3.02 1.13.09 2.28-.58 2.96-1.4z"/>
              </svg>
              <span>Apple</span>
            </button>
          </div>

          {/* Footer Navigation */}
          <div className="text-center pt-2">
            <span className="text-xs text-kithra-muted font-body">
              Don't have an account?{' '}
            </span>
            <button
              onClick={() => setActiveTab('signup')}
              className="text-xs font-heading font-bold text-[#0D9488] hover:underline cursor-pointer"
            >
              Begin Your Compatibility Journey.
            </button>
          </div>

        </div>
      </div>

    </div>
  );
};
