import React from 'react';
import { ActiveTab, MatchUser } from '../types';
import { MOCK_MATCHES } from '../data/mockMatches';
import { 
  Sparkles, 
  Brain, 
  ArrowRight, 
  ShieldCheck, 
  Users, 
  MessageSquare, 
  BookOpen, 
  TrendingUp, 
  Flame,
  Clock,
  Target,
  CheckCircle2
} from 'lucide-react';

interface HomeDashboardViewProps {
  setActiveTab: (tab: ActiveTab) => void;
  onStartChat: (match: MatchUser) => void;
}

export const HomeDashboardView: React.FC<HomeDashboardViewProps> = ({
  setActiveTab,
  onStartChat
}) => {
  return (
    <div className="max-w-6xl mx-auto space-y-8 pb-12">
      
      {/* SECTION 1: TODAY'S MISSION CARD (Single Objective to reduce decision fatigue) */}
      <div className="p-8 rounded-3xl bg-gradient-to-br from-[var(--surface-main)] via-[var(--bg-main)] to-[var(--surface-main)] border border-[var(--accent-sage)]/25 shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-[var(--accent-sage)]/5 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="space-y-3 max-w-xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[var(--accent-sage)]/10 text-[var(--accent-sage)] font-heading text-[11px] font-bold uppercase tracking-wider">
              <Target className="w-3.5 h-3.5" />
              <span>Today's Mission</span>
            </div>

            <h1 className="font-heading font-extrabold text-3xl sm:text-4xl text-kithra tracking-tight">
              Complete 7 Diagnostic Questions
            </h1>

            <p className="font-body text-sm text-kithra-muted leading-relaxed">
              Unlock deep compatibility analysis for Conflict Resolution & Emotional Regulation.
            </p>

            <div className="flex items-center gap-4 text-xs font-body text-kithra-muted pt-2">
              <span className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-[var(--accent-sage)]" />
                <span>Est. 3 mins remaining</span>
              </span>
              <span>•</span>
              <span className="flex items-center gap-1.5 text-emerald-600 font-medium">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                <span>Autosaved locally</span>
              </span>
            </div>
          </div>

          <div className="shrink-0 flex flex-col sm:flex-row md:flex-col items-stretch gap-3">
            <button
              onClick={() => setActiveTab('assessment')}
              className="px-8 py-4 rounded-2xl bg-[var(--accent-sage)] hover:opacity-90 text-white font-heading font-bold text-sm flex items-center justify-center gap-3 shadow-sm hover:shadow-md transition-all cursor-pointer group"
            >
              <Brain className="w-5 h-5 group-hover:scale-110 transition-transform" />
              <span>Continue Mission</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* SECTION 2: RELATIONSHIP READINESS & GROWTH CONTEXT */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Readiness Index */}
        <div className="p-6 rounded-3xl bg-[var(--surface-main)] border border-kithra/15 space-y-4 shadow-soft">
          <div className="flex items-center justify-between">
            <span className="font-heading text-xs uppercase tracking-wider text-kithra-muted font-bold">Relationship Readiness</span>
            <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-600 font-heading text-[10px] font-bold flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              <span>+4% this month</span>
            </span>
          </div>

          <div className="flex items-baseline gap-3">
            <span className="font-heading font-extrabold text-5xl text-kithra">82%</span>
            <span className="font-heading text-xs text-[var(--accent-sage)] font-bold">HIGH ALIGNMENT</span>
          </div>

          <div className="space-y-2 pt-2 border-t border-kithra/10 text-xs font-body">
            <div className="flex justify-between">
              <span className="text-kithra-muted">Strongest Trait:</span>
              <strong className="text-kithra font-heading">Communication (92%)</strong>
            </div>
            <div className="flex justify-between">
              <span className="text-kithra-muted">Needs Attention:</span>
              <strong className="text-[var(--gold-verify)] font-heading">Conflict Style (68%)</strong>
            </div>
          </div>
        </div>

        {/* Streak & Active Reflections */}
        <div className="p-6 rounded-3xl bg-[var(--surface-main)] border border-kithra/15 space-y-4 shadow-soft">
          <div className="flex items-center justify-between">
            <span className="font-heading text-xs uppercase tracking-wider text-kithra-muted font-bold">Self-Growth Streak</span>
            <span className="px-2 py-0.5 rounded bg-amber-500/10 text-amber-500 font-heading text-[10px] font-bold flex items-center gap-1">
              <Flame className="w-3.5 h-3.5 fill-current" />
              <span>5 Days Active</span>
            </span>
          </div>

          <div className="space-y-1">
            <h4 className="font-heading font-bold text-lg text-kithra">Daily Insight Reflection</h4>
            <p className="font-serif italic text-xs text-kithra-muted leading-relaxed">
              "You prioritize emotional safety and structured pauses during escalation."
            </p>
          </div>

          <button 
            onClick={() => setActiveTab('journal')}
            className="w-full py-2.5 rounded-xl border border-kithra/15 hover:border-[var(--accent-sage)] text-xs font-heading font-bold text-kithra transition-colors cursor-pointer flex items-center justify-center gap-2"
          >
            <BookOpen className="w-4 h-4 text-[var(--accent-sage)]" />
            <span>Open Knowledge Base</span>
          </button>
        </div>

        {/* Live Active Introductions */}
        <div className="p-6 rounded-3xl bg-[var(--surface-main)] border border-kithra/15 space-y-4 shadow-soft">
          <div className="flex items-center justify-between">
            <span className="font-heading text-xs uppercase tracking-wider text-kithra-muted font-bold">Curated Network</span>
            <span className="px-2 py-0.5 rounded bg-[var(--gold-verify)]/10 text-[var(--gold-verify)] font-heading text-[10px] font-bold">
              3 Verified
            </span>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex -space-x-3">
              {MOCK_MATCHES.slice(0, 3).map((m) => (
                <img key={m.id} src={m.avatarUrl} alt={m.name} className="w-10 h-10 rounded-full border-2 border-[var(--surface-main)] object-cover" />
              ))}
            </div>
            <div>
              <span className="font-heading font-bold text-sm text-kithra block">3 Matches Ready</span>
              <span className="font-body text-[11px] text-kithra-muted">Signal E2E Chat active</span>
            </div>
          </div>

          <button 
            onClick={() => setActiveTab('matches')}
            className="w-full py-2.5 rounded-xl bg-[var(--bg-main)] hover:bg-[var(--accent-sage)] hover:text-white text-xs font-heading font-bold transition-all cursor-pointer flex items-center justify-center gap-2 border border-kithra/15 text-kithra"
          >
            <Users className="w-4 h-4" />
            <span>Research Matches</span>
          </button>
        </div>

      </div>

      {/* SECTION 3: TOP RESEARCH MATCHES */}
      <div className="space-y-4 pt-4">
        <div className="flex items-center justify-between">
          <h3 className="font-heading font-bold text-xl text-kithra">Top Introduced Compatibility Dossiers</h3>
          <button 
            onClick={() => setActiveTab('matches')}
            className="font-body text-xs font-semibold text-[var(--accent-sage)] hover:opacity-80 transition-opacity flex items-center gap-1 cursor-pointer"
          >
            <span>View All Research Folders</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {MOCK_MATCHES.slice(0, 3).map((match) => (
            <div 
              key={match.id}
              className="p-6 rounded-3xl bg-[var(--surface-main)] border border-kithra/15 space-y-4 hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <img 
                    src={match.avatarUrl} 
                    alt={match.name}
                    className="w-12 h-12 rounded-2xl object-cover"
                  />
                  <div>
                    <div className="flex items-center gap-1">
                      <h4 className="font-heading font-bold text-base text-kithra">{match.name}, {match.age}</h4>
                      <ShieldCheck className="w-3.5 h-3.5 text-[var(--gold-verify)]" />
                    </div>
                    <p className="text-xs font-body text-kithra-muted">{match.profession}</p>
                  </div>
                </div>

                <div className="px-2.5 py-1 rounded-full bg-[var(--accent-sage)]/10 text-[var(--accent-sage)] font-heading text-[10px] font-bold inline-block border border-[var(--accent-sage)]/20">
                  {match.matchPercentage}% Alignment
                </div>

                <p className="font-serif italic text-xs text-kithra-muted leading-relaxed">
                  "{match.tagline}"
                </p>
              </div>

              <button
                onClick={() => onStartChat(match)}
                className="w-full py-2.5 rounded-xl bg-[var(--bg-main)] hover:bg-[var(--accent-sage)] hover:text-white text-xs font-heading font-bold flex items-center justify-center gap-2 border border-kithra/15 transition-all cursor-pointer text-kithra"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Open Signal Chat</span>
              </button>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};

