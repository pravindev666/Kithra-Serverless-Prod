import React, { useState } from 'react';
import { JournalEntry, QuestionDomain } from '../types';
import { DOMAINS } from '../data/questions';
import { 
  BookOpen, 
  Plus, 
  Sparkles, 
  Calendar, 
  Brain, 
  Trash2, 
  Save 
} from 'lucide-react';

export const JournalView: React.FC = () => {
  const [entries, setEntries] = useState<JournalEntry[]>([
    {
      id: 'j1',
      date: '2026-08-04',
      title: 'Reflecting on my Conflict Pause Pattern',
      content: 'During today’s team review at work, I noticed my immediate instinct when tension rose was to step away for 15 minutes before offering a response. Taking that time allowed me to separate emotional heat from the core operational problem. This aligns 100% with my Kithra assessment result.',
      domain: 'Conflict',
      insight: 'A 15-minute pause is not avoidance; it is a sacred boundary protecting relationship safety.'
    },
    {
      id: 'j2',
      date: '2026-07-28',
      title: 'Morning Sanctuary & Solitude',
      content: 'Woke up at 6:00 AM, brewed filter coffee, and spent 45 minutes reading in complete quiet. Having this uninterrupted individual space grounds my entire day and makes me significantly more patient in my interactions.',
      domain: 'Lifestyle',
      insight: 'Individual solitude nourishes collective partnership harmony.'
    }
  ]);

  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newDomain, setNewDomain] = useState<QuestionDomain>('Communication');
  const [showAddForm, setShowAddForm] = useState(false);

  const handleAddEntry = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newContent.trim()) return;

    const newEntry: JournalEntry = {
      id: `j_${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      title: newTitle,
      content: newContent,
      domain: newDomain,
      insight: 'Generated reflection based on your psychological baseline.'
    };

    setEntries([newEntry, ...entries]);
    setNewTitle('');
    setNewContent('');
    setShowAddForm(false);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Minimalist Header */}
      <div className="py-8 border-b border-kithra/30 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-4">
            <div className="inline-flex items-center gap-2 font-data text-xs uppercase tracking-widest font-bold text-kithra-muted">
              <BookOpen className="w-4 h-4 text-[var(--accent-sage)]" />
              Private Reflection Space
            </div>
            <h1 className="font-heading font-extrabold text-4xl sm:text-5xl text-kithra leading-tight">
              Self-Discovery Journal
            </h1>
            <p className="font-serif italic text-xl text-kithra-muted">
              "Understanding the self is the prerequisite to understanding the other."
            </p>
          </div>

          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="px-6 py-3 rounded-2xl bg-[var(--bg-main)] border border-kithra/50 hover:bg-[var(--accent-sage)] hover:text-white hover:border-transparent font-heading font-bold text-[13px] text-kithra flex items-center gap-2 shadow-soft transition-all cursor-pointer shrink-0"
          >
            {showAddForm ? <Trash2 className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
            <span>{showAddForm ? 'Discard Entry' : 'New Entry'}</span>
          </button>
        </div>
      </div>

      {/* Add Entry Form (Minimalist Notebook Style) */}
      {showAddForm && (
        <form onSubmit={handleAddEntry} className="py-8 space-y-6 animate-rise">
          <div className="space-y-4">
            <input 
              type="text"
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              placeholder="Entry Title..."
              className="w-full bg-transparent border-none text-2xl sm:text-3xl font-heading font-bold text-kithra placeholder:text-kithra-muted/40 focus:outline-none focus:ring-0"
              required
              autoFocus
            />

            <div className="flex items-center gap-4 text-xs font-data">
              <span className="text-kithra-muted font-bold uppercase tracking-widest">{new Date().toLocaleDateString()}</span>
              <select
                value={newDomain}
                onChange={(e) => setNewDomain(e.target.value as QuestionDomain)}
                className="bg-transparent border-none text-[var(--accent-sage)] font-bold focus:outline-none focus:ring-0 cursor-pointer uppercase tracking-widest"
              >
                {DOMAINS.map(d => (
                  <option key={d} value={d} className="text-kithra">{d} DOMAIN</option>
                ))}
              </select>
            </div>
          </div>

          <textarea
            value={newContent}
            onChange={(e) => setNewContent(e.target.value)}
            placeholder="Write your reflection here..."
            rows={8}
            className="w-full bg-transparent border-none text-base sm:text-lg font-body text-kithra leading-relaxed placeholder:text-kithra-muted/40 focus:outline-none focus:ring-0 resize-none"
            required
          />

          <div className="flex justify-end pt-4 border-t border-kithra/20">
            <button
              type="submit"
              className="px-8 py-3 rounded-xl bg-[var(--accent-sage)] hover:opacity-90 text-white font-heading font-bold text-[13px] flex items-center gap-2 shadow-md cursor-pointer transition-opacity"
            >
              <Save className="w-4 h-4" />
              <span>Save to Private Ledger</span>
            </button>
          </div>
        </form>
      )}

      {/* Entry List (Paper Style) */}
      <div className="space-y-12 pt-8">
        {entries.map((entry) => (
          <div 
            key={entry.id}
            className="pb-12 border-b border-kithra/20 space-y-6"
          >
            <div className="space-y-3">
              <div className="flex items-center gap-4 text-[11px] font-data font-bold uppercase tracking-widest text-kithra-muted">
                <span>{entry.date}</span>
                <span className="w-1 h-1 rounded-full bg-kithra/30" />
                <span className="text-[var(--accent-sage)]">{entry.domain} Domain</span>
              </div>

              <h3 className="font-heading font-bold text-2xl sm:text-3xl text-kithra">
                {entry.title}
              </h3>
            </div>

            <p className="font-body text-base sm:text-lg text-kithra leading-[1.8]">
              {entry.content}
            </p>

            {entry.insight && (
              <div className="mt-8 p-6 rounded-[2rem] bg-[var(--surface-main)] border border-kithra/40 flex items-start gap-4">
                <Sparkles className="w-6 h-6 text-[var(--accent-sage)] shrink-0 mt-1" />
                <div className="space-y-1">
                  <span className="font-data text-xs uppercase tracking-widest text-[var(--accent-sage)] font-bold block">
                    Synthesized Insight
                  </span>
                  <p className="font-serif italic text-lg text-kithra">
                    "{entry.insight}"
                  </p>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

    </div>
  );
};
