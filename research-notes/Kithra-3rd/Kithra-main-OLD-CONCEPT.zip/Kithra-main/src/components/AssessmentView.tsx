import React, { useState, useEffect } from 'react';
import { PSYCHOMETRIC_QUESTIONS, DOMAINS } from '../data/questions';
import { QuestionDomain, PsychometricReport } from '../types';
import { DEFAULT_REPORT } from '../data/mockReport';
import { 
  ArrowLeft, 
  ArrowRight, 
  CheckCircle2, 
  Brain, 
  RotateCcw, 
  Sparkles,
  Layers,
  ChevronRight,
  Info,
  HelpCircle,
  Clock,
  Keyboard
} from 'lucide-react';

interface AssessmentViewProps {
  onCompleteAssessment: (report: PsychometricReport) => void;
}

export const AssessmentView: React.FC<AssessmentViewProps> = ({ onCompleteAssessment }) => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState<number>(0);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [selectedDomain, setSelectedDomain] = useState<QuestionDomain | 'Overview'>('Overview');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showScientificContext, setShowScientificContext] = useState(false);

  // Load saved answers from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('kithra_assessment_answers');
    if (saved) {
      try {
        setAnswers(JSON.parse(saved));
      } catch (e) {
        console.error(e);
      }
    }
  }, []);

  const totalQuestions = PSYCHOMETRIC_QUESTIONS.length;
  const answeredCount = Object.keys(answers).length;
  const overallProgress = Math.round((answeredCount / totalQuestions) * 100);

  const filteredQuestions = selectedDomain === 'Overview' 
    ? PSYCHOMETRIC_QUESTIONS 
    : PSYCHOMETRIC_QUESTIONS.filter(q => q.domain === selectedDomain);

  const currentQuestion = filteredQuestions[currentQuestionIndex] || PSYCHOMETRIC_QUESTIONS[0];

  const handleSelectOption = (questionId: number, optionId: string) => {
    const updated = { ...answers, [questionId]: optionId };
    setAnswers(updated);
    localStorage.setItem('kithra_assessment_answers', JSON.stringify(updated));

    if (currentQuestionIndex < filteredQuestions.length - 1) {
      setTimeout(() => {
        setCurrentQuestionIndex(prev => prev + 1);
        setShowScientificContext(false);
      }, 250);
    }
  };

  // Keyboard navigation (1, 2, 3, 4 for options, Arrow keys)
  useEffect(() => {
    if (selectedDomain === 'Overview' || !currentQuestion) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (['1', '2', '3', '4'].includes(e.key)) {
        const optionIdx = parseInt(e.key, 10) - 1;
        if (currentQuestion.options[optionIdx]) {
          handleSelectOption(currentQuestion.id, currentQuestion.options[optionIdx].id);
        }
      } else if (e.key === 'ArrowRight' && currentQuestionIndex < filteredQuestions.length - 1) {
        setCurrentQuestionIndex(prev => prev + 1);
        setShowScientificContext(false);
      } else if (e.key === 'ArrowLeft' && currentQuestionIndex > 0) {
        setCurrentQuestionIndex(prev => prev - 1);
        setShowScientificContext(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedDomain, currentQuestionIndex, filteredQuestions, currentQuestion]);

  const handleFinish = () => {
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      onCompleteAssessment(DEFAULT_REPORT);
    }, 1000);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Top Assessment Header */}
      <div className="py-4 space-y-6 relative">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-[1.25rem] bg-[var(--accent-sage)] text-white flex items-center justify-center font-bold shadow-soft">
              <Brain className="w-6 h-6" />
            </div>
            <div>
              <h1 className="font-heading font-extrabold text-2xl sm:text-3xl text-kithra">
                Intelligence Assessment Engine
              </h1>
              <div className="flex items-center gap-3 text-xs font-data text-kithra-muted mt-1 font-semibold">
                <span className="flex items-center gap-1 text-[var(--accent-sage)]">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Est. {Math.ceil((totalQuestions - answeredCount) * 0.4)} mins remaining</span>
                </span>
                <span>•</span>
                <span className="flex items-center gap-1 text-emerald-500 font-bold">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Autosaved</span>
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <span className="font-data text-xs font-bold text-kithra">
              {answeredCount} / {totalQuestions} ({overallProgress}%)
            </span>
            <button
              onClick={() => {
                if (confirm("Reset assessment progress?")) {
                  setAnswers({});
                  localStorage.removeItem('kithra_assessment_answers');
                  setCurrentQuestionIndex(0);
                  setSelectedDomain('Overview');
                }
              }}
              className="px-3 py-1.5 rounded-xl border border-kithra/40 text-kithra-muted hover:text-kithra text-[11px] font-heading font-bold flex items-center gap-1.5 cursor-pointer hover:bg-[var(--surface-main)] transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset</span>
            </button>
          </div>
        </div>

        {/* Overall Progress */}
        <div className="space-y-2 pt-2">
          <div className="h-1.5 w-full bg-[var(--surface-main)] rounded-full overflow-hidden border border-kithra/40 shadow-inner">
            <div 
              className="h-full bg-[var(--accent-sage)] rounded-full transition-all duration-500"
              style={{ width: `${overallProgress}%` }}
            />
          </div>
        </div>
      </div>

      {/* Domain Modules Grid Overview */}
      <div className="space-y-6 pt-6">
        <div className="flex items-center justify-between">
          <h2 className="font-heading font-extrabold text-xl text-kithra flex items-center gap-2">
            <Layers className="w-5 h-5 text-[var(--accent-sage)]" />
            <span>Select Psychometric Module</span>
          </h2>
          <div className="hidden sm:flex items-center gap-1 text-xs font-data text-kithra-muted">
            <Keyboard className="w-3.5 h-3.5" />
            <span>Press 1-4 to choose options</span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          {DOMAINS.map((domain) => {
            const domainQCount = PSYCHOMETRIC_QUESTIONS.filter(q => q.domain === domain).length;
            const domainAnswered = PSYCHOMETRIC_QUESTIONS.filter(q => q.domain === domain && answers[q.id]).length;
            const domainPct = Math.round((domainAnswered / domainQCount) * 100);
            const isSelected = selectedDomain === domain;

            return (
              <button
                key={domain}
                onClick={() => {
                  setSelectedDomain(domain);
                  setCurrentQuestionIndex(0);
                  setShowScientificContext(false);
                }}
                className={`p-5 rounded-3xl border text-left transition-all space-y-3 cursor-pointer shadow-soft hover:shadow-hover ${
                  isSelected 
                    ? 'bg-[var(--surface-main)] border-[var(--accent-sage)] text-[var(--accent-sage)] shadow-md scale-[1.02]' 
                    : 'bg-[var(--surface-main)] border-kithra/40 text-kithra hover:border-kithra/60'
                }`}
              >
                <div className="flex items-center justify-between text-[13px] font-heading">
                  <span className="font-bold">{domain}</span>
                  <span className="font-data text-[10px] font-bold text-kithra-muted">{domainPct}%</span>
                </div>

                {/* Progress bar inside module */}
                <div className="h-1 w-full bg-[var(--bg-main)] rounded-full overflow-hidden shadow-inner">
                  <div 
                    className={`h-full rounded-full transition-all ${isSelected ? 'bg-[var(--accent-sage)]' : 'bg-[#0D9488]'}`}
                    style={{ width: `${domainPct}%` }}
                  />
                </div>

                <div className="text-[10px] font-data text-kithra-muted flex items-center justify-between font-bold">
                  <span>{domainAnswered} / {domainQCount} Qs</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Questions Card */}
      {selectedDomain !== 'Overview' ? (
        <div className="mt-12 p-8 sm:p-14 rounded-[2.5rem] bg-[var(--surface-main)] border border-kithra/40 space-y-8 min-h-[500px] flex flex-col justify-between shadow-soft view-fade-enter">
          <div className="space-y-6 max-w-3xl mx-auto w-full text-center">
            
            <div className="flex items-center justify-between text-[11px] font-data font-bold">
              <span className="text-[var(--accent-sage)] tracking-widest uppercase">
                {currentQuestion.domain} Domain
              </span>
              <span className="text-kithra-muted">
                Question {currentQuestionIndex + 1} of {filteredQuestions.length}
              </span>
            </div>

            <h2 className="font-heading font-extrabold text-2xl sm:text-3xl lg:text-4xl text-kithra leading-[1.15]">
              {currentQuestion.questionText}
            </h2>

            {currentQuestion.subtext && (
              <p className="font-serif italic text-base sm:text-lg text-kithra-muted leading-relaxed">
                "{currentQuestion.subtext}"
              </p>
            )}

            {/* Scientific Context Toggle (Build Trust) */}
            <div className="pt-2">
              <button
                onClick={() => setShowScientificContext(!showScientificContext)}
                className="inline-flex items-center gap-1.5 text-xs font-data text-[var(--accent-sage)] hover:opacity-80 transition-opacity font-semibold cursor-pointer"
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>Why are we asking this? (Psychometric Reference)</span>
              </button>

              {showScientificContext && (
                <div className="mt-3 p-4 rounded-2xl bg-[var(--bg-main)] border border-[var(--accent-sage)]/20 text-left space-y-2 text-xs font-body text-kithra-muted view-fade-enter">
                  <strong className="font-heading text-kithra block">Psychometric Validity:</strong>
                  <p>
                    This question measures conflict escalation dynamics based on Gottman Institute research and attachment theory. It calibrates how your stress response interacts with your partner's processing speed.
                  </p>
                </div>
              )}
            </div>

          </div>

          {/* Options Grid */}
          <div className="space-y-3 my-6 max-w-2xl mx-auto w-full">
            {currentQuestion.options.map((option, idx) => {
              const isSelected = answers[currentQuestion.id] === option.id;
              return (
                <button
                  key={option.id}
                  onClick={() => handleSelectOption(currentQuestion.id, option.id)}
                  className={`w-full p-4 sm:p-5 rounded-2xl border text-left transition-all flex items-center justify-between gap-4 cursor-pointer shadow-xs ${
                    isSelected 
                      ? 'bg-[var(--accent-sage)]/10 border-[var(--accent-sage)] text-[var(--accent-sage)] font-bold shadow-sm' 
                      : 'bg-[var(--bg-main)] border-kithra/40 text-kithra hover:border-[var(--accent-sage)]/60 font-medium'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="w-6 h-6 rounded-lg bg-[var(--surface-main)] border border-kithra/30 font-data text-xs flex items-center justify-center text-kithra-muted font-bold shrink-0">
                      {idx + 1}
                    </span>
                    <span className="font-body text-sm sm:text-base leading-relaxed">
                      {option.text}
                    </span>
                  </div>

                  <div className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 transition-colors ${
                    isSelected ? 'border-[var(--accent-sage)] bg-[var(--accent-sage)] text-white' : 'border-kithra/60'
                  }`}>
                    {isSelected && <CheckCircle2 className="w-3.5 h-3.5" />}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Footer Controls */}
          <div className="flex items-center justify-between pt-6 border-t border-kithra/40 max-w-4xl mx-auto w-full">
            <button
              onClick={() => {
                setCurrentQuestionIndex(prev => Math.max(0, prev - 1));
                setShowScientificContext(false);
              }}
              disabled={currentQuestionIndex === 0}
              className="px-4 py-2.5 rounded-xl text-xs font-heading font-bold text-kithra disabled:opacity-40 flex items-center gap-1.5 hover:bg-[var(--bg-main)] transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Previous</span>
            </button>

            <div className="flex items-center gap-3">
              {currentQuestionIndex < filteredQuestions.length - 1 ? (
                <button
                  onClick={() => {
                    setCurrentQuestionIndex(prev => prev + 1);
                    setShowScientificContext(false);
                  }}
                  className="px-5 py-2.5 rounded-xl bg-[var(--bg-main)] border border-kithra/40 text-xs font-heading font-bold text-kithra flex items-center gap-1.5 hover:border-[var(--accent-sage)] cursor-pointer transition-colors"
                >
                  <span>Next</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              ) : (
                <button
                  onClick={handleFinish}
                  disabled={isSubmitting}
                  className="px-6 py-2.5 rounded-xl bg-[var(--accent-sage)] hover:opacity-90 text-white text-xs font-heading font-bold flex items-center gap-2 shadow-md cursor-pointer transition-opacity"
                >
                  {isSubmitting ? (
                    <span>Calibrating Report...</span>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>Complete Module</span>
                    </>
                  )}
                </button>
              )}
            </div>
          </div>
        </div>
      ) : (
        <div className="p-8 text-center rounded-3xl bg-[var(--surface-main)] border border-kithra space-y-4">
          <Brain className="w-12 h-12 text-[var(--accent-sage)] mx-auto opacity-80" />
          <h3 className="font-heading font-bold text-lg text-kithra">Select a Module Above to Begin</h3>
          <p className="text-xs text-kithra-muted max-w-md mx-auto">
            Click any psychometric domain card above (e.g. Communication, Lifestyle, Values) to complete targeted questions and calibrate your compatibility OS.
          </p>
        </div>
      )}

    </div>
  );
};

