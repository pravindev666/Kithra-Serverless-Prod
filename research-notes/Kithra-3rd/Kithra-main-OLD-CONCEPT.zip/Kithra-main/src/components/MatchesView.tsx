import React, { useState } from 'react';
import { MOCK_MATCHES } from '../data/mockMatches';
import { MatchUser } from '../types';
import { 
  Users, 
  ShieldCheck, 
  Sparkles, 
  MessageSquare, 
  X, 
  CheckCircle2, 
  MapPin, 
  Lock, 
  Activity, 
  Folder,
  ChevronRight,
  Filter
} from 'lucide-react';

interface MatchesViewProps {
  onStartChat: (match: MatchUser) => void;
}

export const MatchesView: React.FC<MatchesViewProps> = ({ onStartChat }) => {
  const [selectedFolder, setSelectedFolder] = useState<string>('All');
  const [selectedMatch, setSelectedMatch] = useState<MatchUser | null>(null);

  const folders = [
    { id: 'All', label: 'All Introductions', count: MOCK_MATCHES.length },
    { id: '100', label: '100% Psychometric Match', count: MOCK_MATCHES.filter(m => m.matchPercentage === 100).length },
    { id: '95', label: '95% Compatibility Tier', count: MOCK_MATCHES.filter(m => m.matchPercentage === 95).length },
    { id: '90', label: '90% High Alignment', count: MOCK_MATCHES.filter(m => m.matchPercentage === 90).length },
    { id: '85', label: '85% Solid Foundation', count: MOCK_MATCHES.filter(m => m.matchPercentage === 85).length },
    { id: '80', label: '80% Value Alignment', count: MOCK_MATCHES.filter(m => m.matchPercentage === 80).length },
    { id: '75', label: '75% Growth Potential', count: MOCK_MATCHES.filter(m => m.matchPercentage === 75).length },
    { id: '60', label: '60% Moderate Contrast', count: MOCK_MATCHES.filter(m => m.matchPercentage === 60).length },
    { id: 'Opposite', label: '50% Soul Opposite', count: MOCK_MATCHES.filter(m => m.matchPercentage === 50).length }
  ];

  const filteredMatches = MOCK_MATCHES.filter((match) => {
    if (selectedFolder === 'All') return true;
    if (selectedFolder === 'Opposite') return match.matchPercentage === 50;
    return match.matchPercentage === parseInt(selectedFolder, 10);
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      
      {/* Banner */}
      <div className="p-6 sm:p-8 rounded-3xl bg-[var(--surface-main)] border border-kithra/15 space-y-2 shadow-xs">
        <div className="flex items-center justify-between">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[var(--accent-sage)]/10 text-[var(--accent-sage)] font-heading text-xs font-bold">
            <ShieldCheck className="w-3.5 h-3.5 text-[var(--gold-verify)]" />
            Double-Blind Match Queue
          </div>
          <span className="font-body text-xs text-kithra-muted">
            Total Matches: <strong className="text-kithra font-heading">{MOCK_MATCHES.length}</strong>
          </span>
        </div>
        <h1 className="font-heading font-extrabold text-2xl sm:text-3xl text-kithra">
          Compatibility Match Folders
        </h1>
        <p className="text-xs sm:text-sm text-kithra-muted font-body">
          Browse introductions categorized by psychometric alignment tiers. Zero public catalog browsing.
        </p>
      </div>

      {/* Gmail / Folder Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
        
        {/* Left Folder Directory Sidebar */}
        <div className="p-4 rounded-3xl bg-[var(--surface-main)] border border-kithra/15 space-y-2 shadow-2xs">
          <div className="px-3 py-2 text-xs font-heading text-kithra-muted uppercase tracking-wider font-bold flex items-center gap-2 border-b border-kithra/15 pb-3">
            <Filter className="w-3.5 h-3.5 text-[var(--accent-sage)]" />
            <span>Compatibility Tiers</span>
          </div>

          <div className="space-y-1 pt-1">
            {folders.map((folder) => {
              const isActive = selectedFolder === folder.id;
              return (
                <button
                  key={folder.id}
                  onClick={() => setSelectedFolder(folder.id)}
                  className={`w-full px-3 py-2.5 rounded-xl text-xs font-heading font-semibold flex items-center justify-between transition-all cursor-pointer ${
                    isActive 
                      ? 'bg-[#0D9488] text-white shadow-2xs' 
                      : 'text-kithra-muted hover:text-kithra hover:bg-[var(--bg-main)]'
                  }`}
                >
                  <div className="flex items-center gap-2.5 truncate">
                    <Folder className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-white' : 'text-kithra-muted'}`} />
                    <span className="truncate">{folder.label}</span>
                  </div>
                  <span className={`px-2 py-0.5 rounded-full font-heading text-[10px] font-bold ${
                    isActive ? 'bg-white/20 text-white' : 'bg-[var(--bg-main)] border border-kithra/15 text-kithra'
                  }`}>
                    {folder.count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Content Area: Match Cards Grid */}
        <div className="lg:col-span-3 space-y-6">
          {filteredMatches.length === 0 ? (
            <div className="p-12 text-center rounded-3xl bg-[var(--surface-main)] border border-kithra/15 space-y-3">
              <Folder className="w-10 h-10 text-kithra-muted mx-auto opacity-50" />
              <h3 className="font-heading font-bold text-base text-kithra">No Matches in this Tier Yet</h3>
              <p className="text-xs text-kithra-muted max-w-md mx-auto font-body">
                Complete remaining assessment modules to expand your double-blind compatibility introductions in this specific tier.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredMatches.map((match) => (
                <div 
                  key={match.id}
                  className="rounded-3xl bg-[var(--surface-main)] border border-kithra/15 overflow-hidden hover:border-[var(--accent-sage)]/50 transition-all flex flex-col justify-between shadow-xs group"
                >
                  <div>
                    {/* Header Image */}
                    <div className="relative h-52 w-full bg-[var(--bg-main)] overflow-hidden">
                      <img 
                        src={match.avatarUrl} 
                        alt={match.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[var(--surface-main)] via-transparent to-black/20" />
                      
                      {/* Match Badge */}
                      <div className="absolute top-4 left-4 px-3 py-1 rounded-full bg-[var(--surface-main)]/90 backdrop-blur-md border border-kithra/15 font-heading text-xs font-extrabold text-[var(--accent-sage)] shadow-xs">
                        {match.matchPercentage === 50 ? 'Complementary' : `${match.matchPercentage}% Alignment`}
                      </div>

                      <div className="absolute top-4 right-4 p-1.5 rounded-full bg-[var(--surface-main)]/90 backdrop-blur-md border border-kithra/15 text-[var(--gold-verify)]">
                        <ShieldCheck className="w-4 h-4" />
                      </div>
                    </div>

                    {/* Card Content */}
                    <div className="p-6 space-y-4">
                      <div>
                        <h3 className="font-heading font-bold text-lg text-kithra">
                          {match.name}, {match.age}
                        </h3>
                        <p className="text-xs font-data text-kithra-muted flex items-center gap-1 mt-0.5">
                          <MapPin className="w-3 h-3 text-[var(--accent-sage)]" />
                          <span>{match.location} • {match.profession}</span>
                        </p>
                      </div>

                      <p className="text-xs font-body text-kithra leading-relaxed italic border-l-2 border-[#0D9488] pl-3">
                        "{match.tagline}"
                      </p>

                      <div className="space-y-1.5 pt-1">
                        <span className="font-data text-[10px] text-kithra-muted uppercase block">
                          Top Shared Core Values:
                        </span>
                        <div className="flex flex-wrap gap-1.5">
                          {match.topSharedValues.map((val, i) => (
                            <span 
                              key={i} 
                              className="px-2.5 py-1 rounded-md bg-[var(--bg-main)] border border-kithra font-body text-[11px] text-kithra"
                            >
                              {val}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="p-6 pt-0 flex gap-3">
                    <button
                      onClick={() => setSelectedMatch(match)}
                      className="flex-1 py-2.5 rounded-xl border border-kithra bg-[var(--bg-main)] text-xs font-heading font-semibold text-kithra hover:border-[var(--accent-sage)] transition-colors cursor-pointer"
                    >
                      Deep Analysis
                    </button>
                    <button
                      onClick={() => onStartChat(match)}
                      className="px-4 py-2.5 rounded-xl bg-[#0D9488] hover:bg-[#0B7C72] text-white text-xs font-heading font-bold flex items-center gap-1.5 shadow-xs cursor-pointer"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>Chat</span>
                    </button>
                  </div>

                </div>
              ))}
            </div>
          )}
        </div>

      </div>

      {/* Deep Analysis Modal */}
      {selectedMatch && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[var(--surface-main)] border border-kithra rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-6 max-h-[90vh] overflow-y-auto shadow-2xl">
            
            {/* Modal Header */}
            <div className="flex items-start justify-between pb-4 border-b border-kithra">
              <div className="flex items-center gap-4">
                <img 
                  src={selectedMatch.avatarUrl} 
                  alt={selectedMatch.name} 
                  className="w-14 h-14 rounded-2xl object-cover border border-kithra"
                />
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="font-heading font-bold text-xl text-kithra">
                      {selectedMatch.name}, {selectedMatch.age}
                    </h2>
                    <ShieldCheck className="w-4 h-4 text-[var(--gold-verify)]" />
                  </div>
                  <p className="text-xs font-data text-kithra-muted">
                    {selectedMatch.profession} • {selectedMatch.location}
                  </p>
                </div>
              </div>

              <button
                onClick={() => setSelectedMatch(null)}
                className="p-2 rounded-xl border border-kithra text-kithra-muted hover:text-kithra cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Why You Align */}
            <div className="p-5 rounded-2xl bg-[var(--bg-main)] border border-kithra space-y-2">
              <span className="font-data text-xs uppercase text-[var(--accent-sage)] font-bold flex items-center gap-1.5">
                <Sparkles className="w-4 h-4" />
                Why You Align ({selectedMatch.matchPercentage}% Compatibility)
              </span>
              <p className="font-body text-xs sm:text-sm text-kithra leading-relaxed">
                {selectedMatch.whyYouAlign}
              </p>
            </div>

            {/* Growth Area */}
            <div className="p-5 rounded-2xl bg-[var(--bg-main)] border border-kithra space-y-2">
              <span className="font-data text-xs uppercase text-[var(--gold-verify)] font-bold flex items-center gap-1.5">
                <Activity className="w-4 h-4" />
                Awareness & Potential Growth Area
              </span>
              <p className="font-body text-xs sm:text-sm text-kithra leading-relaxed">
                {selectedMatch.potentialFrictionPoint}
              </p>
            </div>

            {/* Actions */}
            <div className="pt-4 flex items-center justify-end gap-3 border-t border-kithra">
              <button
                onClick={() => setSelectedMatch(null)}
                className="px-5 py-2.5 rounded-xl border border-kithra text-xs font-heading font-semibold text-kithra hover:bg-[var(--bg-main)] cursor-pointer"
              >
                Close Analysis
              </button>
              <button
                onClick={() => {
                  const match = selectedMatch;
                  setSelectedMatch(null);
                  onStartChat(match);
                }}
                className="px-6 py-2.5 rounded-xl bg-[#0D9488] hover:bg-[#0B7C72] text-white text-xs font-heading font-bold flex items-center gap-2 shadow-xs cursor-pointer"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Start Signal Encrypted Chat</span>
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
