import React, { useState } from 'react';
import { ActiveTab, AppMode } from '../types';
import { 
  Compass, 
  Sparkles, 
  Sun, 
  Moon, 
  Menu, 
  X, 
  ShieldCheck, 
  User, 
  LayoutDashboard, 
  Brain, 
  Users, 
  Lock,
  Globe,
  LogIn
} from 'lucide-react';
import { KithraLogo } from './Logo';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  appMode: AppMode;
  setAppMode: (mode: AppMode) => void;
  isDarkMode: boolean;
  setIsDarkMode: (val: boolean) => void;
  onOpenAuth: () => void;
  isLoggedIn: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  appMode,
  setAppMode,
  isDarkMode,
  setIsDarkMode,
  onOpenAuth,
  isLoggedIn
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  React.useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header 
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
        isScrolled 
          ? 'bg-[var(--surface-glass)] backdrop-blur-xl border-b border-[var(--border-glass)] shadow-sm' 
          : 'bg-[var(--bg-main)]/80 backdrop-blur-md border-b border-kithra/10'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-24">
          
          {/* Logo */}
          <button 
            onClick={() => {
              setAppMode('public');
              setActiveTab('landing');
            }}
            className="flex items-center gap-3 group text-left focus:outline-none cursor-pointer"
            id="kithra-logo-btn"
          >
            <div className="flex items-center justify-center group-hover:scale-105 transition-transform duration-200">
              <KithraLogo className="w-12 h-12" />
            </div>
            <div>
              <span className="font-heading font-extrabold text-2xl tracking-tight text-kithra block leading-none">
                KITHRA
              </span>
              <span className="font-data text-[9px] sm:text-[10px] tracking-[0.2em] text-[var(--accent-sage)] font-medium opacity-90 mt-1 block">
                Understand Yourself. Build Better Relationships.
              </span>
            </div>
          </button>

          {/* Public Navigation Links */}
          <nav className="hidden lg:flex items-center space-x-12 text-sm font-medium font-body">
            <button
              onClick={() => {
                setAppMode('public');
                setActiveTab('landing');
                setTimeout(() => {
                  document.getElementById('section-how-it-works')?.scrollIntoView({ behavior: 'smooth' });
                }, 100);
              }}
              className="group relative px-1 py-2 text-kithra-muted hover:text-kithra transition-opacity cursor-pointer"
            >
              How it Works
              <span className="absolute bottom-0 left-0 w-full h-[1px] bg-kithra scale-x-0 group-hover:scale-x-100 transition-transform duration-200 origin-left"></span>
            </button>

            <button
              onClick={() => {
                setAppMode('public');
                setActiveTab('landing');
                setTimeout(() => {
                  document.getElementById('section-science')?.scrollIntoView({ behavior: 'smooth' });
                }, 100);
              }}
              className="group relative px-1 py-2 text-kithra-muted hover:text-kithra transition-opacity cursor-pointer"
            >
              The Science
              <span className="absolute bottom-0 left-0 w-full h-[1px] bg-kithra scale-x-0 group-hover:scale-x-100 transition-transform duration-200 origin-left"></span>
            </button>

            <button
              onClick={() => {
                setAppMode('public');
                setActiveTab('landing');
                setTimeout(() => {
                  document.getElementById('sample-report')?.scrollIntoView({ behavior: 'smooth' });
                }, 100);
              }}
              className="group relative px-1 py-2 text-kithra-muted hover:text-kithra transition-opacity cursor-pointer"
            >
              Compatibility
              <span className="absolute bottom-0 left-0 w-full h-[1px] bg-kithra scale-x-0 group-hover:scale-x-100 transition-transform duration-200 origin-left"></span>
            </button>

            <button
              onClick={() => {
                setAppMode('public');
                setActiveTab('landing');
                setTimeout(() => {
                  document.getElementById('section-pricing')?.scrollIntoView({ behavior: 'smooth' });
                }, 100);
              }}
              className="group relative px-1 py-2 text-kithra-muted hover:text-kithra transition-opacity cursor-pointer"
            >
              Pricing
              <span className="absolute bottom-0 left-0 w-full h-[1px] bg-kithra scale-x-0 group-hover:scale-x-100 transition-transform duration-200 origin-left"></span>
            </button>

            <button
              onClick={() => {
                setAppMode('public');
                setActiveTab('landing');
                setTimeout(() => {
                  document.getElementById('section-faq')?.scrollIntoView({ behavior: 'smooth' });
                }, 100);
              }}
              className="group relative px-1 py-2 text-kithra-muted hover:text-kithra transition-opacity cursor-pointer"
            >
              FAQ
              <span className="absolute bottom-0 left-0 w-full h-[1px] bg-kithra scale-x-0 group-hover:scale-x-100 transition-transform duration-200 origin-left"></span>
            </button>
          </nav>

          {/* Header Action CTAs */}
          <div className="hidden md:flex items-center gap-6">
            
            <button
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="p-2 rounded-full hover:bg-kithra/5 text-kithra-muted hover:text-kithra opacity-80 hover:opacity-100 transition-all cursor-pointer"
              title="Toggle Dark Mode"
            >
              {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
            </button>

            <div className="flex items-center gap-4 border-l border-kithra/10 pl-6">
              {/* Public Login Button (Ghost) */}
              <button
                onClick={() => {
                  setAppMode('public');
                  setActiveTab('login');
                }}
                className="px-4 py-2 rounded-[12px] border border-kithra/10 hover:border-kithra/30 font-heading font-medium text-sm text-kithra bg-transparent transition-colors cursor-pointer"
              >
                Log in
              </button>

              {/* Public Signup Button (Primary) */}
              <button
                onClick={() => {
                  setAppMode('public');
                  setActiveTab('signup');
                }}
                className="px-5 py-2.5 rounded-[12px] bg-[#0D9488] text-white font-heading font-bold text-sm shadow-sm hover:scale-[1.02] hover:shadow-md transition-all duration-200 cursor-pointer"
              >
                Begin Journey
              </button>
            </div>
          </div>

          {/* Mobile Menu Toggle */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="p-2.5 rounded-xl border border-kithra bg-[var(--surface-main)] text-kithra-muted"
            >
              {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
            </button>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2.5 rounded-xl border border-kithra bg-[var(--surface-main)] text-kithra"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-kithra bg-[var(--surface-main)] p-4 space-y-3">
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => {
                setAppMode('public');
                setActiveTab('login');
                setMobileMenuOpen(false);
              }}
              className="py-2.5 rounded-xl border border-kithra text-kithra font-heading font-bold text-xs text-center block"
            >
              Log in
            </button>

            <button
              onClick={() => {
                setAppMode('public');
                setActiveTab('signup');
                setMobileMenuOpen(false);
              }}
              className="py-2.5 rounded-xl bg-[#0D9488] text-white font-heading font-bold text-xs text-center block"
            >
              Begin Journey
            </button>
          </div>

          <button
            onClick={() => {
              setAppMode('user');
              setActiveTab('home');
              setMobileMenuOpen(false);
            }}
            className="w-full py-3 rounded-xl bg-[#17181C] text-white font-heading font-bold text-xs text-center block"
          >
            Enter User Workspace OS
          </button>

          <button
            onClick={() => {
              setAppMode('admin');
              setMobileMenuOpen(false);
            }}
            className="w-full py-2.5 rounded-xl border border-[var(--gold-verify)] text-[var(--gold-verify)] font-heading font-bold text-xs text-center block"
          >
            Mission Control Admin
          </button>
        </div>
      )}
    </header>
  );
};
