import React, { useState } from 'react';
import { AppMode } from '../types';
import { 
  Lock, 
  Users, 
  ShieldCheck, 
  Activity, 
  BarChart3, 
  FileSpreadsheet, 
  CheckCircle2, 
  AlertTriangle, 
  Sliders, 
  Key, 
  Layers,
  Search,
  Check,
  X,
  CreditCard,
  DollarSign,
  HelpCircle,
  Flag,
  FileText,
  Settings,
  LogOut,
  Sparkles,
  Database
} from 'lucide-react';

interface AdminViewProps {
  setAppMode: (mode: AppMode) => void;
}

export const AdminView: React.FC<AdminViewProps> = ({ setAppMode }) => {
  const [activeTab, setActiveTab] = useState<string>('Dashboard');

  const verificationQueue = [
    { id: 'v1', name: 'Rohan Mehta', age: 31, docType: 'Aadhaar Card', status: 'Pending Review', timestamp: '10 mins ago' },
    { id: 'v2', name: 'Pooja Iyer', age: 28, docType: 'Passport', status: 'Pending Review', timestamp: '25 mins ago' },
    { id: 'v3', name: 'Vikramaditya Singh', age: 34, docType: 'Voter ID', status: 'Pending Review', timestamp: '1 hour ago' }
  ];

  const menuItems = [
    { id: 'Dashboard', label: 'Dashboard', icon: <BarChart3 className="w-4 h-4" /> },
    { id: 'Users', label: 'Users & Members', icon: <Users className="w-4 h-4" /> },
    { id: 'Verification Queue', label: 'Verification Queue (3)', icon: <ShieldCheck className="w-4 h-4 text-amber-400" /> },
    { id: 'Subscriptions', label: 'Subscriptions & MRR', icon: <CreditCard className="w-4 h-4" /> },
    { id: 'Analytics', label: 'Analytics', icon: <Activity className="w-4 h-4" /> },
    { id: 'Question Analytics', label: 'Question Analytics (100-Q)', icon: <Layers className="w-4 h-4" /> },
    { id: 'Fraud Detection', label: 'Fraud Detection', icon: <AlertTriangle className="w-4 h-4 text-rose-400" /> },
    { id: 'Moderation', label: 'Moderation', icon: <Lock className="w-4 h-4" /> },
    { id: 'Support', label: 'Support Queue', icon: <HelpCircle className="w-4 h-4" /> },
    { id: 'Feature Flags', label: 'Feature Flags', icon: <Flag className="w-4 h-4" /> },
    { id: 'Audit Logs', label: 'Audit Logs', icon: <FileText className="w-4 h-4" /> },
    { id: 'CSV Export', label: 'CSV Export', icon: <FileSpreadsheet className="w-4 h-4" /> },
    { id: 'Settings', label: 'System Settings', icon: <Settings className="w-4 h-4" /> }
  ];

  return (
    <div className="min-h-screen bg-[#0B0D12] text-slate-100 flex flex-col md:flex-row font-sans">
      
      {/* Enterprise Dark Admin Sidebar */}
      <aside className="w-full md:w-64 bg-[#12151E] border-r border-slate-800 p-4 flex flex-col justify-between shrink-0 select-none">
        <div className="space-y-6">
          
          {/* Logo */}
          <div className="p-2 border-b border-slate-800 pb-4 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-amber-500/20 border border-amber-500/50 flex items-center justify-center text-amber-400">
                <Lock className="w-4 h-4" />
              </div>
              <div>
                <span className="font-heading font-extrabold text-sm tracking-wider uppercase text-white block">
                  Mission Control
                </span>
                <span className="font-mono text-[9px] text-amber-400 block tracking-tight">
                  mission.kithra.com
                </span>
              </div>
            </div>
          </div>

          {/* Nav Links */}
          <nav className="space-y-1">
            {menuItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full px-3 py-2 rounded-xl text-xs font-semibold flex items-center justify-between transition-all cursor-pointer ${
                    isActive 
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-xs' 
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    {item.icon}
                    <span>{item.label}</span>
                  </div>
                </button>
              );
            })}
          </nav>

        </div>

        {/* Exit Admin */}
        <div className="pt-4 border-t border-slate-800 space-y-2">
          <button
            onClick={() => setAppMode('user')}
            className="w-full p-2.5 rounded-xl border border-slate-700 bg-slate-800/40 text-xs font-semibold text-slate-300 hover:text-white hover:border-slate-600 flex items-center justify-center gap-2 cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            <span>Return to User App</span>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-6 md:p-8 space-y-6 overflow-y-auto">
        
        {/* Header */}
        <div className="p-6 rounded-2xl bg-[#12151E] border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 font-mono text-xs font-bold mb-1">
              <Lock className="w-3.5 h-3.5" />
              Enterprise Administration Portal
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-white">
              {activeTab}
            </h1>
          </div>

          <button
            onClick={() => alert("CSV Export generated successfully.")}
            className="px-4 py-2 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 font-mono text-xs font-bold hover:bg-amber-500/30 flex items-center gap-2 cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Export CSV Report</span>
          </button>
        </div>

        {/* Content Tabs */}
        {activeTab === 'Dashboard' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-5 rounded-2xl bg-[#12151E] border border-slate-800 space-y-2">
                <span className="font-mono text-xs text-slate-400 uppercase">Total Users</span>
                <div className="text-3xl font-extrabold text-white">24,890</div>
                <span className="text-xs font-mono text-emerald-400">+12% this month</span>
              </div>
              <div className="p-5 rounded-2xl bg-[#12151E] border border-slate-800 space-y-2">
                <span className="font-mono text-xs text-slate-400 uppercase">MRR (Subscriptions)</span>
                <div className="text-3xl font-extrabold text-amber-400">₹8,92,430</div>
                <span className="text-xs font-mono text-slate-400">₹369 & ₹696 Tiers</span>
              </div>
              <div className="p-5 rounded-2xl bg-[#12151E] border border-slate-800 space-y-2">
                <span className="font-mono text-xs text-slate-400 uppercase">100-Q Completion</span>
                <div className="text-3xl font-extrabold text-emerald-400">91.4%</div>
                <span className="text-xs font-mono text-slate-400">Avg time: 24.2 mins</span>
              </div>
              <div className="p-5 rounded-2xl bg-[#12151E] border border-slate-800 space-y-2">
                <span className="font-mono text-xs text-slate-400 uppercase">Fraud Triggers</span>
                <div className="text-3xl font-extrabold text-rose-400">0.02%</div>
                <span className="text-xs font-mono text-slate-400">Zero active breaches</span>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'Verification Queue' && (
          <div className="p-6 rounded-2xl bg-[#12151E] border border-slate-800 space-y-4">
            <h2 className="text-lg font-bold text-white">Pending Government ID Verification ({verificationQueue.length})</h2>
            <div className="space-y-3">
              {verificationQueue.map((item) => (
                <div key={item.id} className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white text-sm">{item.name}, {item.age}</span>
                      <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 text-[10px] font-mono font-bold">{item.docType}</span>
                    </div>
                    <span className="text-xs text-slate-400 font-mono">Submitted {item.timestamp}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={() => alert(`Approved ${item.name}`)}
                      className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold cursor-pointer"
                    >
                      Approve
                    </button>
                    <button 
                      onClick={() => alert(`Rejected ${item.name}`)}
                      className="px-3 py-1.5 rounded-lg border border-rose-500/50 text-rose-400 text-xs font-medium hover:bg-rose-500/10 cursor-pointer"
                    >
                      Reject
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab !== 'Dashboard' && activeTab !== 'Verification Queue' && (
          <div className="p-8 rounded-2xl bg-[#12151E] border border-slate-800 space-y-3">
            <span className="font-mono text-xs text-amber-400 font-bold uppercase block">
              System Module Active // {activeTab}
            </span>
            <p className="text-xs text-slate-400 leading-relaxed font-mono">
              Audit logging, database query indexes, and platform controls are running normally on Cloud infrastructure with zero active security alerts.
            </p>
          </div>
        )}

      </main>

    </div>
  );
};
