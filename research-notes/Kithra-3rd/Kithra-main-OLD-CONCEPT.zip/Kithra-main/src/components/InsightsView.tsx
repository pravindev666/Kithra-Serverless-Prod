import React from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  Brain, 
  Sparkles, 
  CheckCircle2, 
  Activity, 
  ShieldCheck, 
  Compass,
  Zap
} from 'lucide-react';

export const InsightsView: React.FC = () => {
  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Banner */}
      <div className="p-8 rounded-3xl bg-[var(--surface-main)] border border-kithra space-y-3 shadow-xs">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[var(--accent-sage)]/10 text-[var(--accent-sage)] font-data text-xs font-bold">
          <BarChart3 className="w-3.5 h-3.5" />
          Psychometric Growth OS
        </div>
        <h1 className="font-heading font-extrabold text-2xl sm:text-3xl text-kithra">
          Self-Awareness Analytics & Behavioral Trends
        </h1>
        <p className="text-xs sm:text-sm text-kithra-muted max-w-2xl">
          Track your psychological evolution, emotional regulation baseline, and relationship readiness metrics over time.
        </p>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="p-6 rounded-2xl bg-[var(--surface-main)] border border-kithra space-y-2">
          <span className="font-data text-xs text-kithra-muted uppercase">Overall Self-Awareness</span>
          <div className="font-heading font-extrabold text-3xl text-[var(--accent-sage)]">92 / 100</div>
          <span className="text-[10px] font-data text-[var(--accent-sage)] flex items-center gap-1">
            <TrendingUp className="w-3 h-3" />
            <span>+4 pts from last assessment</span>
          </span>
        </div>

        <div className="p-6 rounded-2xl bg-[var(--surface-main)] border border-kithra space-y-2">
          <span className="font-data text-xs text-kithra-muted uppercase">Growth Mindset Index</span>
          <div className="font-heading font-extrabold text-3xl text-kithra">94%</div>
          <span className="text-[10px] font-data text-kithra-muted">High adaptability under stress</span>
        </div>

        <div className="p-6 rounded-2xl bg-[var(--surface-main)] border border-kithra space-y-2">
          <span className="font-data text-xs text-kithra-muted uppercase">Conflict De-escalation</span>
          <div className="font-heading font-extrabold text-3xl text-[var(--gold-verify)]">15-Min Pause</div>
          <span className="text-[10px] font-data text-kithra-muted">Gottman Method Verified</span>
        </div>

        <div className="p-6 rounded-2xl bg-[var(--surface-main)] border border-kithra space-y-2">
          <span className="font-data text-xs text-kithra-muted uppercase">Attachment Classification</span>
          <div className="font-heading font-extrabold text-3xl text-kithra">Secure</div>
          <span className="text-[10px] font-data text-kithra-muted">91% Secure-Autonomous</span>
        </div>

      </div>

      {/* Domain Score Breakdown Progress Bars */}
      <div className="p-8 rounded-3xl bg-[var(--surface-main)] border border-kithra space-y-6">
        <div className="flex items-center justify-between border-b border-kithra pb-4">
          <div>
            <h2 className="font-heading font-bold text-xl text-kithra">8 Psychological Domain Score Distributions</h2>
            <p className="text-xs text-kithra-muted">Calculated from your 100-Question Kithra Assessment</p>
          </div>
          <span className="font-data text-xs px-3 py-1 rounded-full bg-[var(--accent-sage)]/10 text-[var(--accent-sage)] font-bold">
            100% Verified
          </span>
        </div>

        <div className="space-y-5">
          {[
            { domain: 'Communication Style', score: 94, label: 'Exceptional', color: 'bg-[#0D9488]' },
            { domain: 'Core Values & Ethics', score: 91, label: 'Very High', color: 'bg-[#0D9488]' },
            { domain: 'Lifestyle Rhythms & Order', score: 88, label: 'High Alignment', color: 'bg-[#0D9488]' },
            { domain: 'Emotional Regulation', score: 96, label: 'Exceptional', color: 'bg-[#C8A24F]' },
            { domain: 'Long-term Goals & Sequence', score: 89, label: 'Very High', color: 'bg-[#0D9488]' },
            { domain: 'Family & Extended Boundaries', score: 85, label: 'High Alignment', color: 'bg-[#0D9488]' },
            { domain: 'Conflict Resolution Protocol', score: 92, label: 'Exceptional', color: 'bg-[#C8A24F]' },
            { domain: 'Existential Purpose & Spirit', score: 87, label: 'High Alignment', color: 'bg-[#0D9488]' }
          ].map((item, idx) => (
            <div key={idx} className="space-y-1.5">
              <div className="flex justify-between items-center text-xs font-data">
                <span className="font-heading font-semibold text-kithra">{item.domain}</span>
                <div className="flex items-center gap-2">
                  <span className="text-kithra-muted">{item.label}</span>
                  <span className="font-bold text-kithra">{item.score}%</span>
                </div>
              </div>
              <div className="h-2 w-full bg-[var(--bg-main)] rounded-full overflow-hidden border border-kithra">
                <div 
                  className={`h-full ${item.color} rounded-full transition-all duration-1000`} 
                  style={{ width: `${item.score}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
