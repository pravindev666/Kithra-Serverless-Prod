import React, { useState } from 'react';
import { ActiveTab, AppMode } from '../types';
import { Heart, Compass, ShieldCheck, ArrowRight, CheckCircle2, User, Mail, Lock } from 'lucide-react';

interface SignupPageProps {
  setActiveTab: (tab: ActiveTab) => void;
  setAppMode: (mode: AppMode) => void;
  onSignupSuccess: () => void;
}

export const SignupPage: React.FC<SignupPageProps> = ({ setActiveTab, setAppMode, onSignupSuccess }) => {
  const [step, setStep] = useState<1 | 2>(1);
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [password, setPassword] = useState('');
  const [agreedTerms, setAgreedTerms] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (step === 1) {
      setStep(2);
    } else {
      onSignupSuccess();
      setAppMode('user');
      setActiveTab('assessment');
    }
  };

  return (
    <div className="min-h-[calc(100vh-80px)] w-full grid grid-cols-1 lg:grid-cols-2 bg-[var(--bg-main)]">
      
      {/* Left Column - Calming Brand Panel */}
      <div className="hidden lg:flex flex-col items-center justify-center p-12 bg-[#E1E6DC] text-[#17181C] relative border-r border-[#D0D7CA]">
        <div className="max-w-md text-center space-y-6">
          <div className="w-20 h-20 rounded-full border-2 border-[#0D9488]/40 flex items-center justify-center mx-auto text-[#0D9488] shadow-xs bg-white/40">
            <Compass className="w-10 h-10 stroke-[1.5]" />
          </div>

          <div className="space-y-3">
            <h1 className="font-heading font-extrabold text-3xl sm:text-4xl text-[#17181C] tracking-tight leading-tight">
              Begin Your Compatibility Journey
            </h1>
            <p className="font-body text-sm sm:text-base text-[#4A5043] leading-relaxed">
              Join thousands of intentional individuals building long-term, scientifically grounded relationships.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white/60 border border-[#D0D7CA] text-left space-y-3 shadow-xs">
            <span className="font-data text-xs font-bold uppercase tracking-wider text-[#0D9488]">
              What happens after signup:
            </span>
            <ul className="space-y-2 text-xs text-[#2D3128] font-body">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#0D9488] shrink-0" />
                <span>Complete the 100-Question Psychometric Assessment</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#0D9488] shrink-0" />
                <span>Receive your Apple Health-style Psychometric Blueprint</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#0D9488] shrink-0" />
                <span>Government ID Verification & Signal Encrypted Matches</span>
              </li>
            </ul>
          </div>

          <div className="pt-4 flex items-center justify-center gap-6 text-xs text-[#5C6354] font-data">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-[#0D9488]" />
              Government Verified
            </span>
            <span>•</span>
            <span className="flex items-center gap-1.5">
              <Lock className="w-4 h-4 text-[#0D9488]" />
              DPDP Privacy Encrypted
            </span>
          </div>
        </div>

        <div className="absolute bottom-6 font-data text-[11px] text-[#7A8272]">
          KITHRA • Human Compatibility Operating System
        </div>
      </div>

      {/* Right Column - Signup Credentials Form */}
      <div className="flex flex-col justify-center items-center p-6 sm:p-12 lg:p-16 bg-[var(--surface-main)]">
        <div className="w-full max-w-md space-y-8">
          
          {/* Header */}
          <div className="space-y-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[var(--accent-sage)]/10 text-[var(--accent-sage)] font-data text-[11px] font-bold">
              Step {step} of 2
            </div>
            <h2 className="font-heading font-extrabold text-2xl sm:text-3xl text-kithra tracking-tight">
              {step === 1 ? 'Create Account' : 'Verify Mobile OTP'}
            </h2>
            <p className="text-xs sm:text-sm text-kithra-muted">
              {step === 1 ? 'Enter your details to create your secure profile.' : 'Enter the verification code sent to your mobile.'}
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-5">
            {step === 1 ? (
              <>
                <div className="space-y-1.5">
                  <label className="font-data text-xs font-semibold text-kithra uppercase block">
                    Full Legal Name
                  </label>
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Ananya Sharma"
                    className="w-full px-4 py-3 rounded-xl bg-[var(--bg-main)] border border-kithra text-xs font-body text-kithra focus:outline-none focus:border-[var(--accent-sage)] transition-colors"
                    required
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="font-data text-xs font-semibold text-kithra uppercase block">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="ananya@example.com"
                    className="w-full px-4 py-3 rounded-xl bg-[var(--bg-main)] border border-kithra text-xs font-body text-kithra focus:outline-none focus:border-[var(--accent-sage)] transition-colors"
                    required
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="font-data text-xs font-semibold text-kithra uppercase block">
                    Mobile Number (+91 India)
                  </label>
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-3 rounded-xl bg-[var(--bg-main)] border border-kithra font-data text-xs text-kithra font-bold">
                      +91
                    </span>
                    <input
                      type="tel"
                      value={mobileNumber}
                      onChange={(e) => setMobileNumber(e.target.value)}
                      placeholder="98765 43210"
                      className="flex-1 px-4 py-3 rounded-xl bg-[var(--bg-main)] border border-kithra text-xs font-data text-kithra focus:outline-none focus:border-[var(--accent-sage)]"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="font-data text-xs font-semibold text-kithra uppercase block">
                    Create Password
                  </label>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full px-4 py-3 rounded-xl bg-[var(--bg-main)] border border-kithra text-xs font-body text-kithra focus:outline-none focus:border-[var(--accent-sage)] transition-colors"
                    required
                  />
                </div>

                <div className="flex items-start gap-2.5 pt-1">
                  <input
                    type="checkbox"
                    id="terms"
                    checked={agreedTerms}
                    onChange={(e) => setAgreedTerms(e.target.checked)}
                    className="mt-0.5 rounded border-kithra text-[#0D9488] focus:ring-0 cursor-pointer"
                    required
                  />
                  <label htmlFor="terms" className="text-xs text-kithra-muted font-body leading-tight cursor-pointer">
                    I agree to Kithra's <a href="#terms" className="underline text-kithra">Terms of Service</a> and <a href="#privacy" className="underline text-kithra">DPDP Compliant Privacy Policy</a>.
                  </label>
                </div>
              </>
            ) : (
              <div className="space-y-4">
                <div className="p-4 rounded-xl bg-[var(--bg-main)] border border-kithra space-y-1">
                  <span className="font-data text-[10px] text-kithra-muted uppercase block">Verification Code Sent To</span>
                  <span className="font-data text-xs font-bold text-kithra block">+91 {mobileNumber || '98765 43210'}</span>
                </div>

                <div className="space-y-1.5">
                  <label className="font-data text-xs font-semibold text-kithra uppercase block">
                    6-Digit Mobile OTP
                  </label>
                  <input
                    type="text"
                    placeholder="123456"
                    maxLength={6}
                    defaultValue="123456"
                    className="w-full px-4 py-3 rounded-xl bg-[var(--bg-main)] border border-kithra text-center font-data text-lg tracking-widest text-kithra focus:outline-none focus:border-[var(--accent-sage)]"
                    required
                  />
                  <p className="text-[11px] font-data text-kithra-muted">
                    Test OTP: <span className="font-bold text-kithra">123456</span>
                  </p>
                </div>
              </div>
            )}

            <button
              type="submit"
              className="w-full py-3.5 rounded-xl bg-[#0D9488] hover:bg-[#0B7C72] text-white font-heading font-bold text-xs uppercase tracking-wider shadow-sm transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              <span>{step === 1 ? 'Continue to OTP Verification' : 'Verify & Start Assessment'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {/* Footer Navigation */}
          <div className="text-center pt-2">
            <span className="text-xs text-kithra-muted font-body">
              Already have an account?{' '}
            </span>
            <button
              onClick={() => setActiveTab('login')}
              className="text-xs font-heading font-bold text-[#0D9488] hover:underline cursor-pointer"
            >
              Log in here.
            </button>
          </div>

        </div>
      </div>

    </div>
  );
};
