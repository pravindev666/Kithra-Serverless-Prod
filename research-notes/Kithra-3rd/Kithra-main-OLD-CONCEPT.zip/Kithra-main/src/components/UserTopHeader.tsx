import React, { useState } from 'react';
import { ActiveTab, AppMode } from '../types';
import { 
  Search, 
  Bell, 
  Moon, 
  Sun, 
  Command,
  ChevronRight,
  Wifi,
  HelpCircle
} from 'lucide-react';
import { ProfileDropdown } from './ProfileDropdown';
import { CommandPalette } from './CommandPalette';

interface UserTopHeaderProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  isDarkMode: boolean;
  setIsDarkMode: (val: boolean) => void;
  setAppMode: (mode: AppMode) => void;
  onOpenCommandPalette?: () => void;
  onOpenShortcuts?: () => void;
}

export const UserTopHeader: React.FC<UserTopHeaderProps> = ({
  activeTab,
  setActiveTab,
  isDarkMode,
  setIsDarkMode,
  setAppMode,
  onOpenCommandPalette,
  onOpenShortcuts
}) => {
  const [isCommandOpen, setIsCommandOpen] = useState(false);

  const handleOpenPalette = () => {
    if (onOpenCommandPalette) {
      onOpenCommandPalette();
    } else {
      setIsCommandOpen(true);
    }
  };

  const getBreadcrumb = (tab: ActiveTab) => {
    switch (tab) {
      case 'home': return 'Mission Control';
      case 'assessment': return 'Intelligence Engine';
      case 'report': return 'Psychometric Blueprint';
      case 'matches': return 'Research Folders';
      case 'messages': return 'Signal E2E Layer';
      case 'journal': return 'Knowledge Base';
      case 'insights': return 'Growth Story';
      case 'profile': return 'Identity Credentials';
      case 'settings': return 'OS Command Center';
      case 'billing': return 'Subscription & Invoices';
      case 'security': return 'Security & DPDP Center';
      default: return 'Workspace OS';
    }
  };

  return (
    <>
      <header className="h-16 bg-[var(--surface-main)] border-b border-kithra px-6 flex items-center justify-between sticky top-0 z-20 shadow-2xs">
        
        {/* Left: OS Breadcrumb */}
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setActiveTab('home')}
            className="font-heading font-extrabold text-xs text-kithra-muted hover:text-[var(--accent-sage)] transition-colors uppercase tracking-wider cursor-pointer"
          >
            Kithra OS
          </button>
          <ChevronRight className="w-3.5 h-3.5 text-kithra-muted/40" />
          <span className="font-heading font-bold text-sm text-kithra capitalize">
            {getBreadcrumb(activeTab)}
          </span>
        </div>

        {/* Center: Command Palette Trigger */}
        <button
          onClick={handleOpenPalette}
          className="hidden md:flex items-center gap-3 px-4 py-2 rounded-xl bg-[var(--bg-main)] border border-kithra/30 hover:border-[var(--accent-sage)]/50 text-kithra-muted hover:text-kithra transition-all cursor-pointer w-72 shadow-2xs group"
        >
          <Search className="w-4 h-4 text-kithra-muted group-hover:text-[var(--accent-sage)] transition-colors" />
          <span className="font-heading text-xs text-kithra-muted group-hover:text-kithra flex-1 text-left">Search commands or data...</span>
          <div className="flex items-center gap-0.5 px-1.5 py-0.5 rounded border border-kithra/30 bg-[var(--surface-main)] font-heading text-[10px] font-bold text-kithra-muted">
            <Command className="w-3 h-3" />
            <span>K</span>
          </div>
        </button>

        {/* Right Utility Actions & Profile */}
        <div className="flex items-center gap-3">
          
          {/* Signal Protocol Status Indicator */}
          <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-600 font-heading text-[10px] font-bold border border-emerald-500/20">
            <Wifi className="w-3 h-3 text-emerald-500 animate-pulse" />
            <span>Signal Active</span>
          </div>

          {/* Keyboard Shortcuts (?) Button */}
          {onOpenShortcuts && (
            <button
              onClick={onOpenShortcuts}
              className="p-2 rounded-xl border border-kithra bg-[var(--bg-main)] text-kithra-muted hover:text-kithra transition-colors cursor-pointer"
              title="Keyboard Shortcuts (?)"
            >
              <HelpCircle className="w-4 h-4" />
            </button>
          )}

          {/* Dark Mode Toggle */}
          <button
            onClick={() => setIsDarkMode(!isDarkMode)}
            className="p-2 rounded-xl border border-kithra bg-[var(--bg-main)] text-kithra-muted hover:text-kithra transition-colors cursor-pointer"
            title="Toggle Dark Mode (D)"
          >
            {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* Notifications */}
          <button
            onClick={() => setActiveTab('messages')}
            className="p-2 rounded-xl border border-kithra bg-[var(--bg-main)] text-kithra-muted hover:text-kithra relative transition-colors cursor-pointer"
            title="Notifications"
          >
            <Bell className="w-4 h-4" />
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-[var(--accent-sage)]" />
          </button>

          {/* Profile Dropdown */}
          <ProfileDropdown 
            setActiveTab={setActiveTab}
            setAppMode={setAppMode}
          />

        </div>
      </header>

      {/* Fallback Command Palette Modal when not provided by parent */}
      {!onOpenCommandPalette && (
        <CommandPalette 
          isOpen={isCommandOpen}
          onClose={() => setIsCommandOpen(false)}
          setActiveTab={setActiveTab}
          isDarkMode={isDarkMode}
          setIsDarkMode={setIsDarkMode}
        />
      )}
    </>
  );
};


