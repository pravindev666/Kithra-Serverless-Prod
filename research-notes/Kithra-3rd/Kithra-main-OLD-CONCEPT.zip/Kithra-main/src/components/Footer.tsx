import React from 'react';
import { Compass, ShieldCheck, Lock, FileText, ExternalLink } from 'lucide-react';
import { ActiveTab } from '../types';
import { KithraLogo } from './Logo';

interface FooterProps {
  setActiveTab: (tab: ActiveTab) => void;
}

export const Footer: React.FC<FooterProps> = ({ setActiveTab }) => {
  return (
    <footer className="bg-[var(--surface-main)] pt-32 pb-24 transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 pb-24">
          
          {/* Col 1 & 2: Brand Purpose */}
          <div className="lg:col-span-5 space-y-8">
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center">
                <KithraLogo className="w-10 h-10" />
              </div>
              <span className="font-heading font-extrabold text-2xl tracking-tight text-kithra">
                KITHRA
              </span>
            </div>

            <div className="space-y-4">
              <h3 className="font-heading font-bold text-2xl text-kithra leading-snug max-w-sm">
                Understand yourself before introducing yourself to someone else.
              </h3>
              <p className="text-sm text-kithra-muted opacity-80 leading-relaxed max-w-md font-body">
                A private psychological framework for relationship compatibility. We help you map your behavioral baseline before connecting you with highly compatible humans.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3 pt-4">
              <span className="font-data text-[9px] uppercase tracking-widest text-kithra-muted/60 font-semibold flex items-center gap-1.5">
                <span className="w-1 h-1 rounded-full bg-[var(--accent-sage)]"></span> DPDP Compliant
              </span>
              <span className="font-data text-[9px] uppercase tracking-widest text-kithra-muted/60 font-semibold flex items-center gap-1.5">
                <span className="w-1 h-1 rounded-full bg-[var(--gold-verify)]"></span> Government Verified
              </span>
              <span className="font-data text-[9px] uppercase tracking-widest text-kithra-muted/60 font-semibold flex items-center gap-1.5">
                <span className="w-1 h-1 rounded-full bg-kithra-muted/40"></span> Private by Design
              </span>
              <span className="font-data text-[9px] uppercase tracking-widest text-kithra-muted/60 font-semibold flex items-center gap-1.5">
                <span className="w-1 h-1 rounded-full bg-kithra-muted/40"></span> Signal Encrypted
              </span>
            </div>
          </div>

          {/* Col 3: Research & Science */}
          {/* Col 3: Research & Science */}
          <div className="lg:col-span-2 lg:col-start-7 space-y-6">
            <h4 className="font-heading font-bold text-sm text-kithra opacity-90 uppercase tracking-widest">
              Research
            </h4>
            <ul className="space-y-4 text-sm text-kithra-muted opacity-80 font-body">
              <li><button onClick={() => setActiveTab('landing')} className="hover:text-kithra hover:opacity-100 hover:translate-x-[2px] transition-all duration-200 text-left">Clinical Psychometrics</button></li>
              <li><a href="#behavioral-models" className="hover:text-kithra hover:opacity-100 hover:translate-x-[2px] transition-all duration-200 block">Behavioral Science</a></li>
              <li><a href="#intelligence" className="hover:text-kithra hover:opacity-100 hover:translate-x-[2px] transition-all duration-200 block">Compatibility Intelligence</a></li>
              <li><span className="inline-flex items-center gap-1.5 hover:text-kithra hover:opacity-100 hover:translate-x-[2px] cursor-pointer transition-all duration-200">Independent Research <ExternalLink className="w-3 h-3" /></span></li>
              <li><a href="#roadmap" className="hover:text-kithra hover:opacity-100 hover:translate-x-[2px] transition-all duration-200 block">Platform Roadmap</a></li>
            </ul>
          </div>

          {/* Col 4: Platform */}
          <div className="lg:col-span-2 space-y-6">
            <h4 className="font-heading font-bold text-sm text-kithra opacity-90 uppercase tracking-widest">
              Platform
            </h4>
            <ul className="space-y-4 text-sm text-kithra-muted opacity-80 font-body">
              <li><button onClick={() => setActiveTab('assessment')} className="hover:text-kithra hover:opacity-100 hover:translate-x-[2px] transition-all duration-200 block">Understand Yourself</button></li>
              <li><button onClick={() => setActiveTab('report')} className="hover:text-kithra hover:opacity-100 hover:translate-x-[2px] transition-all duration-200 block">Clinical Dossier</button></li>
              <li><button onClick={() => setActiveTab('matches')} className="hover:text-kithra hover:opacity-100 hover:translate-x-[2px] transition-all duration-200 block">Verified Introductions</button></li>
              <li><span className="opacity-50 cursor-not-allowed block">Developer API (Soon)</span></li>
              <li><span className="opacity-50 cursor-not-allowed block">Partner Program</span></li>
            </ul>
          </div>

          {/* Col 5: Company */}
          <div className="lg:col-span-2 space-y-6">
            <h4 className="font-heading font-bold text-sm text-kithra opacity-90 uppercase tracking-widest">
              Company
            </h4>
            <ul className="space-y-4 text-sm text-kithra-muted opacity-80 font-body">
              <li><button onClick={() => setActiveTab('landing')} className="hover:text-kithra hover:opacity-100 hover:translate-x-[2px] transition-all duration-200 block">Mission & Manifesto</button></li>
              <li><a href="#careers" className="hover:text-kithra hover:opacity-100 hover:translate-x-[2px] transition-all duration-200 block">Careers (Bengaluru)</a></li>
              <li><a href="#press" className="hover:text-kithra hover:opacity-100 hover:translate-x-[2px] transition-all duration-200 block">Press & Media</a></li>
              <li><button onClick={() => setActiveTab('admin')} className="hover:text-kithra hover:opacity-100 hover:translate-x-[2px] transition-all duration-200 block">Security Operations</button></li>
              <li><a href="#support" className="hover:text-kithra hover:opacity-100 hover:translate-x-[2px] transition-all duration-200 block">Member Support</a></li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-kithra/10 flex flex-col md:flex-row items-center justify-between text-xs text-kithra-muted gap-6 font-body opacity-60">
          <div>
            © {new Date().getFullYear()} Kithra. <span className="hidden sm:inline">A Product of Aztra AI Tech Solutions</span>
          </div>
          <div className="flex flex-wrap items-center justify-center md:justify-end gap-x-8 gap-y-2">
            <a href="#privacy" className="hover:text-kithra hover:underline underline-offset-4 transition-all">Privacy</a>
            <a href="#terms" className="hover:text-kithra hover:underline underline-offset-4 transition-all">Terms</a>
            <a href="#dpdp" className="hover:text-kithra hover:underline underline-offset-4 transition-all">DPDP</a>
            <a href="#cookies" className="hover:text-kithra hover:underline underline-offset-4 transition-all">Cookies</a>
          </div>
        </div>

      </div>
    </footer>
  );
};
