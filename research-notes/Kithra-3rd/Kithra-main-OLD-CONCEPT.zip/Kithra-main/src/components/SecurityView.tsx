import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ShieldCheck, Lock, Key, Laptop, Download, Trash2, CheckCircle2, AlertTriangle, RefreshCw } from 'lucide-react';

export const SecurityView: React.FC = () => {
  const [isExporting, setIsExporting] = useState(false);

  const handleExportData = () => {
    setIsExporting(true);
    setTimeout(() => {
      setIsExporting(false);
      alert('Your complete DPDP-compliant data archive (JSON) has been generated and downloaded.');
    }, 1500);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-12">
      
      {/* Header */}
      <div className="border-b border-kithra/15 pb-6">
        <span className="font-heading text-xs uppercase tracking-wider text-[var(--accent-sage)] font-bold">DPDP & Encryption Baseline</span>
        <h2 className="font-heading font-extrabold text-3xl text-kithra mt-1">Security & Privacy Control Center</h2>
        <p className="font-body text-sm text-kithra-muted mt-1">Manage your zero-knowledge encryption keys, active sessions, and DPDP compliance rights.</p>
      </div>

      {/* Signal E2E Key Protocol Banner */}
      <div className="p-6 rounded-3xl bg-[var(--surface-main)] border border-emerald-500/25 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-emerald-500/10 text-emerald-600 border border-emerald-500/20">
              <Lock className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-heading font-extrabold text-lg text-kithra flex items-center gap-2">
                Signal Protocol Double-Ratchet Active
                <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              </h3>
              <span className="font-body text-xs text-kithra-muted">End-to-End Encryption Keys Managed Locally</span>
            </div>
          </div>
          
          <button className="px-3 py-2 rounded-xl border border-kithra/15 hover:border-[var(--accent-sage)] text-xs font-heading font-bold text-kithra flex items-center gap-2 transition-colors cursor-pointer">
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Rotate Keys</span>
          </button>
        </div>

        <div className="p-3 rounded-xl bg-[var(--bg-main)] font-data text-[11px] text-kithra-muted flex items-center justify-between border border-kithra/15">
          <span>Public Safety Fingerprint: <strong className="text-kithra">e74f-92b1-408a-bc3e-7819-2041-998a</strong></span>
          <span className="text-[10px] text-emerald-600 font-heading font-bold uppercase tracking-wider">VERIFIED</span>
        </div>
      </div>

      {/* Active Devices & Sessions */}
      <div className="p-6 rounded-2xl bg-[var(--surface-main)] border border-kithra/15 space-y-4">
        <h4 className="font-heading font-bold text-base text-kithra flex items-center gap-2">
          <Laptop className="w-4 h-4 text-[var(--accent-sage)]" />
          Active Device Sessions
        </h4>

        <div className="divide-y divide-kithra/10">
          <div className="py-3 flex items-center justify-between text-xs font-body">
            <div className="flex items-center gap-3">
              <Laptop className="w-5 h-5 text-emerald-500" />
              <div>
                <span className="font-heading font-bold text-kithra block">MacBook Pro (Current Session)</span>
                <span className="text-[11px] text-kithra-muted font-body">Mumbai, India • Chrome v127 • Active Now</span>
              </div>
            </div>
            <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-600 font-heading text-[10px] font-bold">THIS DEVICE</span>
          </div>
        </div>
      </div>

      {/* DPDP Compliance & Data Rights */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Data Export */}
        <div className="p-6 rounded-2xl bg-[var(--surface-main)] border border-kithra/15 space-y-4">
          <h4 className="font-heading font-bold text-base text-kithra flex items-center gap-2">
            <Download className="w-4 h-4 text-[var(--accent-sage)]" />
            Export Personal Data Archive
          </h4>
          <p className="font-body text-xs text-kithra-muted leading-relaxed">
            Under India's Digital Personal Data Protection (DPDP) Act, you have the absolute right to download all raw psychometric scores, journal entries, and chat logs in a machine-readable JSON format.
          </p>
          <button
            onClick={handleExportData}
            disabled={isExporting}
            className="w-full py-2.5 rounded-xl bg-[var(--accent-sage)]/10 hover:bg-[var(--accent-sage)]/20 text-[var(--accent-sage)] border border-[var(--accent-sage)]/30 font-heading font-bold text-xs transition-colors cursor-pointer flex items-center justify-center gap-2"
          >
            <Download className="w-4 h-4" />
            <span>{isExporting ? 'Generating Archive...' : 'Download Complete Data (JSON)'}</span>
          </button>
        </div>

        {/* Data Purge */}
        <div className="p-6 rounded-2xl bg-[var(--surface-main)] border border-rose-500/20 space-y-4">
          <h4 className="font-heading font-bold text-base text-rose-500 flex items-center gap-2">
            <Trash2 className="w-4 h-4 text-rose-500" />
            Permanent Account & Data Purge
          </h4>
          <p className="font-body text-xs text-kithra-muted leading-relaxed">
            Permanently delete your psychological profile, encrypted keys, and introduction history. This action cannot be reversed and immediately purges all server records.
          </p>
          <button
            onClick={() => {
              if (confirm('Are you sure you want to permanently purge your Kithra account and zero-knowledge data?')) {
                alert('Account purge request submitted.');
              }
            }}
            className="w-full py-2.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-500 border border-rose-500/30 font-heading font-bold text-xs transition-colors cursor-pointer flex items-center justify-center gap-2"
          >
            <AlertTriangle className="w-4 h-4" />
            <span>Purge All Data & Delete Account</span>
          </button>
        </div>

      </div>

    </div>
  );
};
