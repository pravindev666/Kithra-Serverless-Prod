import React, { useState } from 'react';
import { PsychometricReport, ReportSubTab } from '../types';
import { 
  Brain, 
  CheckCircle2, 
  Sparkles, 
  Download, 
  ShieldCheck, 
  Activity, 
  Compass, 
  BarChart3,
  Award,
  Heart,
  DollarSign,
  Users,
  Lightbulb,
  FileText
} from 'lucide-react';

interface CompatibilityReportViewProps {
  report: PsychometricReport;
  onExploreMatches: () => void;
}

export const CompatibilityReportView: React.FC<CompatibilityReportViewProps> = ({ 
  report, 
  onExploreMatches 
}) => {
  const [activeReportTab, setActiveReportTab] = useState<ReportSubTab>('Overview');

  const reportTabs: { id: ReportSubTab; label: string; icon: React.ReactNode }[] = [
    { id: 'Overview', label: 'Overview', icon: <BarChart3 className="w-3.5 h-3.5" /> },
    { id: 'Communication', label: 'Communication', icon: <Brain className="w-3.5 h-3.5" /> },
    { id: 'Lifestyle', label: 'Lifestyle', icon: <Compass className="w-3.5 h-3.5" /> },
    { id: 'Family', label: 'Family Stance', icon: <Heart className="w-3.5 h-3.5" /> },
    { id: 'Conflict', label: 'Conflict Model', icon: <Activity className="w-3.5 h-3.5" /> },
    { id: 'Growth', label: 'Growth Mindset', icon: <Sparkles className="w-3.5 h-3.5" /> },
    { id: 'Financial', label: 'Financial Alignment', icon: <DollarSign className="w-3.5 h-3.5" /> },
    { id: 'Parenting', label: 'Parenting Vision', icon: <Users className="w-3.5 h-3.5" /> },
    { id: 'Summary', label: 'Executive Summary', icon: <FileText className="w-3.5 h-3.5" /> },
    { id: 'Recommendations', label: 'Recommendations', icon: <Lightbulb className="w-3.5 h-3.5" /> }
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Top Banner Header */}
      <div className="py-8 space-y-12 relative">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-12 border-b border-kithra/30">
          <div className="space-y-6">
            <div className="inline-flex items-center gap-2 font-data text-xs uppercase tracking-widest font-bold text-[var(--gold-verify)]">
              <ShieldCheck className="w-4 h-4" />
              Clinical Psychometric Blueprint
            </div>
            <h1 className="font-heading font-extrabold text-4xl sm:text-5xl lg:text-6xl text-kithra leading-[1.05]">
              Psychometric Compatibility Report
            </h1>
            <p className="text-xl font-serif italic text-kithra-muted max-w-2xl">
              A deeply calibrated narrative analysis across eight core domains of human interaction.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-4 shrink-0">
            <button
              onClick={() => window.print()}
              className="px-6 py-3 rounded-2xl bg-[var(--bg-main)] border border-kithra/50 text-kithra text-[13px] font-heading font-bold hover:border-kithra hover:bg-[var(--surface-main)] transition-colors flex items-center gap-2 cursor-pointer shadow-soft"
            >
              <Download className="w-4 h-4" />
              <span>Export Dossier</span>
            </button>
            <button
              onClick={onExploreMatches}
              className="px-8 py-3 rounded-2xl bg-[var(--accent-sage)] hover:opacity-90 text-white text-[13px] font-heading font-bold flex items-center gap-2 shadow-md cursor-pointer transition-opacity"
            >
              <Sparkles className="w-4 h-4" />
              <span>View Compatible Humans</span>
            </button>
          </div>
        </div>

        {/* Apple Health Tabs Bar - Minimalist */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 hide-scrollbar">
          {reportTabs.map((tab) => {
            const isActive = activeReportTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveReportTab(tab.id)}
                className={`px-4 py-2.5 rounded-2xl text-[13px] font-heading font-bold flex items-center gap-2 whitespace-nowrap transition-all cursor-pointer ${
                  isActive 
                    ? 'bg-[var(--accent-sage)]/10 text-[var(--accent-sage)]' 
                    : 'bg-transparent text-kithra-muted hover:text-kithra hover:bg-[var(--surface-main)]'
                }`}
              >
                <span>{tab.icon}</span>
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Tab Content Display - Paper Style */}
      <div className="py-8 space-y-12 max-w-4xl animate-rise">
        
        {activeReportTab === 'Overview' && (
          <div className="space-y-16">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-12 gap-y-8">
              <div className="space-y-3 pb-6 border-b border-kithra/20">
                <span className="font-data text-[11px] uppercase tracking-widest text-kithra-muted block font-bold">Self-Awareness Index</span>
                <span className="font-heading font-extrabold text-5xl text-[var(--accent-sage)] tracking-tighter">{report.overallSelfAwareness}%</span>
              </div>
              <div className="space-y-3 pb-6 border-b border-kithra/20">
                <span className="font-data text-[11px] uppercase tracking-widest text-kithra-muted block font-bold">Attachment Baseline</span>
                <span className="font-heading font-bold text-2xl text-kithra block leading-tight">{report.attachmentStyle}</span>
              </div>
              <div className="space-y-3 pb-6 border-b border-kithra/20">
                <span className="font-data text-[11px] uppercase tracking-widest text-kithra-muted block font-bold">Conflict Model</span>
                <span className="font-heading font-bold text-2xl text-kithra block leading-tight">{report.conflictStyle}</span>
              </div>
              <div className="space-y-3 pb-6 border-b border-kithra/20">
                <span className="font-data text-[11px] uppercase tracking-widest text-kithra-muted block font-bold">Growth Mindset</span>
                <span className="font-heading font-extrabold text-5xl text-[var(--gold-verify)] tracking-tighter">{report.growthMindsetScore}%</span>
              </div>
            </div>

            <div className="space-y-8 pt-8 border-t border-kithra/30">
              <h3 className="font-heading font-extrabold text-2xl text-kithra">8 Psychological Domains</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-16 gap-y-6 font-data text-xs">
                {report.domainScores.map((ds) => (
                  <div key={ds.domain} className="flex justify-between items-center pb-3 border-b border-kithra/10">
                    <span className="font-bold text-kithra uppercase tracking-wider">{ds.domain}</span>
                    <span className="text-[var(--accent-sage)] font-extrabold tracking-widest">{ds.score}% ({ds.label})</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeReportTab === 'Communication' && (
          <div className="space-y-6">
            <h3 className="font-heading font-extrabold text-3xl text-kithra">Communication & Expressive Style</h3>
            <p className="text-lg text-kithra leading-[1.8] font-body">
              {report.communicationStyle}
            </p>
          </div>
        )}

        {activeReportTab === 'Lifestyle' && (
          <div className="space-y-6">
            <h3 className="font-heading font-extrabold text-3xl text-kithra">Lifestyle Rhythms & Personal Order</h3>
            <p className="text-lg text-kithra leading-[1.8] font-body">
              High preference for structured morning habits, calm domestic atmosphere, and balanced social exposure.
            </p>
          </div>
        )}

        {activeReportTab === 'Family' && (
          <div className="space-y-6">
            <h3 className="font-heading font-extrabold text-3xl text-kithra">Family & Intergenerational Boundaries</h3>
            <p className="text-lg text-kithra leading-[1.8] font-body">
              Deep respect for parental guidance combined with firm marital unit independence for major financial and life choices.
            </p>
          </div>
        )}

        {activeReportTab === 'Conflict' && (
          <div className="space-y-6">
            <h3 className="font-heading font-extrabold text-3xl text-kithra">Conflict Resolution Protocol</h3>
            <p className="text-lg text-kithra leading-[1.8] font-body">
              {report.stressResponse}
            </p>
          </div>
        )}

        {activeReportTab === 'Growth' && (
          <div className="space-y-6">
            <h3 className="font-heading font-extrabold text-3xl text-kithra">Growth Mindset & Psychological Adaptability</h3>
            <p className="text-lg text-kithra leading-[1.8] font-body">
              94th percentile in self-examination, willingness to receive feedback, and commitment to personal evolution.
            </p>
          </div>
        )}

        {activeReportTab === 'Financial' && (
          <div className="space-y-6">
            <h3 className="font-heading font-extrabold text-3xl text-kithra">Financial Behavior & Capital Allocation</h3>
            <p className="text-lg text-kithra leading-[1.8] font-body">
              {report.financialBehavior}
            </p>
          </div>
        )}

        {activeReportTab === 'Parenting' && (
          <div className="space-y-6">
            <h3 className="font-heading font-extrabold text-3xl text-kithra">Parenting Stance & Educational Philosophy</h3>
            <p className="text-lg text-kithra leading-[1.8] font-body">
              Encouraging intellectual autonomy, outdoor activity, emotional resilience, and mindfulness practice.
            </p>
          </div>
        )}

        {activeReportTab === 'Summary' && (
          <div className="space-y-6">
            <h3 className="font-heading font-extrabold text-3xl text-kithra">Executive Psychometric Summary</h3>
            <p className="text-lg text-kithra leading-[1.8] font-body">
              You are an intellectually curious, emotionally regulated individual who thrives in partnerships founded on quiet respect, clear communication, and mutual growth.
            </p>
          </div>
        )}

        {activeReportTab === 'Recommendations' && (
          <div className="space-y-6">
            <h3 className="font-heading font-extrabold text-3xl text-kithra">Matching Recommendations</h3>
            <p className="text-lg text-kithra leading-[1.8] font-body">
              Seek partners with high Agreeableness (80%+), Secure Attachment, and shared appreciation for quiet reflection and structured goals.
            </p>
          </div>
        )}

      </div>

    </div>
  );
};
