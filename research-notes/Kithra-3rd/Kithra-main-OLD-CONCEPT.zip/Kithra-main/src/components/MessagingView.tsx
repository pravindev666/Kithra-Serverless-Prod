import React, { useState } from 'react';
import { MatchUser, ChatMessage } from '../types';
import { MOCK_MATCHES } from '../data/mockMatches';
import { useToast } from './ToastProvider';
import { 
  Lock, 
  Send, 
  Mic, 
  Image as ImageIcon, 
  ShieldCheck, 
  Sparkles, 
  CheckCheck, 
  Info,
  Search,
  Phone,
  Video,
  UserCheck,
  UserX,
  FileText,
  BellOff,
  ChevronRight,
  Smile,
  MessageSquare,
  MapPin,
  Heart
} from 'lucide-react';

interface MessagingViewProps {
  activeMatch?: MatchUser | null;
}

export const MessagingView: React.FC<MessagingViewProps> = ({ activeMatch: initialMatch }) => {
  const { showToast } = useToast();

  // Active Tab in Sidebar: 'chats' or 'requests'
  const [sidebarTab, setSidebarTab] = useState<'chats' | 'requests'>('chats');
  
  // List of active primary chat users
  const [activeChatUsers, setActiveChatUsers] = useState<MatchUser[]>([
    MOCK_MATCHES[0], // Dr. Ananya Sharma
    MOCK_MATCHES[1], // Devkrishna Menon
    MOCK_MATCHES[3], // Siddharth Roy
  ]);

  // List of pending connection requests (FB Messenger style)
  const [pendingRequests, setPendingRequests] = useState<MatchUser[]>([
    MOCK_MATCHES[2], // Rhea Kulkarni (94% / 80%)
    MOCK_MATCHES[4], // Meera Nambiar
  ]);

  // Currently selected match
  const [currentMatch, setCurrentMatch] = useState<MatchUser>(initialMatch || MOCK_MATCHES[0]);

  // Search filter query
  const [searchQuery, setSearchQuery] = useState('');

  // Right Details Panel open/close
  const [showRightDetails, setShowRightDetails] = useState(true);

  // Messages map per match id
  const [messagesMap, setMessagesMap] = useState<Record<string, ChatMessage[]>>({
    'm1': [
      {
        id: 'msg1',
        senderId: 'm1',
        text: `Hello! I read your Kithra report summary regarding your 15-minute pause request during conflict. That was remarkably validating to read—I operate in the exact same way.`,
        timestamp: '10:14 AM',
        isEncrypted: true
      },
      {
        id: 'msg2',
        senderId: 'you',
        text: `Thank you for reaching out! Yes, taking a quiet moment to process thoughts prevents unnecessary emotional reactivity. I noticed your high alignment in household order as well.`,
        timestamp: '10:18 AM',
        isEncrypted: true
      },
      {
        id: 'msg3',
        senderId: 'm1',
        text: `Absolutely. A clean, quiet sanctuary is essential for my creative research work. Would you be open to reflecting on our shared values regarding career and family sequence?`,
        timestamp: '10:22 AM',
        isEncrypted: true
      }
    ],
    'm2': [
      {
        id: 'msg_m2_1',
        senderId: 'm2',
        text: `Greetings! I saw your scores in financial stewardship and eco-restoration. Would love to exchange thoughts on sustainable home sanctuaries.`,
        timestamp: 'Yesterday',
        isEncrypted: true
      }
    ],
    'm4': [
      {
        id: 'msg_m4_1',
        senderId: 'm4',
        text: `Hi! Your focus on open-source hardware and lifelong learning deeply resonates with me.`,
        timestamp: '2 days ago',
        isEncrypted: true
      }
    ]
  });

  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  const isPendingRequest = pendingRequests.some(r => r.id === currentMatch.id);

  // Handle Accept Connection Request
  const handleAcceptRequest = (match: MatchUser) => {
    setPendingRequests(prev => prev.filter(r => r.id !== match.id));
    setActiveChatUsers(prev => [match, ...prev]);
    setCurrentMatch(match);
    
    if (!messagesMap[match.id]) {
      setMessagesMap(prev => ({
        ...prev,
        [match.id]: [
          {
            id: `req_accept_${Date.now()}`,
            senderId: match.id,
            text: `Hi! Thank you for accepting my compatibility request. I look forward to exploring our shared growth values.`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            isEncrypted: true
          }
        ]
      }));
    }

    showToast(`Accepted compatibility request from ${match.name}! Signal E2E session created.`, 'success');
  };

  // Handle Decline Request
  const handleDeclineRequest = (match: MatchUser) => {
    setPendingRequests(prev => prev.filter(r => r.id !== match.id));
    if (activeChatUsers.length > 0) {
      setCurrentMatch(activeChatUsers[0]);
    }
    showToast(`Request from ${match.name} dismissed.`, 'info');
  };

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isPendingRequest) return;

    const newMsg: ChatMessage = {
      id: `msg_${Date.now()}`,
      senderId: 'you',
      text: inputText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isEncrypted: true
    };

    setMessagesMap(prev => ({
      ...prev,
      [currentMatch.id]: [...(prev[currentMatch.id] || []), newMsg]
    }));
    setInputText('');

    setIsTyping(true);
    setTimeout(() => {
      setIsTyping(false);
      const replyMsg: ChatMessage = {
        id: `msg_reply_${Date.now()}`,
        senderId: currentMatch.id,
        text: `I appreciate that reflection deeply. Sharing similar priorities around emotional safety makes communication feel remarkably effortless.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isEncrypted: true
      };
      setMessagesMap(prev => ({
        ...prev,
        [currentMatch.id]: [...(prev[currentMatch.id] || []), replyMsg]
      }));
    }, 2200);
  };

  const currentMessages = messagesMap[currentMatch.id] || [];

  const displayedChats = activeChatUsers.filter(u => 
    u.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    u.profession.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const displayedRequests = pendingRequests.filter(u => 
    u.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    u.profession.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="w-full h-full bg-[var(--surface-main)] flex flex-col md:flex-row overflow-hidden font-body">
      
      {/* ─── PANE 1: LEFT CONVERSATION & REQUESTS SIDEBAR ─── */}
      <div className="w-full md:w-80 lg:w-84 border-r border-kithra/15 flex flex-col bg-[var(--surface-main)] shrink-0 h-full">
        
        {/* Sidebar Header */}
        <div className="p-4 border-b border-kithra/15 space-y-3 shrink-0">
          <div className="flex items-center justify-between">
            <h2 className="font-heading font-extrabold text-xl text-kithra flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-[var(--accent-sage)]" />
              <span>Messenger</span>
            </h2>
            <span className="px-2 py-0.5 rounded-full bg-[var(--accent-sage)]/10 text-[var(--accent-sage)] font-heading text-[10px] font-bold">
              Signal E2E
            </span>
          </div>

          {/* Search bar */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-kithra-muted absolute left-3 top-3" />
            <input 
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search conversations..."
              className="w-full pl-9 pr-3 py-2 rounded-xl bg-[var(--bg-main)] border border-kithra/15 text-xs text-kithra placeholder-kithra-muted focus:outline-none focus:border-[var(--accent-sage)] font-body"
            />
          </div>

          {/* Sub-nav Tabs (Primary vs Requests like FB Messenger) */}
          <div className="flex rounded-xl bg-[var(--bg-main)] p-1 border border-kithra/15">
            <button
              onClick={() => setSidebarTab('chats')}
              className={`flex-1 py-1.5 rounded-lg text-xs font-heading font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                sidebarTab === 'chats'
                  ? 'bg-[var(--surface-main)] text-kithra shadow-2xs'
                  : 'text-kithra-muted hover:text-kithra'
              }`}
            >
              <span>Primary</span>
              {activeChatUsers.length > 0 && (
                <span className="px-1.5 py-0.2 rounded-full bg-[var(--accent-sage)] text-white text-[9px] font-heading font-bold">
                  {activeChatUsers.length}
                </span>
              )}
            </button>

            <button
              onClick={() => setSidebarTab('requests')}
              className={`flex-1 py-1.5 rounded-lg text-xs font-heading font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                sidebarTab === 'requests'
                  ? 'bg-[var(--surface-main)] text-kithra shadow-2xs'
                  : 'text-kithra-muted hover:text-kithra'
              }`}
            >
              <span>Requests</span>
              {pendingRequests.length > 0 && (
                <span className="px-1.5 py-0.2 rounded-full bg-[var(--gold-verify)] text-white text-[9px] font-heading font-bold">
                  {pendingRequests.length}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Conversation List */}
        <div className="flex-1 overflow-y-auto divide-y divide-kithra/10">
          
          {sidebarTab === 'chats' && (
            displayedChats.length === 0 ? (
              <div className="p-8 text-center text-kithra-muted text-xs font-body">
                No active conversations found.
              </div>
            ) : (
              displayedChats.map((user) => {
                const isActive = user.id === currentMatch.id && !isPendingRequest;
                const lastMsg = messagesMap[user.id]?.slice(-1)[0];

                return (
                  <button
                    key={user.id}
                    onClick={() => setCurrentMatch(user)}
                    className={`w-full p-3.5 flex items-center gap-3 text-left transition-all cursor-pointer ${
                      isActive 
                        ? 'bg-[var(--accent-sage)]/10 border-l-4 border-l-[var(--accent-sage)]' 
                        : 'hover:bg-[var(--bg-main)]'
                    }`}
                  >
                    <div className="relative shrink-0">
                      <img 
                        src={user.avatarUrl} 
                        alt={user.name}
                        className="w-11 h-11 rounded-2xl object-cover border border-kithra/20"
                      />
                      <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-[var(--surface-main)]" />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1">
                        <div className="flex items-center gap-1 min-w-0">
                          <h4 className="font-heading font-bold text-xs text-kithra truncate">{user.name}</h4>
                          <ShieldCheck className="w-3.5 h-3.5 text-[var(--gold-verify)] shrink-0" />
                        </div>
                        <span className="text-[10px] text-kithra-muted shrink-0 font-body">
                          {lastMsg?.timestamp || 'Active'}
                        </span>
                      </div>

                      <p className="text-[11px] text-kithra-muted truncate pt-0.5 font-body">
                        {lastMsg ? lastMsg.text : user.profession}
                      </p>

                      <div className="flex items-center gap-2 pt-1">
                        <span className="px-1.5 py-0.2 rounded bg-[var(--accent-sage)]/10 text-[var(--accent-sage)] font-heading text-[9px] font-bold">
                          {user.matchPercentage}% Alignment
                        </span>
                      </div>
                    </div>
                  </button>
                );
              })
            )
          )}

          {sidebarTab === 'requests' && (
            displayedRequests.length === 0 ? (
              <div className="p-8 text-center text-kithra-muted text-xs font-body">
                No pending connection requests.
              </div>
            ) : (
              displayedRequests.map((user) => {
                const isActive = user.id === currentMatch.id;

                return (
                  <button
                    key={user.id}
                    onClick={() => setCurrentMatch(user)}
                    className={`w-full p-3.5 flex items-center gap-3 text-left transition-all cursor-pointer ${
                      isActive 
                        ? 'bg-[var(--gold-verify)]/10 border-l-4 border-l-[var(--gold-verify)]' 
                        : 'hover:bg-[var(--bg-main)]'
                    }`}
                  >
                    <div className="relative shrink-0">
                      <img 
                        src={user.avatarUrl} 
                        alt={user.name}
                        className="w-11 h-11 rounded-2xl object-cover border border-kithra/20"
                      />
                      <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-amber-500 border-2 border-[var(--surface-main)]" />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h4 className="font-heading font-bold text-xs text-kithra truncate">{user.name}</h4>
                        <span className="px-1.5 py-0.2 rounded bg-[var(--gold-verify)]/10 text-[var(--gold-verify)] font-heading text-[9px] font-bold">
                          Request
                        </span>
                      </div>
                      <p className="text-[11px] text-kithra-muted truncate pt-0.5 font-body">{user.profession}</p>
                      <span className="text-[10px] text-[var(--accent-sage)] font-heading font-bold">
                        {user.matchPercentage}% Compatible
                      </span>
                    </div>
                  </button>
                );
              })
            )
          )}

        </div>
      </div>

      {/* ─── PANE 2: CENTER MESSENGER CONVERSATION WINDOW ─── */}
      <div className="flex-1 flex flex-col min-w-0 bg-[var(--bg-main)]/40 h-full">
        
        {/* Chat Header Bar */}
        <div className="p-3.5 px-6 border-b border-kithra/15 bg-[var(--surface-main)] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="relative">
              <img 
                src={currentMatch.avatarUrl} 
                alt={currentMatch.name}
                className="w-10 h-10 rounded-2xl object-cover border border-kithra/20"
              />
              <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-500 border-2 border-[var(--surface-main)]" />
            </div>

            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="font-heading font-bold text-sm text-kithra">{currentMatch.name}</h3>
                <ShieldCheck className="w-4 h-4 text-[var(--gold-verify)]" />
                <span className="px-2 py-0.2 rounded-full bg-[var(--accent-sage)]/10 text-[var(--accent-sage)] font-heading text-[10px] font-bold">
                  {currentMatch.matchPercentage}% Alignment
                </span>
              </div>
              <p className="text-[11px] text-kithra-muted flex items-center gap-1.5 font-body">
                <Lock className="w-3 h-3 text-emerald-500" />
                <span>Signal E2E Encrypted</span>
                <span>•</span>
                <span className="text-emerald-500 font-medium">Active now</span>
              </p>
            </div>
          </div>

          {/* Action Buttons: Audio Call, Video Call, Details Toggle */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => showToast(`Initiating E2E Encrypted Audio Call with ${currentMatch.name}...`, 'info')}
              className="p-2 rounded-xl border border-kithra/15 bg-[var(--bg-main)] text-kithra-muted hover:text-[var(--accent-sage)] transition-colors cursor-pointer"
              title="Start Signal Voice Call"
            >
              <Phone className="w-4 h-4" />
            </button>

            <button
              onClick={() => showToast(`Initiating E2E Encrypted HD Video Call with ${currentMatch.name}...`, 'info')}
              className="p-2 rounded-xl border border-kithra/15 bg-[var(--bg-main)] text-kithra-muted hover:text-[var(--accent-sage)] transition-colors cursor-pointer"
              title="Start Signal HD Video Call"
            >
              <Video className="w-4 h-4" />
            </button>

            <button
              onClick={() => setShowRightDetails(prev => !prev)}
              className={`p-2 rounded-xl border transition-colors cursor-pointer ${
                showRightDetails 
                  ? 'bg-[var(--accent-sage)] text-white border-[var(--accent-sage)]' 
                  : 'bg-[var(--bg-main)] text-kithra-muted hover:text-kithra border-kithra/15'
              }`}
              title="Toggle Contact Details & Psychometrics"
            >
              <Info className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* ─── PENDING CONNECTION REQUEST BANNER (FB Messenger Requests flow) ─── */}
        {isPendingRequest ? (
          <div className="flex-1 p-8 flex flex-col items-center justify-center text-center space-y-6 overflow-y-auto">
            <div className="relative">
              <img 
                src={currentMatch.avatarUrl} 
                alt={currentMatch.name}
                className="w-24 h-24 rounded-3xl object-cover border-4 border-[var(--surface-main)] shadow-xl"
              />
              <div className="absolute -bottom-2 -right-2 p-2 rounded-full bg-[var(--gold-verify)] text-white shadow-md">
                <Sparkles className="w-5 h-5" />
              </div>
            </div>

            <div className="space-y-2 max-w-md">
              <h3 className="font-heading font-extrabold text-2xl text-kithra">
                {currentMatch.name}, {currentMatch.age}
              </h3>
              <p className="text-xs text-kithra-muted flex items-center justify-center gap-1 font-body">
                <MapPin className="w-3.5 h-3.5" />
                <span>{currentMatch.location}</span>
                <span>•</span>
                <span>{currentMatch.profession}</span>
              </p>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[var(--gold-verify)]/10 text-[var(--gold-verify)] font-heading text-xs font-bold border border-[var(--gold-verify)]/20">
                <span>{currentMatch.matchPercentage}% Psychometric Alignment</span>
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-[var(--surface-main)] border border-kithra/20 max-w-lg text-left space-y-3 shadow-xs">
              <div className="flex items-center gap-2 text-xs font-heading font-bold text-kithra">
                <Heart className="w-4 h-4 text-rose-500" />
                <span>Compatibility Connection Request</span>
              </div>
              <p className="font-serif italic text-xs text-kithra-muted leading-relaxed">
                "{currentMatch.bio}"
              </p>
              <div className="pt-2 border-t border-kithra/10 text-[11px] text-kithra-muted space-y-1 font-body">
                <p><strong>Top Shared Values:</strong> {currentMatch.topSharedValues.join(', ')}</p>
                <p><strong>Conflict Style:</strong> {currentMatch.conflictStyle}</p>
              </div>
            </div>

            {/* Accept / Decline Action Buttons */}
            <div className="flex items-center gap-4 pt-2">
              <button
                onClick={() => handleAcceptRequest(currentMatch)}
                className="px-6 py-3 rounded-2xl bg-[#0D9488] hover:bg-[#0B7C72] text-white font-heading font-bold text-xs flex items-center gap-2 shadow-md transition-all cursor-pointer"
              >
                <UserCheck className="w-4 h-4" />
                <span>Accept Connection Request</span>
              </button>

              <button
                onClick={() => handleDeclineRequest(currentMatch)}
                className="px-5 py-3 rounded-2xl bg-[var(--surface-main)] border border-kithra/20 hover:bg-rose-500/10 text-rose-500 font-heading font-semibold text-xs flex items-center gap-2 transition-all cursor-pointer"
              >
                <UserX className="w-4 h-4" />
                <span>Decline</span>
              </button>
            </div>
          </div>
        ) : (
          /* ─── ACTIVE CONVERSATION MESSAGES SCROLL AREA ─── */
          <>
            <div className="flex-1 p-6 overflow-y-auto space-y-4">
              
              {/* E2E Security Pill Banner */}
              <div className="text-center my-2">
                <span className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-[var(--surface-main)] border border-kithra/15 text-[11px] text-kithra-muted shadow-2xs font-body">
                  <Lock className="w-3.5 h-3.5 text-[var(--accent-sage)]" />
                  <span>End-to-end encrypted using Signal Protocol. Keys stored locally on device.</span>
                </span>
              </div>

              {/* Shared Strengths Pill */}
              <div className="bg-[var(--surface-main)] p-3 px-4 rounded-2xl border border-kithra/15 flex items-center justify-between text-xs text-kithra-muted shadow-2xs font-body">
                <span className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[var(--accent-sage)]" />
                  <span>Shared Core Values: <strong className="text-kithra font-heading">{currentMatch.topSharedValues.slice(0, 2).join(' & ')}</strong></span>
                </span>
                <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-600 text-[10px] font-heading font-bold">
                  100-Q Verified
                </span>
              </div>

              {/* Messages list */}
              {currentMessages.map((msg) => {
                const isMe = msg.senderId === 'you';
                return (
                  <div 
                    key={msg.id}
                    className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                  >
                    <div 
                      className={`max-w-lg p-4 rounded-2xl text-xs sm:text-sm font-body leading-relaxed space-y-1.5 ${
                        isMe 
                          ? 'bg-[#0D9488] text-white rounded-tr-xs shadow-xs' 
                          : 'bg-[var(--surface-main)] border border-kithra/15 text-kithra rounded-tl-xs shadow-2xs'
                      }`}
                    >
                      <p>{msg.text}</p>
                      <div className={`flex items-center justify-end gap-1.5 text-[10px] font-body ${isMe ? 'text-white/80' : 'text-kithra-muted'}`}>
                        <span>{msg.timestamp}</span>
                        {isMe && <CheckCheck className="w-3.5 h-3.5" />}
                      </div>
                    </div>
                  </div>
                );
              })}

              {isTyping && (
                <div className="flex items-center gap-2 p-3 rounded-2xl bg-[var(--surface-main)] border border-kithra/15 w-fit text-xs text-kithra-muted font-body">
                  <span className="w-2 h-2 rounded-full bg-[var(--accent-sage)] animate-ping" />
                  <span>{currentMatch.name} is formulating a reflection...</span>
                </div>
              )}

            </div>

            {/* Prompt Starters Bar */}
            <div className="px-4 py-2.5 bg-[var(--surface-main)] border-t border-kithra/15 flex items-center gap-2 overflow-x-auto text-xs shrink-0">
              <span className="text-[11px] text-kithra-muted uppercase shrink-0 font-heading font-bold tracking-wider">Prompts:</span>
              {[
                "Ask about conflict de-escalation style",
                "Discuss financial stewardship goals",
                "Reflect on quiet home sanctuary preferences"
              ].map((prompt, i) => (
                <button
                  key={i}
                  onClick={() => setInputText(prompt)}
                  className="px-3 py-1 rounded-xl bg-[var(--bg-main)] border border-kithra/15 hover:border-[var(--accent-sage)] text-kithra-muted hover:text-kithra text-xs whitespace-nowrap cursor-pointer transition-colors font-body"
                >
                  "{prompt}"
                </button>
              ))}
            </div>

            {/* Message Input Bar (FB Messenger style) */}
            <form onSubmit={handleSend} className="p-4 bg-[var(--surface-main)] border-t border-kithra/15 flex items-center gap-2 shrink-0">
              <button
                type="button"
                className="p-2.5 rounded-xl border border-kithra/15 text-kithra-muted hover:text-kithra hover:bg-[var(--bg-main)] transition-colors cursor-pointer"
                title="Attach image"
              >
                <ImageIcon className="w-4 h-4" />
              </button>
              
              <button
                type="button"
                className="p-2.5 rounded-xl border border-kithra/15 text-kithra-muted hover:text-kithra hover:bg-[var(--bg-main)] transition-colors cursor-pointer"
                title="Record voice note"
              >
                <Mic className="w-4 h-4" />
              </button>

              <button
                type="button"
                className="p-2.5 rounded-xl border border-kithra/15 text-kithra-muted hover:text-kithra hover:bg-[var(--bg-main)] transition-colors cursor-pointer"
                title="Insert emoji"
              >
                <Smile className="w-4 h-4" />
              </button>

              <input 
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Type a thoughtful message..."
                className="flex-1 px-4 py-2.5 rounded-2xl bg-[var(--bg-main)] border border-kithra/15 text-xs sm:text-sm text-kithra placeholder-kithra-muted focus:outline-none focus:border-[var(--accent-sage)] font-body"
              />

              <button
                type="submit"
                className="px-5 py-2.5 rounded-2xl bg-[#0D9488] hover:bg-[#0B7C72] text-white font-heading font-bold text-xs flex items-center gap-1.5 shadow-sm cursor-pointer transition-all"
              >
                <span>Send</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </>
        )}

      </div>

      {/* ─── PANE 3: RIGHT COLLAPSIBLE CONTACT DETAILS & PSYCHOMETRICS ─── */}
      {showRightDetails && (
        <div className="w-full md:w-72 lg:w-80 border-l border-kithra/15 bg-[var(--surface-main)] p-6 overflow-y-auto space-y-6 shrink-0 h-full">
          
          {/* User Header Profile */}
          <div className="text-center space-y-3 pb-6 border-b border-kithra/15">
            <div className="relative inline-block">
              <img 
                src={currentMatch.avatarUrl} 
                alt={currentMatch.name}
                className="w-20 h-20 rounded-3xl object-cover border-2 border-[var(--surface-main)] shadow-md mx-auto"
              />
              <ShieldCheck className="w-5 h-5 text-[var(--gold-verify)] absolute -bottom-1 -right-1 bg-[var(--surface-main)] rounded-full" />
            </div>

            <div>
              <h3 className="font-heading font-extrabold text-base text-kithra">{currentMatch.name}, {currentMatch.age}</h3>
              <p className="text-xs text-kithra-muted font-body">{currentMatch.profession}</p>
              <p className="text-[11px] text-kithra-muted pt-0.5 font-body">{currentMatch.location}</p>
            </div>

            <div className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-[var(--accent-sage)]/10 text-[var(--accent-sage)] font-heading text-xs font-bold">
              <span>{currentMatch.matchPercentage}% Alignment</span>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="space-y-2">
            <h4 className="text-[10px] uppercase tracking-wider text-kithra-muted font-heading font-bold">Actions</h4>
            <button 
              onClick={() => showToast('Opening Psychometric Blueprint Dossier...', 'info')}
              className="w-full p-2.5 rounded-xl border border-kithra/15 hover:border-[var(--accent-sage)] text-xs font-heading font-semibold text-kithra flex items-center justify-between transition-colors cursor-pointer"
            >
              <span className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-[var(--accent-sage)]" />
                <span>View Full Dossier</span>
              </span>
              <ChevronRight className="w-4 h-4 text-kithra-muted" />
            </button>

            <button 
              onClick={() => showToast(`Muted notifications for ${currentMatch.name}`, 'info')}
              className="w-full p-2.5 rounded-xl border border-kithra/15 hover:border-amber-500 text-xs font-heading font-semibold text-kithra flex items-center justify-between transition-colors cursor-pointer"
            >
              <span className="flex items-center gap-2">
                <BellOff className="w-4 h-4 text-amber-500" />
                <span>Mute Notifications</span>
              </span>
              <ChevronRight className="w-4 h-4 text-kithra-muted" />
            </button>
          </div>

          {/* Psychometric Alignment Overview */}
          <div className="space-y-3 pt-4 border-t border-kithra/15">
            <h4 className="text-[10px] uppercase tracking-wider text-kithra-muted font-heading font-bold">Psychometric Compatibility</h4>
            
            <div className="space-y-2 text-xs font-body">
              <div>
                <span className="text-kithra-muted block text-[11px]">Communication Style:</span>
                <span className="font-heading font-bold text-kithra">{currentMatch.communicationStyle}</span>
              </div>

              <div>
                <span className="text-kithra-muted block text-[11px]">Conflict Resolution:</span>
                <span className="font-heading font-bold text-kithra">{currentMatch.conflictStyle}</span>
              </div>
            </div>

            <div className="pt-2">
              <span className="text-kithra-muted block text-[11px] mb-1.5 font-body">Top Shared Values:</span>
              <div className="flex flex-wrap gap-1.5">
                {currentMatch.topSharedValues.map((val, i) => (
                  <span key={i} className="px-2 py-1 rounded-lg bg-[var(--bg-main)] border border-kithra/15 text-[11px] text-kithra font-body font-medium">
                    {val}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Verified Badges */}
          <div className="space-y-2 pt-4 border-t border-kithra/15">
            <h4 className="text-[10px] uppercase tracking-wider text-kithra-muted font-heading font-bold">Verification Badges</h4>
            <div className="space-y-1.5">
              {currentMatch.verifiedBadges.map((badge, i) => (
                <div key={i} className="flex items-center gap-2 text-[11px] font-body text-emerald-600">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                  <span>{badge}</span>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

    </div>
  );
};
