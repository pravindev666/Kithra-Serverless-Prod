import React, { useState, useRef } from 'react';
import { ActiveTab } from '../types';
import { ConstellationViz } from './ConstellationViz';
import { HeroSplitScreen } from './HeroSplitScreen';
import { RadarChart } from './RadarChart';
import { FAQ_ITEMS } from '../data/faq';
import { motion, useInView } from 'framer-motion';
import { 
  ArrowRight, 
  CheckCircle2, 
  ShieldCheck, 
  Lock, 
  Check, 
  FileSpreadsheet,
  Brain,
  AlertCircle,
  Sparkles,
  ChevronDown,
  ChevronUp,
  User,
  Fingerprint,
  FileText,
  Users
} from 'lucide-react';

interface LandingPageProps {
  setActiveTab: (tab: ActiveTab) => void;
  onOpenAuth: () => void;
}

const INTERACTIVE_QUESTIONS = [
  {
    id: 'q1',
    nodeId: 1, // Communication
    question: "When conflict happens...",
    options: ["I need quiet space to process", "I need to talk immediately"]
  },
  {
    id: 'q2',
    nodeId: 2, // Values
    question: "During stressful periods...",
    options: ["I internalize and isolate", "I seek external validation"]
  },
  {
    id: 'q3',
    nodeId: 3, // Lifestyle
    question: "Money is primarily a tool for...",
    options: ["Security and peace of mind", "Experiences and growth"]
  },
  {
    id: 'q4',
    nodeId: 4, // Conflict
    question: "My ideal weekend involves...",
    options: ["Structured routines at home", "Spontaneous social events"]
  }
];

export const LandingPage: React.FC<LandingPageProps> = ({ setActiveTab, onOpenAuth }) => {
  const [activeNodes, setActiveNodes] = useState<number[]>([]);
  const [answeredQuestions, setAnsweredQuestions] = useState<Record<string, number>>({});
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);
  
  const autoPlayRef = useRef<HTMLElement>(null);
  const isAutoPlayInView = useInView(autoPlayRef, { once: true, amount: 0.5 });
  
  // Animation Variants
  const sectionVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { type: "spring", stiffness: 40, damping: 20, duration: 0.8 }
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.15 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { type: "spring", stiffness: 50, damping: 20 }
    }
  };

  const handleAnswer = (questionId: string, optionIndex: number, nodeId: number) => {
    setAnsweredQuestions(prev => {
      if (prev[questionId] !== undefined) return prev;
      setActiveNodes(currentNodes => [...currentNodes, nodeId]);
      return { ...prev, [questionId]: optionIndex };
    });
  };

  const handleAutoPlay = (nodeId: number) => {
    setActiveNodes(currentNodes => {
      if (!currentNodes.includes(nodeId)) {
        return [...currentNodes, nodeId];
      }
      return currentNodes;
    });
  };

  React.useEffect(() => {
    if (isAutoPlayInView) {
      const timers = [
        setTimeout(() => handleAutoPlay(1), 500),
        setTimeout(() => handleAutoPlay(2), 1200),
        setTimeout(() => handleAutoPlay(3), 1900),
        setTimeout(() => handleAutoPlay(4), 2600),
        setTimeout(() => handleAutoPlay(5), 3300),
        setTimeout(() => handleAutoPlay(6), 4000),
        setTimeout(() => handleAutoPlay(7), 4700),
        setTimeout(() => handleAutoPlay(8), 5400),
      ];
      return () => timers.forEach(clearTimeout);
    }
  }, [isAutoPlayInView]);

  const isEngineComplete = activeNodes.length === 8;

  return (
    <div className="space-y-24 md:space-y-32 pb-24 overflow-x-hidden">
      
      {/* SECTION 1: HERO */}
      <motion.section 
        initial="hidden" 
        animate="visible" 
        variants={containerVariants}
        className="pt-24 md:pt-32 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto text-center space-y-12"
      >
        <div className="space-y-6">
          <motion.h1 variants={itemVariants} className="font-heading font-extrabold text-5xl sm:text-6xl md:text-7xl lg:text-[5rem] leading-[1.05] text-kithra tracking-tight max-w-5xl mx-auto">
            Find someone you're <span className="text-[var(--accent-sage)]">actually compatible</span> with.
          </motion.h1>
          <motion.p variants={itemVariants} className="font-serif italic text-2xl sm:text-3xl text-kithra-muted max-w-3xl mx-auto">
            Not based on photos. Not based on luck.<br/>
            Based on how you think, communicate, and build relationships.
          </motion.p>
        </div>

        <motion.div variants={itemVariants} className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
          <button 
            onClick={() => setActiveTab('assessment')}
            className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-[#0D9488] hover:bg-[#0B7C72] text-white font-heading font-bold text-base shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>Discover Your Blueprint</span>
            <ArrowRight className="w-5 h-5" />
          </button>
          <button 
            onClick={() => {
              document.getElementById('sample-report')?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="px-6 py-4 text-kithra-muted hover:text-kithra font-heading font-semibold text-base transition-colors flex items-center justify-center cursor-pointer hover:underline underline-offset-4"
          >
            <span>See Sample Report</span>
          </button>
        </motion.div>

        {/* Value Strip */}
        <motion.div variants={itemVariants} className="flex flex-wrap items-center justify-center gap-x-8 gap-y-4 pt-4 pb-4 text-sm font-body text-kithra font-medium">
          <span className="flex items-center gap-2"><Check className="w-4 h-4 text-[var(--accent-sage)]"/> Psychology-based compatibility</span>
          <span className="flex items-center gap-2"><Check className="w-4 h-4 text-[var(--accent-sage)]"/> Government identity verification</span>
          <span className="flex items-center gap-2"><Check className="w-4 h-4 text-[var(--accent-sage)]"/> Private by design</span>
          <span className="flex items-center gap-2"><Check className="w-4 h-4 text-[var(--accent-sage)]"/> Built for long-term relationships</span>
        </motion.div>

        {/* Split Screen Visualizer */}
        <HeroSplitScreen />
      </motion.section>

      {/* STATS STRIP */}
      <motion.section
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-100px" }}
        variants={containerVariants}
        className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto"
      >
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-12 py-8">
          {[
            { value: '8', label: 'Psychological Dimensions' },
            { value: '100', label: 'Assessment Questions' },
            { value: 'E2E', label: 'Signal Encrypted' },
            { value: '0', label: 'Ads. Ever.' },
          ].map((stat, idx) => (
            <motion.div key={idx} variants={itemVariants} className="text-center space-y-2">
              <span className="font-heading font-extrabold text-4xl sm:text-5xl text-[var(--accent-sage)]">{stat.value}</span>
              <p className="font-data text-[10px] uppercase tracking-widest text-kithra-muted font-bold">{stat.label}</p>
            </motion.div>
          ))}
        </div>
      </motion.section>

      {/* SECTION 2: WHY CURRENT MATCHING FAILS */}
      <motion.section 
        initial="hidden" 
        whileInView="visible" 
        viewport={{ once: true, margin: "-100px" }} 
        variants={sectionVariants} 
        className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto"
      >
        <div className="p-10 sm:p-16 rounded-[2.5rem] bg-[var(--surface-main)] border border-[var(--coral-highlight)]/20 shadow-xs relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-[var(--coral-highlight)]/5 rounded-full blur-[100px] pointer-events-none" />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center relative z-10">
            <div className="space-y-6">
              <span className="inline-flex items-center gap-2 font-data text-xs uppercase tracking-widest text-[var(--coral-highlight)] font-bold">
                <AlertCircle className="w-4 h-4" />
                The Missing Layer
              </span>
              <h2 className="font-heading font-extrabold text-3xl sm:text-4xl lg:text-5xl text-kithra leading-tight">
                Why current matching fails.
              </h2>
              <p className="font-body text-lg text-kithra-muted leading-relaxed">
                We are taught to choose partners using highly visible, immediate information. But relationships are sustained—or broken—by invisible dimensions that only reveal themselves years later.
              </p>
            </div>
            
            <motion.div 
              initial="hidden" whileInView="visible" viewport={{ once: true }}
              variants={{ hidden: { opacity: 0 }, visible: { opacity: 1, transition: { staggerChildren: 0.12 } } }}
              className="space-y-8"
            >
              <div className="space-y-4">
                <h3 className="font-heading font-bold text-xl text-kithra-muted opacity-60">Visible Information</h3>
                <p className="text-sm font-body text-kithra-muted opacity-60">Age, Height, Salary, Photos, Profession, Location.</p>
              </div>
              
              <div className="space-y-4">
                <h3 className="font-heading font-bold text-2xl text-[var(--coral-highlight)]">Invisible Compatibility</h3>
                {['Communication patterns during conflict.', 'Emotional regulation and stress response.', 'Financial philosophy and spending habits.', 'Boundaries with extended family.', 'Requirements for solitude and lifestyle.'].map((trait, i) => (
                  <motion.p key={i} variants={{ hidden: { opacity: 0, x: -20 }, visible: { opacity: 1, x: 0 } }} className="font-body text-base text-kithra font-medium flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[var(--coral-highlight)] shrink-0" />
                    {trait}
                  </motion.p>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </motion.section>

      {/* SECTION 3: WHY COMPATIBILITY MATTERS */}
      <motion.section 
        initial="hidden" 
        whileInView="visible" 
        viewport={{ once: true, margin: "-100px" }} 
        variants={sectionVariants} 
        className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto text-center space-y-12"
      >
        <h2 className="font-serif italic text-3xl sm:text-4xl md:text-5xl text-kithra leading-tight">
          "Attraction begins relationships.<br/>
          <span className="text-[var(--accent-sage)]">Compatibility sustains them.</span>"
        </h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-left max-w-6xl mx-auto pt-8">
          <div className="p-6 rounded-2xl bg-[var(--surface-main)] border border-kithra/40 space-y-2">
            <h4 className="font-heading font-bold text-kithra">Different Communication Styles</h4>
            <p className="text-sm font-body text-kithra-muted">One partner needs immediate resolution, while the other requires quiet time to process. Without understanding, this creates endless escalation.</p>
          </div>
          <div className="p-6 rounded-2xl bg-[var(--surface-main)] border border-kithra/40 space-y-2">
            <h4 className="font-heading font-bold text-kithra">Different Financial Priorities</h4>
            <p className="text-sm font-body text-kithra-muted">One views money as a tool for present experiences; the other views it purely as long-term security. This invisible gap breeds daily resentment.</p>
          </div>
          <div className="p-6 rounded-2xl bg-[var(--surface-main)] border border-kithra/40 space-y-2">
            <h4 className="font-heading font-bold text-kithra">Different Family Boundaries</h4>
            <p className="text-sm font-body text-kithra-muted">Differing expectations on extended family involvement in nuclear household decisions causes severe, silent friction over decades.</p>
          </div>
          <div className="p-6 rounded-2xl bg-[var(--surface-main)] border border-kithra/40 space-y-2">
            <h4 className="font-heading font-bold text-kithra">Different Lifestyle Expectations</h4>
            <p className="text-sm font-body text-kithra-muted">Mismatched needs for social energy versus domestic solitude slowly erode intimacy and personal equilibrium.</p>
          </div>
        </div>

        {/* 8-Dimensional Radar Chart visual anchor */}
        <div className="pt-16 max-w-2xl mx-auto">
          <div className="text-center space-y-2 mb-12">
            <h3 className="font-heading font-extrabold text-2xl text-kithra">Compatibility Intelligence</h3>
            <p className="font-data text-xs uppercase tracking-widest text-[var(--accent-sage)] font-bold">Structural Alignment Map</p>
          </div>
          <RadarChart />
        </div>
      </motion.section>

      {/* SECTION 4: HOW KITHRA WORKS */}
      <motion.section 
        initial="hidden" 
        whileInView="visible" 
        viewport={{ once: true, margin: "-100px" }} 
        variants={containerVariants} 
        className="px-4 sm:px-6 lg:px-8 max-w-[90rem] mx-auto py-12"
      >
        <motion.div variants={itemVariants} className="text-center space-y-4 mb-16">
          <h2 className="font-heading font-extrabold text-4xl sm:text-5xl text-kithra">
            How Kithra Works
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-6 max-w-7xl mx-auto">
          {[
            { icon: User, title: 'You', desc: 'A self-directed individual ready for genuine relationship alignment.' },
            { icon: Fingerprint, title: 'Human Blueprint', desc: 'A calm, 100-question assessment mapping your psychological baseline.' },
            { icon: Brain, title: 'Compatibility Intelligence', desc: 'Evaluating exactly how your behavioral models align with others.' },
            { icon: FileText, title: 'Clinical Dossier', desc: 'A private, profoundly clear report explaining your own relationship mechanics.' },
            { icon: Users, title: 'Verified Introductions', desc: 'Meeting highly compatible humans, with zero swiping and full privacy.' }
          ].map((item, idx) => (
            <motion.div 
              key={idx} 
              variants={itemVariants}
              className="space-y-4 text-center md:text-left flex flex-col items-center md:items-start relative group"
            >
              <div className="flex items-center gap-3 w-full justify-center md:justify-start">
                <span className="font-heading font-extrabold text-3xl text-[var(--accent-sage)]/20">0{idx + 1}</span>
                <div className="w-12 h-12 rounded-xl bg-[var(--surface-main)] border border-[var(--accent-sage)]/30 flex items-center justify-center text-[var(--accent-sage)] z-10 group-hover:scale-110 group-hover:border-[var(--accent-sage)] group-hover:shadow-md transition-all duration-300">
                  <item.icon className="w-5 h-5" />
                </div>
              </div>
              {idx < 4 && (
                <motion.div 
                  initial={{ scaleX: 0 }}
                  whileInView={{ scaleX: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.8, delay: 0.3 + idx * 0.15, ease: 'easeOut' }}
                  className="hidden md:block absolute top-6 left-[4.5rem] w-[calc(100%-4.5rem)] h-[2px] bg-gradient-to-r from-[var(--accent-sage)]/30 to-transparent origin-left" 
                />
              )}
              <h3 className="font-heading font-bold text-lg text-kithra pt-2">{item.title}</h3>
              <p className="text-sm text-kithra-muted font-body leading-relaxed">{item.desc}</p>
            </motion.div>
          ))}
        </div>
      </motion.section>

      {/* SECTION 5: INTERACTIVE HUMAN BLUEPRINT */}
      <motion.section 
        ref={autoPlayRef}
        initial="hidden" 
        whileInView="visible" 
        viewport={{ once: true, margin: "-100px" }} 
        variants={sectionVariants} 
        className="px-4 sm:px-6 lg:px-8 max-w-[90rem] mx-auto py-12"
      >
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-24 items-center">
          <div className="space-y-8">
            <h2 className="font-heading font-extrabold text-3xl sm:text-4xl text-kithra">
              Build your Compatibility Profile.
            </h2>
            <p className="font-body text-lg text-kithra-muted">
              Answer four simple questions. Watch how Kithra maps your psychological dimensions in real-time.
            </p>
            
            {INTERACTIVE_QUESTIONS.map((q, idx) => (
              <div 
                key={q.id} 
                className={`space-y-4 transition-all duration-700 ${
                  answeredQuestions[q.id] !== undefined ? 'opacity-50 scale-[0.98]' : 'opacity-100'
                }`}
              >
                <div className="flex items-center gap-4">
                  <span className="font-serif italic text-2xl text-kithra-muted/50">0{idx + 1}.</span>
                  <h3 className="font-heading font-bold text-xl sm:text-2xl text-kithra">{q.question}</h3>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pl-12">
                  {q.options.map((opt, optIdx) => (
                    <button
                      key={optIdx}
                      onClick={() => handleAnswer(q.id, optIdx, q.nodeId)}
                      disabled={answeredQuestions[q.id] !== undefined}
                      className={`text-left p-4 rounded-xl border font-body text-sm transition-all duration-300 ${
                        answeredQuestions[q.id] === optIdx
                          ? 'bg-[var(--accent-sage)] text-white border-[var(--accent-sage)]'
                          : answeredQuestions[q.id] !== undefined
                          ? 'bg-[var(--surface-main)] border-kithra/10 text-kithra-muted opacity-30 cursor-not-allowed'
                          : 'bg-[var(--bg-main)] border-kithra hover:border-[var(--accent-sage)] hover:text-[var(--accent-sage)] text-kithra cursor-pointer shadow-sm'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>
            ))}

            <div className={`pt-8 pl-12 transition-all duration-1000 ${isEngineComplete ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8 pointer-events-none'}`}>
              <button 
                onClick={() => setActiveTab('assessment')}
                className="px-6 py-3 rounded-2xl bg-[#0D9488] text-white font-heading font-bold text-[13px] flex items-center gap-2 shadow-md cursor-pointer hover:bg-[#0B7C72] transition-colors"
              >
                <Sparkles className="w-4 h-4" />
                <span>Complete Your Full Blueprint</span>
              </button>
            </div>
          </div>

          <div className="bg-[var(--surface-main)] rounded-[3rem] p-8 sm:p-12 border border-kithra/40 flex items-center justify-center min-h-[500px] shadow-sm">
            <div className="w-full space-y-12">
              <ConstellationViz activeNodes={activeNodes} />
              <div className="text-center space-y-2 h-16">
                {isEngineComplete ? (
                  <p className="font-heading font-bold text-xl text-[var(--accent-sage)] animate-in fade-in zoom-in duration-500">
                    Your Psychological Graph is active.
                  </p>
                ) : (
                  <p className="font-data text-xs uppercase tracking-widest text-kithra-muted">
                    Answer questions to map dimensions.
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      </motion.section>

      {/* SECTION 6: SAMPLE REPORT */}
      <motion.section 
        id="sample-report" 
        initial="hidden" 
        whileInView="visible" 
        viewport={{ once: true, margin: "-100px" }} 
        variants={sectionVariants} 
        className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto py-12"
      >
        <div className="text-center space-y-4 mb-12">
          <span className="font-data text-xs uppercase tracking-widest text-[var(--accent-sage)] font-semibold">
            The Result
          </span>
          <h2 className="font-heading font-extrabold text-4xl sm:text-5xl text-kithra">
            Your Clinical Dossier
          </h2>
          <p className="font-body text-lg text-kithra-muted max-w-2xl mx-auto">
            Instead of abstract scores, you receive deep, narrative explanations of your psychological mechanics. You learn exactly what your traits mean in practice.
          </p>
        </div>

        <motion.div 
          initial="hidden" whileInView="visible" viewport={{ once: true }}
          variants={{ hidden: { opacity: 0 }, visible: { opacity: 1, transition: { staggerChildren: 0.15 } } }}
          className="bg-[var(--surface-main)] rounded-[2rem] p-8 sm:p-12 border border-kithra/50 shadow-md relative overflow-hidden"
        >
          <motion.div variants={itemVariants} className="flex flex-col sm:flex-row sm:items-end justify-between border-b border-kithra/30 pb-8 mb-8 gap-4">
            <div className="space-y-2">
              <h3 className="font-heading font-extrabold text-2xl sm:text-3xl text-kithra">Psychometric Blueprint Analysis</h3>
              <p className="font-data text-[10px] uppercase tracking-widest text-kithra-muted font-bold">Confidential Record</p>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 bg-[var(--bg-main)] rounded-xl border border-kithra">
              <span className="w-2 h-2 rounded-full bg-[var(--accent-sage)]" />
              <span className="font-data text-[10px] uppercase tracking-widest font-bold">Attachment: Secure</span>
            </div>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-10">
            {[
              { name: 'Communication', pct: 78, text: 'You naturally process disagreements after reflection rather than immediately. You excel at expressing needs without blame, provided you are granted time to regulate.' },
              { name: 'Conflict', pct: 89, text: 'You prefer collaborative resolution over confrontation. Under stress, your blueprint relies on a mandatory de-escalation period followed by root-cause breakdown.' },
              { name: 'Lifestyle', pct: 56, text: 'You recharge through quiet routines. You require 30% sacred individual solitude to maintain emotional equilibrium alongside shared domestic time.' },
              { name: 'Values', pct: 95, text: 'You value continuous personal development. You actively seek feedback and view relationship friction as a catalyst for mutual evolution rather than a threat.' }
            ].map((item, i) => (
              <motion.div key={i} variants={itemVariants} className="space-y-3">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-heading font-bold text-lg text-kithra">{item.name}</span>
                    <span className="font-data text-xs text-[var(--accent-sage)] font-bold">{item.pct}%</span>
                  </div>
                  <div className="w-full h-2 bg-kithra/5 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      whileInView={{ width: `${item.pct}%` }}
                      viewport={{ once: true }}
                      transition={{ duration: 1.2, delay: 0.3 + i * 0.2, ease: 'easeOut' }}
                      className="h-full rounded-full bg-[var(--accent-sage)]"
                    />
                  </div>
                </div>
                <p className="font-body text-sm text-kithra-muted leading-relaxed">
                  {item.text}
                </p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </motion.section>

      {/* SECTION 7: TRUST ARCHITECTURE */}
      <motion.section 
        initial="hidden" 
        whileInView="visible" 
        viewport={{ once: true, margin: "-100px" }} 
        variants={sectionVariants} 
        className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto py-12 space-y-12"
      >
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <h2 className="font-heading font-extrabold text-4xl sm:text-5xl text-kithra">
            Institutional Trust Architecture
          </h2>
          <p className="font-body text-lg text-kithra-muted">
            People trust banks with money and hospitals with health. We bring the same institutional credibility to relationship decisions.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="p-8 rounded-3xl bg-[var(--surface-main)] border border-kithra space-y-3 transition-all duration-300 hover:shadow-[0_8px_30px_rgb(13,148,136,0.12)] hover:border-[#0D9488]/30 hover:-translate-y-1 cursor-default">
            <ShieldCheck className="w-6 h-6 text-[var(--gold-verify)]" />
            <h3 className="font-heading font-bold text-lg text-kithra">Government Verification</h3>
            <p className="text-sm text-kithra-muted leading-relaxed font-body">Mandatory Aadhaar/Passport ID matching ensures every member is legally verified before any introduction occurs. No fake profiles exist.</p>
          </div>
          <div className="p-8 rounded-3xl bg-[var(--surface-main)] border border-kithra space-y-3 transition-all duration-300 hover:shadow-[0_8px_30px_rgb(13,148,136,0.12)] hover:border-[#0D9488]/30 hover:-translate-y-1 cursor-default">
            <User className="w-6 h-6 text-[var(--gold-verify)]" />
            <h3 className="font-heading font-bold text-lg text-kithra">3D Liveness Detection</h3>
            <p className="text-sm text-kithra-muted leading-relaxed font-body">Biometric photo verification prevents catfishing. We guarantee the person you match with matches their photos.</p>
          </div>
          <div className="p-8 rounded-3xl bg-[var(--surface-main)] border border-kithra space-y-3 transition-all duration-300 hover:shadow-[0_8px_30px_rgb(13,148,136,0.12)] hover:border-[#0D9488]/30 hover:-translate-y-1 cursor-default">
            <AlertCircle className="w-6 h-6 text-[var(--gold-verify)]" />
            <h3 className="font-heading font-bold text-lg text-kithra">Human Moderation</h3>
            <p className="text-sm text-kithra-muted leading-relaxed font-body">Dedicated moderation teams proactively monitor behavior metrics and remove accounts violating our strict psychological safety standards.</p>
          </div>
          <div className="p-8 rounded-3xl bg-[var(--surface-main)] border border-kithra space-y-3 transition-all duration-300 hover:shadow-[0_8px_30px_rgb(13,148,136,0.12)] hover:border-[#0D9488]/30 hover:-translate-y-1 cursor-default">
            <Lock className="w-6 h-6 text-[var(--accent-sage)]" />
            <h3 className="font-heading font-bold text-lg text-kithra">Signal E2E Encryption</h3>
            <p className="text-sm text-kithra-muted leading-relaxed font-body">Your direct conversations use the Signal protocol. They are mathematically unreadable to Kithra employees, third parties, or algorithms.</p>
          </div>
          <div className="p-8 rounded-3xl bg-[var(--surface-main)] border border-kithra space-y-3 transition-all duration-300 hover:shadow-[0_8px_30px_rgb(13,148,136,0.12)] hover:border-[#0D9488]/30 hover:-translate-y-1 cursor-default">
            <FileSpreadsheet className="w-6 h-6 text-[var(--accent-sage)]" />
            <h3 className="font-heading font-bold text-lg text-kithra">DPDP Compliance</h3>
            <p className="text-sm text-kithra-muted leading-relaxed font-body">Strict adherence to India’s data protection laws. You own your data. Export your archive or purge your account permanently anytime.</p>
          </div>
          <div className="p-8 rounded-3xl bg-[var(--surface-main)] border border-kithra space-y-3 transition-all duration-300 hover:shadow-[0_8px_30px_rgb(13,148,136,0.12)] hover:border-[#0D9488]/30 hover:-translate-y-1 cursor-default">
            <Fingerprint className="w-6 h-6 text-[var(--accent-sage)]" />
            <h3 className="font-heading font-bold text-lg text-kithra">Private by Design</h3>
            <p className="text-sm text-kithra-muted leading-relaxed font-body">There is no public browsing catalog. Your profile is strictly invisible to the public and only revealed to highly compatible mutual matches.</p>
          </div>
        </div>
      </motion.section>

      {/* SECTION 8: PRICING */}
      <motion.section 
        initial="hidden" 
        whileInView="visible" 
        viewport={{ once: true, margin: "-100px" }} 
        variants={sectionVariants} 
        className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto py-12"
      >
        <div className="text-center space-y-4 mb-12">
          <h2 className="font-heading font-extrabold text-4xl sm:text-5xl text-kithra">
            Transparent Pricing
          </h2>
          <p className="font-body text-lg text-kithra-muted">
            No dark patterns. No hidden fees. No advertising revenue. 
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="p-8 rounded-3xl bg-[var(--surface-main)] border border-kithra space-y-8 flex flex-col justify-between transition-all duration-300 hover:shadow-[0_8px_30px_rgb(13,148,136,0.08)] hover:-translate-y-1">
            <div className="space-y-4">
              <div className="space-y-1">
                <h3 className="font-heading font-bold text-xl text-kithra">Self-Discovery</h3>
                <p className="text-xs text-kithra-muted leading-relaxed">Understand yourself. The foundational blueprint.</p>
              </div>
              <div className="font-heading font-extrabold text-3xl text-kithra">
                ₹0 <span className="text-xs font-normal text-kithra-muted font-body">/ forever</span>
              </div>
              <ul className="space-y-3 text-xs text-kithra-muted font-body pt-2">
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-[var(--accent-sage)]" /> 100-Question Blueprint</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-[var(--accent-sage)]" /> Self-Awareness Index</li>
              </ul>
            </div>
            <button
              onClick={() => setActiveTab('assessment')}
              className="w-full py-3 rounded-xl bg-[var(--bg-main)] border border-kithra font-heading font-bold text-xs text-kithra hover:border-[var(--accent-sage)] transition-colors cursor-pointer"
            >
              Discover Your Blueprint
            </button>
          </div>

          <div className="p-8 rounded-3xl bg-[#0D9488] space-y-8 shadow-sm flex flex-col justify-between relative text-white md:-mt-4 md:mb-4 transition-all duration-300 hover:shadow-[0_12px_40px_rgb(13,148,136,0.3)] hover:-translate-y-1">
            <span className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-[var(--surface-main)] text-[var(--accent-sage)] font-data text-[10px] uppercase tracking-widest font-bold">
              Most Popular
            </span>
            <div className="space-y-4">
              <div className="space-y-1">
                <h3 className="font-heading font-bold text-xl">Essential OS</h3>
                <p className="text-xs opacity-80 leading-relaxed">Meet compatible people backed by intelligence.</p>
              </div>
              <div className="font-heading font-extrabold text-3xl">
                ₹369 <span className="text-xs font-normal opacity-80 font-body">/ month</span>
              </div>
              <ul className="space-y-3 text-xs font-body pt-2">
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-white/50" /> Clinical Dossier Report</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-white/50" /> Verified Introductions</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-white/50" /> Encrypted Messaging</li>
              </ul>
            </div>
            <button
              onClick={onOpenAuth}
              className="w-full py-3 rounded-xl bg-white text-[#0D9488] font-heading font-bold text-xs transition-opacity hover:opacity-90 shadow-md cursor-pointer"
            >
              Explore Compatibility
            </button>
          </div>

          <div className="p-8 rounded-3xl bg-[var(--surface-main)] border border-kithra space-y-8 flex flex-col justify-between transition-all duration-300 hover:shadow-[0_8px_30px_rgb(212,168,83,0.1)] hover:border-[var(--gold-verify)]/30 hover:-translate-y-1">
            <div className="space-y-4">
              <div className="space-y-1">
                <h3 className="font-heading font-bold text-xl text-kithra">Master OS</h3>
                <p className="text-xs text-kithra-muted leading-relaxed">Build relationships with lifelong deep insights.</p>
              </div>
              <div className="font-heading font-extrabold text-3xl text-kithra">
                ₹696 <span className="text-xs font-normal text-kithra-muted font-body">/ one-time</span>
              </div>
              <ul className="space-y-3 text-xs text-kithra-muted font-body pt-2">
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-[var(--gold-verify)]" /> Lifetime Matches</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-[var(--gold-verify)]" /> Relationship Journaling</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-[var(--gold-verify)]" /> Priority Support</li>
              </ul>
            </div>
            <button
              onClick={onOpenAuth}
              className="w-full py-3 rounded-xl bg-[var(--bg-main)] border border-kithra font-heading font-bold text-xs text-kithra hover:border-[var(--gold-verify)] transition-colors cursor-pointer"
            >
              Get Lifetime Access
            </button>
          </div>
        </div>
      </motion.section>

      {/* SECTION 9: FAQ */}
      <motion.section 
        initial="hidden" 
        whileInView="visible" 
        viewport={{ once: true, margin: "-100px" }} 
        variants={sectionVariants} 
        className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 py-12"
      >
        <div className="text-center space-y-4">
          <h2 className="font-heading font-extrabold text-3xl sm:text-4xl text-kithra">
            Clear Answers
          </h2>
          <p className="font-body text-lg text-kithra-muted">
            We value absolute transparency regarding your data, privacy, and matching mechanics.
          </p>
        </div>

        <div className="space-y-3 pt-6">
          {FAQ_ITEMS.map((faq, idx) => (
            <div 
              key={idx}
              className="rounded-2xl bg-[var(--surface-main)] border border-kithra overflow-hidden transition-colors"
            >
              <button
                onClick={() => setOpenFaqIndex(openFaqIndex === idx ? null : idx)}
                className="w-full p-5 text-left flex items-center justify-between gap-4 focus:outline-none cursor-pointer hover:bg-[var(--bg-main)]/50 transition-colors"
              >
                <span className="font-heading font-semibold text-sm sm:text-base text-kithra">
                  {faq.question}
                </span>
                {openFaqIndex === idx ? (
                  <ChevronUp className="w-5 h-5 text-[var(--accent-sage)] shrink-0" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-kithra-muted shrink-0" />
                )}
              </button>
              {openFaqIndex === idx && (
                <div className="px-5 pb-5 text-sm text-kithra-muted leading-relaxed font-body border-t border-kithra/50 pt-4">
                  {faq.answer}
                </div>
              )}
            </div>
          ))}
        </div>
      </motion.section>


      {/* SECTION 11: FINAL CTA */}
      <motion.section 
        initial="hidden" 
        whileInView="visible" 
        viewport={{ once: true, margin: "-100px" }} 
        variants={containerVariants} 
        className="px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto pb-24 pt-12 text-center space-y-10"
      >
        <div>
          {['You may meet hundreds of people.', 'You may only build one life.'].map((line, i) => (
            <motion.span key={i} variants={itemVariants} className="font-serif italic text-4xl sm:text-5xl text-kithra leading-tight block">
              {line}
            </motion.span>
          ))}
          <motion.span variants={itemVariants} className="font-heading font-extrabold text-4xl sm:text-5xl text-[var(--accent-sage)] tracking-tight block mt-2">
            Choose with understanding.
          </motion.span>
        </div>
        
        <motion.div variants={itemVariants}>
          <button 
            onClick={() => setActiveTab('assessment')}
            className="px-10 py-5 rounded-2xl bg-[#0D9488] hover:bg-[#0B7C72] text-white font-heading font-bold text-lg shadow-xl hover:shadow-2xl transition-all cursor-pointer animate-pulse"
          >
            Begin Your Journey
          </button>
        </motion.div>
      </motion.section>

    </div>
  );
};
