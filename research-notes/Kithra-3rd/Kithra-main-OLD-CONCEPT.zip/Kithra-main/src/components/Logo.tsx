import React from 'react';

interface LogoProps {
  className?: string;
}

export const KithraLogo: React.FC<LogoProps> = ({ className = "w-10 h-10" }) => {
  return (
    <svg 
      viewBox="0 0 100 60" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Left Sage Circle */}
      <circle 
        cx="35" 
        cy="30" 
        r="20" 
        stroke="#7FA98D" 
        strokeWidth="6" 
      />
      
      {/* Right Gold Circle */}
      <circle 
        cx="65" 
        cy="30" 
        r="20" 
        stroke="#D4AF37" 
        strokeWidth="6" 
      />

      {/* Center 4-Pointed Star */}
      <path 
        d="M 50 10 Q 50 30 32 30 Q 50 30 50 50 Q 50 30 68 30 Q 50 30 50 10 Z" 
        fill="currentColor" 
        className="text-kithra dark:text-white drop-shadow-sm"
      />
    </svg>
  );
};
