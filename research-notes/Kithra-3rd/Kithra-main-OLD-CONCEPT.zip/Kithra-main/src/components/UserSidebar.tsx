import React, { useState } from 'react';
import { ActiveTab, AppMode } from '../types';
import { 
  Home, 
  Brain, 
  Heart, 
  Users, 
  MessageSquare, 
  BookOpen, 
  BarChart3, 
  User, 
  Settings, 
  Crown, 
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  CreditCard
} from 'lucide-react';
import { KithraLogo } from './Logo';

interface UserSidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  setAppMode: (mode: AppMode) => void;
  onOpenUpgradeModal?: () => void;
}

export const UserSidebar: React.FC<UserSidebarProps> = ({
  activeTab,
  setActiveTab,
  setAppMode,
  onOpenUpgradeModal
}) => {
  const [isCollapsed, setIsCollapsed] = useState(false);

  const mainNav: { id: ActiveTab; label: string; icon: React.ReactNode; badge?: string; badgeColor?: string }[] = [
    { id: 'home', label: 'Home', icon: <Home className="w-4 h-4" /> },
    { id: 'assessment', label: 'Assessment', icon: <Brain className="w-4 h-4" />, badge: '82%', badgeColor: 'bg-[var(--accent-sage)]/10 text-[var(--accent-sage)]' },
    { id: 'matches', label: 'Matches', icon: <Users className="w-4 h-4" />, badge: '3', badgeColor: 'bg-[var(--gold-verify)]/10 text-[var(--gold-verify)]' },
    { id: 'messages', label: 'Messages', icon: <MessageSquare className="w-4 h-4" />, badge: '1', badgeColor: 'bg-emerald-500/10 text-emerald-600' },
  ];

  const growthNav: { id: ActiveTab; label: string; icon: React.ReactNode }[] = [
    { id: 'report', label: 'Report Blueprint', icon: <Heart className="w-4 h-4" /> },
    { id: 'journal', label: 'Knowledge Base', icon: <BookOpen className="w-4 h-4" /> },
    { id: 'insights', label: 'Growth Story', icon: <BarChart3 className="w-4 h-4" /> },
  ];

  const systemNav: { id: ActiveTab; label: string; icon: React.ReactNode }[] = [
    { id: 'profile', label: 'Profile & Credentials', icon: <User className="w-4 h-4" /> },
    { id: 'billing', label: 'Billing & Plans', icon: <CreditCard className="w-4 h-4" /> },
    { id: 'security', label: 'Security Center', icon: <ShieldCheck className="w-4 h-4" /> },
    { id: 'settings', label: 'OS Settings', icon: <Settings className="w-4 h-4" /> },
  ];

  return (
    <aside className={`${isCollapsed ? 'w-20' : 'w-64'} bg-[var(--bg-main)] border-r border-kithra/20 flex flex-col justify-between h-screen sticky top-0 shrink-0 z-30 select-none transition-all duration-300 ease-in-out`}>
      <div>
        {/* Brand Header */}
        <div className="p-4 pt-6 pb-2 flex items-center justify-between">
          <button 
            onClick={() => {
              setAppMode('public');
              setActiveTab('landing');
            }}
            className="flex items-center gap-3 cursor-pointer group text-left overflow-hidden"
            title="View Universal Public Site"
          >
            <div className="flex items-center justify-center group-hover:scale-105 transition-transform shrink-0">
              <KithraLogo className="w-8 h-8" />
            </div>
            {!isCollapsed && (
              <div className="transition-opacity duration-200">
                <span className="text-xl font-heading font-extrabold tracking-tight uppercase block text-kithra leading-none">
                  Kithra
                </span>
                <span className="font-heading font-semibold text-[9px] text-[var(--accent-sage)] tracking-widest uppercase block mt-1">
                  Workspace OS
                </span>
              </div>
            )}
          </button>

          {/* Collapse Toggle */}
          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="p-1.5 rounded-lg border border-kithra/20 hover:border-kithra text-kithra-muted hover:text-kithra transition-colors cursor-pointer"
            title={isCollapsed ? "Expand Sidebar" : "Collapse Sidebar"}
          >
            {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        </div>

        {/* Navigation Sections */}
        <div className="px-3 py-4 space-y-6 overflow-y-auto max-h-[calc(100vh-200px)]">
          
          {/* Main Section */}
          <div>
            {!isCollapsed && (
              <div className="px-3 mb-2 font-heading text-[10px] uppercase tracking-wider text-kithra-muted/70 font-bold">
                Main Workspace
              </div>
            )}
            <nav className="space-y-1">
              {mainNav.map((item) => {
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    title={isCollapsed ? item.label : undefined}
                    className={`w-full px-3 py-2.5 rounded-xl text-xs font-heading font-bold flex items-center justify-between transition-all cursor-pointer ${
                      isActive 
                        ? 'text-[var(--accent-sage)] bg-[var(--accent-sage)]/10 border border-[var(--accent-sage)]/20 shadow-xs' 
                        : 'text-kithra-muted hover:text-kithra hover:bg-black/5 dark:hover:bg-white/5 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className={isActive ? 'text-[var(--accent-sage)]' : 'text-kithra-muted/70'}>
                        {item.icon}
                      </span>
                      {!isCollapsed && <span>{item.label}</span>}
                    </div>

                    {!isCollapsed && item.badge && (
                      <span className={`px-2 py-0.5 rounded-full font-heading text-[10px] font-bold ${item.badgeColor}`}>
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Growth Section */}
          <div>
            {!isCollapsed && (
              <div className="px-3 mb-2 font-heading text-[10px] uppercase tracking-wider text-kithra-muted/70 font-bold">
                Growth Engine
              </div>
            )}
            <nav className="space-y-1">
              {growthNav.map((item) => {
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    title={isCollapsed ? item.label : undefined}
                    className={`w-full px-3 py-2.5 rounded-xl text-xs font-heading font-bold flex items-center gap-3 transition-all cursor-pointer ${
                      isActive 
                        ? 'text-[var(--accent-sage)] bg-[var(--accent-sage)]/10 border border-[var(--accent-sage)]/20 shadow-xs' 
                        : 'text-kithra-muted hover:text-kithra hover:bg-black/5 dark:hover:bg-white/5 border border-transparent'
                    }`}
                  >
                    <span className={isActive ? 'text-[var(--accent-sage)]' : 'text-kithra-muted/70'}>
                      {item.icon}
                    </span>
                    {!isCollapsed && <span>{item.label}</span>}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* System Section */}
          <div>
            {!isCollapsed && (
              <div className="px-3 mb-2 font-heading text-[10px] uppercase tracking-wider text-kithra-muted/70 font-bold">
                System Controls
              </div>
            )}
            <nav className="space-y-1">
              {systemNav.map((item) => {
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    title={isCollapsed ? item.label : undefined}
                    className={`w-full px-3 py-2.5 rounded-xl text-xs font-heading font-bold flex items-center gap-3 transition-all cursor-pointer ${
                      isActive 
                        ? 'text-[var(--accent-sage)] bg-[var(--accent-sage)]/10 border border-[var(--accent-sage)]/20 shadow-xs' 
                        : 'text-kithra-muted hover:text-kithra hover:bg-black/5 dark:hover:bg-white/5 border border-transparent'
                    }`}
                  >
                    <span className={isActive ? 'text-[var(--accent-sage)]' : 'text-kithra-muted/70'}>
                      {item.icon}
                    </span>
                    {!isCollapsed && <span>{item.label}</span>}
                  </button>
                );
              })}
            </nav>
          </div>

        </div>
      </div>

      {/* Footer Bottom Actions */}
      <div className="p-3 space-y-2 border-t border-kithra/10">
        
        {/* Upgrade Card */}
        <button
          onClick={() => setActiveTab('billing')}
          className="w-full p-3 rounded-2xl bg-gradient-to-br from-[var(--gold-verify)]/10 to-[var(--bg-main)] border border-[var(--gold-verify)]/30 hover:border-[var(--gold-verify)] flex flex-col text-left transition-all cursor-pointer group shadow-soft"
        >
          <div className="flex items-center justify-between w-full">
            <Crown className="w-4 h-4 text-[var(--gold-verify)] group-hover:rotate-12 transition-transform" />
            {!isCollapsed && (
              <span className="px-2 py-0.5 rounded bg-[var(--gold-verify)]/10 text-[var(--gold-verify)] font-heading text-[9px] font-bold uppercase tracking-wider">
                Master OS
              </span>
            )}
          </div>
          {!isCollapsed && (
            <div className="mt-1.5">
              <span className="font-heading font-bold text-xs text-kithra block">Master Member</span>
              <span className="font-body text-[10px] text-kithra-muted block">All features unlocked</span>
            </div>
          )}
        </button>

      </div>
    </aside>
  );
};

