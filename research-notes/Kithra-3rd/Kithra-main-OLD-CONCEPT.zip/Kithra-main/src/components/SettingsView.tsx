import React, { useState } from 'react';
import { 
  Sliders, 
  Moon, 
  Sun, 
  Globe, 
  Bell, 
  ShieldCheck, 
  Lock, 
  Download, 
  Trash2, 
  EyeOff,
  CheckCircle2
} from 'lucide-react';

interface SettingsViewProps {
  isDarkMode: boolean;
  setIsDarkMode: (val: boolean) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ isDarkMode, setIsDarkMode }) => {
  const [isIncognito, setIsIncognito] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState('English');
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);

  const languages = [
    { name: 'English', script: 'English' },
    { name: 'Hindi', script: 'Devanagari (हिंदी)' },
    { name: 'Tamil', script: 'Tamil (தமிழ்)' },
    { name: 'Telugu', script: 'Telugu (తెలుగు)' },
    { name: 'Kannada', script: 'Kannada (கன்னட)' },
    { name: 'Malayalam', script: 'Malayalam (മലയാളം)' }
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Header Banner */}
      <div className="p-8 rounded-3xl bg-[var(--surface-main)] border border-kithra/15 space-y-2 shadow-xs">
        <div className="flex items-center gap-2">
          <Sliders className="w-5 h-5 text-[var(--accent-sage)]" />
          <h1 className="font-heading font-extrabold text-2xl text-kithra">
            Account & OS Settings
          </h1>
        </div>
        <p className="text-xs sm:text-sm text-kithra-muted font-body">
          Manage your privacy preferences, DPDP data ownership, theme mode, and subscriptions.
        </p>
      </div>

      <div className="space-y-6">
        
        {/* Appearance & Theme */}
        <div className="p-6 rounded-3xl bg-[var(--surface-main)] border border-kithra/15 space-y-4">
          <h3 className="font-heading font-bold text-base text-kithra">
            Appearance & Theme
          </h3>

          <div className="flex items-center justify-between p-4 rounded-2xl bg-[var(--bg-main)] border border-kithra/15">
            <div className="space-y-0.5">
              <span className="font-heading font-semibold text-sm text-kithra block">Dark Mode Canvas</span>
              <span className="text-xs text-kithra-muted block font-body">Independently designed high-contrast dark theme.</span>
            </div>
            <button
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="px-4 py-2 rounded-xl border border-kithra/15 bg-[var(--surface-main)] text-xs font-heading font-bold text-kithra hover:border-[var(--accent-sage)] flex items-center gap-2 cursor-pointer transition-colors"
            >
              {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
              <span>{isDarkMode ? 'Dark Enabled' : 'Light Enabled'}</span>
            </button>
          </div>
        </div>

        {/* Language & Indian Script Fallbacks */}
        <div className="p-6 rounded-3xl bg-[var(--surface-main)] border border-kithra/15 space-y-4">
          <div className="space-y-1">
            <h3 className="font-heading font-bold text-base text-kithra flex items-center gap-2">
              <Globe className="w-4 h-4 text-[var(--accent-sage)]" />
              <span>Language & Typography</span>
            </h3>
            <p className="text-xs text-kithra-muted font-body">
              Identical visual rhythm maintained across all Indian scripts.
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
            {languages.map((lang) => (
              <button
                key={lang.name}
                onClick={() => setSelectedLanguage(lang.name)}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  selectedLanguage === lang.name 
                    ? 'bg-[#0D9488] text-white border-[#0D9488]' 
                    : 'bg-[var(--bg-main)] text-kithra-muted border-kithra/15 hover:text-kithra'
                }`}
              >
                <span className="font-heading font-semibold text-xs block">{lang.name}</span>
                <span className="font-body text-[11px] opacity-80 block">{lang.script}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Privacy & Incognito Mode */}
        <div className="p-6 rounded-3xl bg-[var(--surface-main)] border border-kithra/15 space-y-4">
          <h3 className="font-heading font-bold text-base text-kithra">
            Matching Privacy & Visibility
          </h3>

          <div className="flex items-center justify-between p-4 rounded-2xl bg-[var(--bg-main)] border border-kithra/15">
            <div className="space-y-0.5">
              <span className="font-heading font-semibold text-sm text-kithra block">Incognito / Pause Matching</span>
              <span className="text-xs text-kithra-muted block font-body">Temporarily hide your profile while preserving your report.</span>
            </div>
            <button
              onClick={() => setIsIncognito(!isIncognito)}
              className={`px-4 py-2 rounded-xl text-xs font-heading font-bold transition-colors flex items-center gap-1.5 cursor-pointer ${
                isIncognito ? 'bg-[var(--coral-error)] text-white' : 'bg-[var(--surface-main)] text-kithra border border-kithra/15'
              }`}
            >
              <EyeOff className="w-3.5 h-3.5" />
              <span>{isIncognito ? 'Incognito Active' : 'Visible'}</span>
            </button>
          </div>
        </div>

        {/* DPDP Compliance & Data Export */}
        <div className="p-6 rounded-3xl bg-[var(--surface-main)] border border-kithra/15 space-y-4">
          <h3 className="font-heading font-bold text-base text-kithra flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[var(--gold-verify)]" />
            <span>DPDP Data Ownership & Security</span>
          </h3>

          <div className="space-y-3">
            <button
              onClick={() => alert("Your complete DPDP data archive CSV has been compiled and downloaded.")}
              className="w-full p-4 rounded-2xl bg-[var(--bg-main)] border border-kithra text-left flex items-center justify-between text-xs font-heading font-semibold text-kithra hover:border-[var(--accent-sage)] transition-colors"
            >
              <div className="space-y-0.5">
                <span className="block">Export Full DPDP Data Archive (CSV/JSON)</span>
                <span className="text-kithra-muted font-normal block">Download all assessment responses, messages, and verification logs.</span>
              </div>
              <Download className="w-4 h-4 text-[var(--accent-sage)] shrink-0" />
            </button>

            <button
              onClick={() => {
                if (confirm("Are you sure you want to permanently delete your Kithra account and purge all data? This cannot be undone.")) {
                  alert("Account deleted and data purged successfully.");
                }
              }}
              className="w-full p-4 rounded-2xl bg-[var(--bg-main)] border border-[var(--coral-error)]/40 text-left flex items-center justify-between text-xs font-heading font-semibold text-[var(--coral-error)] hover:bg-[var(--coral-error)]/10 transition-colors"
            >
              <div className="space-y-0.5">
                <span className="block">Delete Account & Purge Data Permanently</span>
                <span className="text-kithra-muted font-normal block">Immediately erase all assessment records and signal messages from servers.</span>
              </div>
              <Trash2 className="w-4 h-4 shrink-0" />
            </button>
          </div>
        </div>

      </div>

    </div>
  );
};
