import React, { useState } from 'react';
import { ProfileSubTab } from '../types';
import { 
  ShieldCheck, 
  CheckCircle2, 
  Activity, 
  Music, 
  Linkedin, 
  User, 
  Sparkles, 
  Brain, 
  MapPin,
  Compass,
  Briefcase,
  Heart,
  Home,
  Image as ImageIcon,
  BookOpen
} from 'lucide-react';

export const ProfileView: React.FC = () => {
  const [activeSubTab, setActiveSubTab] = useState<ProfileSubTab>('Identity');

  const subTabs: { id: ProfileSubTab; label: string; icon: React.ReactNode }[] = [
    { id: 'Identity', label: 'Identity', icon: <User className="w-3.5 h-3.5" /> },
    { id: 'Verification', label: 'Verification', icon: <ShieldCheck className="w-3.5 h-3.5 text-[var(--gold-verify)]" /> },
    { id: 'Values', label: 'Values', icon: <Brain className="w-3.5 h-3.5" /> },
    { id: 'Lifestyle', label: 'Lifestyle', icon: <Compass className="w-3.5 h-3.5" /> },
    { id: 'Career', label: 'Career', icon: <Briefcase className="w-3.5 h-3.5" /> },
    { id: 'Religion', label: 'Religion & Philosophy', icon: <Sparkles className="w-3.5 h-3.5" /> },
    { id: 'Family', label: 'Family & Children', icon: <Heart className="w-3.5 h-3.5" /> },
    { id: 'Habits', label: 'Habits & Order', icon: <Home className="w-3.5 h-3.5" /> },
    { id: 'Photos', label: 'Photos', icon: <ImageIcon className="w-3.5 h-3.5" /> },
    { id: 'Compatibility DNA', label: 'Compatibility DNA', icon: <Activity className="w-3.5 h-3.5" /> },
  ];

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      
      {/* Top Profile Hero Card */}
      <div className="p-8 sm:p-10 rounded-3xl bg-[var(--surface-main)] border border-kithra space-y-6 shadow-xs">
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
          <img 
            src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80" 
            alt="User avatar" 
            className="w-24 h-24 rounded-3xl object-cover border-2 border-[var(--accent-sage)] shadow-sm shrink-0"
          />

          <div className="space-y-2 text-center sm:text-left flex-1">
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
              <h1 className="font-heading font-extrabold text-2xl text-kithra">
                Dr. Ananya Sharma, 29
              </h1>
              <span className="px-2.5 py-0.5 rounded-full bg-[var(--gold-verify)]/15 text-[var(--gold-verify)] font-heading text-xs font-bold flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                Institutional Verification 100%
              </span>
            </div>

            <p className="text-xs font-body text-kithra-muted flex items-center justify-center sm:justify-start gap-1">
              <MapPin className="w-3.5 h-3.5 text-[var(--accent-sage)]" />
              <span>Bengaluru, Karnataka, India • Cognitive Neuroscientist</span>
            </p>

            <p className="font-body text-xs sm:text-sm text-kithra leading-relaxed pt-1">
              "Studying human memory dynamics by day, exploring classical violin by night. Seeking a partner grounded in peace, intellectual curiosity, and shared sanctuary."
            </p>
          </div>
        </div>

        {/* Sub-Tab Navigation Bar */}
        <div className="flex items-center gap-2 pt-4 border-t border-kithra/15 overflow-x-auto pb-1">
          {subTabs.map((tab) => {
            const isActive = activeSubTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveSubTab(tab.id)}
                className={`px-3.5 py-2 rounded-xl text-xs font-heading font-semibold flex items-center gap-2 whitespace-nowrap transition-all cursor-pointer ${
                  isActive 
                    ? 'bg-[#0D9488] text-white shadow-2xs' 
                    : 'bg-[var(--bg-main)] text-kithra-muted border border-kithra/15 hover:text-kithra'
                }`}
              >
                <span>{tab.icon}</span>
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Sub-Tab Content Views */}
      <div className="p-8 rounded-3xl bg-[var(--surface-main)] border border-kithra/15 shadow-2xs space-y-6">
        
        {activeSubTab === 'Identity' && (
          <div className="space-y-4">
            <h3 className="font-heading font-bold text-lg text-kithra">Basic Identity & Background</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-body text-kithra">
              <div className="p-4 rounded-2xl bg-[var(--bg-main)] border border-kithra/15 space-y-1">
                <span className="font-heading text-[10px] uppercase tracking-wider text-kithra-muted font-bold block">Full Name & Credentials</span>
                <span className="font-bold block text-sm font-heading">Dr. Ananya Sharma, Ph.D.</span>
              </div>
              <div className="p-4 rounded-2xl bg-[var(--bg-main)] border border-kithra/15 space-y-1">
                <span className="font-heading text-[10px] uppercase tracking-wider text-kithra-muted font-bold block">Current Residence</span>
                <span className="font-bold block text-sm font-heading">Indiranagar, Bengaluru, India</span>
              </div>
              <div className="p-4 rounded-2xl bg-[var(--bg-main)] border border-kithra/15 space-y-1">
                <span className="font-heading text-[10px] uppercase tracking-wider text-kithra-muted font-bold block">Hometown / Heritage</span>
                <span className="font-bold block text-sm font-heading">Jaipur, Rajasthan, India</span>
              </div>
              <div className="p-4 rounded-2xl bg-[var(--bg-main)] border border-kithra/15 space-y-1">
                <span className="font-heading text-[10px] uppercase tracking-wider text-kithra-muted font-bold block">Languages Spoken</span>
                <span className="font-bold block text-sm font-heading">English, Hindi, Kannada (Conversational)</span>
              </div>
            </div>
          </div>
        )}

        {activeSubTab === 'Verification' && (
          <div className="space-y-4">
            <h3 className="font-heading font-bold text-lg text-kithra flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-[var(--gold-verify)]" />
              <span>Government & Institutional Verification Badges</span>
            </h3>

            <div className="space-y-3">
              <div className="p-4 rounded-2xl bg-[var(--bg-main)] border border-kithra/15 flex items-center justify-between text-xs font-body">
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-[var(--gold-verify)]" />
                  <div>
                    <span className="font-bold block text-kithra font-heading">Government Photo ID (Aadhaar / Passport)</span>
                    <span className="text-kithra-muted">Verified on 12 Jan 2026 via Cryptographic Check</span>
                  </div>
                </div>
                <span className="px-2.5 py-1 rounded bg-[var(--gold-verify)]/15 text-[var(--gold-verify)] font-heading font-bold">100% Passed</span>
              </div>

              <div className="p-4 rounded-2xl bg-[var(--bg-main)] border border-kithra/15 flex items-center justify-between text-xs font-body">
                <div className="flex items-center gap-3">
                  <Linkedin className="w-5 h-5 text-blue-600" />
                  <div>
                    <span className="font-bold block text-kithra">LinkedIn Professional Profile Sync</span>
                    <span className="text-kithra-muted">National Institute of Mental Health & Neurosciences (NIMHANS)</span>
                  </div>
                </div>
                <span className="px-2.5 py-1 rounded bg-[var(--accent-sage)]/10 text-[var(--accent-sage)] font-bold">Synced</span>
              </div>

              <div className="p-4 rounded-2xl bg-[var(--bg-main)] border border-kithra/15 flex items-center justify-between text-xs font-body">
                <div className="flex items-center gap-3">
                  <Linkedin className="w-5 h-5 text-blue-600" />
                  <div>
                    <span className="font-bold block text-kithra font-heading">LinkedIn Professional Profile Sync</span>
                    <span className="text-kithra-muted">National Institute of Mental Health & Neurosciences (NIMHANS)</span>
                  </div>
                </div>
                <span className="px-2.5 py-1 rounded bg-[var(--accent-sage)]/10 text-[var(--accent-sage)] font-heading font-bold">Synced</span>
              </div>

              <div className="p-4 rounded-2xl bg-[var(--bg-main)] border border-kithra/15 flex items-center justify-between text-xs font-body">
                <div className="flex items-center gap-3">
                  <Activity className="w-5 h-5 text-red-500" />
                  <div>
                    <span className="font-bold block text-kithra font-heading">Apple Health Sleep & Wellness Sync</span>
                    <span className="text-kithra-muted">Consistent early riser (6:00 AM) verified</span>
                  </div>
                </div>
                <span className="px-2.5 py-1 rounded bg-[var(--accent-sage)]/10 text-[var(--accent-sage)] font-heading font-bold">Connected</span>
              </div>
            </div>
          </div>
        )}

        {activeSubTab === 'Values' && (
          <div className="space-y-4">
            <h3 className="font-heading font-bold text-lg text-kithra">Core Compass & Ethics</h3>
            <div className="space-y-3 text-xs sm:text-sm font-body text-kithra">
              <div className="p-4 rounded-2xl bg-[var(--bg-main)] border border-kithra/15">
                <span className="font-heading text-[10px] uppercase tracking-wider text-kithra-muted font-bold block">Truth & Transparency</span>
                <span>Values extreme directness and clear boundary agreements over polite evasion.</span>
              </div>
              <div className="p-4 rounded-2xl bg-[var(--bg-main)] border border-kithra/15">
                <span className="font-heading text-[10px] uppercase tracking-wider text-kithra-muted font-bold block">Financial Philosophy</span>
                <span>Proponent of shared long-term asset building while maintaining individual autonomy pools.</span>
              </div>
            </div>
          </div>
        )}

        {activeSubTab === 'Lifestyle' && (
          <div className="space-y-4">
            <h3 className="font-heading font-bold text-lg text-kithra">Lifestyle & Daily Rhythms</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-body text-kithra">
              <div className="p-4 rounded-2xl bg-[var(--bg-main)] border border-kithra/15">
                <span className="font-heading text-[10px] uppercase tracking-wider text-kithra-muted font-bold block">Morning Routine</span>
                <span>6:00 AM wake up, pour-over coffee, 45 minutes of quiet reading or classical violin.</span>
              </div>
              <div className="p-4 rounded-2xl bg-[var(--bg-main)] border border-kithra/15">
                <span className="font-heading text-[10px] uppercase tracking-wider text-kithra-muted font-bold block">Weekend Leisure</span>
                <span>Weekend nature hikes, chamber music rehearsals, exploring artisanal cafes.</span>
              </div>
            </div>
          </div>
        )}

        {activeSubTab === 'Career' && (
          <div className="space-y-4">
            <h3 className="font-heading font-bold text-lg text-kithra">Career & Ambition</h3>
            <p className="text-xs text-kithra leading-relaxed font-body">
              Assistant Professor of Cognitive Neuroscience. Deeply passionate about research on neuroplasticity and memory consolidation. Seeks a partner who respects intellectual dedication while maintaining work-life balance.
            </p>
          </div>
        )}

        {activeSubTab === 'Religion' && (
          <div className="space-y-4">
            <h3 className="font-heading font-bold text-lg text-kithra">Religion, Faith & Philosophy</h3>
            <p className="text-xs text-kithra leading-relaxed font-body">
              Rational humanism with deep respect for mindful philosophical traditions and nature reverence. Non-dogmatic, open to cultural celebrations with mutual freedom.
            </p>
          </div>
        )}

        {activeSubTab === 'Family' && (
          <div className="space-y-4">
            <h3 className="font-heading font-bold text-lg text-kithra">Family & Children Stance</h3>
            <p className="text-xs text-kithra leading-relaxed font-body">
              Desire for children (1 or 2) within 3-4 years after building strong marital foundation. High respect for family elders while preserving autonomous marital decision-making.
            </p>
          </div>
        )}

        {activeSubTab === 'Habits' && (
          <div className="space-y-4">
            <h3 className="font-heading font-bold text-lg text-kithra">Home Order & Personal Habits</h3>
            <p className="text-xs text-kithra leading-relaxed font-body">
              Minimalist clutter-free living space. Plant-based diet. Non-smoker. Enjoys cooking dinner together at home during weeknights.
            </p>
          </div>
        )}

        {activeSubTab === 'Photos' && (
          <div className="space-y-4">
            <h3 className="font-heading font-bold text-lg text-kithra">Verified Photo Gallery</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              <img 
                src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80" 
                alt="Gallery photo 1" 
                className="w-full h-40 object-cover rounded-2xl border border-kithra/15"
              />
              <img 
                src="https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=600&q=80" 
                alt="Gallery photo 2" 
                className="w-full h-40 object-cover rounded-2xl border border-kithra/15"
              />
              <img 
                src="https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=600&q=80" 
                alt="Gallery photo 3" 
                className="w-full h-40 object-cover rounded-2xl border border-kithra/15"
              />
            </div>
          </div>
        )}

        {activeSubTab === 'Compatibility DNA' && (
          <div className="space-y-4">
            <h3 className="font-heading font-bold text-lg text-kithra">Psychometric DNA Summary</h3>
            <div className="p-4 rounded-2xl bg-[var(--bg-main)] border border-kithra/15 space-y-2 text-xs font-body">
              <div className="flex justify-between">
                <span className="text-kithra-muted">100-Q Assessment Status:</span>
                <span className="font-bold text-[var(--accent-sage)] font-heading">Completed (82/100 modules verified)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-kithra-muted">Attachment Baseline:</span>
                <span className="font-bold text-kithra font-heading">Secure-Autonomous (91%)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-kithra-muted">Primary Gottman Conflict Protocol:</span>
                <span className="font-bold text-[var(--gold-verify)] font-heading">15-Minute De-escalation Pause</span>
              </div>
            </div>
          </div>
        )}

      </div>

    </div>
  );
};
