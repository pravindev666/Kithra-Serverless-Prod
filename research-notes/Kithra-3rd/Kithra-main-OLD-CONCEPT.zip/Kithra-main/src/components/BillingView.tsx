import React from 'react';
import { motion } from 'framer-motion';
import { Crown, Check, ShieldCheck, Download, CreditCard, Sparkles, AlertCircle } from 'lucide-react';

export const BillingView: React.FC = () => {
  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-12">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-kithra/20 pb-6">
        <div>
          <span className="font-data text-xs uppercase tracking-widest text-[var(--accent-sage)] font-semibold">Account & Finance</span>
          <h2 className="font-heading font-extrabold text-3xl text-kithra mt-1">Subscription & Invoices</h2>
          <p className="font-body text-sm text-kithra-muted mt-1">Manage your active OS plan, payment methods, and billing history.</p>
        </div>

        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-[var(--gold-verify)]/10 text-[var(--gold-verify)] border border-[var(--gold-verify)]/20 font-data text-xs font-bold">
          <Crown className="w-4 h-4" />
          <span>MASTER OS ACTIVE</span>
        </div>
      </div>

      {/* Active Plan Card */}
      <div className="p-8 rounded-3xl bg-gradient-to-br from-[var(--surface-main)] via-[var(--bg-main)] to-[var(--surface-main)] border border-[var(--gold-verify)]/30 shadow-md relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-[var(--gold-verify)]/5 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[var(--accent-sage)]/10 text-[var(--accent-sage)] font-data text-[10px] font-bold uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Full OS Suite Unlocked</span>
            </div>
            <h3 className="font-heading font-extrabold text-2xl text-kithra">Master OS Lifetime Membership</h3>
            <p className="font-body text-sm text-kithra-muted max-w-xl">
              You have unrestricted lifetime access to all psychometric dossiers, E2E encrypted introductions, AI reflections, and priority matching.
            </p>
          </div>

          <div className="text-right shrink-0">
            <div className="font-heading font-extrabold text-3xl text-kithra">₹696</div>
            <span className="font-data text-xs text-kithra-muted uppercase tracking-wider">One-time payment</span>
          </div>
        </div>

        {/* Feature Checkmarks */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-8 border-t border-kithra/10 mt-6 font-body text-xs text-kithra-muted">
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-500" />
            <span>Lifetime Unlimited Introductions</span>
          </div>
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-500" />
            <span>Clinical Dossier PDF Export</span>
          </div>
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-500" />
            <span>AI Journal Reflection Graph</span>
          </div>
        </div>
      </div>

      {/* Payment Method & Billing Details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Payment Method */}
        <div className="p-6 rounded-2xl bg-[var(--surface-main)] border border-kithra space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="font-heading font-bold text-base text-kithra flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-[var(--accent-sage)]" />
              Payment Method
            </h4>
            <span className="font-data text-xs text-emerald-500 font-bold">Verified</span>
          </div>
          
          <div className="p-4 rounded-xl bg-[var(--bg-main)] border border-kithra/20 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-6 rounded bg-slate-800 text-white font-mono text-[10px] flex items-center justify-center font-bold">
                UPI / Card
              </div>
              <div>
                <span className="font-heading font-bold text-xs text-kithra block">Razorpay Direct Pay</span>
                <span className="font-data text-[10px] text-kithra-muted">Encrypted Tokenized</span>
              </div>
            </div>
          </div>
        </div>

        {/* DPDP Privacy Guarantee */}
        <div className="p-6 rounded-2xl bg-[var(--surface-main)] border border-kithra space-y-4">
          <h4 className="font-heading font-bold text-base text-kithra flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[var(--gold-verify)]" />
            Financial Privacy
          </h4>
          <p className="font-body text-xs text-kithra-muted leading-relaxed">
            Kithra never stores credit card or bank account credentials. All financial transactions are processed under India's Digital Personal Data Protection Act compliance protocols.
          </p>
        </div>

      </div>

      {/* Invoice History */}
      <div className="p-6 rounded-2xl bg-[var(--surface-main)] border border-kithra space-y-4">
        <h4 className="font-heading font-bold text-base text-kithra">Invoice History</h4>

        <div className="divide-y divide-kithra/10">
          <div className="py-3 flex items-center justify-between text-xs font-body">
            <div>
              <span className="font-heading font-bold text-kithra block">Master OS Membership</span>
              <span className="font-data text-[10px] text-kithra-muted">INV-2026-84920 • Aug 08, 2026</span>
            </div>
            <div className="flex items-center gap-4">
              <span className="font-heading font-bold text-kithra">₹696</span>
              <button className="p-2 rounded-lg border border-kithra/30 hover:border-[var(--accent-sage)] text-kithra-muted hover:text-kithra transition-colors cursor-pointer" title="Download Invoice">
                <Download className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
};
