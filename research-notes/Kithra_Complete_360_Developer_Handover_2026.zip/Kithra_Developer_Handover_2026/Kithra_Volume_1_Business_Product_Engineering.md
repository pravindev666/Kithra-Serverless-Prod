# BRD — Business Requirements Document

**Revision:** 1.0 | **Owner:** Founder | **Status:** proposed, not validated

## 1. Executive definition
Kithra is a consent-based human-connection network with three autonomous intention modes: **Friendship**, **Dating**, and **Matrimony**. Members answer versioned questionnaires to receive evidence-informed *descriptions* of similarities, differences, potential friction and complementary preferences, then mutually opt into introductions, conversations and groups. One login and wallet may serve the modes, but matching eligibility, profile visibility, consent, communications and paywalls must be independently configurable **per mode**. A marriage search must never be inferred from friendship participation.

### North-star outcome
**Mutually confirmed continued connection at day 30**, measured separately by friendship (recontact/shared activity), dating (mutual desire to continue), and matrimony (mutual intentional conversation and appropriate next step). Do not optimize time-on-app, endless swiping or survey completion alone.

### Economic reality
The product is a two-sided local-density network, a moderation service and a high-trust data custodian. A polished algorithm with 100,000 inactive accounts fails if compatible participants are not active in each relevant pool. Indian consumers are price-sensitive and matching promises face substantiation risk; initial revenue assumptions must be validated.

## 2. People and jobs to be done

**Comparison / requirement matrix — accessible record view:**

**Record 1: New-to-city adult (23–35)**

- **Persona:** New-to-city adult (23–35)
- **Need:** Reliable hobby companion
- **Non-negotiable risk:** unwanted romantic solicitation
- **Core mode:** Friendship

**Record 2: Introverted adult seeking serious friends**

- **Persona:** Introverted adult seeking serious friends
- **Need:** Low-pressure, compatible introductions
- **Non-negotiable risk:** harassment/ghosting
- **Core mode:** Friendship

**Record 3: Intentional dating adult (21–38)**

- **Persona:** Intentional dating adult (21–38)
- **Need:** Mutual values and expectations
- **Non-negotiable risk:** stalking/catfishing
- **Core mode:** Dating

**Record 4: Matrimony-seeking adult**

- **Persona:** Matrimony-seeking adult
- **Need:** Serious shared-life preferences, family involvement only with consent
- **Non-negotiable risk:** coercion, dowry, caste discrimination, unverified claims
- **Core mode:** Matrimony

**Record 5: Safety reviewer**

- **Persona:** Safety reviewer
- **Need:** Triage credible harm without uncontrolled access to intimate answers
- **Non-negotiable risk:** privacy misuse/unsafe content
- **Core mode:** Operations

**Record 6: Support agent**

- **Persona:** Support agent
- **Need:** Resolve payments, account access, appeals
- **Non-negotiable risk:** excessive privileges
- **Core mode:** Operations

**Record 7: Psychometrics steward**

- **Persona:** Psychometrics steward
- **Need:** Publish defensible question-bank versions and monitor bias
- **Non-negotiable risk:** pseudoscience, overinterpretation
- **Core mode:** Research


Age ranges are research cohorts, not hard exclusions. Product enrollment initially **18+**; adults should not be excluded merely by age. Questionnaires should work in English and later Indian languages with tested translations rather than machine-translated psychometric claims.

## 3. Business objectives (provisional gates)
- **B01** Demonstrate sustained connection: at least 20% of consenting introduced pairs mutually confirm a second interaction at day 30 in controlled cohort; threshold is an experiment target, not a market benchmark.
- **B02** Measure matching lift: test deep questionnaire vs interest/availability-only control on 30-day continued connections; launch deep-model differentiation only if measurable net benefit.
- **B03** Establish trust: safety incidents per 1,000 conversations, complaint acknowledgement, resolution times, repeat-offender rate and verified appeal outcomes; zero tolerated unaddressed critical incidents.
- **B04** Maintain economically sustainable operation: positive contribution per paying cohort after payment fees, infrastructure, fraud, refunds, human moderation and support—not just gross subscription receipts.
- **B05** Meet applicable Indian requirements and avoid data overcollection before launch.
- **B06** Preserve provider portability so D1/Workers can eventually be replaced without changing user domain concepts.

## 4. Product strategy: one account, three guarded contexts
- User chooses at least one intention, can change them, and can pause each independently.
- Never expose a friendship profile in the matrimonial pool automatically; no cross-mode message access, recommendations, group auto-enrollment or sensitive-profile reuse without explicit permission.
- Each mode has separate intent, visibility, answer-sharing rules, eligibility, filtering, discovery permissions and communication request workflows.
- Shared immutable identifiers and authentication reduce friction; distinct **mode persona** records reduce accidental exposure.
- No assurances that a user is a spouse, safe, truthful, eligible for marriage or medically/psychologically compatible merely because they complete a quiz.

## 5. Competitive alternatives and differentiated hypothesis
Comparable features exist in **OkCupid** (question compatibility), **We3** (friendship psychographics), **Boo** (personality matching), **Dimensional** (trait profiling), **TrulyMadly**, **Aisle**, **Schmooze**, **Betterhalf**, **Hinge**, plus existing **WhatsApp/Discord/Meetup** communities. AI-twin vendors claim similar avatar matching, but independently validated Indian outcome data is scarce. Kithra's defensible difference, *if proven*, is clearer three-context intent separation, explainable complementarity, practical safety and observed continuation of real relationships. The word "soul twin" is a user-friendly metaphor, not evidence of neurological identity.

## 6. Scope and exclusions

**Initial validated MVP:** account registration, mode consents and personas, limited quiz placeholders backed by versioned definitions, precomputed non-clinical trait summaries, mode-scoped match discovery, mutual requests, basic private chat, blocking/reporting, limited moderated groups, settings/data-rights, administrative triage, paid entitlements only after trust flows.

**MVP+ (after 90 days):** question bank expansions, score-band explainers, friend activities, notification digests, paid tiers, admin quiz publishing and blinded A/B evaluation.

**Later:** optional AI companion that summarizes *only expressly authorized user-provided traits*; supervised community organizers; native mobile apps; deeper matching calibration; multilingual cultural adaptation; family introduction controls in matrimony. Voice/video calls, face recognition, Aadhaar collection, involuntary sensitive trait inference and "AI brain replicas" are **out of MVP**. Persona simulation requires separate research, opt-in, opt-out, retention, guardrails and new privacy assessment.

## 7. Revenue strategy, acquisition and risks
- Free core: taking assessments, seeing basic summaries, discovering a useful number of users, blocking/reporting, deleting account, baseline chat after mutual connection.
- Premium: advanced filters, extended but rate-limited introductions, detailed opt-in comparison reports, private circles, non-safety convenience features; no priority to bypass other users' preferences.
- Matrimony may have separate paid plan later, but **must not bundle guaranteed match or marriage outcomes**.
- Acquisition: city/college-alumni/professional-cohort launches with a local density plan; referrals through genuinely useful shared experiences, not pressure.
- Key risks: adverse selection, ghosting, low women's safety confidence, cultural/marriage coercion, deceptive profiles, privacy catastrophe with intimate data, spurious psychometric certainty, high customer acquisition cost, payment disputes.

## 8. Operating model
Roles: founder/product owner; part-time moderator/on-call safety owner; qualified privacy counsel; independent security reviewer; psychometric advisor; technical owner. An unstaffed complaint channel is not acceptable for a live strangers-connected-to-strangers product. Establish availability and escalation coverage before wide launch.

**Business approvals required:** MVP positioning; allowed age; all three distinct mode eligibility policies; legal entity/contact details; pilot budget; moderation coverage; first price experiment; marketing claims; cancellation/refund policy; decision to permit profile photos and uploads.

## 9. Release/investment gates
**Gate A:** 20–30 interviews, 50+ opted-in adult pilot registrations, evidence of user-need. **Gate B:** controlled cohort with safe introductions and follow-up evidence. **Gate C:** engineer/legal/security sign-off for paid public beta. **Gate D:** expand matching categories only after no worsening in safety and demonstrable improved connection outcome. Each gate has recorded go/no-go decision.



---



# PRD — Product Requirements Document

**Version 1.0 — product specifications, not existing capabilities.** The supplied repository is a visual prototype with simulated auth, reports, matches, messages, billing, security and admin numbers; no mock outputs may be presented as live data.

## 1. Information hierarchy and conceptual vocabulary
- **Account:** authenticating human, internal `user_id`, lifecycle and safety state.
- **Persona:** user's mode-specific public identity: FRIEND, DATE, MATRIMONY. Each mode separately chooses display name, visibility, photos, discovery region, preferences and communication constraints.
- **Assessment:** quiz attempt using a fixed published bank version, unique order seed, explicit consent and response audit trail.
- **Profile vector:** bounded derived dimensions with confidence/coverage, not a physical "brain map".
- **Match candidate:** two eligible consenting personas subject to mutual mode, age, blocks, filters, privacy, location and risk policy.
- **Lens:** similarity/Mirror, difference/Counterpoint, complementarity/Mosaic, overall Resonance. Match score is index-based, not relationship success probability.
- **Introduction:** express mutual opt-in; creates chat authorization only after request accepted.
- **Circle:** user-created topical community with rules and permissions; optional privacy mode.
- **Case:** safety/support complaint with ticket, evidence, timestamps, dispositions, appeal rights and restricted operator access.

## 2. Product-level state machines
**Account:** `invited -> pending_verification -> active -> restricted -> suspended -> deleted` with additional `deletion_pending`. **Mode persona:** `inactive -> onboarding -> ready -> discoverable -> paused -> closed`. **Quiz attempt:** `assigned -> in_progress -> submitted -> scored` or `expired`, `withdrawn`, `invalidated`. **Introduction:** `requested -> accepted -> closed` or `declined`, `expired`, `blocked`. **Message:** `accepted -> persisted -> delivered -> seen` (read-receipt only with user preference). **Report:** `open -> triaged -> investigating -> actioned -> resolved` or `escalated`, `appealed`.

## 3. Journeys
### J01: Arrive and explore
Public landing → transparent how matching works (and its limits) → choose initial mode(s) → sign up via Firebase → verify email → adult age policy → accept current T&C and applicable notices → specify optional psychological profiling consent → choose private display details. No mandatory 100-question wall before the user knows what they will receive.

### J02: Start quiz
Quiz catalog → choose theme and consent scope → estimate time, progress and skipability → backend creates **versioned assignment** → resume across devices → submit subset/full set according to completeness rules → receive self-understanding summary with caveat, examples and score definitions. Quiz cannot claim a diagnosis.

### J03: Discover humans
Mode switcher → eligibility and preference checks → lens toggle (Mirror/Counterpoint/Mosaic) → band filter (100,90,80...10) representing descriptive *index intervals*, not precisely measured probabilities → preview profile with safe shared details → why-you-might-connect/possible friction with confidence → send request (caps and mutual eligibility) → receiver accepts/declines → optional conversation starts.

### J04: Establish trust
Any profile/message/group includes block, mute and report; block suppresses discovery, old requests and messages, without alerting blocked user; report captures safe evidence and case ID, allows immediate preservation where lawful, and acknowledgement. Report is accessible without payment.

### J05: Join/create Circle
Discover themed groups → membership request → accept rules → join thread → moderators manage members/content → creator moderation privileges limited to group, never global admin. Group invites must not expose undisclosed profile or intimate details.

### J06: Upgrade and cancel
Pricing context → clear entitlement list, taxes, renewal amount/date, cancellation → provider checkout → signed webhook to confirm entitlement → invoice and transaction history → cancel future renewal while honoring paid period → downgrade without losing core safety or user data → refund request and manual review.

### J07: Data rights
Settings → privacy control and consent dashboard → download requested structured export → edit/rectify persona → withdraw assessment sharing; delete derived scores or recalculate → request deletion with lawful retention disclosure, non-blocking progress and confirmation.

## 4. Feature epics, requirements and acceptance criteria

**Comparison / requirement matrix — accessible record view:**

**Record 1: P-001**

- **ID:** P-001
- **Epic / behavior:** Create account, verify email and log in
- **Release:** MVP
- **Acceptance criteria:** unverified users cannot enter discovery/chat; audited login; rate limited

**Record 2: P-002**

- **ID:** P-002
- **Epic / behavior:** Configure mode personas independently
- **Release:** MVP
- **Acceptance criteria:** all fields/visibility scoped to selected mode; switching mode never leaks details

**Record 3: P-003**

- **ID:** P-003
- **Epic / behavior:** Quiz catalog & placeholder themes
- **Release:** MVP
- **Acceptance criteria:** exactly 100 indexed placeholders per published themed set, drafts hidden

**Record 4: P-004**

- **ID:** P-004
- **Epic / behavior:** Versioned assessment assignment
- **Release:** MVP
- **Acceptance criteria:** server assigns seed/version; idempotent save; resume across devices

**Record 5: P-005**

- **ID:** P-005
- **Epic / behavior:** Consent-aware trait synthesis
- **Release:** MVP
- **Acceptance criteria:** rescoring deterministic; handles missing data; deletes on withdrawal

**Record 6: P-006**

- **ID:** P-006
- **Epic / behavior:** Discovery with lens/band controls
- **Release:** MVP
- **Acceptance criteria:** no blocked, ineligible, or non-discoverable users in results

**Record 7: P-007**

- **ID:** P-007
- **Epic / behavior:** Explanation and uncertainty
- **Release:** MVP
- **Acceptance criteria:** show evidence dimensions and confidence, not proof of guaranteed outcome

**Record 8: P-008**

- **ID:** P-008
- **Epic / behavior:** Mutual connection request
- **Release:** MVP
- **Acceptance criteria:** cannot message until accepted, unless consented group policy allows

**Record 9: P-009**

- **ID:** P-009
- **Epic / behavior:** Private text chat
- **Release:** MVP
- **Acceptance criteria:** durable server authorization, moderation triggers, delete/report

**Record 10: P-010**

- **ID:** P-010
- **Epic / behavior:** Report, block and support ticket
- **Release:** MVP
- **Acceptance criteria:** reporting works under every paid/free state, admin case visible

**Record 11: P-011**

- **ID:** P-011
- **Epic / behavior:** Private/public themed Circles
- **Release:** MVP constrained
- **Acceptance criteria:** creation gated; moderation queue and anti-spam, caps

**Record 12: P-012**

- **ID:** P-012
- **Epic / behavior:** Admin RBAC and audit trail
- **Release:** MVP
- **Acceptance criteria:** no admin rights from frontend or client-provided role

**Record 13: P-013**

- **ID:** P-013
- **Epic / behavior:** Consent/export/deletion
- **Release:** MVP
- **Acceptance criteria:** API job progresses and returns verifiable results

**Record 14: P-014**

- **ID:** P-014
- **Epic / behavior:** Razorpay subscriptions
- **Release:** Pilot+
- **Acceptance criteria:** signed webhook, idempotency, reconciled entitlements

**Record 15: P-015**

- **ID:** P-015
- **Epic / behavior:** Multilingual quiz item bank
- **Release:** Post-validation
- **Acceptance criteria:** expert translation and measurement equivalence studies

**Record 16: P-016**

- **ID:** P-016
- **Epic / behavior:** AI persona companion/simulated twin
- **Release:** Research only
- **Acceptance criteria:** separate consent, safety and model validation before shipping

**Record 17: P-017**

- **ID:** P-017
- **Epic / behavior:** Voice/video calls
- **Release:** Later
- **Acceptance criteria:** cost, abuse, reporting and recording policies approved

**Record 18: P-018**

- **ID:** P-018
- **Epic / behavior:** Family-assist matrimony introductions
- **Release:** Later
- **Acceptance criteria:** explicit per-participant approval; no family access by default


## 5. Three relationship modes — deliberately different outcomes
- **Friendship:** shared interests, schedule compatibility, local region, platonic boundary, desired contact frequency; romantic approach through friendship is reportable unwanted contact after boundary communicated.
- **Dating:** adult-only, mutual declared dating intent, separate selective preference disclosure, opt-in to photos, romantic interest, family expectations where applicable; never infer sexual orientation from hidden questions.
- **Matrimony:** committed intent, voluntary family involvement, education/employment claims labeled self-declared unless independently verified, shared practical life plans, financial expectations, living arrangements; consent-based and anti-coercion safeguards. Avoid caste/religion as hidden ranking or moral merit measures; if legal counsel approves optional explicitly declared preferences, provide transparent user control and fairness monitoring.

## 6. Grouping taxonomy
Global neutral families **Origin** (introductory), **Currents** (thinking/communication), **Mosaic** (complementary roles), **Horizon** (life direction), **Rhythm** (daily habits), **Compass** (values orientation), **Bridge** (conflict repair), **Orbit** (shared interests). Localized expressions may describe preferences but must not rank communities or label them inferior, defective, high/low worth, alpha/beta. Group names must not imply mental diagnoses.

## 7. Content and notification policy
Preferences: product, safety/transactional, marketing separately; email digests default restrained and opt-out for nonessential notifications; no message-content previews on lock screens by default for dating/matrimony; safety notifications are mandatory where legally required; user can turn off activity indicators; no "your soulmate is waiting" fear-of-missing-out framing.

## 8. Edge cases
- Ambiguous self-report answers produce no definitive trait label; incomplete quizzes reduce confidence.
- Users can have multiple persona modes but must not match themselves or bypass prior blocks.
- Deleting account revokes active sessions, disappears from new discovery, and handles retained moderation/payment evidence by lawful schedule.
- Accepted chat counterpart changes mode or revokes consent → existing chat policy must remain clear; no silent mode conversion.
- Safety report against a match → immediate protection while appeal remains independent.
- Location changes → region updates opt-in, never broadcast exact coordinates.
- User under 18 at enrollment or suspected minor → restricted/closed pending safety review.
- Payment partially succeeds → entitlement only from trusted webhook, not redirect query params.
- Empty local matching pool → show transparent waitlist/interest Circles, not invented candidates.

## 9. Suggested success metrics
Eligible active pool by mode/city, quiz meaningful completion, user-reported comfort/safety, match requests accepted, 7/30-day mutual recontact, group recurring interactions, 1k-chat harm rate, complaint SLA, refund rate, 30-day paid retention, contribution margin. Segregate raw quiz telemetry and restrict analyst access.



---



# SRS / FRS / NFR — System & Software Requirements

Status: design targets; **not guarantees or verified benchmarks**.

## 1. Technical compatibility and environment
Client: semantic HTML, CSS/Tailwind v4, React 19 + TypeScript strict, Vite 8; TanStack Query or equivalent; React Router; `motion/react` (avoid shipping both old `framer-motion` and `motion` without reason), Zod validation. API: TypeScript Cloudflare Workers/Hono, Web Crypto and JOSE JWT verifier, Drizzle or prepared SQL for D1; separate packages for domain, identity, UI and adapters. Deploy via Wrangler, preview environments and GitHub Actions. Respect all platform runtime limitations; no assumption Node APIs work in Workers.

## 2. Functional requirement groups
**Auth:** FR-A01 verified email/password and Google; FR-A02 password reset; FR-A03 refresh token/session expiration; FR-A04 disabled-user revocation; FR-A05 brute-force protection; FR-A06 privileged admin identity plus MFA; FR-A07 data access request after reauth; FR-A08 email change verification.

**Privacy:** FR-P01 opt-in per relationship mode; FR-P02 quiz and analytics data processing notices; FR-P03 profile field-level visibility; FR-P04 redact/share summarized traits only; FR-P05 export; FR-P06 rectify; FR-P07 deletion queue; FR-P08 documented retention; FR-P09 audit consent notice version and timestamps; FR-P10 honor withdrawal and stop future matching.

**Quiz:** FR-Q01 published 100-item theme banks; FR-Q02 finite versioned attempts; FR-Q03 cryptographically random assignment order; FR-Q04 server-controlled item selection; FR-Q05 save/recover; FR-Q06 skip and revoke; FR-Q07 adaptive branching only with model governance; FR-Q08 no raw answer leakage in public APIs; FR-Q09 question localization; FR-Q10 separate quiz-author and publisher approval.

**Matching:** FR-M01 eligibility hard filters; FR-M02 similarity/difference/complementarity lenses; FR-M03 score-band filtering and counts; FR-M04 explanation; FR-M05 confidence and missing-data info; FR-M06 fairness/bias monitor; FR-M07 rate limiting; FR-M08 anti-sybil; FR-M09 respect blocks; FR-M10 opt-out/pausing.

**Social:** FR-S01 mutual request and spam caps; FR-S02 user text chat; FR-S03 moderated group threads; FR-S04 report message/profile/group; FR-S05 block/mute; FR-S06 media upload gated/scanned; FR-S07 admin case evidence; FR-S08 notifications; FR-S09 user-generated content moderation & appeal; FR-S10 anti-impersonation.

**Commercial:** FR-C01 entitlement catalog; FR-C02 billing checkout; FR-C03 signed webhook and idempotent ledger; FR-C04 invoice/receipt; FR-C05 cancellation; FR-C06 refund path; FR-C07 taxation and GST settings; FR-C08 price version immutability; FR-C09 plan expiry grace policy.

**Admin:** FR-O01 invitation-only admin creation; FR-O02 scoped RBAC; FR-O03 least-privilege case access; FR-O04 two-person critical action approval; FR-O05 PII reveal requires justification; FR-O06 write-only action evidence and tamper-evident audit exports; FR-O07 support tickets; FR-O08 report SLAs; FR-O09 analytics coarse/aggregated; FR-O10 emergency stop flag.

## 3. NFR/SLO targets — pilot and growth

**Comparison / requirement matrix — accessible record view:**

**Record 1: API latency**

- **Dimension:** API latency
- **Pilot target:** p95 ≤ 700ms for simple API (excluding third-party calls), under representative regional traffic
- **How verified:** Worker timings/trace

**Record 2: Public page UX**

- **Dimension:** Public page UX
- **Pilot target:** Core Web Vitals LCP ≤ 2.5s, CLS ≤ .1, INP ≤ 200ms on tested mid-range phones
- **How verified:** Lighthouse + field RUM

**Record 3: Reliability**

- **Dimension:** Reliability
- **Pilot target:** ≥99.5% monthly core API availability target, excluding documented external provider incidents
- **How verified:** synthetic checks

**Record 4: Message delivery**

- **Dimension:** Message delivery
- **Pilot target:** >99.9% persisted for accepted messages; retriable and deduplicated
- **How verified:** chaos and load tests

**Record 5: Data safety**

- **Dimension:** Data safety
- **Pilot target:** automatic backups, recovery drill each quarter
- **How verified:** restore tests

**Record 6: Encryption**

- **Dimension:** Encryption
- **Pilot target:** TLS in transit, private media, key management & appropriate at-rest encryption
- **How verified:** security review

**Record 7: Access**

- **Dimension:** Access
- **Pilot target:** all PII endpoints authenticated and policy tested
- **How verified:** automated permissions matrix

**Record 8: Accessibility**

- **Dimension:** Accessibility
- **Pilot target:** WCAG 2.2 AA target; reduced motion, keyboard access, contrast and live regions
- **How verified:** axe + manual

**Record 9: Browser**

- **Dimension:** Browser
- **Pilot target:** current Chrome, Firefox, Safari and Edge; mobile responsive
- **How verified:** browser matrix

**Record 10: Privacy**

- **Dimension:** Privacy
- **Pilot target:** no raw psychological answers in client analytics or default log payloads
- **How verified:** audit and DLP test

**Record 11: API abuse**

- **Dimension:** API abuse
- **Pilot target:** per-route & per-identity token buckets and anomaly rules
- **How verified:** abuse simulation

**Record 12: Data deletion**

- **Dimension:** Data deletion
- **Pilot target:** operational within published period except lawful holds
- **How verified:** reconciliation job


These are planning targets; calibrate on load tests and available infrastructure. No absolute 100% uptime promise.

## 4. Security acceptance contracts
Every request verifies `Authorization` token signature, issuer, audience, expiry, account active state, mode membership, operation permission, block relation and object ownership. Tokens alone never grant admin role; server DB `admin_memberships` is authoritative. Every PII read is audited at appropriate granularity. Content Security Policy, secure cookies (if session-based), strict CORS, CSRF protection where cookies used, no secrets embedded in bundles, CSP nonces/hashes, and safe HTML sanitization mandatory.

## 5. Operational error taxonomy
Return structured RFC 7807-style error with stable `code`, user-safe `title`, correlation ID, HTTP status and `retry_after` when applicable. No internal stack trace, source, other user's data or unverified probability in error. Frontend maps: invalid input 400, unauthenticated 401, unauthorized 403, invisible target 404, conflict 409, rate-limited 429, unavailable 503.

## 6. Engineering standards and definition of done
- TypeScript `strict=true`; formatting/lint; changes require reviewers, automated PR checks, migrations up/down with tested rollback; no shared production credentials.
- Every feature includes a threat model delta, event instrumentation with privacy review, empty/error/loading states, mobile accessibility, acceptance test, operator documentation.
- Automated unit, integration, contract, end-to-end, authz fuzz tests, webhook replay test and restore test.
- Deployment uses staged rollout, canary flags, documented runbooks, alert owners and incident communication templates.

## 7. Unsupported promises to prohibit
Do not label messages "Signal Protocol E2EE" without independently audited end-to-end key protocol. TLS + server-side encryption ≠ E2EE. Do not claim biometric or government-ID verification until service genuinely performs it with legitimate basis. Do not suggest "brain replica," "exact human twin," "clinical psychometrics," "scientifically guaranteed marriage" or "uncheatable quiz" in production copy.



---



# QRD — Questionnaire, Psychometric Research & Assessment Engineering

**Important:** all 100 items per theme are **placeholders by design**. There is no scientific validation at present. Professional psychometric review, consent and longitudinal validation precede use of high-stakes claims.

## 1. Objectives and risks
Collect only data needed to support user-understandable compatibility, not wholesale replication of a human brain. A psychological questionnaire cannot reconstruct consciousness, predict all behaviors, or truthfully prevent respondents from using AI. No hidden sexual-orientation, religion, caste, disability, trauma or mental-health classifier. If a trait is necessary for an explicitly selected dating/matrimony feature, obtain informed, separate, revocable consent for the exact trait and processing purpose; evaluate fairness and legality.

## 2. Proposed themes, each with 100-item **future** sets

**Comparison / requirement matrix — accessible record view:**

**Record 1: Reasoning & Decision Style**

- **Theme:** Reasoning & Decision Style
- **Short slug:** DECIDE
- **Intended constructs:** uncertainty tolerance, deliberation, problem approach
- **Releases:** later pilot

**Record 2: Conversation & Conflict**

- **Theme:** Conversation & Conflict
- **Short slug:** CONNECT
- **Intended constructs:** feedback, repair, listening preference
- **Releases:** early pilot

**Record 3: Values & Trust**

- **Theme:** Values & Trust
- **Short slug:** COMPASS
- **Intended constructs:** reliability, honesty expectations, boundaries
- **Releases:** early pilot

**Record 4: Emotional Coping**

- **Theme:** Emotional Coping
- **Short slug:** EQUILIBRIUM
- **Intended constructs:** self-reported emotion regulation and reassurance needs
- **Releases:** expert-gated

**Record 5: Social Rhythm**

- **Theme:** Social Rhythm
- **Short slug:** RHYTHM
- **Intended constructs:** solitude, availability, activities, contact cadence
- **Releases:** early pilot

**Record 6: Growth & Ambition**

- **Theme:** Growth & Ambition
- **Short slug:** HORIZON
- **Intended constructs:** learning goals, career/life goals
- **Releases:** later pilot

**Record 7: Family & Long-Term Plans**

- **Theme:** Family & Long-Term Plans
- **Short slug:** ROOTS
- **Intended constructs:** household/family orientation and life plans
- **Releases:** matrimony only

**Record 8: Money & Practical Life**

- **Theme:** Money & Practical Life
- **Short slug:** GROUND
- **Intended constructs:** spending, risk, household financial expectations
- **Releases:** matrimony only

**Record 9: Interests & Curiosity**

- **Theme:** Interests & Curiosity
- **Short slug:** SPARK
- **Intended constructs:** books, art, technology, adventure, hobbies
- **Releases:** early pilot

**Record 10: Complementary Collaboration**

- **Theme:** Complementary Collaboration
- **Short slug:** MOSAIC
- **Intended constructs:** negotiation, role preferences, task approach
- **Releases:** research

**Record 11: Digital Boundaries & Privacy**

- **Theme:** Digital Boundaries & Privacy
- **Short slug:** SHIELD
- **Intended constructs:** contact boundaries, sharing and safety preferences
- **Releases:** early pilot

**Record 12: Future Change & Resilience**

- **Theme:** Future Change & Resilience
- **Short slug:** TIDE
- **Intended constructs:** adaptation, moving cities, changes in commitments
- **Releases:** later pilot


Every theme is a **catalog** of versions: `CONNECT-v1-setA` (100 placeholders), `CONNECT-v1-setB` (100 different placeholders), etc. The user asked to avoid repeated questions: achievable by rotating versioned item banks, but mathematically impossible to promise unique items indefinitely with a finite catalog. Clearly limit re-use within a configurable interval and prioritize psychometric comparability over randomness.

## 3. Question model
Required: `question_id` UUID, `theme_id`, `item_bank_version`, `item_revision`, `locale`, `body_placeholder`, `response_type`, `choices`, `construct_ids`, `weighting_version`, `reverse_coded`, `sensitivity_class`, `consent_purpose`, `estimated_seconds`, `active`, `effective_at`, `retired_at`, `psychometric_review_id`, `experiment_group`, `accessibility_label`, and `display_constraints`. All placeholder text must be rendered with **"Draft item—do not infer psychological meaning"** in nonproduction.

Response forms: forced choice, 5/7 point Likert, situational judgment, ranking, optional open text. Free-text high sensitivity requires separate opt-in, moderation/data-minimization and training-data ban by default. Randomize response-option order only when it cannot change interpretation (e.g. do not shuffle Likert scale endpoints). No deceptive "magic trick" claims.

## 4. Quiz assignment / selection
1. Server authenticates user and confirms relevant mode consent and theme eligibility.
2. Server locks a published quiz version, selects from a sufficiently large pool, uses cryptographically secure randomness to make a stable order seed, and stores an encrypted/opaque assignment ID.
3. Exclude items recently seen within policy window, while preserving required anchor items used for score comparability.
4. Deliver a small batch of signed item IDs (not trait weights); answers posted incrementally with `attempt_id`, `item_id`, `revision`, `answer`, and idempotency key.
5. On submit, server validates assignment completeness, consistency, quotas and selected validity signals. Flag anomalies for **retest**, not automatic accusation.
6. Derive traits server-side using a published scoring version; retain enough audit to reproduce the score while respecting deletion and retention schedules.
7. Recalculate all dependent matches if user withdraws consent or a scoring bug is corrected; queue updates and inform users of material changes.

## 5. Anti-gaming—what is realistic
Question-order randomization, alternate wording, scenario variations, lie/social-desirability scales only if validly assessed, test-retest drift analysis, timing anomaly flags (not simplistic AI detector), response consistency checks, rate limits, batch visibility, soft trust flags, optional corroborating experiences over time, bias review and abuse dispute. **Cannot prevent AI usage, nor prove genuine personality from answers alone**. Do not penalize disabled or slow-reading users for time spent.

## 6. Psychological validity and method
- Pre-register constructs and intended score interpretation before collecting data.
- Use peer-reviewed instruments only with license/attribution, Indian language/cultural validation and professional oversight; no diagnosis.
- Conduct cognitive interviews (what does the question mean), pilot item analysis, reliability and temporal stability, dimensionality, convergent/discriminant validation, measurement invariance across relevant demographics if lawfully collected, and outcome validation.
- Avoid assuming Big Five, MBTI, attachment style, "love languages" or proprietary archetypes are interchangeable; each has a different evidentiary basis.
- Compare extended questionnaire against short baseline; report differential attrition and sample-selection effects.
- No outcome interpretation unless suitable representative holdout validation exists; all percentages labeled index agreement and model version.

## 7. Versioning & scoring integrity
`assessment_attempt` binds one exact `item_bank_version`, `scoring_version`, `consent_receipt_id`, pseudonymous member ID, assignment digest, start/end. `score_snapshot` immutable versioned derivation and optional invalidation cause; never overwrite historical score silently. API does not return weights, sensitive responses, anomaly flags or model internals to other users.

## 8. Sample machine-readable placeholder
See `scaffolds/quiz-placeholder.schema.json`. A seed generator should produce `Q001`–`Q100` for each selected theme and set, all with `status:'placeholder'`. They are **not administered in production** until author, psychometric reviewer, legal/privacy reviewer and publishing admin approve.

## 9. Definition of done for a real quiz bank
All 100 published items have clear constructs, age appropriateness, reasonable answer burden, accessibility, localized wording review, no biased or invasive hidden inference, agreed opt-out/skip behavior, validated scoring parameters, supporting documentation, consent notice, model card, adversarial retest, reproducibility tests, and a signed release approval.



---



# MRD — Matching, Compatibility Lenses, Identity Taxonomy & Model Governance

## 1. Governing principle
Kithra's numerical match measure is a **model-defined agreement index**, not the probability that two humans will have a successful friendship, date or marriage. `100%` means index maximum given measured dimensions with sufficient coverage; `0%` means measured divergence according to index; never "destined" or "perfect soul". Restrict scores when confidence/coverage is too low.

## 2. Proposed categories and user-friendly labels
- **Mirror Twin**: unusually similar measured scores across selected traits; not identical brains.
- **Counterpoint**: unusually different measured traits; could be interesting, not necessarily compatible.
- **Mosaic Fit**: modeled *complementarity* on a defined set of role/behavior preferences, with mandatory shared boundaries and consent.
- **Resonance**: broad mode-specific shared aims and styles.
- **Horizon Match**: shared growth and future-life goals.
- **Circle Match**: shared activity/community interest.
- **Quiet Harmony**: similar communication pace, not an innate personality class.
These are UI labels under test, not clinical diagnoses, personal worth labels or fixed human castes/classes.

## 3. Eligibility precedes scoring
`eligible(u,v,mode)` requires verified-active adult accounts, same consented mode, each discoverable and allowlisted by region/visibility, no blocks/reports requiring hold, compatible disclosed preferences, age policies, no duplicate/self, within request quotas, not fraud-restricted. Dating/matrimony must respect explicit reciprocal orientation and relationship preferences *only if voluntarily provided for that mode*; no inferred sexual orientation. All hard filters are non-negotiable; **no high score may override consent or a block**.

## 4. Example computational framework (hypothesis, not validated)
For two users, normalize psychometric traits `x_i` and `y_i` to [0,1], and derive `w_i >= 0` from mode-specific published model version. Let `present_i` reflect both having sufficient reliable data, and `confidence_i` be trust in measurement.

`similarity = 100 * Σ(w_i * confidence_i * present_i * (1 - |x_i-y_i|)) / Σ(w_i * confidence_i * present_i)`.

`difference = 100 * Σ(w_i * confidence_i * present_i * |x_i-y_i|) / Σ(w_i * confidence_i * present_i)`.

`complementarity` is NOT simply `difference`: it requires an empirically defensible pairing function for particular preference pairs, and must respect shared values and safety boundaries. Example: one prefers planning and the other prefers spontaneous activities; this may cause friction, not balance. Until validated, expose it as *possible complementary preferences* and let both humans decide.

`score_coverage = Σ(w_i * present_i) / Σ(w_i)`; do not show precision/bands when coverage below a predeclared confidence gate (initial proposal: 70%, to validate). Report rounded intervals/bands (90–100,80–89...10–19) with note "model index", not false exact numeric certainty. UI may offer `100 / 90 / ... / 10` filters only if these represent bucket upper endpoints rather than a claim of 100% psychological accuracy.

## 5. Mode-specific weights (provisional; must be tested)

**Comparison / requirement matrix — accessible record view:**

**Record 1: Shared social activities**

- **Dimension:** Shared social activities
- **Friendship:** 20
- **Dating:** 10
- **Matrimony:** 5

**Record 2: Communication & conflict**

- **Dimension:** Communication & conflict
- **Friendship:** 20
- **Dating:** 25
- **Matrimony:** 20

**Record 3: Values / boundaries**

- **Dimension:** Values / boundaries
- **Friendship:** 25
- **Dating:** 25
- **Matrimony:** 25

**Record 4: Time / geographic availability**

- **Dimension:** Time / geographic availability
- **Friendship:** 25
- **Dating:** 15
- **Matrimony:** 10

**Record 5: Future plans / practical life**

- **Dimension:** Future plans / practical life
- **Friendship:** 5
- **Dating:** 15
- **Matrimony:** 30

**Record 6: Complementary habits (validated only)**

- **Dimension:** Complementary habits (validated only)
- **Friendship:** 5
- **Dating:** 10
- **Matrimony:** 10

**Record 7: **Total****

- **Dimension:** **Total**
- **Friendship:** **100**
- **Dating:** **100**
- **Matrimony:** **100**


Do **not** present these as scientifically established weights. They are initial hypotheses for offline experimentation. No scoring on protected categories as proxy for worth. A user may disclose religion or other preferences voluntarily but any use in rankings must pass counsel/privacy/fairness review.

## 6. Twin, opposite and puzzle fairness
- Mirror: high similarity + adequate reliability and coverage.
- Counterpoint: high difference; the description says "interesting contrast" not "your destined anti-soulmate".
- Mosaic Fit: specific observable complementarity with **mutual confirmation**; never assert that one partner "fixes" another or can repair illness, trauma, abuse or moral deficiency.
- Population sizes: never claim there is a 100% mirror candidate if nobody meets threshold; transparent empty state.
- Avoid exposure amplification: ranking should balance relevance, new users, fairness, safety and available attention; not always promote already-popular profiles.

## 7. Pair outcome feedback and responsible learning
Collect explicit minimal feedback after actual interactions: comfortable?, mutually wish to continue?, met safely?, contact again at D7/D30? No covert analysis of private messages to infer romance/sexuality. Use consented aggregated outcome analysis to test whether scores predict continuation better than simple baseline; account for selection bias and missing responses; do not train AI models on chat content without a fresh, separate opt-in.

## 8. Match explanation design
For each candidate show: compatible mode, explainable top 3 dimensions, 1–2 possible challenges framed neutrally, data confidence, "What we have not measured," quick block/report, a note that humans are more than an index. Never expose the other's raw quiz answers; only share traits each party specifically marked public in that mode. Disabled or privacy-restricted profiles should not be included.

## 9. Offline experiments and model governance
Maintain model registry: `model_id`, `version`, `data lineage`, source questionnaire versions, construct definitions, consent basis, fairness results, holdout methodology, release date, rollback trigger, owner and known limitations. Use deterministic scoring for initial release. LLM may help write explanations from **approved summarized traits**, not decide hidden suitability or infer sensitive classes. Test adversarial manipulations and demographic outcome disparity lawfully. Human override only for safety/remediation, never secretly force romantic matches.

## 10. Latency & scaling
Use batch match generation on quiz submit/consent change with durable queue; indexed candidate retrieval by mode/region/interest; local top-N rerank in Worker CPU budget; materialize top candidates and lens scores in D1 with model version/time-to-live. Cache non-sensitive cohort counts; never cache private scores across users. For 100k+ active users consider dedicated vector DB/Postgres and async scoring service after measurement, not preemptively.



---



# SAD / TAD / ADR — Serverless Architecture, Operations & Server Migration

**Architecture decision:** Cloudflare Pages + Workers + D1 + R2 + Durable Objects + Queues, Firebase Auth, Razorpay (India) for the validated pilot. Workers API can later move to Node.js or container services; D1 can later move to PostgreSQL; R2 uses S3-compatible storage API. This is a target, not a claim that the source ZIP already runs on Cloudflare.

## 1. Current concept ZIP versus target
The ZIP uses Vite/React 19/TypeScript, Tailwind 4, Motion/Framer Motion, component-level `useState` and static data; `src/App.tsx` sets `DEFAULT_REPORT` and mock matches. `src/components/AuthModal.tsx` demo OTP accepts six digits and admin condition accepts any nonempty password. `src/components/AdminView.tsx` displays hardcoded sample cases and metrics. `src/components/SecurityView.tsx` claims Signal E2EE but simulates export. No production database, API, authorized messages, billing webhooks, data-rights service or admin auth is shown. **Retain UI-independent reusable TS components; replace the untrusted interaction and state logic.**

## 2. Context architecture
```mermaid
flowchart LR
  Browser[React/Vite Pages] -->|Firebase ID JWT + TLS| API[Workers / Hono API]
  Browser -->|Firebase login| Firebase[Firebase Authentication]
  API -->|SQL prepared queries| D1[(D1 relational data)]
  API -->|Private media signed access| R2[(R2 objects)]
  API -->|room coordination| DO[Durable Objects / chat]
  API -->|jobs| Q[Cloudflare Queues]
  Q --> D1
  API <-->|signed checkout/webhook| RP[Razorpay]
  API --> OBS[Logs/metrics/error alerts]
  Admin[Admin Pages / Access] -->|strong MFA + RBAC| API
```
Do not allow direct browser D1 access. Auth JWT verification is local at edge with Google public signing keys and verified `aud`, `iss`, `exp`, `sub`; also check the Kithra account's `disabled`, `token_valid_after`/session-revocation state from D1. Cache public keys with HTTP TTL, implement fail-closed validation. This avoids embedding Firebase Admin SDK assumptions in Workers.

## 3. Repos/packages and boundaries
```
apps/web/                 # public app + authenticated user workspace
apps/admin/               # distinct admin frontend / origin
apps/api/                 # Workers entry + routes + Durable Objects
packages/ui/              # accessible token-based components
packages/domain/          # pure TS entities, policies, scoring (no Cloudflare SDK)
packages/contracts/       # Zod + OpenAPI types and events
packages/adapters/        # interfaces + D1/R2/Firebase/Razorpay adapters
packages/observability/   # scrubbed structured logs and tracing
migrations/d1/            # forward/rollback schema migrations
infra/wrangler/           # env-specific deployment, flags
research/quiz-banks/      # non-prod placeholders and review metadata
```
Dependency rule: domain cannot import D1/Cloudflare/Firebase/React. API uses `UserRepository`, `AssessmentRepository`, `ObjectStore`, `AuthVerifier`, `PaymentGateway`, `EventBus`, `RealtimeChannel`, `SecretsProvider` interfaces injected from provider adapters.

## 4. Cloudflare resource decisions
- **Pages:** static Vite bundle; preview branch builds; route fallback for SPA; `Content-Security-Policy` and secure headers. Pages Functions count against Workers usage, so a single Hono API Worker is easier to monitor.
- **Workers:** Hono HTTP routing, validation, authorization, scoring small batches; Free includes 100k requests/day and 10ms CPU per invocation; scheduled/queue and heavy ML tasks must stay within product limits and be offloaded to paid plans or external service.
- **D1:** relational entities and indexes; Free 5 million rows read/day, 100k rows written/day, 5GB account storage but only **500MB maximum per individual Free database**; constraints reset by plan. Favor compact rows, indexes and TTL; store media in R2; do not store entire chat media or raw embeddings in D1. Paid individual DB up to 10GB subject to current docs.
- **R2:** private avatars, consented media, temporary exports with lifecycle deletion; Standard Free 10GB-month, 1M Class A and 10M Class B operations/month. Bucket/private objects require signed APIs; default public bucket disabled; short-lived signed reads, MIME sniffing and malware scan process.
- **Durable Objects:** optional per-room chat coordinator using SQLite backend supported on Free; WebSocket hibernation and persistence. **D1 persists message records** and DO handles presence/fanout; DO isn't a permanent single source of truth for all conversations. Per-room authorization on join and every command; protect against message spoofing.
- **Queues:** welcome notifications, transcript-safe score recompute, email, media scanning, deletion and export jobs; 10,000 free operations/day as checked; DLQ, retry, idempotency. No critical report relying solely on eventually processed queue—immediate case persistence first.
- **Cron:** overdue grievance escalation, retention sweep, billing reconciliation, expired requests, consent revocation cleanup, backup verification and analytics aggregates.
- **Turnstile/WAF/Rate Limits:** bot reduction not security replacement; dedicated token buckets keyed by authenticated ID and risk IP.

**Official verified docs:** https://developers.cloudflare.com/workers/platform/pricing/ ; https://developers.cloudflare.com/d1/platform/pricing/ ; https://developers.cloudflare.com/d1/platform/limits/ ; https://developers.cloudflare.com/r2/pricing/ ; https://developers.cloudflare.com/durable-objects/platform/pricing/ ; https://developers.cloudflare.com/queues/platform/pricing/ . Verified 2026-11-01. Prices and feature limits must be rechecked at implementation time.

## 5. Authentication ADR-001: Firebase Auth or Supabase Auth?
**Comparison / requirement matrix — accessible record view:**

**Record 1: Email/password and Google**

- **Decision factor:** Email/password and Google
- **Firebase Auth:** supported, recommended initial
- **Supabase Auth:** supported

**Record 2: Phone OTP**

- **Decision factor:** Phone OTP
- **Firebase Auth:** available, SMS charged; enable later
- **Supabase Auth:** phone requires SMS provider and associated charges

**Record 3: Cloudflare Worker JWT validation**

- **Decision factor:** Cloudflare Worker JWT validation
- **Firebase Auth:** RSA public keys/JWKS-like Google cert endpoint; manual validation
- **Supabase Auth:** project JWKS with asymmetric signing keys (check key configuration)

**Record 4: Persistence fit**

- **Decision factor:** Persistence fit
- **Firebase Auth:** D1 primary, Firebase only for identity
- **Supabase Auth:** Supabase project introduces idle Postgres if not using it

**Record 5: Free allowances**

- **Decision factor:** Free allowances
- **Firebase Auth:** provider-dependent, Identity Platform 50k tier1 MAUs before charges
- **Supabase Auth:** free 50k MAUs; inactive project may pause

**Record 6: Migration**

- **Decision factor:** Migration
- **Firebase Auth:** independent Kithra user ID and provider identities
- **Supabase Auth:** likewise


**Decision:** Firebase for pilot, with email/password or Google, verified email and no mandatory phone. Future phone must use abuse budgets. Admins use a separately authenticated email/password sign-in with strong MFA (passkey/TOTP as supported by selected provider), server-side role and optionally Cloudflare Access protective layer. A secret URL/email/password **alone is insufficient**. No open admin registration; seed first superadmin through secure audited setup, not frontend.

## 6. Authentication token and session design
`external_identity(provider, subject)` maps to Kithra `users.id` UUID (not the email, phone or Firebase UID as the long-lived domain key). Worker validates issuer/audience/time/signature and retrieves active account. New users require verifiable user/email action; new admin membership requires dual approval for privileged roles. Credential reset and email changes revoke privileged sessions. Sessions expire and are rotated; revocation within bounded window documented. For high-risk admin action demand recent reauthentication and second approver.

## 7. Payments ADR-002
Use Razorpay Checkout/Subscriptions where the merchant account and the exact plan/auto-debit mechanism are approved and live. Browser success redirect is never authority. Verify signed webhook HMAC on raw body, deduplicate provider event IDs, write payment ledger before entitlement change; compare local state against gateway periodically. Do not store card details. Monthly/quarterly/half-yearly/annual offers require clear taxes, renewal, consent and cancellation; review RBI e-mandate support for each method.

## 8. Data location & privacy caveat
Cloudflare D1's default location is automatic; its jurisdiction controls are not equivalent to a guaranteed Indian-only region. Firebase may store/process identity data in chosen provider infrastructure; verify terms, subprocessors, transfers and data residency before using it for intimate data. No unverified claim that all data remains physically in India. Encrypt raw responses at field/application level using audited key management and limit decryption to scoring services; retain keys out of code and source. Revisit localization laws with counsel.

## 9. Cost and failure management
Pilot volume model: 1,000 signups × 3 modes × 2 themes ×100 answer records can create 600k answer rows, quickly stressing DB and writes; use assignment-completion snapshots, compact indexed records and batch API operations, not raw new row per UI keystroke. Chargeable variables: Workers request/CPU, D1 rows and storage, DO message operations, R2 ops/storage, Firebase SMS, email transactional sends, media moderation, payments, support and legal. Set budget alerts and **hard feature-level limits**; avoid runaway async model inference. Do not forecast ₹0 hosting for a real community without traffic tests.

## 10. Server migration blueprint
**Trigger options:** increased active users and writes, D1 query hot spots, requirement for complex vector searches, regulatory hosting commitments, heavy media/ML workloads, or 99.9%+ supported SLA. **Target A:** Cloudflare Pages + API Node.js containers on managed VM/Kubernetes + PostgreSQL + Redis + S3-compatible objects + Firebase or migration to self-owned auth. **Target B:** keep Workers as public API gateway and migrate only matching/SQL to Postgres service. Steps: (1) create repository adapters; (2) shadow reads and reconcile; (3) bulk export and PII-preserving import; (4) dual-write outbox with idempotent replay; (5) read routing feature flag; (6) compare counts/foreign keys/hashes; (7) promote new system; (8) rollback within a test-proven RPO; (9) maintain deletion tombstones across all replicas/backups. Migration requires tested security model parity.

## 11. Operational playbooks
Build + test per pull request, preview deploy, staging smoke tests, signed release, production canary, RUM and alerts, daily encrypted backup verification, monthly manual restore test during pilot, periodic vulnerability scan, quarterly incident tabletop. Keep separate Cloudflare/Firebase/Razorpay administrator accounts with strongest available MFA and at least two emergency authorized owners; secrets rotation documented. Emergency switch disables discovery/chat while still allowing account/data-rights and safety access.

## 12. Architecture decision register (ADRs)
ADR001 Firebase Auth (accepted provisionally). ADR002 Razorpay (pending merchant approval). ADR003 D1 primary relational (pilot only). ADR004 R2 private files (accepted). ADR005 no fabricated E2EE (accepted). ADR006 opaque explainable score bands not probability (accepted). ADR007 18+ pilot (accepted pending legal review). ADR008 separate mode personas (accepted). ADR009 PII/psychometric protection by field-level encryption and service isolation (requires technical spike). ADR010 admin on separate origin with MFA+RBAC+audit (accepted).



---



# DRD / API-RD — Data Model, API Contracts & Events

**Contract principle:** all writes server-validated and idempotent where retries are expected. All selected IDs are opaque, globally unique UUID/ULID; do not expose Firebase UID as primary. Timestamps ISO 8601 UTC. Column and endpoint names are proposals and should be synchronized with migrations / OpenAPI.

## 1. Domain database entities

**Comparison / requirement matrix — accessible record view:**

**Record 1: users**

- **Entity:** users
- **Key data and foreign keys:** id, account_status, min_age_verified, created_at, deleted_at
- **Important invariants:** one individual, unique internal ID, deletion holds

**Record 2: external_identities**

- **Entity:** external_identities
- **Key data and foreign keys:** id, user_id, provider, provider_subject, last_verified_at
- **Important invariants:** `(provider,subject)` unique; no trust in client email

**Record 3: mode_personas**

- **Entity:** mode_personas
- **Key data and foreign keys:** id, user_id, mode, public_name, visibility, bio, region, status
- **Important invariants:** unique `(user,mode)`, mode-specific fields and blocks

**Record 4: mode_consents**

- **Entity:** mode_consents
- **Key data and foreign keys:** id, user_id, mode, notice_version, scope, granted, occurred_at
- **Important invariants:** explicit event history; withdrawal not overwritten

**Record 5: profile_fields**

- **Entity:** profile_fields
- **Key data and foreign keys:** id, persona_id, field_key, cipher_value, visibility
- **Important invariants:** privacy tiers; encrypt sensitive values

**Record 6: question_themes**

- **Entity:** question_themes
- **Key data and foreign keys:** id, slug, locale, status
- **Important invariants:** theme is neutral and configurable

**Record 7: question_banks**

- **Entity:** question_banks
- **Key data and foreign keys:** id, theme_id, version, locale, publish_state
- **Important invariants:** immutable after publication

**Record 8: questions**

- **Entity:** questions
- **Key data and foreign keys:** id, bank_id, ordinal, text, response_schema, construct_mapping_ref
- **Important invariants:** public API strips traits/weights

**Record 9: quiz_attempts**

- **Entity:** quiz_attempts
- **Key data and foreign keys:** id, user_id, bank_id, seed_ref, status, assigned_at, submitted_at
- **Important invariants:** cannot switch version mid-attempt

**Record 10: quiz_assignments**

- **Entity:** quiz_assignments
- **Key data and foreign keys:** id, attempt_id, question_id, sequence
- **Important invariants:** stable assigned order; unique question/attempt

**Record 11: quiz_answers**

- **Entity:** quiz_answers
- **Key data and foreign keys:** id, attempt_id, question_id, encrypted_value, updated_at
- **Important invariants:** at-rest application encryption, personal data

**Record 12: trait_snapshots**

- **Entity:** trait_snapshots
- **Key data and foreign keys:** id, user_id, mode, model_version, coverage, encrypted_vector
- **Important invariants:** private by default, immutable version

**Record 13: match_snapshots**

- **Entity:** match_snapshots
- **Key data and foreign keys:** id, source_persona, target_persona, mode, lens, score_band, model_version
- **Important invariants:** server eligibility verified on retrieval

**Record 14: requests**

- **Entity:** requests
- **Key data and foreign keys:** id, from_persona, to_persona, mode, status, expires_at
- **Important invariants:** idempotent duplicate handling; blocked no access

**Record 15: conversations**

- **Entity:** conversations
- **Key data and foreign keys:** id, mode, membership_version, status
- **Important invariants:** no cross-mode chat accidentally

**Record 16: conversation_members**

- **Entity:** conversation_members
- **Key data and foreign keys:** conversation_id, user_id, joined_at, muted
- **Important invariants:** authorized participants only

**Record 17: messages**

- **Entity:** messages
- **Key data and foreign keys:** id, conversation_id, sender_id, body_cipher_or_ref, created_at
- **Important invariants:** immutable sender, per-convo sequence

**Record 18: circles**

- **Entity:** circles
- **Key data and foreign keys:** id, mode_scope, name, rules_version, visibility, moderation_status
- **Important invariants:** includes privacy and admin policy

**Record 19: circle_members**

- **Entity:** circle_members
- **Key data and foreign keys:** circle_id, user_id, role, state
- **Important invariants:** group roles not platform admin

**Record 20: circle_posts**

- **Entity:** circle_posts
- **Key data and foreign keys:** id, circle_id, author_id, body_ref, moderation_state
- **Important invariants:** reports and retention rules

**Record 21: blocks**

- **Entity:** blocks
- **Key data and foreign keys:** blocker_id, blocked_id, mode_scope, created_at
- **Important invariants:** immediate bilateral discovery suppression

**Record 22: reports**

- **Entity:** reports
- **Key data and foreign keys:** id, reporter_id, subject_type, subject_id, category, severity, created_at
- **Important invariants:** reports retained confidentially

**Record 23: moderation_cases**

- **Entity:** moderation_cases
- **Key data and foreign keys:** id, report_id, assigned_team, priority, state, due_at
- **Important invariants:** appeal and evidence trace

**Record 24: case_actions**

- **Entity:** case_actions
- **Key data and foreign keys:** id, case_id, actor_id, action, rationale, at
- **Important invariants:** immutable-style append-only log

**Record 25: support_tickets**

- **Entity:** support_tickets
- **Key data and foreign keys:** id, requester_id, category, state, assignee_id
- **Important invariants:** minimized PII; service SLA

**Record 26: admin_memberships**

- **Entity:** admin_memberships
- **Key data and foreign keys:** admin_user_id, role_id, state, mfa_verified_at
- **Important invariants:** superadmin grant only via approved workflow

**Record 27: roles, permissions, role_permissions**

- **Entity:** roles, permissions, role_permissions
- **Key data and foreign keys:** normalized scope, action
- **Important invariants:** capability matrix centrally enforced

**Record 28: audit_events**

- **Entity:** audit_events
- **Key data and foreign keys:** id, actor_id, target_ref, action, metadata_redacted, at, hash_chain
- **Important invariants:** no raw sensitive answers/log payloads

**Record 29: payment_customers**

- **Entity:** payment_customers
- **Key data and foreign keys:** user_id, gateway_customer_id
- **Important invariants:** provider ref only; no card data

**Record 30: plan_catalog**

- **Entity:** plan_catalog
- **Key data and foreign keys:** id, code, price_minor, currency, term_days, visibility
- **Important invariants:** versioned prices/taxes

**Record 31: subscriptions**

- **Entity:** subscriptions
- **Key data and foreign keys:** id, user_id, gateway_sub_id, plan_version, state, period_end
- **Important invariants:** webhooks authoritative

**Record 32: payments**

- **Entity:** payments
- **Key data and foreign keys:** id, provider_event_id, amount_minor, currency, result
- **Important invariants:** unique provider event ID

**Record 33: entitlement_grants**

- **Entity:** entitlement_grants
- **Key data and foreign keys:** user_id, feature, quota, expires_at, source
- **Important invariants:** no safety features gated

**Record 34: rights_requests**

- **Entity:** rights_requests
- **Key data and foreign keys:** id, user_id, type, status, deadline, completed_at
- **Important invariants:** auditable export/erasure

**Record 35: export_jobs**

- **Entity:** export_jobs
- **Key data and foreign keys:** id, user_id, object_key, expires_at, state
- **Important invariants:** expiring signed link in private bucket

**Record 36: retention_holds**

- **Entity:** retention_holds
- **Key data and foreign keys:** id, subject_id, legal_basis, expiry, approvers
- **Important invariants:** access-controlled, lawful only

**Record 37: feature_flags**

- **Entity:** feature_flags
- **Key data and foreign keys:** id, audience, flag_key, enabled, version
- **Important invariants:** no hardcoded toggles

**Record 38: notification_jobs**

- **Entity:** notification_jobs
- **Key data and foreign keys:** id, user_id, kind, state, attempts
- **Important invariants:** channel preference respected


**Data domains:** (1) identity (Firebase), (2) social/personas (D1), (3) derived assessments (D1 encrypted fields), (4) media/exports (R2 private), (5) support/audit (restricted D1 or isolated DB). Avoid exposing admin to raw quizzes in normal views; provide redacted summaries when appropriate.

## 2. Index and retention design
High-value indexes: `mode_personas(mode,status,region)`, `external_identities(provider,subject)`, `questions(bank_id,ordinal)`, `quiz_answers(attempt_id,question_id)`, `requests(to_persona,status,created_at)`, `messages(conversation_id,created_at)`, `reports(status,created_at)`, `moderation_cases(state,due_at)`, `subscriptions(user_id,state)`, `payments(provider_event_id)`, `audit_events(target_ref,at)`. Every dataset has classification, declared purpose, retention trigger, deletion mode, processor and access role. Do not add broad PII indexes without need.

## 3. REST API v1 (representative)

**Comparison / requirement matrix — accessible record view:**

**Record 1: GET**

- **Method:** GET
- **Endpoint:** `/v1/me`
- **Permission / behavior:** logged-in profile and consent state

**Record 2: PATCH**

- **Method:** PATCH
- **Endpoint:** `/v1/me`
- **Permission / behavior:** self only, permitted fields, reauth if sensitive

**Record 3: POST**

- **Method:** POST
- **Endpoint:** `/v1/me/modes`
- **Permission / behavior:** activate one mode with appropriate notice

**Record 4: PATCH**

- **Method:** PATCH
- **Endpoint:** `/v1/personas/{id}`
- **Permission / behavior:** owner and matching mode only

**Record 5: GET**

- **Method:** GET
- **Endpoint:** `/v1/quiz/themes`
- **Permission / behavior:** public approved catalog; localization

**Record 6: POST**

- **Method:** POST
- **Endpoint:** `/v1/quiz/attempts`
- **Permission / behavior:** assign versioned question bank; auth

**Record 7: GET**

- **Method:** GET
- **Endpoint:** `/v1/quiz/attempts/{id}`
- **Permission / behavior:** owner only, no trait weights

**Record 8: PUT**

- **Method:** PUT
- **Endpoint:** `/v1/quiz/attempts/{id}/answers`
- **Permission / behavior:** idempotent upsert; ownership + schema

**Record 9: POST**

- **Method:** POST
- **Endpoint:** `/v1/quiz/attempts/{id}/submit`
- **Permission / behavior:** score async and return job/status

**Record 10: GET**

- **Method:** GET
- **Endpoint:** `/v1/reports/me?mode=friend`
- **Permission / behavior:** own derived report only

**Record 11: GET**

- **Method:** GET
- **Endpoint:** `/v1/discovery?mode=friend&lens=mirror&band=80`
- **Permission / behavior:** enforce consent, blocks, fraud gate

**Record 12: POST**

- **Method:** POST
- **Endpoint:** `/v1/introductions`
- **Permission / behavior:** one-user request with quota

**Record 13: POST**

- **Method:** POST
- **Endpoint:** `/v1/introductions/{id}/respond`
- **Permission / behavior:** receiver action only

**Record 14: GET**

- **Method:** GET
- **Endpoint:** `/v1/conversations`
- **Permission / behavior:** members only

**Record 15: POST**

- **Method:** POST
- **Endpoint:** `/v1/conversations/{id}/messages`
- **Permission / behavior:** member, rate/abuse gated

**Record 16: POST**

- **Method:** POST
- **Endpoint:** `/v1/blocks`
- **Permission / behavior:** immediate user protection

**Record 17: POST**

- **Method:** POST
- **Endpoint:** `/v1/reports`
- **Permission / behavior:** reporting works free and after block

**Record 18: GET/POST**

- **Method:** GET/POST
- **Endpoint:** `/v1/circles`, `/v1/circles/{id}/join`
- **Permission / behavior:** contextual membership

**Record 19: POST**

- **Method:** POST
- **Endpoint:** `/v1/payments/checkout`
- **Permission / behavior:** entitlement catalog + provider checkout

**Record 20: POST**

- **Method:** POST
- **Endpoint:** `/v1/webhooks/razorpay`
- **Permission / behavior:** signed raw body, not user-auth

**Record 21: POST**

- **Method:** POST
- **Endpoint:** `/v1/rights/exports`
- **Permission / behavior:** self + reauth, rate-limited

**Record 22: POST**

- **Method:** POST
- **Endpoint:** `/v1/rights/deletion`
- **Permission / behavior:** self + reauth + retention explanation

**Record 23: GET**

- **Method:** GET
- **Endpoint:** `/v1/admin/cases`
- **Permission / behavior:** admin claim + case read capability + MFA

**Record 24: POST**

- **Method:** POST
- **Endpoint:** `/v1/admin/cases/{id}/actions`
- **Permission / behavior:** permission, reason, audit and double-check

**Record 25: POST**

- **Method:** POST
- **Endpoint:** `/v1/admin/invitations`
- **Permission / behavior:** admin-management grant only; never client role

**Record 26: GET**

- **Method:** GET
- **Endpoint:** `/v1/admin/audit`
- **Permission / behavior:** security auditor or superadmin scoped


See `scaffolds/routes.openapi.yaml` as minimal machine-readable skeleton; developer must expand every endpoint and generate typed clients.

## 4. Example API payloads
```json
{"mode":"friend","lens":"mirror","band":{"min":80,"max":89},"limit":20,"cursor":"opaque"}
```
```json
{"candidate_id":"p_opaque","lens":"mirror","index_band":"80-89","coverage":0.84,"explanations":["similar communication pace","shared preferred activities"],"caveat":"Compatibility index, not a relationship prediction"}
```
```json
{"question_id":"q_opaque","answer":{"choice_id":"a3"},"assignment_revision":1,"idempotency_key":"client-generated-unique"}
```
Responses must never include raw hidden item-trait weights, nonconsented protected characteristics, other users' private answers, service secrets, internal audit logs or unapproved verification artifacts.

## 5. Events, retries, eventual consistency
Events: `UserVerified`, `ModeConsentGranted`, `ModeConsentWithdrawn`, `QuizAttemptSubmitted`, `TraitSnapshotComputed`, `MatchCacheInvalidated`, `IntroductionAccepted`, `MessageSent`, `UserBlocked`, `ReportCreated`, `CaseEscalated`, `SubscriptionPaymentSettled`, `RefundIssued`, `AccountDeletionRequested`, `AccountErased`. Carry `event_id`, `schema_version`, actor, minimized payload, timestamp, aggregate ID, idempotency key. Use transactional outbox where possible; worker retries never double-charge, re-send abusive content or re-grant access. Consent withdrawal and blocks are synchronous in access policy even if cached matches update later.

## 6. D1 SQL scaffold caveat
`scaffolds/schema.sql` is only a core baseline for implementation and performance tests. It does not cover every table or encryption model described above. Security-sensitive and legal-retention behaviors must have migration review and explicit integration tests before deployment.



---



# Security-RD — Threat Model, Control Requirements, Incident Response

## 1. Highest-value assets
Real identities, addresses/regions, psychological responses, inferred traits, preferences across friendship/dating/matrimony, private messages, reports, intimate media, payment entitlements, administrator tools and security evidence. Breaches may cause stalking, coercion, discrimination, extortion or reputational harm: classify assessment data as highly confidential even where statute classifications differ.

## 2. Trust boundaries and critical threats
- Browser → API: JWT theft, CSRF/cookie misuse, forged identities, IDOR/BOLA, object injection, credential stuffing.
- User → matching pool: profile scraping, mass requests, catfishing, minors, harassment, hidden dating solicitation, deanonymization through score queries.
- Chat/groups → moderators: unsolicited sexual content, grooming, fraud, deepfakes, unlawful media, violent threats, doxxing; malicious report floods.
- Workers → D1/R2/DO: public object URLs, malformed SQL, stale permissions, insecure signed upload, message replay, unbounded cost.
- Payments → entitlements: webhook forgery, duplicate callbacks, stale subscription/grant, refunds not reflected, client-side checkout tampering.
- Admin → private data: insider overreach, mass export, privilege escalation, stolen admin session, unsupported account intervention, audit modification.
- AI/model → data: model prompt injection, exfiltration to third-party API, memorization, discriminatory profiling, unverified trait reconstruction.

## 3. Mandatory controls (MUST)
- **Auth:** Firebase verified JWT server-side, email verification, rotation/revocation model, rate limits, password recovery, admin MFA. Eliminate mock OTP/password gate entirely.
- **Authorization:** deny-by-default per action + object, persona/mode boundary; OWASP ASVS 5.0 controls; automated cross-tenant IDOR tests.
- **Admin:** invitation-only authorized identity, device/session policies, no solely client-side role checks, dual approval for mass data export/role grant/permanent ban; comprehensive append-only audit.
- **PII encryption:** TLS, service-managed encryption at rest plus envelope/field-level protection for raw answers, derived sensitive traits and report evidence; keys rotated via secrets management, access recorded; cache plaintext only transiently.
- **Messaging:** choose candid **server-accessible encrypted-at-rest messaging** for moderation-capable MVP and inform users. End-to-end encryption is later optional and requires a separate safety design and real cryptographic implementation; no "Signal" badge by analogy.
- **Uploads:** only allowlisted MIME+magic bytes, randomized opaque object key, antivirus scanning, stripping dangerous EXIF where appropriate, size/quota cap, thumbnail generation only in approved pipeline, signed downloads, no direct public media bucket.
- **Abuse controls:** rate limit login/OTP/introductions/chat/uploads; slow mode for new accounts; bot challenge after anomaly; confidence-based trust review without public social scores.
- **Logging:** redact answers, secrets, tokens, private message bodies, government IDs and exact region; append audit state transitions, correlation ID and actor.
- **Data rights:** deletion propagation to DB, caches, R2, queues, exports and analytics with retained-lawful-hold exception; backups lifecycle and expiry policy.
- **Supply chain:** dependency scanning, lockfile pinning, secret scanning, IaC review, signed deploy artifacts, minimal service accounts, staging/prod key segregation.

## 4. Security test cases
S01 unauthenticated read to every private endpoint →401. S02 valid user A attempts user B's quiz answers, export and chat →403/404. S03 user changes from friendship to dating and requests nonconsented private fields →forbidden. S04 blocked user continues websocket and sends messages →revoked immediately. S05 operator without `safety.evidence.read` opens intimate media →deny, audit. S06 replay signed payment event →no duplicated entitlement. S07 malformed signed upload or HTML masquerading as image →reject/quarantine. S08 disable account mid-session →existing credential invalidated by local state check. S09 CSRF/cross-origin post →reject. S10 simulated mass-match scraping →limiter, anomaly flag. S11 consent withdrawal removes recommendations regardless of stale cached scores. S12 malicious LLM output includes prompt-injected commands →never executes data-modifying actions.

## 5. Incident severity / response
- **SEV-0:** active intimate-data exfiltration, large breach, child exploitation emergency, confirmed admin compromise; immediate containment/on-call and counsel/regulatory escalation.
- **SEV-1:** credible severe harassment/stalking threat, major auth bypass, payment compromise; urgent investigator assignment and targeted protective suspension.
- **SEV-2:** user data export issue, moderate service disruption, repeated abusive content; bounded SLA, remediation and lessons learned.
- **SEV-3:** cosmetic defects, low severity false positives; planned fix.

Response sequence: detect → open case and immutable timeline → contain accounts/keys/routes → preserve needed evidence lawfully → assess impact and notification obligations → remediate → restore → validate → postmortem. Run tabletop exercises before launch. **CERT-In reportable incidents can trigger six-hour reporting**; future DPDP Rule 7 can require without-delay affected-person/Board notice plus a 72h detailed Board report; exact current effective dates and jurisdiction confirmed with counsel. Prewrite templates in admin console, never auto-send inaccurate claims.

## 6. Safety-policy fundamentals
Prohibit threats, fraud, impersonation, minors, nonconsensual intimate imagery, doxxing, stalking, sexual pressure after an explicit boundary, solicitation of money, hate/harassment and cheating/forced matrimonial practices where unlawful. Offer in-product block/report at all conversation touchpoints; optional mutual silence modes. Know limitations of self-report "verified" badge. For urgent threats present local emergency services instructions; Kithra is not a 24/7 emergency responder unless it truly staffs one.

## 7. Before launch sign-off
Independent application penetration test including admin, chat, D1 object IDOR and payment callbacks; evidence of restore drill; provider data processing contracts, admin permission audit, encryption key handling documentation, secure secret rotation, privacy impact assessment, live incident contacts and clear public security claims.



---



# Billing-RD / Financial Model — Pricing, Entitlements, and Economics

Prices below are **proposed validation hypotheses**, not competitor-derived willingness to pay or profit forecasts. Use user interviews and live gateway/tax rates before publication. Legal and safety controls remain free.

## 1. Proposed plans (pilot)

**Comparison / requirement matrix — accessible record view:**

**Record 1: Free**

- **Tier:** Free
- **Monthly:** ₹0
- **3 months:** ₹0
- **6 months:** ₹0
- **12 months:** ₹0
- **Primary entitlements:** basic quiz, profile, useful discovery, limited requests, mutual chat, groups, report/block, full privacy controls

**Record 2: Plus**

- **Tier:** Plus
- **Monthly:** ₹149
- **3 months:** ₹399
- **6 months:** ₹749
- **12 months:** ₹1,399
- **Primary entitlements:** extra monthly introductions, multi-lens deeper explanations, advanced search, saved profiles

**Record 3: Connect**

- **Tier:** Connect
- **Monthly:** ₹299
- **3 months:** ₹799
- **6 months:** ₹1,499
- **12 months:** ₹2,799
- **Primary entitlements:** higher but capped intro quota, curated group features, additional filters and report comparisons

**Record 4: Matrimony Intent (later, optional)**

- **Tier:** Matrimony Intent (later, optional)
- **Monthly:** ₹399
- **3 months:** ₹1,099
- **6 months:** ₹2,099
- **12 months:** ₹3,899
- **Primary entitlements:** serious-intent tools, opt-in life-planning comparison and guided introductions, no guarantees


**Important:** initial MVP should launch Free only or test a clearly disclosed nominal paid pilot; do not commit engineering to all four tiers before demand exists. All above prices are illustrative *before final GST handling*, discounts relative to monthly are not implied auto-renew consent. The user may purchase one shared subscription with per-mode entitlements later, or separate modes, but never silently activate a different relationship mode when upgrading.

## 2. Never paywall
Blocking, reporting, privacy and consent withdrawal, access/correction/export/deletion where rights apply, basic interaction after mutual acceptance, emergency help, abuse appeal and complaint responses. Avoid paid bypass of someone's preferences, "priority access" to people who opted out, or refunds withheld for unsafe service.

## 3. Billing lifecycle
`draft_checkout -> pending_gateway -> payment_confirmed -> entitlement_granted -> active -> renewal_pending -> renewed/grace/past_due -> cancelled/expired/refunded`. Upgrade/downgrade proration and refund policies must be decided and disclosed. Gateway failure must not strip user privacy/safety or existing paid access prematurely. Persist `price_version`, `tax_calculation`, consent timestamp, renewal election, provider refs and finalized invoice metadata. User can download invoice and cancel future renewals without agent intervention.

## 4. Razorpay engineering requirements
Payment methods/recurring constraints depend on actual merchant setup and live Indian rails. Use subscription mandates only with required informed consent, pre-debit communications and legal compliance. Stripe-like instant card recurring assumptions may not apply to UPI/card mandates. Razorpay signed webhook verification on raw body, event ID unique index, idempotent ledger, server-confirmed payment status, reconciliation, retry/outbox, back-office refund approvals and masked details. Do not store PAN, CVV or UPI credentials.

## 5. Illustrative unit economics (not forecasts)
Assume Registered → MAU = 30%, Paid conversion of MAU = 3%, subscription realized ARPPU ₹149/month, gateway+indirect processing allowance 3% (placeholder), monthly fixed ops ₹7,500 baseline, variable support/moderation ₹1.5 per MAU, variable infra/email ₹0.4 per MAU. Gross margin before paid acquisition and tax = revenue − gateway − fixed − variable.

**Comparison / requirement matrix — accessible record view:**

**Record 1: 100**

- **Registrations:** 100
- **MAU:** 30
- **Paying:** 1
- **Gross ₹/mo:** 149
- **Approx modeled contribution ₹/mo:** -7,412

**Record 2: 1,000**

- **Registrations:** 1,000
- **MAU:** 300
- **Paying:** 9
- **Gross ₹/mo:** 1,341
- **Approx modeled contribution ₹/mo:** -6,769

**Record 3: 5,000**

- **Registrations:** 5,000
- **MAU:** 1,500
- **Paying:** 45
- **Gross ₹/mo:** 6,705
- **Approx modeled contribution ₹/mo:** -3,846

**Record 4: 10,000**

- **Registrations:** 10,000
- **MAU:** 3,000
- **Paying:** 90
- **Gross ₹/mo:** 13,410
- **Approx modeled contribution ₹/mo:** -192

**Record 5: 100,000**

- **Registrations:** 100,000
- **MAU:** 30,000
- **Paying:** 900
- **Gross ₹/mo:** 134,100
- **Approx modeled contribution ₹/mo:** 65,577


**Formula** `gross = paying × 149`; `fees = 0.03 × gross`; `variable = 1.9 × MAU`; `contribution = gross − fees − variable − 7500`. Above rounded to nearest rupee. Actual realized subscription prices vary by plan, discounts, GST, refunds, plan churn and processor costs. This model explicitly does **not** include founder salary, paid marketing CAC, capital expenditure, independent audits, lawyers, significant media moderation, staff coverage, nontrivial AI inference or taxes. Long-term cost may be far higher; observe paid cohort and incidents per active member.

## 6. Cohort and pricing experiments
Experiment price versus conversion ethically through clearly disclosed offers: Plus ₹99/149/199; no dark pattern, fake scarcity, deceptive fake charges, or incompatible payment mandates. Collect willingness-to-pay before checkout; measure refund complaints and 30/90-day retention. Pricing roadmap requires segment-specific India evidence and competition validation.

## 7. Cost guardrails
Feature flags for photo uploads, AI models, large answer-set retention, group/member quotas. Approx average 10 profile photos × 300KB × 5,000 accounts ≈15GB before versions/backups; R2 Standard 10GB-month free allowance would be exceeded. Even compressed images and read operations incur resource use; script quota alerts. Long conversations/media and identity/SMS cost can dominate modest subscription revenue. Human support at 24/7 scale cannot be assumed free. Set monthly spend thresholds with graceful degradation of nonessential features, not safety.

## 8. Subscription edge cases
Refund granted after entitlement expiration; duplicate payment webhook; subscription payment success but email failed; wrong price version; gift/referral fraud; user banned with paid time; deceased user account; cancellation near renewal boundary; tax invoice correction; expired mandate; payment dispute; deletion request with financial retention. Each gets deterministic state machine and reconciled audit record.



---



# QA-RD / Analytics-RD — Acceptance, Test Strategy, Instrumentation & Experiments

## 1. Quality architecture
**Unit:** scoring weights/coverage/bands, consent state transitions, eligibility predicates, billing entitlements, moderation deadlines. **Integration:** Firebase JWT verification, D1 migrations/transactions, R2 private upload, DO message state, Queue retries, Razorpay webhook. **Contract:** OpenAPI schema and generated TS client matches server on every release. **E2E:** sign-up, independent mode onboarding, quiz resume, discovery, mutual request/chat, block/report, case action, cancellation/export/delete. **Security:** IDOR/authorization and admin privilege adversarial matrix; device and browser matrix; limited load tests on paid sandbox budgets.

## 2. Prioritized full scenario matrix
**Comparison / requirement matrix — accessible record view:**

**Record 1: T01**

- **ID:** T01
- **Test:** Fresh unauthenticated user opens `/api/v1/me`
- **Required outcome:** 401, no private data

**Record 2: T02**

- **ID:** T02
- **Test:** User activates friend only and tries matrimony discovery
- **Required outcome:** empty/403 with explanation

**Record 3: T03**

- **ID:** T03
- **Test:** Complete quiz after random order and resume from device B
- **Required outcome:** stable assignment and saved response accuracy

**Record 4: T04**

- **ID:** T04
- **Test:** Two users share 100% measured index but one blocked the other
- **Required outcome:** not discoverable / cannot chat

**Record 5: T05**

- **ID:** T05
- **Test:** Score insufficient coverage
- **Required outcome:** no misleading 90% confidence outcome

**Record 6: T06**

- **ID:** T06
- **Test:** User changes answer then recalculates
- **Required outcome:** new score version, match cache invalidated

**Record 7: T07**

- **ID:** T07
- **Test:** User withdraws profiling consent
- **Required outcome:** discoverability disabled for that inference, prior cache unreadable

**Record 8: T08**

- **ID:** T08
- **Test:** User uses AI to answer quiz
- **Required outcome:** no "undetectable proof" claim; retest policy transparent

**Record 9: T09**

- **ID:** T09
- **Test:** Message sent with expired or forged token
- **Required outcome:** deny, no persistence

**Record 10: T10**

- **ID:** T10
- **Test:** Report from free/expired/banned plan
- **Required outcome:** protected reporting remains accessible through policy-safe channel

**Record 11: T11**

- **ID:** T11
- **Test:** Admin support agent guesses moderation evidence URL
- **Required outcome:** 403 + audited failed access

**Record 12: T12**

- **ID:** T12
- **Test:** Admin role client spoof and forged email
- **Required outcome:** deny via verified server permissions

**Record 13: T13**

- **ID:** T13
- **Test:** Risky admin ban requires 2 approvals
- **Required outcome:** cannot commit with one account

**Record 14: T14**

- **ID:** T14
- **Test:** Payment webhook repeated 20 times
- **Required outcome:** exactly one ledger credit and entitlement

**Record 15: T15**

- **ID:** T15
- **Test:** Cancel subscription
- **Required outcome:** no future renewal from platform while core data remains

**Record 16: T16**

- **ID:** T16
- **Test:** Erase personal data with lawful hold
- **Required outcome:** purge eligible records, retain only documented hold with restricted access

**Record 17: T17**

- **ID:** T17
- **Test:** D1 free read limit reached
- **Required outcome:** graceful nonessential throttling, alert; safety case still available via contingency

**Record 18: T18**

- **ID:** T18
- **Test:** R2 object URL leaked
- **Required outcome:** expired scoped signed URL cannot reveal other objects

**Record 19: T19**

- **ID:** T19
- **Test:** Worker deployment rollback
- **Required outcome:** previous version restores, schema forward compatibility

**Record 20: T20**

- **ID:** T20
- **Test:** Low-end mobile + reduced motion
- **Required outcome:** full functionality, no excessive animation


## 3. Events and privacy taxonomy
Store consented, minimized aggregate usage metadata, not raw answers, private texts, mental-health labels or sexual preference as marketing analytics. Example events: `onboarding_started`, `mode_activated`, `quiz_attempt_started`, `quiz_progress_checkpoint` (counts, no answers), `quiz_submitted`, `score_viewed`, `discovery_viewed`, `connection_requested`, `connection_accepted`, `report_opened`, `report_submitted`, `block_applied`, `second_contact_confirmed_day7`, `continued_connection_confirmed_day30`, `subscription_started`, `renewal_cancelled`, `support_sla_breached`, `case_closed`. Each event includes schema version, timestamp, coarse mode, experiment variant if consented, anonymized cohort and correlation ID; never user plaintext in third-party analytics.

## 4. Primary outcomes
**North star:** day-30 mutual continuity rate = pairs with two-sided affirmative follow-up / eligible introduced pairs, with transparent missing-data denominator. Secondary: completed meaningful introductions per active local cohort, day7 repeat contact, user safety comfort score, actual group repeat participation, subscription retention, complaints/1,000 active conversations, median and p95 response/resolution time, fairness across tested groups (only where lawful and proportionate).

## 5. Scientific matching experiments
A/B design: baseline interest/availability matching vs deeper consented trait matching, randomize qualified users where ethically feasible, report cohort sizes and confidence intervals, pre-register success measure, monitor differential dropoff and harm. Avoid sending someone to an unsafe or incompatible match as a "control"; all arms use identical hard safety filters. Assess matching explainability and human agency. Do not use AI-generated simulated conversations as evidence of real compatibility.

## 6. Release quality gates
No P0 security issue; full authz suite and admin MFA passed; no false copy; accessibility AA targeted; critical routes load tested, backup/restore verified, 30-day retention and abuse cases tested, legal/privacy reviewed, on-call acknowledged, monitoring dashboards and rollback rehearsed. Test artifacts stored with release SHA.

## 7. Reporting dashboards
Public product dashboard aggregates by city/mode and hides small counts to prevent reidentification. Admin views segmented by duty; no casual raw quiz exports. Executive weekly report: activated users per pool, qualified introductions, continued connections, conversion, safety incidents and SLA, net cash burn. Matching science report: score calibration, holdout lift, attrition, bias and caveat compliance. Finance report: settled payments, refunds/chargebacks, realized ARPPU, gross margin and spend versus ceilings.



---



# Delivery-RD — Dependency-aware Delivery, Roadmap & Developer Backlog

**This is a recommended phased roadmap, not an estimate that one person can complete all of it in 90 days.** Three relationship modes, psychometrics, chat, public groups and an operating moderation console are a multi-disciplinary product; avoid committing to a calendar that substitutes for staff/clinical/legal work.

## 1. Workstream dependencies
1. Product/legal gates and safety policy before collecting intimate answers.
2. Auth/identity, consent, mode persona and admin roles before quizzes/discovery/chat.
3. Question bank review/permissioning before psychological scoring can represent anything meaningful.
4. Matching policy and score contract before candidate discovery.
5. Report/block/moderation capacity before stranger chat/groups/media.
6. Billing ledger and cancellation tested before paid plans.
7. App metrics and safety analytics before feature expansion.
8. Migration abstraction before major DB growth, not after vendor lock-in.

## 2. Planning calendar for a small team
**Phase 0 — 0–30 days: research and controlled validation.** 20–30 interviews per initial segment, safe concierge matching, separate positioning tests for three modes, opinionated legality/data map, architecture spike, brand prototype. **Exit:** evidence of repeat contact and trust with consenting adults; no full public launch.

**Phase 1 — 30–60 days: secure skeleton.** Monorepo, design tokens/story components, CI/CD, identity/JWT verification, mode-scoped personas, D1 migrations, admin invitation + MFA, consent log, rights request scaffold, private R2 upload, safety report pipeline, worker observability and audit logging. **Exit:** demonstrated deny-by-default auth and data boundaries.

**Phase 2 — 60–90 days: restricted experience.** Approved limited theme quiz, server-side scoring with transparent caveat, match candidate batch, discovery, requests, text chat, blocks/reports, moderated private Circles, admin case triage, consent withdrawal and data export/deletion end-to-end. Security review and pilot readiness gate. **Exit:** approved adult invite-only pilot with staff safety coverage.

**Phase 3 — 90–150 days: validate and harden.** cohort science, accessibility/bias/security fixes, stable messaging and SLA alerts, backup/restore, full customer support, moderation staff training and billing gateway test. Only then consider subscriptions, public Circles, staged cities, additional themed banks.

**Phase 4 — 150–270 days: optional scale.** localized question research and translations, matrimony-specific controls, multiple quiz versions, advanced lens experiments, curated activity loops, B2B partnerships and server migration if performance/legality requires it. AI twins and media-heavy calls remain separate later research tracks.

## 3. Developer sprint epics / estimation units

**Comparison / requirement matrix — accessible record view:**

**Record 1: E00**

- **Epic ID:** E00
- **Scope:** repo assessment, remove simulated claims, architecture setup
- **Dependency:** none
- **Relative size:** M
- **Release acceptance:** no demo auth in production

**Record 2: E01**

- **Epic ID:** E01
- **Scope:** Firebase identity + JWT and account mapping
- **Dependency:** E00
- **Relative size:** L
- **Release acceptance:** all invalid tokens rejected

**Record 3: E02**

- **Epic ID:** E02
- **Scope:** mode consent, profiles & field ACL
- **Dependency:** E01
- **Relative size:** XL
- **Release acceptance:** cross-mode isolation tested

**Record 4: E03**

- **Epic ID:** E03
- **Scope:** public UX and component design
- **Dependency:** E00
- **Relative size:** L
- **Release acceptance:** responsive, WCAG tests

**Record 5: E04**

- **Epic ID:** E04
- **Scope:** question catalog/banks/attempts
- **Dependency:** E01,E02
- **Relative size:** XL
- **Release acceptance:** deterministic versioning and resume

**Record 6: E05**

- **Epic ID:** E05
- **Scope:** scoring engine + explanations
- **Dependency:** E04 + scientific approval
- **Relative size:** XL
- **Release acceptance:** reproduce all scores; caveats

**Record 7: E06**

- **Epic ID:** E06
- **Scope:** matching discovery + cache + consent
- **Dependency:** E05,E02
- **Relative size:** XL
- **Release acceptance:** hard safety filters enforced

**Record 8: E07**

- **Epic ID:** E07
- **Scope:** connection requests + text chat
- **Dependency:** E06,E08
- **Relative size:** XL
- **Release acceptance:** mutual consent and report tools

**Record 9: E08**

- **Epic ID:** E08
- **Scope:** moderator/admin cases, roles, complaints
- **Dependency:** E01,E02
- **Relative size:** XL
- **Release acceptance:** first/second-line safety flows

**Record 10: E09**

- **Epic ID:** E09
- **Scope:** Circles & group controls
- **Dependency:** E07,E08
- **Relative size:** XL
- **Release acceptance:** group-specific moderation

**Record 11: E10**

- **Epic ID:** E10
- **Scope:** data rights, deletion and retention
- **Dependency:** E02,E04,E08
- **Relative size:** XL
- **Release acceptance:** verified end-to-end erasure jobs

**Record 12: E11**

- **Epic ID:** E11
- **Scope:** payment entitlements + renewals
- **Dependency:** E08,E10
- **Relative size:** L
- **Release acceptance:** reconciled webhook/cancel

**Record 13: E12**

- **Epic ID:** E12
- **Scope:** security/observability/backup
- **Dependency:** all
- **Relative size:** XL
- **Release acceptance:** incident drill and pentest

**Record 14: E13**

- **Epic ID:** E13
- **Scope:** outcome analytics & experiments
- **Dependency:** E06,E07
- **Relative size:** M
- **Release acceptance:** 7/30-day outcome reports

**Record 15: E14**

- **Epic ID:** E14
- **Scope:** multilanguage, AI twin, video
- **Dependency:** evidence gates
- **Relative size:** XXL
- **Release acceptance:** research-only until new approval


Relative sizes XS/S/M/L/XL/XXL represent comparative effort, not person-day promises. Milestone timing must be re-estimated after staffing and prototype tests.

## 4. Full feature priority table
**MUST before public launch:** authenticated accounts, verified adult eligibility policy, profile privacy by mode, opt-in quiz consent, scoring caveat, discovery hard filters, mutual request, text-only safe chat, block/report, support desk, basic moderation + on-call, admin MFA/RBAC, consent rights, accurate terms/privacy, backup/restore, operational logs, security audit, error handling and accessibility.

**SHOULD after pilot:** varied question sets, natural-language score explanations from approved traits, moderated Circles and meetups, payment plans, in-app notifications, user feedback, better insight graphs, verified claimed facts with provider-approved flow.

**COULD after evidence:** verified organizers, official curated group sessions, discovery quality learning, long-term compatibility research, advanced conversation prompts, localized cohorts, optional family-assisted matrimony.

**WON'T initially:** full AI mind replicas, predicting protected traits secretly, public sharing of raw quizzes, video calls, on-device face biometrics, mandatory Aadhaar, open adult+minor matching, unmoderated anonymous groups, paid bypass of user consent, guaranteed soulmates.

## 5. Cost-aware feature flags and graceful modes
- `public_discovery_enabled`, `new_signups_enabled`, `media_upload_enabled`, `private_groups_enabled`, `matching_compute_enabled`, `payments_enabled`, `ai_simulation_enabled=false`, `read_only_mode`.
- On Cloudflare limit exhaustion protect help and reporting via alternative documented contact; do not hide safety system behind rate limit. Offline/retry states must not create duplicate payments or messages.
- Configure per-month spend caps/alerts for R2/Worker/DO, account creation SMS email and moderation time.

## 6. Deliverables for each discipline
**Founder:** persona interview log, revenue assumptions, acceptance and risk signoffs. **Psychology:** construct map, survey licenses, item validation, model card and unfairness tests. **Designer:** all Figma screens, tokens, responsive prototypes and content guidance. **Engineer:** tested code, API spec, migration scripts, ops dashboards, secrets, CI and runbooks. **Security:** threat model, pentest, checklist, incident tabletop. **Legal:** signed policies, data map, record of applicability, grievance procedures. **Moderator:** documented queue, escalation, appeals and training simulations. **QA:** traceability matrix and defect severity ledger.

## 7. Definition of a shippable vertical slice
A real authorized user (not mocked) activates friendship mode, completes a **valid published** safe assessment, receives a clearly caveated index, sees only eligible and opt-in candidate(s), sends/receives a request, exchanges a persisted text message, reports abuse, has a human respond via authenticated case handling, and withdraws profiling consent such that further matching ceases; all actions audited/tested and legal review complete.

## 8. Explicit next decisions
D01 city/cohort for launch; D02 invitation-only vs open beta; D03 timeline and staff coverage; D04 science advisor and research protocol; D05 first published theme approval; D06 starting plan price research; D07 host region/vendor contracts; D08 moderated image capability; D09 identity verification policy; D10 whether any paid/matrimonial family tools are delayed; D11 brand/domain clearance and Indian company identity; D12 responsible officer contact.



---



# Competitive-RD / Market Validation — Product Reality in India and Abroad

**Research status 1 November 2026.** Available downloads/revenue claims do not prove psychological matching efficacy. Kithra's overlap is strong; AI-persona matching is not new. Always separate self-reported figures, public marketing, verified financial results and independent outcomes.

## 1. Competitors with clear functional overlap

**Comparison / requirement matrix — accessible record view:**

**Record 1: OkCupid**

- **Competitor:** OkCupid
- **Overlap with Kithra:** deep questionnaire + match percentages
- **Evidence and interpretation:** established questionnaire compatibility; not guaranteed success; https://www.okcupid.com/

**Record 2: We3**

- **Competitor:** We3
- **Overlap with Kithra:** psychographic questions, friendship groups and explanations
- **Evidence and interpretation:** site describes hundreds of factors and triadic introduction; reported >1M tribes and 50k+ in-person meetups **self-reported**, not independently audited: https://www.we3app.com/how-it-works/

**Record 3: Boo**

- **Competitor:** Boo
- **Overlap with Kithra:** personality-based friends + dating with communities
- **Evidence and interpretation:** official FAQ says 30-question test, personality matches and friend/date modes; https://boo.world/faq

**Record 4: Dimensional**

- **Competitor:** Dimensional
- **Overlap with Kithra:** >200 psychological traits, compare relationship dimensions
- **Evidence and interpretation:** official site reports 200+ traits; https://www.dimensional.me/

**Record 5: TrulyMadly**

- **Competitor:** TrulyMadly
- **Overlap with Kithra:** Indian dating, compatibility and verification
- **Evidence and interpretation:** Inc42 financial breakdown FY25 approx revenue ₹12.3 crore and net loss ₹1 crore; source is third-party financial compilation, not outcomes: https://inc42.com/company/trulymadly/financials/

**Record 6: Aisle**

- **Competitor:** Aisle
- **Overlap with Kithra:** India-focused serious dating, curated discovery
- **Evidence and interpretation:** current features/revenue/scale should be rechecked from company and filings, no high-certainty psychological claim; https://www.aisle.co/

**Record 7: Schmooze**

- **Competitor:** Schmooze
- **Overlap with Kithra:** indirect preference inference from memes, Indian product
- **Evidence and interpretation:** Business Standard Sep 2024: company reported 1M Indian users in 10 months, raised $4M; not proven relationship outcomes: https://www.business-standard.com/companies/start-ups/ai-led-dating-platform-schmooze-raises-4-million-series-a-round-124091701179_1.html

**Record 8: Konvo**

- **Competitor:** Konvo
- **Overlap with Kithra:** **AI twins** converse and preview potential matches
- **Evidence and interpretation:** site advertises AI twin chats/virtual dates and made-for-India positioning; claims have not been independently validated: https://konvo.space/

**Record 9: Betterhalf**

- **Competitor:** Betterhalf
- **Overlap with Kithra:** India-oriented matrimony with algorithmic claims
- **Evidence and interpretation:** adjacent paid serious-intent audience; https://www.betterhalf.ai/

**Record 10: Hinge**

- **Competitor:** Hinge
- **Overlap with Kithra:** prompt-driven relationship discovery
- **Evidence and interpretation:** broader intent-based discovery; https://hinge.co/

**Record 11: Meetup**

- **Competitor:** Meetup
- **Overlap with Kithra:** activity-led friendships
- **Evidence and interpretation:** actual group activities, no long psychometrics; https://www.meetup.com/

**Record 12: Discord / WhatsApp**

- **Competitor:** Discord / WhatsApp
- **Overlap with Kithra:** organic communities and conversations
- **Evidence and interpretation:** substitute for social infrastructure; https://discord.com/ and https://www.whatsapp.com/


## 2. Relevant competitor counterstrategies
- **Against OkCupid:** show why a score is meaningful, mode separation, consent and real continuation, not merely more questions.
- **Against We3:** explore one-to-one and group friendship formats with actual 7/30-day mutual outcomes, friend boundaries, local density and better privacy clarity.
- **Against Boo:** clear choice of friendship/dating/matrimony and measurable connection quality, not personality type stereotypes.
- **Against Dimensional:** practical voluntary introductions and safety rather than just a dashboard of traits.
- **Against Konvo:** avoid premature AI replica promise, provide validated consented behavioral insights and a transparent data-governance advantage.
- **Against Indian dating incumbents:** build trust and resolve safety issues operationally, without pretending algorithmic compatibility removes human uncertainty.

## 3. India readiness and true success test
Evidence of downloads/registrations is **not** evidence of active compatible matches. For each operator evaluate: India monthly active users in target city and mode, gender/intent composition where publicly verified, 30-day retention, share of mutual conversations, repeat contact and outcomes, subscription conversion/paid refunds, user complaints and moderation capacity. Most private startups do not publish reliable causal success data; label unknown rather than estimate a number.

## 4. Field validation program
Week 1: interview at least 20–30 per one target cohort (not necessarily all three modes), log current alternatives and genuine frustrations, avoid leading/"would you use AI twin" questions. Week 2: present three positionings and a simple legal/privacy prototype; measure real opt-ins and privacy concern. Week 3: invite adult volunteers, assign a short transparent matching task with human safety screening, consented mutual introductions; avoid asking 1,200 questions before showing any value. Week 4+: at day7/30 independently ask both members about continued contact, quality and safety; report missing/negative answers, not just testimonials. Use simple interest/availability baseline comparison. Only retain consented outcome data in minimal form.

## 5. Falsifiable go / change / stop rules
**GO to secure beta:** user demand plus positive evidence of safe repeat interactions and willingness to participate without exaggerated claims. **CHANGE matching:** questionnaire burden increases abandonment with no credible lift over simple interests. **CHANGE niche:** no local active compatible density despite reasonable acquisition; move to narrower age/community/language pool. **STOP or pause:** unmanaged abuse, inability to staff legal safety response, high privacy risks that cannot be mitigated, deceptive model explanation dependence, unsustainable per-active-member economics. These are decision rules, not predictions.

## 6. What cannot honestly be claimed
No proven competitor was identified with independently verified "100% brain replication", "90% relationship success" or certainty of opposite/puzzle-fit marriage outcome in India. Commercial marketing may use soulmate language; Kithra must not equate such claims with science.



---



# Evidence Register, Assumptions, Open Decisions & Source Traceability

**Checked:** 1 November 2026. Search results and product/vendor prices may change after that. URLs are starting points; official text and signed legal opinion outrank this report. This register clearly separates primary source evidence, concept ZIP, recommended design decisions and unvalidated assumptions.

## A. Uploaded source evidence
`Kithra-main.zip` extracted and inspected by file path:
- `package.json`: React 19, TypeScript, Vite 8, Tailwind 4, `framer-motion`, `motion`, `@google/genai`, Express dependency. This is the current concept stack, not proof of backend deployment.
- `src/App.tsx`: default mocked psychometric report and matches, stateful view navigation.
- `src/components/AssessmentView.tsx`: localStorage answers and `DEFAULT_REPORT` on completion.
- `src/data/questions.ts`: current template bank with 100 questions distributed over eight domains and ad-hoc weighting; **future question banks are new specification**.
- `src/data/mockMatches.ts`: fictional candidates and percentages.
- `src/components/AuthModal.tsx`: mock six-digit OTP and admin password condition accepting any nonempty value; not secure.
- `src/components/AdminView.tsx`: static sample metrics, verification and navigation tabs.
- `src/components/MessagingView.tsx`: simulated conversation features and unverified encryption imagery.
- `src/components/SecurityView.tsx`: simulated export and misleading E2EE copy.
- `src/components/BillingView.tsx`: plan visual design, not actual payment processing.
- `WORK_DONE.md`: self-described UI work, not independently verified production feature completion.
- `README.md`, `.env.example`: generic app notes and Gemini/APP_URL placeholders; no evidence of functional Worker/D1/R2 infrastructure.
- User-supplied ChatGPT shared link: https://chatgpt.com/share/6ae65881-aae0-83e8-b306-4fc4a1e96887 had a title only and **no readable page lines**; not used as a substantive source.

## B. Official provider technical source links (verified)
1. Cloudflare Workers pricing: https://developers.cloudflare.com/workers/platform/pricing/ — 100k requests/day and 10ms CPU Free; min $5/mo Workers Paid as of check.
2. Cloudflare Workers limits: https://developers.cloudflare.com/workers/platform/limits/ — runtime/resource constraints.
3. Cloudflare D1 pricing: https://developers.cloudflare.com/d1/platform/pricing/ — 5M rows read/day, 100k written/day, 5GB total Free storage.
4. Cloudflare D1 limits: https://developers.cloudflare.com/d1/platform/limits/ — **500MB max per database Free**, 10GB paid individual DB.
5. Cloudflare R2 pricing: https://developers.cloudflare.com/r2/pricing/ — 10GB-month Standard free, Class A/B operations.
6. Cloudflare Durable Objects pricing: https://developers.cloudflare.com/durable-objects/platform/pricing/ — SQLite DO Free availability.
7. Cloudflare Queues pricing: https://developers.cloudflare.com/queues/platform/pricing/ — Free 10k ops/day, retention limits.
8. Firebase pricing: https://firebase.google.com/pricing — phone SMS billed, identity billing tiers.
9. Identity Platform pricing: https://cloud.google.com/identity-platform/pricing — Tier 1 first 50k MAU free if using Identity Platform pricing structure; inspect SKU/plan.
10. Firebase server-side token verification: https://firebase.google.com/docs/auth/admin/verify-id-tokens — validate public certificate, issuer/audience/expiry.
11. Supabase pricing: https://supabase.com/pricing — 50k MAU on Free; Free project paused after inactivity, 500MB DB.
12. Supabase JWT: https://supabase.com/docs/guides/auth/jwts — asymmetric JWKS verification.
13. Motion for React: https://motion.dev/docs/react — preferred `motion/react` API.
14. OWASP ASVS 5.0: https://asvs.owasp.org/ — authentication/access control testing baseline.
15. Cloudflare D1 data location: https://developers.cloudflare.com/d1/configuration/data-location/ — default automatic location, jurisdiction controls not an India-localization guarantee.

## C. India laws and official information
1. DPDP Act commencement Gazette G.S.R. 843(E): https://egazette.gov.in/WriteReadData/2025/267647.pdf ; inspected English second page screenshot and text. 13 Nov 2025 initial, 13 Nov 2026 one-year, 13 May 2027 eighteen-month provisions.
2. DPDP Rules 2025 Gazette G.S.R. 846(E), reproduced text: https://indiacode.ecourtsindia.com/rules/digital-personal-data-protection-dpdp-rules-2025-fe07b131/ ; use official eGazette canonical PDF before counsel approval.
3. MeitY DPDP rules overview (PIB): https://www.pib.gov.in/PressReleasePage.aspx?PRID=2190014
4. IT Intermediary Guidelines 2021, amended Feb 2026 consolidated MeitY link: https://master-meity.digifootprint.gov.in/documents/act-and-policies/information-technology-intermediary-guidelines-and-digital-media-ethics-code-rules-2021-it-rules-2021-IjM5QjMtQWa
5. 2026 synthetic-media duty overview: https://www.pib.gov.in/PressReleasePage.aspx?PRID=2245053
6. CERT-In directions: https://www.cert-in.org.in/Directions70B.jsp
7. CERT-In 6h FAQs: https://www.cert-in.org.in/PDF/FAQs_on_CyberSecurityDirections_May2022.pdf
8. Consumer Protection e-commerce law portal: https://consumeraffairs.gov.in/pages/consumer-protection-acts
9. Consumer Protection E-Commerce 2026 changes: https://www.pib.gov.in/PressReleasePage.aspx?PRID=2308759 — announced effective 1 Jan 2027; ask counsel applicability.

## D. Competitor primary/recent sources
- https://www.we3app.com/how-it-works/ ; https://www.we3app.com/faq/
- https://boo.world/faq ; https://www.dimensional.me/
- https://konvo.space/ ; https://www.okcupid.com/
- https://schmooze.in/ ; https://www.aisle.co/ ; https://www.betterhalf.ai/
- https://www.business-standard.com/companies/start-ups/ai-led-dating-platform-schmooze-raises-4-million-series-a-round-124091701179_1.html
- https://inc42.com/company/trulymadly/financials/

## E. Assumptions needing founder approval
`A01` Kithra is 18+ only initially. `A02` three relationship modes share identity but not visibility. `A03` Cloudflare primary storage acceptable after cross-border/data residency review. `A04` Firebase auth instead of Supabase. `A05` email/password+Google first; phone optional later. `A06` admin managed by named email/password + strong MFA + deny-by-default RBAC. `A07` score bands measure index agreement, not probability. `A08` "AI twin" disabled until separately consented and validated. `A09` first validated quiz bank only after specialist review; rest placeholders. `A10` Free-first pilot before paid subscriptions. `A11` limited text chat and private moderated groups. `A12` price ladder illustrative. `A13` no mandatory Aadhaar/biometric or exact coordinates. `A14` no true E2EE claim until audited implementation. `A15` chat/group access not public during unstaffed pilot.

## F. Open decisions / decision rights
**Founder:** market segment/launch city, intended modes and rollout order, investment/ads goals, acceptable quiz length, pricing structure, product naming and brand IP. **Psychometrics advisor:** trait constructs, question permissions, scoring, model validation and honest claims. **Counsel:** Indian DPDP/IT Rules, user policies, privacy basis, cross-border, matrimonial obligations, payment/regulatory conditions. **Engineering lead:** Worker data architecture, R2 encryption, JWT verification, DB migration, backups, error budget, app security. **Trust lead:** staffing, report categories, escalation, evidence retention, appeals. **Designer:** user tests, brand, responsive and accessible prototypes. None may unilaterally bypass a legal/safety gate.

## G. Recommendation versus verification
**Verified from ZIP:** UI prototypes and insecure mocked logic. **Verified from public current docs:** provider allowances, regulatory commencement instruments, competitor descriptions and some company-reported metrics. **Recommended architecture:** not implemented or load-tested. **Mathematical examples:** not psychometrically validated. **Pricing and operating costs:** hypothetical; require testing. **Legal drafts:** placeholders; not airtight and cannot substitute legal advice.



---



# AI-RD — Optional Digital Personality Twin: Research Specification, Safety & Evaluation

**Status:** FUTURE RESEARCH; disabled by default. This document intentionally does not claim Kithra will copy a person's brain, create a sentient replica, infer intimate identities secretly, or reliably predict marriage or friendship outcomes. It defines a possible *consent-based model of the user's explicitly disclosed communication preferences* and a set of gating requirements before even a small controlled experiment.

## 1. What is actually feasible?
- **Persona summary:** a user-reviewed, editable representation of self-described preferences and questionnaire-based bounded traits.
- **AI simulation:** an LLM configured to respond as a *hypothetical agent* according to that summary. It may generate plausible dialogue, but it is **not** the user and does not reliably reproduce future beliefs, emotions, actions or consent.
- **Two-agent rehearsal:** opted-in agents can simulate introductory scenarios to offer conversation-starting topics or areas for discussion; this is **not a real human chemistry test**, cannot replace actual mutual consent, and cannot be used as factual proof of compatibility.
- **Behavior-over-time improvement:** only consented, user-confirmed feedback updates the summary; avoid covert scraping of private messages, journals or off-platform data.

## 2. Separate opt-in and revocation
Consent step clearly states source datasets (selected quiz dimensions, written self-description, optional specifically selected past messages if ever supported), intended outputs, third-party processors, retention, deletion, impersonation limits, model fallibility, costs and users' ability to preview/edit/revoke. Opt-in is **per person**, per source category and per mode; two agents may not communicate unless both owners opted in to that pairing/use. Revocation immediately stops new generations, marks prior simulation unshareable and launches documented deletion cleanup where lawful.

## 3. Data processing pipeline
```
Consent registry → minimal approved trait summary → user review/approval
→ policy scrubber and mode scoping → LLM prompt template → guarded simulation
→ clear "AI-generated hypothetical" label → user correction/approval
→ optional human-human introduction only after fresh mutual consent
```
Never give a model unrestricted access to D1, private messages, admin tooling or payments. No personal address, government ID, medical history, raw sexual orientation inference or trauma narrative in the prompt. Persona ID and pseudonym separate from account identifiers. Third-party inference endpoints receive the minimum authorized, redacted information.

## 4. Agent representation (example, not clinical)
`agent_version`, `user_id`, `mode`, `user_approved_summary`, `trait_model_version`, `declared_interests`, `communication_preferences`, `unshareable_boundaries`, `prompt_template_version`, `consent_id`, `expires_at`, `provider`, `output_disclaimer`, `reviewed_at`, `revoked_at`. Do not store secret prompts as proof of safety; actual policy enforcement lives in service code.

## 5. Why simulation should not score human relationships directly
Agents may amplify stereotypes, hallucinate confidence, answer in ways the underlying user never would, and optimize for pleasing dialogue. Simulations across agents have correlated biases and can make incompatible people look compatible. If used experimentally, treat outputs as **conversation suggestions**, not a component of 100%/90% match score without independent human-outcome validation. Allow both participants to reject simulated summaries without penalty.

## 6. Technical evaluation before enabling
- Consent and processor agreement verified.
- Privacy red-team: prompt injection, secrets exfiltration, cross-user leak, jailbreaking, identity spoofing.
- Test mismatched/missing questionnaire coverage and adversarial prompt manipulation.
- Human validation: does each owner accurately endorse what the model says? Report confidence/uncertainty.
- Comparative outcome trial: optional agent interaction vs no agent, measuring safety and **actual** continued contact, not simulated applause.
- Cost caps per invocation, token budgets, strict timeout, content moderation, model version pinning and trace IDs with **no raw sensitive content in logs**.
- Affected-person deletion and processor purge contract tested before production.
- Regulatory classification of synthetic output under applicable 2026 IT intermediary rules and consumer protection reviewed by counsel; AI outputs clearly labeled.

## 7. Product UX for future agent mode
Dedicated "Explore your preferences with AI" workspace, explicit account of what is and is not used, data preview, simulated transcript with persistent **AI simulation — not a real conversation** watermark, user corrections, privacy pause, delete-agent button, processor info and cost/use notices. No "your brain was replicated" copy, no making commitments or sending actual human messages without direct fresh approval.

## 8. Release gate
Separate security review, psychological-accuracy claims review, measurable human benefit, positive informed consent comprehension test, vendor contract/legal approval, acceptable cost model and staffed abuse response. Until then show no AI Twin button or waitlist that falsely implies functioning brain simulation.



---



# Community-RD / Growth-RD — Circles, Social Graph, Regionalization & Healthy Network Effects

## 1. The cold-start problem
Kithra can contain hundreds of thousands of inactive accounts yet provide no useful matches in a specific gender/intent/region/age/interest pool. Report **eligible active candidate density** by selected mode, city and broad interests, not raw registration count; expose truthful waitlists. Prefer one tested launch cohort and 2–3 scheduled activities to shallow national expansion. Group programming should create a reason to return that is not an engagement addiction loop.

## 2. Independent social surfaces
- **Member social graph:** voluntary mutual connection edge; block relation overrides any edge.
- **Mode persona graph:** public discovery edge scoped by selected mode; a friendship connection does not imply dating availability.
- **Circle graph:** group membership and moderation role not proof of off-platform compatibility.
- **Quiz graph:** index derived privately, never display other users' undisclosed raw answers.
- **Offline event graph:** consent-based RSVP; default public location only, no home/real-time tracking.

## 3. Circle feature specification
`Circle` has ID, neutral name, description, primary theme, optional mode restriction, coarse location, language(s), visibility (`public_listed`, `private_unlisted`, `invite_only`), membership rules, owner, moderators, max members, creation review status, content policy version. User actions: explore, request join, accept rules, view posts, mute, leave, block member, report content, create restricted circle with quotas. Circle admin actions: approve membership, pin rules, remove content, temporarily mute, send membership announcements subject to policy. Platform admins retain safety oversight; group managers cannot see intimate quiz data or global case records.

## 4. Region-neutral personality naming
Do not categorize people into alpha/beta, high/low status, superior/inferior, religion/caste-based "types". **Universal labels** for interpretive dimensions: `Compass`, `Rhythm`, `Mosaic`, `Horizon`, `Current`, `Bridge`, `Spark`, `Anchor`. **Optional India-oriented expressive aliases** for community themes (not immutable psychological classifications): `Sangam` (confluence), `Setu` (bridge), `Lehar` (wave), `Aangan` (shared gathering place), `Udaan` (aspiration). Indian language professionals should assess meanings and accessibility; English, Hindi and Tamil expressions cannot be assumed culturally interchangeable. These names describe communities and preferences, **not ethnicity, caste, religion, worth or destiny**. All members can browse or opt out; no identity-based assignment.

## 5. More features that fit this universe (prioritized by outcome)

**Comparison / requirement matrix — accessible record view:**

**Record 1: Small-group icebreaker Circles**

- **Experience:** Small-group icebreaker Circles
- **User need:** avoid awkward one-to-one beginnings
- **Phase:** MVP after moderation
- **Safety and cost caveat:** group reporting & boundaries

**Record 2: Mutual conversation starters**

- **Experience:** Mutual conversation starters
- **User need:** help first meaningful dialogue
- **Phase:** MVP
- **Safety and cost caveat:** optional, not auto-sent AI

**Record 3: Shared reading/learning challenge**

- **Experience:** Shared reading/learning challenge
- **User need:** repeat organic contact
- **Phase:** post-pilot
- **Safety and cost caveat:** avoid leaderboard pressure

**Record 4: City newcomers board**

- **Experience:** City newcomers board
- **User need:** discover local safe groups
- **Phase:** post-pilot
- **Safety and cost caveat:** coarse location only

**Record 5: Co-working/creator collaborations**

- **Experience:** Co-working/creator collaborations
- **User need:** productive friendship
- **Phase:** post-pilot
- **Safety and cost caveat:** anti-scam and IP policy

**Record 6: Quiet affinity groups**

- **Experience:** Quiet affinity groups
- **User need:** accessible low-pressure friendships
- **Phase:** post-pilot
- **Safety and cost caveat:** privacy, member choice

**Record 7: Intent-specific date planning**

- **Experience:** Intent-specific date planning
- **User need:** safer date logistics
- **Phase:** later
- **Safety and cost caveat:** venue info, no live tracking

**Record 8: Shared-life-planning conversation guide**

- **Experience:** Shared-life-planning conversation guide
- **User need:** matrimony mutual expectations
- **Phase:** later
- **Safety and cost caveat:** self-declared, no guarantee

**Record 9: Community-host toolkit**

- **Experience:** Community-host toolkit
- **User need:** partnerships and repeat meetups
- **Phase:** later
- **Safety and cost caveat:** host identity and liability review

**Record 10: Conversation follow-up reminder**

- **Experience:** Conversation follow-up reminder
- **User need:** reduce ghosting with consent
- **Phase:** post-pilot
- **Safety and cost caveat:** no spam or guilt prompts

**Record 11: Compatibility change tracker**

- **Experience:** Compatibility change tracker
- **User need:** self-reflection over time
- **Phase:** later
- **Safety and cost caveat:** privacy and scoring drift

**Record 12: AI-summarized preference card**

- **Experience:** AI-summarized preference card
- **User need:** opt-in clarity
- **Phase:** research
- **Safety and cost caveat:** third-party data processing

**Record 13: Video/voice groups**

- **Experience:** Video/voice groups
- **User need:** online social presence
- **Phase:** much later
- **Safety and cost caveat:** high moderation/media costs

**Record 14: Moderated real-world events**

- **Experience:** Moderated real-world events
- **User need:** strengthen ties
- **Phase:** later
- **Safety and cost caveat:** event safety and organizer vetting

**Record 15: Professional peer circles**

- **Experience:** Professional peer circles
- **User need:** founder and tech collaborations
- **Phase:** post-pilot
- **Safety and cost caveat:** job/scam solicitation checks


## 6. Gamification limits
Reward *mutual, useful outcomes* like attending agreed small groups or completing a conversation guide, not message volume, streaks, harmful self-disclosure, desirability ranking or coercive endorsements. No visible scores that indicate higher personal value. Referral campaigns must be opt-in, anti-spam, without revealing who uses matrimonial mode. Every new social mechanic must report harassment and exclusion risks.

## 7. Messaging and notifications economics
Allow member-generated invitations only within quotas; message dispatch via DO and persistence in D1; attachment lifecycle to R2; opt-in email summaries, low-frequency suggestions and a single configurable quiet-hours setting. No paid unlock for receiving basic messages from a mutual consented match. If push notifications are eventually built, respect mode concealment on lock screens.

## 8. Localization and inclusion
Support multilingual UI separately from psychometric translation: UI labels can be translated with ordinary QA; psychological questions require cognitive interviews and item-level measurement equivalence analysis. Right-to-left ready components if expanding internationally; avoid culturally biased labels, no photographs of fictitious people labeled as current members, avoid assumptions of family authority in matrimony. Regional data retention/sharing assessed for all chosen providers.

## 9. Growth experiments
Test: `city-newcomer circles`, `interest cohort`, `founder/learning club`, `serious relationship conversation prompts` as separate cohorts. Measure invite→active conversion, safe mutual introductions, repeat contact, circle active member concentration, moderation cost per 100 active participants. Partner with clubs only when a real co-host and safety point of contact exists; never claim vendor endorsement without contract.



---

