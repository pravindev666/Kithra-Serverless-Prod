# UXR / UID / Design-RD — Kithra Complete UI/UX & Motion Handover

**Audience:** UI/UX designers, design system engineer, front-end developer, accessibility reviewer. **Source ZIP is a product concept only**. Do not inherit its design uncritically; all colors, type, layout and interactions below are a fresh coherent recommendation. Deliver high-fidelity Figma responsive prototypes and implementable components with explicit states.

## 1. Product experience principles
1. **Human first, not algorithm first.** Display a human profile before an invented perfection badge. Use compatibility as an explanation, not value ranking.
2. **One identity, three quiet worlds.** Intent-specific Friendship, Dating and Matrimony contexts, visually distinct only where it clarifies context; never leak one persona into another.
3. **Discovery through mutual choice.** Avoid swipe-addiction, infinite scarcity/fear framing and fake urgency.
4. **Trust without surveillance theater.** Explain exactly what has and has not been verified, security implemented and user visibility.
5. **Respect highly private data.** Reveal only summaries the member chose; privacy controls next to disclosure, not buried.
6. **Friction where it protects.** Slow down intimate consent, public sharing, privilege grants and risky actions; reduce friction for routine browsing.
7. **A calm living experience.** Tactile microinteraction, not screenfuls of continuous motion. Reduced-motion accessible parity.

## 2. Brand territories and visual concept
**Positioning:** modern, insightful, warm and trustworthy; avoid occult/soulmate certainty, clinical diagnosis, cosmic mysticism too strongly or matrimonial stereotypes. Visual metaphor: **connecting facets**—slightly asymmetrical geometric shapes, which align through deliberate choices, not a literal brain scan. Use soft field gradients and editorial portraits only when appropriately licensed and consented; no AI-generated member photos falsely presented as real.

### Color tokens

**Comparison / requirement matrix — accessible record view:**

**Record 1: background**

- **Token:** background
- **Light:** `#F7F7F3`
- **Dark:** `#0F1822`
- **Usage:** neutral canvas

**Record 2: surface**

- **Token:** surface
- **Light:** `#FFFFFF`
- **Dark:** `#182430`
- **Usage:** cards and sheets

**Record 3: surface-muted**

- **Token:** surface-muted
- **Light:** `#EEF0EE`
- **Dark:** `#22313D`
- **Usage:** secondary panels

**Record 4: ink**

- **Token:** ink
- **Light:** `#18252A`
- **Dark:** `#F2F5F2`
- **Usage:** primary text

**Record 5: ink-muted**

- **Token:** ink-muted
- **Light:** `#56636B`
- **Dark:** `#ACB7BE`
- **Usage:** secondary text

**Record 6: brand-deep**

- **Token:** brand-deep
- **Light:** `#264D56`
- **Dark:** `#8FD0CC`
- **Usage:** headings/logo accent

**Record 7: teal-action**

- **Token:** teal-action
- **Light:** `#147C82`
- **Dark:** `#57BCC0`
- **Usage:** primary CTA

**Record 8: teal-hover**

- **Token:** teal-hover
- **Light:** `#105E64`
- **Dark:** `#8DD6D8`
- **Usage:** interaction

**Record 9: coral-soft**

- **Token:** coral-soft
- **Light:** `#D99683`
- **Dark:** `#E5AB98`
- **Usage:** warm human accent

**Record 10: lilac**

- **Token:** lilac
- **Light:** `#9389BF`
- **Dark:** `#B0A5DB`
- **Usage:** alternate visual lens

**Record 11: positive**

- **Token:** positive
- **Light:** `#207D62`
- **Dark:** `#74C9A4`
- **Usage:** successful controlled states

**Record 12: warning**

- **Token:** warning
- **Light:** `#AA6B20`
- **Dark:** `#F2C070`
- **Usage:** caution notices

**Record 13: danger**

- **Token:** danger
- **Light:** `#B73C4A`
- **Dark:** `#FF8A94`
- **Usage:** abuse/confirmation destructive

**Record 14: border**

- **Token:** border
- **Light:** `#D9E0DF`
- **Dark:** `#34444B`
- **Usage:** hairline separators


Accent palettes for **mode identification**: Friendship teal `#147C82`, Dating rose `#B75D77`, Matrimony indigo `#655AA9` (with accessible text variants on respective themes). Colors identify the current mode but never indicate caste, gender, attractiveness or psychological worth.

### Typography, icons and layout
Use **Manrope** (display), **Inter** (body/interface), optional **Newsreader** italic for 1–2 editorial hero words (do not overdo). Fallback system fonts. Display 64/72 desktop, 38/44 mobile; H1 48/56 desktop; H2 36/44; H3 24/32; body 16/26; compact UI 14/20; captions ≥12/18 sparingly. Use a consistent 8pt spacing grid with 4pt increments; radii 12/16/24/32; 1px borders; subtle non-colored shadows, not neon glows everywhere. Icons Lucide or custom 24px stroke with semantic labels. User photos are circular/soft-square; no fake verified marks. Max readable text width 70ch. Public page grid 12 columns, max 1280px, 24–48px gutter. Workspace desktop sidebar 252px; contextual details panel 320px; content max 1180px. Mobile 360px baseline and 44px minimum targets; use bottom nav for 4–5 high-frequency destinations.

### Implementation tokens
Use `scaffolds/design-tokens.json` as the source for CSS custom properties, Figma variables, theme switch and component states. Include focus ring, breakpoint and motion primitives. Never derive contrast from a hue without testing WCAG 2.2 AA.

## 3. Public landing page — art direction and scroll narrative
**Section L1 / first fold:** minimalist navigation left Kithra wordmark; right "How it works", "Safety", "Our approach", "Pricing", "Log in"; CTA "Explore connections". Hero line **"People are more than profiles."** secondary "Discover friends, dates and potential life partners through thoughtful questions and mutual choice." Three mode chips displayed as clearly different intents. Hero illustration: four subtle translucent tessellated facets approach one another and form a flexible whole; **not brains, souls or medical imagery**. On mobile replace with simple static/low-motion graphic. Public hero does not claim X% success.

**L2 / Explain the three worlds:** Friendship / Dating / Matrimony cards, each with expectations and an independently opt-in selector; a mode focus toggle updates copy, does not autoplay huge transitions.

**L3 / How it works:** Choose intention → Answer optional questions → View clear compatibility lens → Make mutual connection → Build real relationship. Animated path with descriptive relationship connectors only, scrolling under reduced motion static.

**L4 / Compatibility lens demo:** sample fictional match report with switcher `Mirror / Counterpoint / Mosaic`, human-friendly explanation and caveat "Scores summarize answers, not certainty." No fabricated testimonials.

**L5 / Privacy promise:** transparent raw-answer privacy, opt-in sharing, boundaries, blocking, report, human moderation. Badges only for implemented audited features. Link to legal center.

**L6 / Circle communities:** small facilitated topic-focused groups; screenshots/mockups explicitly labeled illustrative until real.

**L7 / Pricing:** Free + optional upgrades, month/quarter/half-year/year toggle, full GST and auto-renew clarity, cancel anytime meaning explained.

**L8 / Frequently asked:** is Kithra dating? do I need 100 questions? can I skip? are scores guaranteed? can I hide myself? can I delete? which data other users see? can admin see chats? who handles reports?

**L9 / Footer:** official entity, contact, legal, privacy, data rights, community guidelines, help, accessibility, security disclosures and status page.

## 4. Motion system (Framer Motion / `motion/react`)
**Motion goal:** purposeful, calm, performant and accessible; use CSS transforms and opacity, never scroll-jacking.

**Comparison / requirement matrix — accessible record view:**

**Record 1: enter**

- **Motion token:** enter
- **Parameters:** 260ms, ease `[0.22,1,0.36,1]`, `y: 12 → 0`, opacity `0 → 1`
- **Where:** card entrance

**Record 2: appear**

- **Motion token:** appear
- **Parameters:** 180ms ease-out, opacity only
- **Where:** dialogs and data updates

**Record 3: softSpring**

- **Motion token:** softSpring
- **Parameters:** `type:'spring', stiffness:260, damping:28`
- **Where:** tab indicator / small affordance

**Record 4: pageTransition**

- **Motion token:** pageTransition
- **Parameters:** 220ms crossfade, `y:6 → 0`
- **Where:** workspace panes

**Record 5: hoverScale**

- **Motion token:** hoverScale
- **Parameters:** 120ms, scale to 1.015 max
- **Where:** CTA/cards

**Record 6: reducedMotion**

- **Motion token:** reducedMotion
- **Parameters:** all nonessential transform animations disabled, opacity short or instant
- **Where:** accessibility


Suggested snippets (pseudocode, confirm installed version):
```tsx
import { motion, AnimatePresence, useReducedMotion } from 'motion/react';
const reduced = useReducedMotion();
<motion.section initial={reduced ? false : {opacity:0,y:12}} whileInView={{opacity:1,y:0}}
 viewport={{once:true,amount:0.15}} transition={{duration:0.26,ease:[0.22,1,0.36,1]}} />
```
Hero facets animate **once** with 350–600ms sequence stagger, then remain still. Focus changes by reduced-motion-safe crossfade. Hero load must not be blocked by large video/WebGL; no particles that increase GPU cost. Avoid infinite shimmering 3D "soul twin" animation, 100 parallax layers, forced scroll snapping, content that moves while typing, layout shifts or distraction in admin. Use `LazyMotion` and bundle splitting; test 30fps+ mid-tier mobile and preserve full function with JavaScript animation disabled.

## 5. App-wide information architecture
### Desktop sidebar
```
[Logo] Kithra
[Intent switcher: Friendship ▾]      (always visible)

DISCOVER
  Overview
  Discover People
  Match Lenses (Mirror / Counterpoint / Mosaic)
  Connections & Requests
  Circles

CONNECT
  Messages
  Notifications
  Saved Profiles

DISCOVER YOURSELF
  Quiz Library
  My Assessments
  My Compatibility Profile
  Growth Notes (optional, private)

ACCOUNT
  My Mode Profiles
  Membership & Billing
  Privacy & Consent
  Safety & Help
  Settings
```
On narrow tablet: compact icon rail with tooltips and accessible labels. Mobile: bottom nav **Discover / Connections / Circles / Messages / Me**; quiz library via Me/discover prominent banner; switch intent via top-bar pill; prevent accidental cross-mode switch by clearly changing header/canvas marker. Do not force all destinations as 14 visible mobile tabs.

## 6. End-to-end user screen inventory & edge states
**U01 Landing:** interactive hero, scroll narrative, copy and CTA; disclose limits.
**U02 Sign-up/log-in:** email & password, Google, forgot password, confirm email, terms/age separate; loading/error/rate limit states; no silent account linking by email.
**U03 Intent onboarding:** choose one or more, explain visibility boundaries; empty selection cannot proceed to discovery.
**U04 Create mode persona:** display name, age validation, coarse city, interests, pronouns optional, photos optional, audience/visibility, safety preference; preview as another user.
**U05 Privacy & consent:** consent cards by mode/quiz, data sharing diagram, toggle explanation, consent history and withdraw all; no hidden default consent.
**U06 Quiz library:** category tiles by theme, number of valid published item sets, estimated duration, relevance by mode and progress.
**U07 Quiz run:** one question at a time, question `x/100`, save indicator, back/skip/quit, keyboard radio navigation, edit response, context tooltip and sensitive-question warning where relevant; mobile sticky Next; no timer penalties.
**U08 Quiz resume/error:** previously saved partial, pending sync, offline, recovered attempts, locked published version; recovery path.
**U09 My psychological profile:** plain-language traits and coverage/confidence, adjustable visibility, evidence explanation, no clinical diagnosis or surveillance implication.
**U10 Discover people:** list/grid/mapless city pool, mode/lens/band controls; truthful pool count; minimal filters; reasons + risks; skeleton/empty/blocked/restricted states.
**U11 Detailed match profile:** public photo optional, mode, human story, consented compatibility highlights, mutual interest, report/block shortcuts, non-scientific caveats; avoid "opposite fixes you".
**U12 Connection inbox:** pending incoming/outgoing, accepted, expired, declined; reject without penalty or disclosure; manage request volume.
**U13 Messages:** desktop split conversation list/main thread/optional details; mobile single chat view; ability to block/report from header, message action and profile; text first, attachments later; clear transport security disclosure, no fake E2E.
**U14 Circles index:** themes, local/remote, public/private, member counts, moderation rules, filter by mode.
**U15 Circle detail:** feed, conversation, rules, moderators, invitations, report, leave, member role; no unsolicited mode transfer.
**U16 Create a Circle:** name/description/topic/moderation setting/location scope, member admissions, creator responsibilities, permissions.
**U17 Activity events (later):** participant cap, public location guidance, RSVP, cancellation and safety review.
**U18 Membership:** available plans, entitlement comparison, GST/renewal rules, gateway redirect, receipts/cancel/refund.
**U19 Account settings:** notifications, region and language, account, security/session log, connected identity, delete/export/consent.
**U20 Safety Center:** transparent verified security features, report tracker, help desk, appeals, safety guides, legal requests contact.
**U21 Support ticket:** category, problem description, optional attachments, attachments privacy disclosure, ticket status.
**U22 System states:** blocked/suspended/quiz-version-deprecated/score-incomplete/empty local pool/internet failure/consent withdrawn; each has a constructive next step.

## 7. Component catalog
Button (primary, secondary, quiet, danger), IconButton, Tabs, SegmentedControl, IntentModeSwitcher, AccessiblePopover, DropdownMenu, ProfileCard, MatchLensCard, TrustBadge (strict criteria), ScoreBandBadge with help, ConfidenceIndicator (when supported), ConsentToggle, QuizChoiceGroup, QuizProgress, ResumeCard, MemberAvatar, ConnectionRequest, MessageBubble, ReportDialog, NotificationToast, InfoDisclosure, AlertBanner, SkeletonCard, EmptyState, ConfirmationDialog, Pagination, FilterSheet, SearchAutocomplete, Date/LocationInput, AdminRiskPill, AuditEventRow, CaseTimeline, RoleMatrix. For each Figma component define variants, interaction, error, focus, disabled, high-contrast and dark state, screen-reader output and motion specification.

## 8. Core screen specs for UX handoff
### Discovery list
Header mode switch and large human-focused heading, visible lens explanation, small live list and deferred filters. On card show name, general city, chosen public interests, *descriptive* band, explanation; request action not available until eligible. 100/90/80...10 bands are optional advanced filter and refer to index ranges; do not show "100% chance".

### Match detailed panel
Split: left human story/intent, right `Why you might connect`, `How you differ`, `What the model doesn't know`, confidence and mutual contact CTA. On mobile stack, persistent CTA only after reading essential boundaries. Raw answers never displayed without separate sender approval.

### Quiz 100-question journey
Question progress must be honest: `18 of 100`, ability to finish later. 100 continuous questions can cause fatigue; design checkpoints every 20, transparent skip policy, summary after completion or after validated short subset, no false gamification streak. Zero items production ready until vetted. Keep completion autosave even on network disruptions.

### Messaging
Request gate before conversation; unread, sending, failed/retry, deleted, reported, blocked states. Provide easy exit, plain content warnings, media safety controls and limitations of moderation privacy; do not design fake voice-call buttons for unbuilt features.

### Matrimony context
Sober copy, serious intent, voluntary family visibility, separate sensitive preference consent, clear marital status self-report vs verified. No dowry filters or discriminatory psychological type names. Add explicit mismatch/boundary disclosures; family contact cannot appear unless both persons independently authorize.

## 9. Microcopy and accessibility
Never say "100% perfect person", "clinically verified soulmate", "brain replica", "Aadhaar verified" without a real legal process. Prefer "Strong measured alignment in 5 shared areas" with model explanation. Errors are specific and respectful; avoid blaming users who skip personal questions. All controls keyboard accessible, form labels real, logical focus restoration, visible indicators, alt text for meaningful imagery, AA contrast, no information purely color-coded, 200% zoom and reduced motion tested. Maintain layouts under English plus Hindi/Tamil string expansion; do not localize official scoring labels without expert review.

## 10. Figma handover checklist
Deliver `00 Foundations`, `01 Components`, `02 Public Landing`, `03 Onboarding`, `04 Friendship`, `05 Dating`, `06 Matrimony`, `07 Quiz`, `08 Discovery & Matching`, `09 Messaging & Groups`, `10 Safety & Billing`, `11 Admin Console`, `12 Responsive/States`, `13 Prototype Motion`, `14 Content & Translations`; light/dark as applicable. Name variants consistently; include token export and motion specs, component interaction matrices, annotated error/empty/privacy states, 360/768/1024/1440px breakpoints. For development: Storybook (optional), Chromatic visual regression, automated a11y tests, performance budget and no unbuilt feature decoration.

## 11. Design acceptance criteria
A first-time user understands mode separation within 20s; all flows have privacy explanation and easy cancel; every matching explanation shows uncertainty; a report/block reachable in ≤2 interactions from chat and profile; data deletion available without payment; no navigation dead ends; admin safety functions visually distinguish urgency; test on lower-end Android, keyboard-only, screen reader, reduced-motion and low bandwidth.



---



# Admin-RD — Mission Control, RBAC, Support, Moderation and Admin UX

**Product rule:** The admin dashboard is a separate privileged product, not a hidden tab accessible with a static secret. Frontend visibility is convenience; security is enforced at the Worker/API and on data access. Its scope is incident response, customer support, trust/safety, billing review, score bank governance and privacy rights—not casually reading members' personal stories.

## 1. Admin authentication and provisioning
Use `admin.kithra.[tld]` as a distinct origin (or separate `/admin` deployment behind Cloudflare Access if domain constraints), not linked in public nav. Allowed admin identities use **specific verified email accounts plus password and MFA**, backed by Firebase provider identity plus Kithra server-side allowlist and privileges. Require elevated MFA/passkey or TOTP for all admin access; if provider limitations affect this, choose a supported dedicated MFA/auth solution before launch. Restrict admin membership to invite-only, verified by superadmin with reason, expiry and approval. Admin email domain allowlist is defense-in-depth, not identity proof by itself. Optionally Cloudflare Access adds a second identity/device gate. No plain-text passwords in database/code, no common admin shared account, no default secret. Read-only auditors and safety agents have individual accounts.

## 2. RBAC permission matrix

**Comparison / requirement matrix — accessible record view:**

**Record 1: Dashboard aggregate KPI**

- **Action:** Dashboard aggregate KPI
- **Owner/Superadmin:** Y
- **Trust & Safety Lead:** Y
- **Safety Reviewer:** Y
- **Support Agent:** Y
- **Finance:** Y
- **Quiz Publisher:** Y
- **Analyst:** Y
- **Auditor:** Y

**Record 2: View user public account metadata**

- **Action:** View user public account metadata
- **Owner/Superadmin:** Y
- **Trust & Safety Lead:** Y
- **Safety Reviewer:** case only
- **Support Agent:** ticket only
- **Finance:** masked
- **Quiz Publisher:** N
- **Analyst:** aggregate
- **Auditor:** metadata only

**Record 3: Read reported chat excerpt**

- **Action:** Read reported chat excerpt
- **Owner/Superadmin:** approval
- **Trust & Safety Lead:** assigned
- **Safety Reviewer:** assigned
- **Support Agent:** N
- **Finance:** N
- **Quiz Publisher:** N
- **Analyst:** N
- **Auditor:** audit ref only

**Record 4: Full raw quiz answers**

- **Action:** Full raw quiz answers
- **Owner/Superadmin:** N by default
- **Trust & Safety Lead:** N
- **Safety Reviewer:** N
- **Support Agent:** N
- **Finance:** N
- **Quiz Publisher:** N
- **Analyst:** N
- **Auditor:** N

**Record 5: Restrict account temporary**

- **Action:** Restrict account temporary
- **Owner/Superadmin:** Y
- **Trust & Safety Lead:** Y
- **Safety Reviewer:** request
- **Support Agent:** N
- **Finance:** N
- **Quiz Publisher:** N
- **Analyst:** N
- **Auditor:** N

**Record 6: Permanent ban**

- **Action:** Permanent ban
- **Owner/Superadmin:** dual approval
- **Trust & Safety Lead:** dual approval
- **Safety Reviewer:** N
- **Support Agent:** N
- **Finance:** N
- **Quiz Publisher:** N
- **Analyst:** N
- **Auditor:** N

**Record 7: View payment references**

- **Action:** View payment references
- **Owner/Superadmin:** masked
- **Trust & Safety Lead:** N
- **Safety Reviewer:** N
- **Support Agent:** masked
- **Finance:** Y
- **Quiz Publisher:** N
- **Analyst:** aggregate
- **Auditor:** audit only

**Record 8: Refund request approval**

- **Action:** Refund request approval
- **Owner/Superadmin:** approved threshold
- **Trust & Safety Lead:** N
- **Safety Reviewer:** N
- **Support Agent:** create request
- **Finance:** Y
- **Quiz Publisher:** N
- **Analyst:** N
- **Auditor:** log only

**Record 9: Publish quiz bank**

- **Action:** Publish quiz bank
- **Owner/Superadmin:** Y via approval
- **Trust & Safety Lead:** N
- **Safety Reviewer:** N
- **Support Agent:** N
- **Finance:** N
- **Quiz Publisher:** propose/approve split
- **Analyst:** N
- **Auditor:** log only

**Record 10: Configure public feature flag**

- **Action:** Configure public feature flag
- **Owner/Superadmin:** Y
- **Trust & Safety Lead:** limited safety
- **Safety Reviewer:** N
- **Support Agent:** N
- **Finance:** N
- **Quiz Publisher:** quiz only
- **Analyst:** N
- **Auditor:** N

**Record 11: Invite/revoke admin**

- **Action:** Invite/revoke admin
- **Owner/Superadmin:** dual approval
- **Trust & Safety Lead:** N
- **Safety Reviewer:** N
- **Support Agent:** N
- **Finance:** N
- **Quiz Publisher:** N
- **Analyst:** N
- **Auditor:** audit

**Record 12: Audit-log export**

- **Action:** Audit-log export
- **Owner/Superadmin:** Y + justification
- **Trust & Safety Lead:** restricted
- **Safety Reviewer:** N
- **Support Agent:** N
- **Finance:** N
- **Quiz Publisher:** N
- **Analyst:** N
- **Auditor:** approved

**Record 13: Deletion/legal hold exception**

- **Action:** Deletion/legal hold exception
- **Owner/Superadmin:** dual approval + counsel
- **Trust & Safety Lead:** request
- **Safety Reviewer:** N
- **Support Agent:** N
- **Finance:** N
- **Quiz Publisher:** N
- **Analyst:** N
- **Auditor:** evidence only


`Y` authorizes only permitted scope. Separate role and capability from organizational titles. Every capability checked per case/tenant, not just route level. Reviews require step-up authentication for high-risk actions. Data-access "break glass" logs reason, reviewer, duration and recipient alerts; default disabled.

## 3. Information architecture / admin sidebar
```
KITHRA | MISSION CONTROL
[Global case search — restricted] [Alerts] [Admin identity + MFA status]

OVERVIEW
  Operations Dashboard
  Safety Command Center
  Live Incident Alerts

TRUST & SAFETY
  Reports Queue
  Case Investigations
  Appeals
  User Restrictions
  Group Moderation
  Verification Requests (only if implemented)

SUPPORT
  Tickets Inbox
  Billing & Refunds
  Account Recovery
  Data Rights / Deletion

MATCHING & RESEARCH
  Quiz Theme Catalog
  Question Bank Review
  Scoring Model Registry
  Fairness/Outcome Monitoring

FINANCE & GROWTH
  Plans & Entitlements
  Payment Ledger (scoped)
  Acquisition/Retention (aggregated)

SYSTEM
  Feature Flags & Emergency Controls
  Roles & Invitations
  Audit Logs
  Incident Runbooks
  Settings / Provider Status
```
No direct "psychometric dossier" item. If cases require access, show narrow redacted evidence only with case justification. Admin responsive design primarily desktop 1280/1440+; tablet read-only triage; destructive actions disabled on mobile or require full reauth.

## 4. Admin visual guidance
Different from public Kithra's welcoming canvas, but related token system: deep slate `#111B24`, surface `#1C2A35`, ink `#F3F7F7`, teal action `#6DBFC2`, amber `#F1BB68`, red `#F28C93`; case badges neutral unless genuine urgency. Left rail 248px, top bar 68px, central table with filter/search, right 360px context drawer with evidence timelines and policy guidance. Dense but legible: body 14/20, 12px metadata, 32px data figures. Motions limited to 160ms drawer crossfade and table row highlights; no attention-grabbing landing effects. All audit actions show plain-language consequence and undo only when genuinely reversible.

## 5. Dashboard metrics
Queue backlog by priority/category, time to first response, time to investigation/resolution, emergency breach warnings, appeal overturn, repeat offenders, review staff available, unreconciled payments, user support CSAT, deleted-account backlog, matching fairness tests status, current free-tier usage/budget, last backup and restore test, system health. Metrics must come from actual persisted data and freshness timestamp, not fake counts.

## 6. Moderation case runbook
**Report creation:** write immutable report and state synchronously; assign `case_id`, hold relevant evidence only lawfully, anonymize reporter information from subject. **Triage:** severity based on specific harm, age, ongoing exposure, repeat pattern. **Investigate:** redact defaults, open only scoped excerpts, record each evidence access and reason, corroborate before punitive action. **Action:** educate/warn, remove content, restrict features, suspend, ban, refer to authorities where required; avoid automatic global punishments without review. **Notify:** give reporter meaningful safety update, avoid exposing private investigation; provide subject accessible reasons and appeal path where feasible and lawful. **Appeal:** reviewer not original investigator, record rationale. **Close:** documented final state, scheduled evidence disposal or justified retention.

### SLA engine
At minimum implement category-aware deadlines and escalations, not one global timer. Contingent internal schedule: immediate `critical` handoff and emergency policy, specialized intimate-image/impersonation cases as legally applicable within 2h, content grievances 36h where applicable, general acknowledgements 24h and general resolutions 7d where applicable (verify current consolidated 2026 IT Rules with counsel). Show colored state only after precise deadline type and on-call capacity are known. Automatic overdue escalation via cron/queue with backup recipient, no false claim of resolution if case is simply marked read.

## 7. Support case UX
Inbox queues `New / Assigned / Waiting for user / Escalated / Resolved / Appeal`; category filters, severity, mode, age of ticket; keyboard shortcuts available but dangerous actions always explicit. Conversation history redacts identity and notifies agent when private material accessed. Suggested macros are human-reviewed, not auto-sent for legal/security harms. Support agent can request proof of account ownership using secure channel but never ask for password or full card number. Evidence attachments quarantined and object-scoped.

## 8. Admin roles and invite lifecycle
First trusted superadmin created out-of-band via setup script or privileged audited migration. Addition requires existing superadmin plus reviewer approval for elevated roles. Invite token one-time and short-lived, bound to verified email address; account enrolls MFA before privilege activation. Remove/revoke token on suspension, employment termination, expiration, account compromise; session revocation at API boundary. Roles are capability sets, nonrecursive; `owner` role is not a wildcard bypass of privacy safeguards.

## 9. Admin UX flows and acceptance
- **A01 access:** non-admin trying admin host → generic unauthorized, no information leakage; even successful Firebase login not enough.
- **A02 case report:** support can open and assign own tickets but not read unreported messages.
- **A03 ban:** moderator recommends, safety lead approves, system logs two distinct human identities.
- **A04 sensitive export:** only permitted auditor, step-up auth, documented reason, time-limited result, alert owner.
- **A05 quiz publication:** draft → independent science reviewer → privacy reviewer → publisher → canary; trace revisions; rollback.
- **A06 feature flag:** disable discovery/chat immediately while leaving help, safety and data-rights accessible.
- **A07 admin offboarding:** revoked role reflected across fresh requests and socket sessions; signed action logs retained.
- **A08 payment case:** finance refunds only through signed gateway API with two-person approval above threshold; ledger reconciliation.

## 10. Operational staffing requirement
An owner must be reachable for urgent law/safety cases at all times the public platform operates, or product scope (uploads/public messaging) must be limited accordingly. Cloud services cannot substitute for human investigation. Staffing, duty rotation, vendor/legal escalation and incident tabletop are launch dependencies rather than optional polish.



---

