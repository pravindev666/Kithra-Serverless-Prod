# Compliance-RD / PIA — India Data Protection, Platform Operations & Legal Readiness

**As of 1 November 2026. Legal drafting aid only; not legal advice or legal immunity.** India-specific status must be reverified immediately before launch. The platform cannot contract out of statutory duties. Build policies and controls around actual deployment and actual corporate entity.

## 1. Timeline you must not confuse
- **DPDP Act, 2023** notified staged commencement on **13 November 2025** under G.S.R. 843(E). Initial institutional/other provisions commenced then.
- Provisions scheduled **13 November 2026**: one-year items including Act s6(9) and specified rule(s) regarding consent managers. This does not itself force every ordinary startup to register as a consent manager.
- Major substantive processing/rights/security/breach provisions scheduled **13 May 2027** (18 months from 13 November 2025) under Act and DPDP Rules, 2025, G.S.R. 846(E). Compliance program should be ready before that date, not deferred until after.
- Existing **IT Act / 2011 SPDI rules**, where applicable, cover sensitive personal data categories including sexual orientation and mental health; exact transitional status/overlap requires counsel.
- **IT Intermediary Guidelines 2021 as amended 2026**, including February 2026 corrigendum, may govern Kithra if it qualifies as an intermediary hosting user content. Duties differ by classification and facts; do not label every platform a "significant social media intermediary" without threshold analysis.
- **CERT-In Directions dated 28 April 2022:** report specified cyber incidents within 6 hours, with additional requirements for certain entities/logs and applicable retention; implement reporting readiness. Other legal obligations may apply (consumer protection, payments, intellectual property, Indian criminal laws regarding stalking, obscenity, impersonation, dowry, etc.).
- **Consumer Protection (E-Commerce) Amendment Rules 2026**, as announced 10 September 2026, have an intended 1 January 2027 start; scope/application to Kithra subscriptions must be assessed.

## 2. Primary official evidence
DPDP commencement Gazette: https://egazette.gov.in/WriteReadData/2025/267647.pdf ; DPDP Rules text indexed: https://indiacode.ecourtsindia.com/rules/digital-personal-data-protection-dpdp-rules-2025-fe07b131/ ; MeitY/PIB explanatory release: https://www.pib.gov.in/PressReleasePage.aspx?PRID=2190014 ; Consolidated IT Intermediary 2026: https://master-meity.digifootprint.gov.in/documents/act-and-policies/information-technology-intermediary-guidelines-and-digital-media-ethics-code-rules-2021-it-rules-2021-IjM5QjMtQWa ; CERT-In https://www.cert-in.org.in/Directions70B.jsp ; E-commerce updates: https://www.pib.gov.in/PressReleasePage.aspx?PRID=2308759 .

## 3. Privacy impact assessment: map every processing purpose

**Comparison / requirement matrix — accessible record view:**

**Record 1: Email, provider UID**

- **Collection:** Email, provider UID
- **Purpose:** account and recovery
- **Access:** identity service + restricted support
- **Sharing:** Firebase and transactional provider
- **Default retention idea (NOT legal conclusion):** while account + lawful records

**Record 2: Adult age confirmation**

- **Collection:** Adult age confirmation
- **Purpose:** enforce 18+ enrollment
- **Access:** automated safety
- **Sharing:** no public display
- **Default retention idea (NOT legal conclusion):** minimum evidence necessary

**Record 3: Mode-specific display profile**

- **Collection:** Mode-specific display profile
- **Purpose:** chosen discovery
- **Access:** matched viewers per field policy
- **Sharing:** consented other users
- **Default retention idea (NOT legal conclusion):** active mode + deletion grace

**Record 4: Quiz raw answers**

- **Collection:** Quiz raw answers
- **Purpose:** derive assessments
- **Access:** scoring service only
- **Sharing:** **never by default to another user**
- **Default retention idea (NOT legal conclusion):** until purpose fulfilled/withdrawal + lawful holds

**Record 5: Derived traits/model scores**

- **Collection:** Derived traits/model scores
- **Purpose:** matching
- **Access:** scoring service and owner
- **Sharing:** consented trait summaries only
- **Default retention idea (NOT legal conclusion):** current version; retire superseded snapshots

**Record 6: Exact location**

- **Collection:** Exact location
- **Purpose:** not required for MVP
- **Access:** none
- **Sharing:** none
- **Default retention idea (NOT legal conclusion):** **do not collect**

**Record 7: City/region**

- **Collection:** City/region
- **Purpose:** local relevance
- **Access:** discovery service
- **Sharing:** coarse region if opted in
- **Default retention idea (NOT legal conclusion):** mode active

**Record 8: Chat messages**

- **Collection:** Chat messages
- **Purpose:** agreed correspondence, abuse evidence
- **Access:** participants; limited escalation staff
- **Sharing:** participants / specific legal process
- **Default retention idea (NOT legal conclusion):** published configurable schedule

**Record 9: Reports and case evidence**

- **Collection:** Reports and case evidence
- **Purpose:** safety grievance, lawful evidence
- **Access:** assigned moderation team
- **Sharing:** required authorities where applicable
- **Default retention idea (NOT legal conclusion):** proportionate incident retention

**Record 10: Device/IP/rate-limit data**

- **Collection:** Device/IP/rate-limit data
- **Purpose:** anti-fraud and security
- **Access:** security staff
- **Sharing:** hosting providers
- **Default retention idea (NOT legal conclusion):** necessity-based; counsel-reviewed

**Record 11: Subscription references**

- **Collection:** Subscription references
- **Purpose:** billing/legal audit
- **Access:** finance support
- **Sharing:** payment gateway
- **Default retention idea (NOT legal conclusion):** tax/accounting legal minimum

**Record 12: AI persona training**

- **Collection:** AI persona training
- **Purpose:** **off by default**
- **Access:** none until opt-in
- **Sharing:** approved processor only
- **Default retention idea (NOT legal conclusion):** separately documented, revocable


## 4. DPDP control-by-control rollout
**Notice** clear, accessible, standalone explanation of personal data and purpose before consent; multilingual/localized variants and link to rights/contact. **Consent** freely given, specific, informed, unambiguous affirmative action; separate from T&C and granular by mode/quiz, AI, notifications, public trait sharing; withdrawal as easy as giving consent. **Purpose limitation** no resale of quiz answers to advertisers or covert inference. **Data minimization** no mandatory religion/caste/sexuality details or biometric scans for friendship, no hidden classifier. **Accuracy and rights** allow editing and complaint handling; score recomputation when changed. **Security** measures per Rule 6, including encryption, access, monitoring, backups, vendor contracts and appropriate logs. **Breach** draft ready-made notices and decision tree for Rule 7 from its effective date: notify affected individuals/Board without delay, detailed Board information within 72h unless extended; CERT-In separately as applicable. **Children** begin 18+; consider proportionate age assurance and a response procedure when minor detected; if minors allowed later, parent-consent and restrictions substantially increase complexity. **Retention** document schedules and apply applicable Rule 8 statutory retention/erasure provisions, with potential lawful holds and back-up limits. **International processors** keep data maps and contract protections; legal restrictions and transfers are jurisdiction- and future-notification-sensitive.

## 5. Sensitive inference: special design rule
User's concept includes indirect assessment to predict intimate matters. Do **not** covertly infer sexual orientation, mental health, religion or comparable intimate categories from innocuous answers. Assessment data can be sensitive even if the final UI omits the inferred label. For any optional disclosed characteristic, require clear consent, justifiable necessity, use limitation and fairness review; never reveal to family, group admins or other members without explicit setting. An AI-generated "brain twin" is a separate processing purpose with elevated disclosure/retention/impersonation requirements.

## 6. Intermediary / user-generated content duties
Counsel must classify whether/how Rule 3 obligations apply, establish grievance officer details where required, operational routes for unlawful-content orders and notices, complaint SLAs by category under amended law, evidence preservation only as permitted/required, user policies, periodic updates and appeals. Internal proposed targets deliberately stricter than needed until confirmed: **acknowledge grievances within 24h**, general resolution **≤7 days**, specialized takedown **≤36h**, intimate-image/impersonation **≤2h when provision applies**. These are contingent category timelines; do not promise all tickets a two-hour resolution. Escalate severe child safety and imminent threats urgently irrespective of user plan.

## 7. Identity and matrimonial responsibility
Kithra is NOT a licensed match guarantee, a clinical diagnosis provider or a marriage registrar. State plainly that members' claims are self-reported unless independently verified. Do not indiscriminately demand Aadhaar or store government ID scans. Marriage eligibility (age, current marital status, individual consent, permitted age/legal limits, prohibited relationships) requires carefully worded declarations and potentially documentary review with consent and counsel, never an algorithmic guarantee. Do not allow family profiles to control adults without the adult's authorization, or publish protected characteristics in discriminatory hierarchies.

## 8. Payments and consumer rights
Show complete price, GST/taxes and renewal terms before payment; explicit auto-renew consent where applicable; easily accessible cancellation and refund policy; no dark patterns (prechecked renewal/hidden terms); actual payment processor handles cards/UPI; invoices and dispute records; respond to grievances and charges fairly. Merchant/provider policies and RBI card/UPI e-mandate requirements can change; confirm with provider before publishing pricing.

## 9. Privacy risk scoring (illustrative)

**Comparison / requirement matrix — accessible record view:**

**Record 1: Raw quiz response leak**

- **Risk:** Raw quiz response leak
- **Impact:** Critical
- **Likelihood if uncontrolled:** high in insecure prototype
- **Mitigation and owner:** encrypt, access checks, vault, security lead

**Record 2: Admin insider profiling**

- **Risk:** Admin insider profiling
- **Impact:** Critical
- **Likelihood if uncontrolled:** medium
- **Mitigation and owner:** per-case access, dual approval, audit

**Record 3: Stalking through discovery**

- **Risk:** Stalking through discovery
- **Impact:** High
- **Likelihood if uncontrolled:** medium/high
- **Mitigation and owner:** coarse location, blocking, ratelimits, safety owner

**Record 4: Involuntary orientation inference**

- **Risk:** Involuntary orientation inference
- **Impact:** Critical
- **Likelihood if uncontrolled:** high if designed
- **Mitigation and owner:** ban hidden inference, consent review, privacy lead

**Record 5: Matrimony coercion/fraud**

- **Risk:** Matrimony coercion/fraud
- **Impact:** High
- **Likelihood if uncontrolled:** medium
- **Mitigation and owner:** separate mode, reporting, warnings, human moderation

**Record 6: Fake user verification claims**

- **Risk:** Fake user verification claims
- **Impact:** High
- **Likelihood if uncontrolled:** high in prototype
- **Mitigation and owner:** remove false UI badges, truthful statements

**Record 7: Payment/renewal complaints**

- **Risk:** Payment/renewal complaints
- **Impact:** Medium
- **Likelihood if uncontrolled:** medium
- **Mitigation and owner:** webhooks/reconciliation, visible cancellation


## 10. Launch compliance checklist with evidence
- [ ] Legal entity name, registered address, official grievance/business contacts and principal controller established.
- [ ] Counsel-signed data map, current-law applicability, DPDP launch-gap register, vendor contracts and international transfer review.
- [ ] Per-mode/quiz consent versioning and logs tested; default most-private settings.
- [ ] Privacy/T&C/community/payment/refund/cookie notices reviewed, versions recorded and localized.
- [ ] Data export, correction, withdrawal, deletion and retention-hold workflows function end-to-end.
- [ ] No hidden trait inference, fabricated claims, unauthorized media publication or unmoderated public stranger chat.
- [ ] Moderator staff availability, emergency escalation, grievance processes and appeal paths staffed/tested.
- [ ] Threat model, pentest, incident tabletop, backups and recovery drills completed.
- [ ] Payment gateway and e-mandate technical/legal verification; actual cancellation and invoices tested.
- [ ] All vendor and cloud free-tier limits reviewed for release date; alert budget and failure responses configured.

## 11. Counsel decision log to complete
C01 intermediary status and significant threshold; C02 scope of 2011 SPDI rules and DPDP transition; C03 consent design for assessment/matching modes; C04 retention + compelled disclosure policy; C05 moderation response duties; C06 cross-border data transfer/cloud hosting; C07 matrimony representation and minimum age checks; C08 tax/invoice and renewals; C09 synthetic-avatar handling under 2026 IT Rules; C10 user-generated media safety and law-enforcement protocol. Each requires owner, date, written opinion and revised product behavior.



---



# Draft Legal and User-Facing Policies — Counsel Review Mandatory

**Templates, not production-ready legal advice.** These drafts deliberately contain `[LEGAL_ENTITY]`, `[REGISTERED_ADDRESS]`, `[CONTACT_EMAIL]`, `[GRIEVANCE_EMAIL]`, `[EFFECTIVE_DATE]`, `[AGE_POLICY]`, `[RETENTION_SCHEDULE]`, `[PRIVACY_PROCESSORS]`, `[REFUND_WINDOW]`, `[APPLICABLE_FORUM]` etc. Fill only with verified operational facts after counsel review. They do not shield Kithra from law, negligent conduct or unfair terms. Every notice must match the actual product and effective Indian requirements.

---

## A. Terms of Service — draft
**1. Contracting party and service.** These Terms govern use of Kithra operated by `[LEGAL_ENTITY]`, `[REGISTERED_ADDRESS]`, `[CONTACT_EMAIL]`. Kithra provides optional friendship, dating and matrimony discovery, questionnaires, introductions, communities and communications. Kithra does **not** promise a match, friendship, romance, marriage or psychological accuracy. Our index scores are descriptive tools, not clinical assessment or guarantees.

**2. Eligibility.** You must be at least `[AGE_POLICY: initially 18 years]` and legally capable of agreement. You must provide accurate and current personal information, keep credentials private, and not use an account for another individual without permission. Users pursuing matrimony are responsible for any additional marriage-law eligibility and accurate self-disclosure; Kithra's self-report is not official verification.

**3. Separate intent modes.** Friendship, Dating and Matrimony are voluntary and separate. Activation of one does not automatically enroll you in another. You can pause or close a mode, restrict who sees each profile and withdraw optional questionnaire sharing according to the Privacy Notice.

**4. Assessments and model limits.** Questionnaires may be incomplete, culturally imperfect or updated. Scores reflect disclosed model rules and measured responses at the relevant time. They cannot reconstruct a brain or prove the future quality of a relationship. You may decline optional questions and assess match recommendations with independent judgment.

**5. Conduct.** You must not impersonate others, harass, stalk, threaten, cheat, coerce, solicit illegal payments, publish nonconsensual images, target minors, or circumvent blocks or restrictions. In friendship mode respect platonic boundaries; dating/matrimony interactions require mutual intent and respect. Kithra may restrict access, remove content, investigate reports and cooperate with authorities consistent with law and fair procedure.

**6. User content and license.** You retain your rights in your uploaded original content. You provide a nonexclusive, purpose-limited license necessary to host and display content to audiences you select, operate messaging and enforce community safety. This does not authorize selling your private quiz answers or training third-party AI models without separate consent.

**7. Paid features.** Prices and applicable taxes are displayed before checkout. Digital entitlements, renewal dates, cancellation, refunds, errors and disputes are explained in the Billing Policy. Safety, blocking, reports, core data rights and account deletion are never paywalled. Refund rights granted by law cannot be waived through these Terms.

**8. Communication and meeting safety.** Users are strangers and can misrepresent themselves. Exercise judgment, meet initially in public, never transfer money to an unknown person, and use in-product reports for abuse. Kithra does not conduct comprehensive criminal/background checks unless a specific feature truthfully says otherwise.

**9. Suspension, appeals, termination.** We may restrict an account for credible abuse or legal compliance while offering a documented review/appeal path where appropriate. You may delete your account; data handling follows the Privacy Notice and legally necessary retention.

**10. Liability and disputes.** To the extent legally permissible, Kithra does not guarantee outcomes or uninterrupted availability. Nothing here excludes liability, consumer protection rights or remedies that applicable law prohibits limiting. Dispute forum, governing law, contact and required processes: `[COUNSEL_APPROVED_TERMS]`.

**11. Changes.** Notify users of material changes in accessible language; secure new consent when required for a materially new processing purpose. **Effective date:** `[EFFECTIVE_DATE]`.

---

## B. Privacy Notice — draft
**Controller/fiduciary:** `[LEGAL_ENTITY, CONTACT, PRIVACY_OFFICER]`. **What we collect:** identity email/provider subject, chosen mode and persona information, voluntarily submitted quiz answers, derived trait descriptors, voluntary connection requests, messages, groups, abuse reports, operational security events, payment references and preferences. We do **not** need exact home addresses, government IDs or biometric scans for normal signup.

**Purposes and grounds:** (1) account, identity and service delivery; (2) your chosen mode's discovery and mutual messaging; (3) optional questionnaire scoring and explanations; (4) safety, fraud prevention, complaints and legal compliance; (5) optional notifications/marketing where separately selected; (6) optional AI simulation only under a separate, independently explained opt-in not enabled by default. List precise applicable legal bases when counsel finalizes this Notice.

**Mode separation:** Each friendship, dating and matrimony persona has separate visibility and opt-in. Questionnaire raw answers are private by default; other members see only expressly shareable trait summaries or public profile fields. No data sale or targeted ad use of intimate questionnaire records.

**Sensitive inferences:** Kithra does not covertly infer sexual orientation, caste, religion, health or similar personal attributes from ordinary quiz answers. If any optional disclosed sensitive category becomes relevant to a clearly selected mode, it will have explicit controls and separate review.

**Who may receive data:** authorized service processors `[PRIVACY_PROCESSORS]` such as authentication, hosting, email, payments and security; your opted-in recipients; lawful authorities if valid and necessary. List countries/data locations/transfer safeguards accurately—do not state "India-only" unless technically verified.

**Security and retention:** Describe actual access controls, encryption, audit logs, incident handling, backups and retention schedule `[RETENTION_SCHEDULE]`. A badge saying "end-to-end encrypted" must only appear if actual verified E2EE is deployed; otherwise explain transport and storage protections truthfully.

**Rights and control:** contact `[PRIVACY_EMAIL]` to request access, correction, consent withdrawal, export, erasure and grievance resolution as applicable. Disclose retention exceptions, processor effects and required identification/reauthentication. User can pause discovery and independently remove each mode. Explain response timelines only after counsel confirms obligations.

**Breach notifications:** Provide legally required notices if a personal data breach occurs. **Policy changes:** timestamp, version history and material-change notice. **Contact:** `[PRIVACY_EMAIL]` and grievance information.

---

## C. Community Standards & Safety Policy — draft
**Values:** dignity, autonomy, truthful self-presentation and mutual consent. **Prohibited:** bullying, sexual pressure, hate, misrepresentation, trafficking or sex-for-money solicitation, financial scams, nonconsensual sexual imagery, doxxing, threats, impersonation, child exploitation, circumventing blocks, spam, attempts to harvest quiz/identity data and coercion into marriage. **Mode etiquette:** no unsolicited romance in friendship mode after a boundary is expressed; no matrimonial family pressure or dowry promotion; clear consent in dating. **Reporting:** profile, message, group and help-center paths; emergency risks directed to local authorities. **Actions:** warning, content removal, limited reach, suspension, permanent ban, authority referral when legally required; proportionality, documentation and appeals. **Enforcement:** human review for high-severity cases; automated classifiers assist but never override due process for ambiguous ordinary disagreements.

---

## D. Consent text inventory — interface drafts
**Mode selection:** "I want to participate in [Friendship/Dating/Matrimony] discovery. I understand that people in this mode can see the profile fields I make visible." Each mode requires its own checkbox/toggle, unchecked initially.

**Quiz:** "I agree to the processing of my selected quiz answers to generate a personal trait summary and matching recommendations. Other users will not see my raw answers. I can stop participating or withdraw this optional consent in Settings. See details." Unchecked initially; show theme and purpose.

**Expanded sharing:** "Show these selected trait summaries to eligible connections in [mode]." Off until opted in. **AI twin (future):** "Allow Kithra to create an optional simulated conversation profile using the selected data shown here. This is not a replica of my mind. I can deactivate and request deletion." Off and independently consented.

**Transactional email:** service required; **marketing:** optional and independently controlled. **Activity indicators/read receipts:** optional settings with clear reciprocal expectation.

---

## E. Billing, Refund & Cancellation Policy — draft
Subscriptions provide only the features listed at checkout. Before authorization show gross amount, taxable portion/GST treatment, period, renewal status, grace policy, renewal reminder policy, cancellation path and customer support contact. Users may cancel renewal in Account > Billing without contacting support; cancellation normally stops future billing while granting already purchased entitlement until the paid period ends unless an exception applies. Refund requests use `[REFUND_WINDOW]`/`[GRIEVANCE_EMAIL]`, the actual payment provider workflow and applicable legal consumer protections. Refund timing depends on payment rail; avoid guaranteeing instant reversal. Price changes require notice and lawful authorization. Downgrade cannot remove essential safety tools or prevent export/deletion. Auto-renewal must never be hidden, prechecked or misrepresented. **Finalized by counsel and payment gateway before accepting funds.**

---

## F. Data Retention Schedule and Deletion Policy — template
Each dataset entry must specify owner, collection reason, lawful basis, active retention, inactivity trigger, backup expiry, approved legal hold, processor deletion, encrypted key erasure and verification artifact. Suggested implementation lifecycle: user request → mark `deletion_pending` and revoke discovery/session → prevent new writes → allow lawful short cancellation window if transparent → purge active D1/R2/DO and caches → queue linked processor instructions → retain only narrowly legally required case/payment/security records → document completion and backup expiry. Do not promise literal instantaneous erasure from immutable disaster backups.

---

## G. Grievance and Appeals Policy — draft
`[GRIEVANCE_OFFICER_NAME, ADDRESS, EMAIL, WORKING_HOURS]`. Every report receives case ID and acknowledgement; user receives category-appropriate status without disclosing private investigation materials. Team prioritizes imminent harm, sexualized harassment/impersonation and legal takedowns; deadlines follow applicable IT Rules classification and current amendment. Appeals are reviewed by someone other than original decision maker when feasible. Government/legal requests require validation, minimization and documentation, except secrecy requirements. Kithra cannot promise a 24/7 human helpline unless one operates.

---

## H. Cookie / Tracking Notice — draft
List strictly necessary authentication/security cookies separately from optional analytics/marketing cookies. No tracking embedded in quiz answers by default. Provide preference controls appropriate to current law and chosen analytics SDK. Document retention, provider and opt-out behavior; honor browser privacy protections where supported.

## Legal sign-off sheet (fill before production)
`document name | version | last verified law | owner | lawyer name | lawyer approval date | translated variants | public URL | product control tests | change-monitor cadence`.



---

