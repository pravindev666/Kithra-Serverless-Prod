# AI-RD — Optional Digital Personality Twin: Research Specification, Safety & Evaluation

**Status:** FUTURE RESEARCH; disabled by default. This document intentionally does not claim Kithra will copy a person's brain, create a sentient replica, infer intimate identities secretly, or reliably predict marriage or friendship outcomes. It defines a possible *consent-based model of the user's explicitly disclosed communication preferences* and a set of gating requirements before even a small controlled experiment.

## 1. What is actually feasible?
- **Persona summary:** a user-reviewed, editable representation of self-described preferences and questionnaire-based bounded traits.
- **AI simulation:** an LLM configured to respond as a *hypothetical agent* according to that summary. It may generate plausible dialogue, but it is **not** the user and does not reliably reproduce future beliefs, emotions, actions or consent.
- **Two-agent rehearsal:** opted-in agents can simulate introductory scenarios to offer conversation-starting topics or areas for discussion; this is **not a real human chemistry test**, cannot replace actual mutual consent, and cannot be used as factual proof of compatibility.
- **Behavior-over-time improvement:** only consented, user-confirmed feedback updates the summary; avoid covert scraping of private messages, journals or off-platform data.

## 2. Separate opt-in and revocation
Consent step clearly states source datasets (selected quiz dimensions, written self-description, optional specifically selected past messages if ever supported), intended outputs, third-party processors, retention, deletion, impersonation limits, model fallibility, costs and users' ability to preview/edit/revoke. Opt-in is **per person**, per source category and per mode; two agents may not communicate unless both owners opted in to that pairing/use. Revocation immediately stops new generations, marks prior simulation unshareable and launches documented deletion cleanup where lawful.

## 3. Data processing pipeline
```
Consent registry → minimal approved trait summary → user review/approval
→ policy scrubber and mode scoping → LLM prompt template → guarded simulation
→ clear "AI-generated hypothetical" label → user correction/approval
→ optional human-human introduction only after fresh mutual consent
```
Never give a model unrestricted access to D1, private messages, admin tooling or payments. No personal address, government ID, medical history, raw sexual orientation inference or trauma narrative in the prompt. Persona ID and pseudonym separate from account identifiers. Third-party inference endpoints receive the minimum authorized, redacted information.

## 4. Agent representation (example, not clinical)
`agent_version`, `user_id`, `mode`, `user_approved_summary`, `trait_model_version`, `declared_interests`, `communication_preferences`, `unshareable_boundaries`, `prompt_template_version`, `consent_id`, `expires_at`, `provider`, `output_disclaimer`, `reviewed_at`, `revoked_at`. Do not store secret prompts as proof of safety; actual policy enforcement lives in service code.

## 5. Why simulation should not score human relationships directly
Agents may amplify stereotypes, hallucinate confidence, answer in ways the underlying user never would, and optimize for pleasing dialogue. Simulations across agents have correlated biases and can make incompatible people look compatible. If used experimentally, treat outputs as **conversation suggestions**, not a component of 100%/90% match score without independent human-outcome validation. Allow both participants to reject simulated summaries without penalty.

## 6. Technical evaluation before enabling
- Consent and processor agreement verified.
- Privacy red-team: prompt injection, secrets exfiltration, cross-user leak, jailbreaking, identity spoofing.
- Test mismatched/missing questionnaire coverage and adversarial prompt manipulation.
- Human validation: does each owner accurately endorse what the model says? Report confidence/uncertainty.
- Comparative outcome trial: optional agent interaction vs no agent, measuring safety and **actual** continued contact, not simulated applause.
- Cost caps per invocation, token budgets, strict timeout, content moderation, model version pinning and trace IDs with **no raw sensitive content in logs**.
- Affected-person deletion and processor purge contract tested before production.
- Regulatory classification of synthetic output under applicable 2026 IT intermediary rules and consumer protection reviewed by counsel; AI outputs clearly labeled.

## 7. Product UX for future agent mode
Dedicated "Explore your preferences with AI" workspace, explicit account of what is and is not used, data preview, simulated transcript with persistent **AI simulation — not a real conversation** watermark, user corrections, privacy pause, delete-agent button, processor info and cost/use notices. No "your brain was replicated" copy, no making commitments or sending actual human messages without direct fresh approval.

## 8. Release gate
Separate security review, psychological-accuracy claims review, measurable human benefit, positive informed consent comprehension test, vendor contract/legal approval, acceptable cost model and staffed abuse response. Until then show no AI Twin button or waitlist that falsely implies functioning brain simulation.
