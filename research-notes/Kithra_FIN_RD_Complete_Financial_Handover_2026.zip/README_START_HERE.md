# Kithra FIN-RD — Start Here

**Created:** 1 November 2026

This handover is the finance addendum to the existing **Kithra complete full-product dual-deployment specification**. It supersedes previous AI cost scenarios: **the matching engine is deterministic and relational; there are no AI twins, LLM, embeddings, token charges or inference services in the approved scope.**

## Files to give the developer / finance adviser

1. `Kithra_FIN_RD_Financial_Requirements_and_Sustainability.docx` — primary handover specification for product, backend/operations, finance and compliance.
2. `Kithra_FIN_RD_Financial_Requirements_and_Sustainability.md` — copyable source document suitable for technical version control.
3. `Kithra_5_Year_Editable_Financial_Model.xlsx` — 10 worksheets, formulas and source links.

## How to use the workbook

1. Open `Dashboard`. Choose **Cloudflare / Single VPS / Multi Server** from the yellow `B5` deployment selector.
2. Change BLUE values on the `Assumptions` sheet. Check that tier and term percentages sum to **100%** (row 75).
3. Revise `Plans` prices before publishing any customer offer; all shown prices are **unvalidated proposals**.
4. Inspect `Infra Compare` for 100, 1,000, 5,000, 10,000 and 100,000 registered users. A single VPS **is not viable beyond the marked workload gate**, regardless of the low displayed base bill.
5. Inspect `Monthly 60`, `Annual 5`, `Scale Cases`, `Salary Sensitivity` and `Break Even`. External fees and assumptions can change; see `Sources`.

## Financial caution

- INR prices are assumed GST-inclusive for illustrative results; actual GST treatment and recovery depend on professional advice.
- Revenue is normalized monthly, including quarterly/annual subscriptions. The cash balance is a **forecast proxy** and does not implement actual payment-date cohorts, deferred revenue, bank settlements, taxes payable or full statutory statements.
- Default 5-year results are a **hypothetical loss scenario**, not observed Kithra traction, actual unpaid debts, or an instruction to spend that amount.
- Vendor cost numbers are only sourced wherever explicitly marked; salary/marketing/staff/legal/per-user infrastructure usage are editable founder assumptions.
- No one is guaranteed 90–100% psychological compatibility simply because their deterministic questionnaire results match.

## Developer acceptance

Instrument each component for invoice-level costs and traceability, pass Cloudflare+Docker parity tests, implement billing ledger and consent/mode controls, and provide an accountant-approved bank-cash forecast before launch. Reserve moderators and incident support rather than assuming hosting cost is the entire spend.
