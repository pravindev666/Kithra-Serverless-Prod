# KITHRA
## FIN-RD — Financial Requirements, Cost Architecture & Business Sustainability

**Version:** 1.0 — 1 November 2026  
**Audience:** Founder, engineering lead, finance/accounting adviser, potential investors, product and trust/safety leads  
**Status:** Planning specification and decision-support model; not an investment forecast, statutory account, tax opinion or supplier quotation  
**Paired artifact:** `Kithra_5_Year_Editable_Financial_Model.xlsx` (formula-driven, ten worksheets)

> **Controlling clarification:** Kithra is a complete Friendship, Dating and Matrimony platform. Personality assessments and compatibility matching use **deterministic, versioned scoring rules and database relationships**. **No AI inference, no AI twins, no LLM, no embedding/vector infrastructure, and no fee for AI** is included in the design or financial model. A possible future ability to assemble a digital representation of users does not create an approved AI feature or budget. Any later such addition requires an independent privacy impact assessment, legal clearance, science validation and financial change request.

---

# 1. Executive investment and operating conclusion

The current Kithra product plan is materially larger than a standard website: identity, three separately consented relationship modes, 100-question assessment sets, deterministic matching, mutual messages, images, community/groups, reporting, safety intervention, staff RBAC, payments, backups, account/data-rights operations, and tested deployment on both Cloudflare and Docker-based servers. **The product's continuing cost is dominated by people, trust and safety, development, distribution, and compliance—not raw API hosting.**

The attached financial workbook provides:

1. 60 months of operating costs, registered members, MAU, payers, subscription revenue, taxation assumptions, profit and normalized cash runway.
2. 5-year rollups, five user-scale cases (100 / 1,000 / 5,000 / 10,000 / 100,000 registrations), pessimistic/base/optimistic conversion sensitivities, and Cloudflare / single VPS / multi-server comparisons.
3. Four founder-pay choices (₹0 / ₹25,000 / ₹50,000 / ₹1,00,000 monthly), linked costs for moderation, support, legal/compliance, security, marketing, staff and development.
4. Source-registered external prices separated from unverified internal planning allowances.
5. Pricing tiers and term mix connected to gross and after-GST economics, gateway charges, refunds and a deliberately limited break-even estimator.

**Default editable assumptions** (not customer traction): MAU = 30% of registered accounts; paying conversion = 3% of MAU; founder salary ₹25,000/month; fractional employee 0.5 FTE at ₹35,000 per FTE/month plus 15% burden; development/maintenance retainer ₹40,000/month; initial complete-product build allowance ₹25,00,000; starting cash ₹5,00,000; U.S. dollar conversion ₹94.9125. The blended subscriber gross monthly equivalent is about **₹215.45**, derived from a hypothetical subscription-tier and period mix. Plans are assumed GST-inclusive and their supply is modeled provisionally at 18% GST; a qualified Indian accountant must confirm tax classification, registration, input credits and collection rules.

**Illustrative implications at these assumptions:**

| Scale (registered) | Monthly active (30%) | Paying (3% MAU) | Monthly net subscription revenue after illustrated refunds/GST | Estimated Cloudflare vendor expense | Operating conclusion |
|---:|---:|---:|---:|---:|---|
| 100 | 30 | 1 | ~₹179 | ~₹560 | Large loss after staff, compliance and salaries |
| 1,000 | 300 | 9 | ~₹1,610 | ~₹560 | Large loss |
| 5,000 | 1,500 | 45 | ~₹8,052 | ~₹577 | Large loss |
| 10,000 | 3,000 | 90 | ~₹16,104 | ~₹610 | Large loss |
| 100,000 | 30,000 | 900 | ~₹1,61,037 | ~₹3,906 | Still potentially loss-making at the staffing assumptions |

Cloudflare totals above include an illustrative 18% tax allowance on international infrastructure invoices, and use workload estimates that **must** be replaced with runtime metrics. They do not prove capacity, uptime, India-only data residency or compliance.

**The model's simplified break-even indicator is approximately 31,500 monthly active members / 105,000 registered members** under its present contribution margin and fixed-cost assumptions, before properly re-stepping staff, anti-fraud operations and platform complexity at that scale. **This is not an investment recommendation or reliable growth forecast.**

# 2. Scope, traceability and financial rules

## 2.1 Products inside the same business

**FRIENDSHIP:** opt-in friendship profile, interest/value assessments, Mirror (measured similarity), Counterpoint (difference), Mosaic Fit (specified complementary differences), discovery, mutual request/accept, conversations, circles, moderated activities and abuse controls.

**DATING:** separate opt-in consent, dating-specific intent, eligibility, discovery safeguards, communication, appropriate filters and subscription entitlements. No friendship-only profile is exposed merely because an account has a paid plan.

**MATRIMONY:** separate adult consent, serious-intent workflows, extended questionnaire themes, controlled introductions, verification choices, fraud controls and support operations. No outcome guarantees.

**PLATFORM-WIDE:** 100-question themed set versioning and placeholders; published question bank administration, anti-abuse sampling/shuffling and deterministic scoring; identity and settings; group roles, media, reporting, appeals, payment and refund ledgers, consent/rights, analytics, backups, security controls, staff RBAC and auditable operations.

**Two deployable targets:** Cloudflare Workers Static Assets/Pages, Workers/Hono, D1, Durable Objects, Queues, R2, Firebase identity and payment gateway; and Docker Compose/Hono Node, PostgreSQL, Redis, WebSockets, S3-compatible storage, Caddy/Nginx and Jenkins. Production should have one write-source-of-truth at a time. Maintaining **both deployment targets** adds testing and operations costs even if only one is live.

## 2.2 Finance non-negotiables

- **FIN-001 — no fictitious AI cost:** AI expenses must be zero unless a later formally authorized capability is actually implemented. Deterministic scoring can be benchmarked as SQL + CPU time with explainable, versioned rules.
- **FIN-002 — protect safety:** blocking, reporting, privacy controls, account/consent rights where applicable, basic mutually accepted messaging and necessary complaints must not depend on payment.
- **FIN-003 — separate registered, active, paying:** all forecasts must distinguish registration base, 30-day active users, paying users, active paid subscribers and successful real connections. A registration is not recurring revenue.
- **FIN-004 — separate expenses:** Cloudflare bills ≠ full cost of business; operational salaries, partner tools, moderation, legal and taxes must be visible.
- **FIN-005 — dual-deployment equivalence:** a cheaper deployment is not accepted unless functional tests, trust/safety tools, data protection, backup/restore and recovery capability pass in both environments.
- **FIN-006 — currency and invoice controls:** USD infrastructure and INR subscriptions require a dated foreign-exchange assumption, invoiced tax treatment and reconciliation.
- **FIN-007 — forecast controls:** user-editable drivers, explicit owner signoff, update date, source URL, version number and variance tracking are mandatory.
- **FIN-008 — billing integrity:** gross customer consideration, GST collected, refunds, gateway charges, net recognized revenue, credit/deferred-revenue balances and bank cash movements must not be conflated in production finance records.
- **FIN-009 — founder salary is cost:** founder compensation, tax on salary, reimbursements and profit distributions are separate concepts. An unpaid founder must still estimate opportunity cost.
- **FIN-010 — spend guardrails:** monthly vendor budgets, metering, alert thresholds and emergency nonessential-feature throttles must be operational. Never throttle urgent safety, complaint or rights workflows purely to prevent overages.

# 3. Source-backed vendor price schedule (as checked 1 November 2026)

| Component | Vendor rate | Model treatment | Important limit |
|---|---|---|---|
| Cloudflare Workers Paid | $5/month; 10 million requests + 30 million CPU milliseconds monthly; $0.30 per extra million requests, $0.02 per extra million CPU ms | $5 shared Workers base plus marginal requests/CPU | Static asset requests can be free; do not count them as dynamic API calls. Verify actual CPU per route. |
| D1 | Paid first 25 billion rows read/month, 50 million written/month and 5 GB stored included; subsequent $0.001/million reads, $1/million writes, $0.75/GB-month | Read/written/GB terms; most small workloads below paid thresholds | Free per-db maximum 500 MB, Paid per-db maximum 10 GB as of 30 Oct 2026; sharding or DB migration may be required. |
| Cloudflare R2 Standard | 10 GB-month storage, 1 million Class A and 10 million Class B operations free; excess $0.015/GB-month, $4.50/M A, $0.36/M B, no R2 egress fee | Photos/media storage + read/write operations | Media processing, scans, transformations and external transfer routes may have additional costs. |
| Durable Objects | Workers Paid includes 1 million requests and 400,000 GB-seconds/month; $0.15/M extra requests and $12.50/M extra GB-seconds | Messaging events and active-time estimate | Hibernation, WebSocket message patterns and object data costs matter; idle time must be measured. |
| Cloudflare Queues | Workers Paid includes 1 million standard operations/month; $0.40/M extra | Per-MAU queue ops | Write + read + delete can each be billed; large message payload rounds to 64 KB units. |
| Firebase Authentication | Email/social and Identity Platform no-cost usage depends on configuration; phone SMS billed by country | Email/Google at assumed zero marginal cost within allowance; SMS off by default | Phone/KYC provider pricing and bill activation must be separately confirmed. |
| DigitalOcean VPS | 4GB $24/month, 8GB $48/month on basic shared CPU examples | $48 main host in reference setup | Running full PostgreSQL/Redis/API/Jenkins together is not an HA or security target; Jenkins modeled on separate $12 host. |
| DigitalOcean managed PostgreSQL | Single-node plans from $15; HA configuration quoted by provider | $60/month **illustrative floor**, two $30 units | Plans and standby offerings changed October/November 2026; re-quote actual eligible HA configuration. |
| Razorpay gateway | Typical 2% fee + GST; subscription add-on page advertises 0.5% promotional add-on | 2.5% gross + illustrative 18% fee GST | Varies with settlement, channel, merchant, billing type, offers and signed contract; not an approved quote. |
| USD/INR | 31 Oct 2026 observed reference: USD 1 = INR 94.9125 | Editable USD conversion | Not a guaranteed future conversion or bank settlement rate. |

**Sources and URLs:** official Cloudflare Workers, D1, R2, DO and Queues pricing and limits; DigitalOcean published Droplet and managed PostgreSQL pricing; Firebase pricing; Razorpay Gateway and Subscription pricing; CBIC GST guidance. Full URLs appear in Section 18 and in workbook `Sources`/`Assumptions` sheets.

**Tax modeling boundary:** The 18% GST assumption is aligned with CBIC's general IT services guidance but does not itself establish how a particular Kithra membership is classified, registration timing, cross-border sale, credits or payment-provider service treatment. Every tax or invoice change requires accountant signoff.

# 4. Deterministic matching — engineering cost drivers

Kithra matches users through **stored, consented relational data**:

1. User completes 100-item versioned question sets by theme. Version and randomized order are persisted so answers can be verified and rescored reproducibly.
2. Validation normalizes response scales and eligibility constraints. Mandatory relationship-mode, block, age, consent, preference and visibility predicates are evaluated first.
3. Server computes rule-driven multidimensional indexes and band assignments. Mirror, Counterpoint and Mosaic Fit are defined mathematically with weight/rule version and explanation metadata. They are **not probabilities of lifelong success**.
4. Candidate retrieval uses indexed query predicates, possibly precomputed compatible candidate sets, materialized/ranked summaries or batch jobs. Caches and relationships are invalidated on profile/consent/answer change.
5. The match engine can be implemented on D1 for manageable per-query workloads and on PostgreSQL with equivalent domain rules. Large cohorts must be benchmarked; uncontrolled all-pairs comparisons have quadratic growth and are not affordable at scale.

**Cost model included:** API calls per MAU/month, CPU ms per call, D1 rows read/write, SQL storage per registered user, R2 GB/media operations, Durable Object messages/GB-seconds, and queue operations. **Explicitly excluded:** LLM tokens, prompt embeddings, vector similarity compute, agents, AI twins and GPU serving.

### Assessment data budget

At 12 themes × two 100-question sets, the product may store **2,400 question definitions**, but each user will not necessarily answer every set. Questionnaire text is shared/versioned content. Answer records, attempt history, security events, matching explanations, consent events, fraud flags and audit logs may eventually dominate relational storage. The workbook's 300 KB relational data per registered account is a placeholder, not a guarantee. A large answer archive must have limits and justified retention; sensitive raw answers must be minimized and access-controlled.

### Media budget

The workbook assumes 4 MB of R2 media per registered account. Ten compressed images × 300 KB already approach 3 MB before thumbnails, versions or moderation evidence. Video uploads, frequent re-uploads, image processing and preservation holds change the economics sharply. Finance must require mode-specific upload quotas and measured storage curves; never promise unlimited video or storage on the basis of R2's low base storage rate.

# 5. The three hosting models

## A. Cloudflare serverless

**Service map:** Cloudflare Workers Static Assets or Pages, Hono Worker API, D1, R2 Standard private media, Durable Objects for real-time coordination, Queues for jobs, Cron Triggers, Firebase Auth, Razorpay and external email provider. No persistent conventional Linux process is assumed.

**Cost formula summary** (USD converted to INR with FX and configurable invoice tax factor):

- Workers = $5 + max(0, dynamic requests − 10 million)/million × $0.30 + max(0, CPU ms − 30 million)/million × $0.02.
- D1 = max(0, GB − 5) × $0.75 + max(0, rows read − 25 billion)/million × $0.001 + max(0, rows written − 50 million)/million × $1.
- R2 Standard = max(0, GB − 10) × $0.015 + max(0, Class A − 1 million)/million × $4.50 + max(0, Class B − 10 million)/million × $0.36.
- Durable Objects = max(0, event requests − 1 million)/million × $0.15 + max(0, GB-seconds − 400,000)/million × $12.50.
- Queues = max(0, standard operations − 1 million)/million × $0.40.

**Operational risks:** D1 per-database 10GB Paid hard cap; query contention due to single-threaded database; costs from abuse, expensive queries or unhibernated Durable Objects; deployment/organization permissions; account termination dependence; backup integrity and restore drills; insufficient geographic residency assurances; gateway, SMS, email and moderation spend outside Cloudflare.

## B. Docker Compose on one VPS

**Reference estimate:** one 8GB VM $48/month, separate CI runner $12/month, backup/storage allowance $10/month, all multiplied by FX and invoice-tax allowance (~₹7,840/month using current inputs). Domain, certificates, separate offsite backup, vendor R2, monitoring staff, support, payroll and paid DB management are additional.

**Container services:** frontend static files behind Caddy or Nginx; Hono/Node API; local PostgreSQL; Redis; background jobs; security sidecars if required; externally hosted R2. Jenkins runs on a **separate**, non-public CI host. Database, Redis and Jenkins ports must not be exposed publicly.

**Not a high-availability architecture:** downtime and data corruption can affect everyone. The model marks a 3,000-MAU **planning ceiling**, but even that requires real load tests. At higher workloads, the cheap single-VPS figure is *not viable*, irrespective of its displayed monthly cost. Founder on-call time and upgrades are additional economic costs.

## C. Multi-server Docker deployment

**Reference topology:** at least two app nodes, managed/highly available PostgreSQL subject to plan quote, Redis for cache and messaging coordination, load balancer, separate Jenkins runner, monitoring and offsite backups. The default cost floor is $232/month (~₹25,983 after editable FX/tax allowance) for two application nodes and other named components. At 100,000 registrations/30,000 MAU, the **unvalidated** planning assumption scales app nodes to eight; illustrative invoice becomes about ₹58,238/month.

**Operational risks:** replication lag, private network costs, TLS/certificate renewals, PostgreSQL PITR, schema migration downtime, queues, application session/reconnect semantics, observability retention, deployment and rollback labor, and active incident response. An HA label does not remove the need to test restores and failovers.

## D. Portability expense reserve

One source repository and domain package may be shared, but the two deployments need separately maintained:

- SQLite/D1 and PostgreSQL migrations + schema contract tests.
- Durable Objects and Node/WebSocket+Redis real-time adapters, persistence/acknowledgment parity.
- Queue/Cron Workers and Redis/BullMQ job adapters, retries and idempotency.
- S3-compatible object storage and R2 signed URL/media policies.
- Deployment secret management, metrics, backups, restore and logging.
- Jenkins CI runs to build, scan, test and deploy the server target; Wrangler pipeline for Workers target.
- Migration rehearsal (counts, referential integrity, payment ledger, consent and block graph, deletion tombstones, moderation holds and rollback boundaries).

A developer's quote that counts only initial Cloudflare deployment does **not** satisfy the two-in-one full-product requirement.

# 6. Subscription pricing and revenue calculation

The following **proposed, not validated** prices are carried forward from the previous Kithra master specification. A final agreement must specify whether each tier is an account-level bundle or mode-specific entitlement; account purchase must never silently opt a user into a relationship mode.

| Tier | 1 month | 3 months | 6 months | 12 months | Core value |
|---|---:|---:|---:|---:|---|
| Free | ₹0 | ₹0 | ₹0 | ₹0 | Account, entry assessments, respectful discovery, accepted conversations, communities, safety/privacy controls |
| Plus | ₹149 | ₹399 | ₹749 | ₹1,399 | Greater discovery/intro quotas and deterministic matching explanations |
| Connect | ₹299 | ₹799 | ₹1,499 | ₹2,799 | Additional curated group/connection capacity and comparison tools |
| Matrimony Intent | ₹399 | ₹1,099 | ₹2,099 | ₹3,899 | Serious-intent tools and guided introductions; no match or marriage guarantee |

**Workbook default paid tier mix:** Plus 55%, Connect 30%, Matrimony 15%. **Billing-period mix:** monthly 50%, quarterly 25%, six-month 15%, annual 10%. Converting term prices to a normalized gross monthly equivalent produces ~₹215.45 per paying member; net after 2% refunds and 18% illustrative GST ≈ ₹178.93. Gateway fees at 2.5% + 18% fee GST ≈ ₹6.36 per payer. These are inputs, not observed behavior.

**Do not charge for:** reporting, blocking, account rights, correction/deletion/consent withdrawal where applicable, basic safety help, victim assistance, user support of severe abuse, or prior accepted communication where a gratuitous safety lockout would be harmful.

**Pricing decisions requiring signoff:** tax-inclusive or tax-exclusive display, no forced auto-renew, real UPI/UPI Autopay and card mandate availability, refunds and partial-term upgrades, cancellation accessibility, annual prepayment recognition, payment gateway per-method quote, plan-family versus mode-specific treatment, trial terms, promotional cohorts and fairness in matrimonial discovery.

# 7. Monthly revenue and unit economics formula

Let **R** = registered accounts, **m** = MAU fraction, **c** = paid conversion of MAU, **P** = normalized gross blended monthly price, **f** = refund fraction, **g** = illustrative GST percentage, **p** = gateway fee and **s** = subscription add-on fee.

- MAU = R × m (rounded).
- Paying members = MAU × c (rounded).
- Normalized customer gross = Paying × P.
- Recognized subscription revenue (illustrative) = Gross × (1 − f) / (1 + g) when prices are GST-inclusive.
- Gateway cash cost = Gross × (p + s) × (1 + gateway GST).
- Variable operating cost = MAU × (moderation + human support + email) + new accounts × verification cost.
- Operating result = recognized revenue − gateway − hosting − variable operating − founder payroll − employee payroll/burden − legal/compliance − accounting/insurance − marketing − development retainer − backups/tools.
- Income tax provision = max(0, positive monthly operating result) × illustrative income-tax fraction **solely for planning**. Actual tax depends on entity, carry-forwards, provisions, depreciation and professional advice.

**The 60-month workbook models revenue accrued evenly from term memberships. It deliberately does not claim to model when annual subscribers actually prepay, how deferred revenue is recognized, what invoice/tax liability timing applies, or the exact card settlement and bank balance.** Its ending cash is a normalized financing proxy. An accountant should add a transaction-level billing cohort ledger for a statutory bank-cash forecast.

# 8. Founder, personnel, moderation and compliance expense structure

| Expense | Default illustrative allowance | Responsibility / inclusion | Not included or not guaranteed |
|---|---:|---|---|
| Founder salary | ₹25,000/month | Compensation while building/operating | Founder dividends, equity, personal taxes, salary arrears |
| Employee / contracted operating coverage | 0.5 FTE × ₹35,000/month + 15% burden = ₹20,125/month | Product maintenance, operations, support | 24/7 coverage; multiple full-time reviewers; hiring fees |
| Ongoing development | ₹40,000/month | Bugfixes, dual-deployment checks, integration changes | Major new features, full engineering department |
| Legal counsel | ₹8,000/month | Budgeted attorney reserve | Confirmed legal-retainer offer or compliance guarantee |
| Cybersecurity, audits and privacy | ₹7,000/month | Spread-over-year reserve | A completed external security audit; costs can be lumpy |
| Accounting/filings | ₹3,000/month | Bookkeeping/GST/corporate work | Actual company registration advice and audit fees |
| Insurance | ₹2,500/month | Placeholder cyber/liability insurance | An actual binding insurance policy |
| Marketing | ₹12,000/month | Content, partnerships, limited campaigns | Paid CAC, retention or response guarantees |
| Moderation | ₹0.90 per MAU/month | Scale-sensitive variable reserve | Human 24/7 safety or investigation coverage |
| Support | ₹0.35 per MAU/month | Average usage reserve | High-touch matrimony complaints or legal requests |
| Email/notifications | ₹0.05 per MAU/month | Standard email notices | SMS, WhatsApp Business messages and KYC vendor charges |
| Backups and miscellaneous | ₹4,000/month | Separate backup and tools allowance | Disaster recovery guarantee or independent managed NOC |
| Initial legal/security setup | ₹60,000 one-off | Legal and core setup reserve | Quoted scope from specific providers |
| Initial independent review | ₹1,50,000 one-off | Financial placeholder for testing/certification | Assurance without contracted scope and acceptance evidence |
| Full-product engineering build | ₹25,00,000 one-off | Editable placeholder only | Bid-approved price; comprehensive product could cost more |

**Salary sensitivity:** The workbook shows 0 / 25k / 50k / 1 lakh salary choices against each registration scale. Where founder performs coding, set development retainers to zero **only if** the owner genuinely performs the work; still record uncompensated founder hours and development delays outside cash reports. Payroll escalation 7%/year and marketing escalation 5%/year are hypothetical stress drivers.

**Moderation reality:** Friendship, Dating and Matrimony involve unsolicited contact, scams, impersonation, harassment and potentially intimate information. High-risk complaints require trained intervention and defined response time. An automated block button does not replace staffed safety operations. The initial ₹0.90/MAU reserve must be challenged aggressively once there is real moderation volume.

# 9. Five-year projection — exactly what the starter model says

**Forecast is illustrative; these are not predictions.** The default workload begins with 100 registered members, adds 300 new accounts in month one and increases new-account inflow by 4% per month; 1% of existing accounts are modeled as closing monthly. MAU remains 30% and paid conversion 3% of MAU. The selected hosting mode starts as Cloudflare.

| Year | Registered end | MAU end | Revenue net ₹ | Expenses ₹ | Net result ₹ | Cash balance ₹ |
|---:|---:|---:|---:|---:|---:|---:|
| 1 | 4,377 | 1,313 | ₹44,017 | ₹14,80,307 | **−₹14,36,290** | **−₹36,46,290** |
| 2 | 10,745 | 3,224 | ₹1,46,901 | ₹15,89,052 | **−₹14,42,151** | **−₹50,88,441** |
| 3 | 20,517 | 6,155 | ₹3,03,286 | ₹17,19,114 | **−₹14,15,828** | **−₹65,04,270** |
| 4 | 35,782 | 10,735 | ₹5,45,198 | ₹18,83,324 | **−₹13,38,126** | **−₹78,42,395** |
| 5 | 59,890 | 17,967 | ₹9,26,318 | ₹20,97,392 | **−₹11,71,074** | **−₹90,13,469** |

The end-of-year cash figures contain an initial **₹5,00,000 assumed capital balance**, less one-off illustrative build/legal/audit costs of ₹27,10,000 in month one and the cumulative operating losses. Negative values are *additional funding gaps* under this cash proxy, not personal liabilities or established actual company debts.

**Interpretation:** A comprehensive Kithra platform with a paid engineering team is not made profitable by inexpensive Cloudflare hosting. Under these precise assumptions the funding gap remains material even by year five. Increasing paid conversion, retaining active users, raising prices responsibly, finding a B2B revenue stream or operating with much lower actual personnel costs would change the outcome. None has been demonstrated yet.

# 10. Break-even, sensitivity and counterfactuals

The workbook computes a simplified monthly contribution:

- After illustrated refunds/GST: ~₹178.93 per paying MAU.
- Gateway cost: ~₹6.36 per payer.
- Difference: ~₹172.57 contribution per payer before average support/moderation/email.
- Paying MAU = 3% of all MAU, so gross effective contribution after ₹1.30/MAU operations reserve is ~₹3.88 per MAU.
- Fixed monthly costs (not including selected hosting): ~₹1,21,625. The workbook estimates ~31,518 MAU/~1,05,060 registered accounts to cover this fixed baseline and reference hosting cost.

**Not a true scale break-even:** additional FTEs, security reviews, D1 per-database limits, 24/7 moderation, fraud rates, marketing/customer acquisition and retention challenges would increase spending at 31,518 MAU. This simplified line is useful for falsifying implausible pricing, not a guarantee of profitability.

## Three scenario tests in the workbook

| Parameter | Pessimistic | Base | Optimistic |
|---|---:|---:|---:|
| MAU / registered users | 15% | 30% | 45% |
| Paying / MAU | 1% | 3% | 6% |
| Subscription pricing | Same proposed plans | Same | Same |
| Salaries/marketing | Same base costs | Same | Same |
| Hosting | User chooses Cloudflare/VPS/multi | Same | Same |

The scenario tests deliberately **do not invent improved CAC or lower fraud costs** for optimism. They also do not simulate price elasticity, differentiated customer cohorts or a network-effect curve. Those require observed data.

## Operational pricing levers to test

- Whether Plus and Connect are valued primarily for *more introductions* or for deep deterministic compatibility explanations; free users must retain useful matching and safety.
- Whether Matrimony Intent adds net revenue or mostly raises verification, complaint, safety and support costs.
- Whether longer prepaid plans improve retention or create high refund/renewal complaints.
- Whether one unified subscription can allow independent consent across all three modes without confusing price-value or billing rights.
- Whether limits on messages, media and daily matching can control abuse without making basic communication effectively unusable.

# 11. Capital, runway and financing policy

**The current 60-month ending cash column is a normalized cash proxy, not an audited cash-flow statement.** Monthly bank balances for 3-, 6- and 12-month subscriptions differ from monthly revenue recognition, and processor settlements, refunds, GST remittances, deferred revenue and annual contract renewals have timing consequences. This is a mandatory future accounting workstream, not a defect to conceal.

**FIN-RUN-01:** set an owner-approved cash budget and a minimum 9–12 months of *critical* spend (moderation, incident response, backups, compliance, essential infrastructure and core payroll) before a full public release. This reserve target is a governance recommendation, not a solvency law.

**FIN-RUN-02:** obtain at least two itemized engineering bids for the entire contracted full product *and both deployment targets*, with acceptance tests, warranty, security and maintenance; compare upfront owner-build cost separately.

**FIN-RUN-03:** treat founder salary as an explicit operating expense. If deferred or waived, model accrued unpaid compensation only if there is a legal/contractual obligation to pay it later. Do not present unpaid work as a free business advantage to investors.

**FIN-RUN-04:** maintain a 13-week rolling bank cash forecast once actual operations commence; reconcile settled gateway balances to subscriber ledgers weekly and bank accounts monthly.

**FIN-RUN-05:** if projected 90-day runway is below agreed floor, restrict nonessential product experiments and marketing, but retain incident response, privacy rights, and security resources.

# 12. Financial risk register

| Risk | Consequence | Leading indicator | Owner/action |
|---|---|---|---|
| Unverified subscription demand | High registrations, inadequate payers | Paid MAU %, trial-to-paid %, renewals | Founder tests pricing and long-term retention |
| Hidden churn | Misstated lifetime value | 30/90-day repeat connection and subscription renewal | Product/finance track paid cohorts |
| High-risk abuse | Legal, safety, staff cost spike | Reports / 1,000 MAU; severity; SLA breaches | Trust & safety lead; human reserve |
| Expensive all-pairs matching | D1 contention/API delays | Rows read per query, p95 latency, queue age | Backend lead builds indexed candidate strategy |
| D1 cap or single-file contention | Disruption and forced migration | Per DB used/limit, write queue, lock time | Architect designs sharding/PG migration |
| Private data leakage | Compensatory and reputational damage | Unauthorized access attempts, incident reports | Security lead; controls and incident plan |
| Payment settlement discrepancies | Revenue misstatement, complaints | Gateway ledger minus bank ledger | Finance/admin daily reconciliation |
| Annual plan accounting error | False cash runway and net revenue | Deferred revenue/renewal schedule | Accountant implements cohort ledger |
| Founder underpaid | Hidden cost, burnout | Hours and sustainable owner compensation | Founder reassesses actual required salary |
| Vendor FX/invoice changes | Lower gross margin | Monthly USD/INR and published prices | Finance updates vendor assumptions monthly |
| Server failure or Jenkins compromise | Outage or breached secrets | Restore tests, security scans and patch level | Ops/security assign ownership |
| Poor moderation cost assumption | Operating losses | Cost per ticket, median agent time | Ops tracks real fully loaded costs |

# 13. Finance and admin dashboard requirements

The Kithra administrator needs access to finance data only to the extent appropriate to role-based permissions. The financial dashboard must not expose raw questionnaire responses, sensitive inferred traits, private chat content or unmasked full payment details.

**Finance dashboard:** gross billings; refunds; failed payments; outstanding settlements; GST breakup; recognized net revenue; subscribers by plan and term; pending renewals; subscriber-month churn; MRR/ARR *with precise definitions*; contribution margin; first-payment conversion; CAC by campaign; hosting cost per MAU; moderation cost per reported case; legal/compliance reserves; payroll and runway; active subscription entitlements; restricted billing dispute case counts; infrastructure budget alerts.

**Staff RBAC:** Finance reviewer can access aggregate ledger and tax records; billing operator can inspect a customer invoice and issue approved refunds; support agent sees only masked payment status; compliance officer accesses legally required records with necessity; superadmin does not bypass sensitive data controls. Refunds over a defined amount require two-person approval and auditable reason codes; payment webhooks use immutable event IDs and reconciliation.

**Daily/weekly/monthly workflow:**

- Daily: reconcile payment webhooks, gateway status vs entitlements, refund/chargeback exceptions, security costs and critical payment failure spikes.
- Weekly: monitor MAU, conversion, moderation contact demand, gross and net subscription cohort margins, sampled routing-cost outliers.
- Monthly: close invoices, GST reports as applicable, vendor invoices in USD, tax adjustment and credits, payroll, external counsel invoices, marketing ROI, bank cash, runway and budget variance.
- Quarterly: test restore, conduct pricing/conversion review, reassess staffing and customer rights workload; compare Cloudflare and server costs on actual telemetry.
- Annually: salary escalation, insurance/audit renewals, T&C/pricing changes, long-term business viability review, depreciation/tax review with professional advisers.

# 14. Engineering requirements to support measurable costs

**FIN-ENG-01:** expose per-route CPU time, D1 read and write rows, total DB bytes by domain, R2 storage/object count and Class A/B operations, DO messages and non-hibernating duration, queued operations, and auth verification usage without logging intimate questionnaire answers.

**FIN-ENG-02:** record per-feature workload cost estimates: registration, quiz (100-item set), score recomputation, match discovery, profile thumbnails, private chat, reports, appeals, billing, audit, and data export/deletion. Compare to empirical metrics after load tests.

**FIN-ENG-03:** introduce explicit budget alarms at 50%, 75%, 90% and 100% of monthly owner-approved vendor budgets. Alerts must notify finance and operations; avoid unreviewed automatic deletion or shutdown of critical workflows.

**FIN-ENG-04:** maintain feature cost budgets and quotas for image upload, retention, attachment sizes, bulk re-scoring, candidate batch size, discovery refresh limits and messaging flood prevention.

**FIN-ENG-05:** avoid a global unbounded `for each user, score every other user` job. Pre-filter compatibility by consent/relationship mode and privacy eligibility; use bounded candidate pools, resumable jobs, idempotent outbox and explainable score versioning.

**FIN-ENG-06:** implement mirrored load test scenarios for Cloudflare Workers/D1 and Docker API/PostgreSQL. Compare effective p95 latency, drop/retry rates, fraud/error impact, cost per 1,000 meaningful connections, and monthly incident support labor. Publish measurable capacity with a failure point; no advertised unlimited users.

**FIN-ENG-07:** build and test a Cloudflare→server export and cutover: legal consent, score version, block graph, payment/refund ledger, message sequence and report evidence must survive without data loss beyond an explicitly accepted RPO. Existing open conversations must be reconnectable.

**FIN-ENG-08:** document billing implementation with Razorpay raw signed event verification, idempotency, server-side entitlements, plan versioning, statutory invoice fields and reconciliation. Finance cannot rely on frontend checkout success.

**FIN-ENG-09:** preserve account/quiz privacy and deletion workflows as protected costs, not optional plan-level features; define legally required retention and data-access holds.

# 15. Financial reporting metrics & definitions

| Metric | Meaning | Needed denominator / limitation |
|---|---|---|
| Registrations | Unique created accounts (cumulative) | Not equivalent to reachable people |
| MAU | Distinct active users in trailing 30 days | Define meaningful activity, exclude bots/test staff |
| Paying MAU | Users with a paid entitlement active in period | Active annual subscribers differ from payments collected |
| MRR | Monthly normalized recurring revenue from active paid subscriptions | Net of required adjustments; not all gateway collections |
| ARR | MRR × 12 where stable | Not revenue on tax returns; no false annualizing one-offs |
| Gross customer billings | Total consideration charged to customers | GST-inclusive if product rates displayed tax-inclusive |
| Recognized revenue | Revenue earned in period excluding tax/refunds | Deferred prepaid revenue recognized over term |
| CAC | Verified acquisition spend / new acquired customers | Separate registered CAC and *paying* CAC |
| ARPPU | Revenue per paying active user | Separate blended gross and net of taxes |
| Hosting unit cost | Total vendor infrastructure / MAU | Do not label as full service cost |
| Safety cost/MAU | Paid staff + systems safety costs / MAU | Requires allocation and case severity |
| Contribution margin | Net revenue less variable fees and variable operating costs | May exclude fixed staff, list exclusions |
| EBITDA-like operating result | Revenue - operating expense (before noncash depreciation etc.) | Workbook is illustrative cash OPEX, not accounting EBIT |
| Runway | Accessible cash / recurring net burn (months) | Needs real bank cash, liabilities and prepaid timing |
| Match success | Mutually continued contact/consented group participation | Not inferred from 90% quiz similarity |

# 16. Model validation and QA tests

Acceptance requirements for the developer and accountant:

1. Changing the selected deployment to Cloudflare, Single VPS or Multi Server updates 60 months of hosting expense, operating result, cash proxy and dashboard outputs without manual recoding.
2. Changing founder salary to 0 / ₹25k / ₹50k / ₹1 lakh updates the 60-month forecast and salary sensitivity while **never changing customer-facing plan prices**.
3. Every no-AI term remains excluded from cost drivers; no vector DB, GPU, LLM cost or AI-twin pipeline is created by inference from past documents.
4. The three tier weights and four billing-period weights must add to 100%. Production import/forecast tool must reject totals outside 100% rather than silently normalizing.
5. Monthly gross customer consideration less refunds and GST ties to recognized monthly revenue under selected tax-inclusive assumptions.
6. Gateway fees are applied to gross charged consideration with stated fee-GST assumption. Exporting gateway settlements and bank cash requires a separate settlement schedule.
7. A Cloudflare bill below ₹1,000 at low scale must not be described as the full monthly platform cost, because personnel, legal, marketing and security remain present.
8. When Single VPS is selected beyond its planning MAU ceiling, the UI/report must flag capacity invalidity rather than treating its flat bill as valid production economics.
9. At 100,000 registrations/30,000 MAU, D1 storage estimate 30GB exceeds a **single** 10GB Paid per-database limit: architecture must have a sharding strategy or PostgreSQL migration.
10. Stripe-style or implicit auto-debit behavior must not be assumed for Indian gateways without product-specific merchant approval and applicable mandate law review.
11. Add at least a 20%/50% vendor-cost stress scenario, a duplicate webhook refund scenario, payment failure stress, high-abuse moderation stress and short-tenure churn in a second-stage financial reconciliation workbook before procurement.
12. Finance/staff authorization, export restrictions, notes/approval history and stored receipts must be part of the production admin dashboard test plan.

# 17. Model limitations and required independent signoffs

**What is grounded:** Cloudflare's published unit prices and included quantities, DigitalOcean public list prices, Firebase public documentation, Razorpay public rates, observed USD/INR conversion, and prior founder-proposed subscription prices.

**What is *not* grounded yet:** real Kithra traffic, conversion, MAU, people willing to pay, salary contracts, legal invoices, moderation rates, support tickets, security-review fees, actual Indian GST classification, payment method mix, processor deal, server region invoice, business profits, the full packaged development cost or user relationships. The workbook makes these assumptions editable rather than presenting them as verified facts.

**Mandatory independent approvals:** Indian chartered accountant (tax, accrual/deferred revenue, cash statements, input tax credit, TDS, payroll, entity structure); Indian privacy/IT counsel (DPDP, intermediary obligations, adult/child policy, complaints, rights/retention); payment merchant and contract reviewer; engineering lead (measured SQL/DO/storage costs and dual-target load); trust/safety owner (real cost of human investigations); founder (subscription entitlements, hiring, acceptable burn and launch funding).

**FIN-RD is not a statement that Kithra is “airtight” from Indian law.** Good documentation only helps ensure the product follows applicable requirements; it does not remove those requirements or provide legal immunity.

# 18. Source register and revision rules

As retrieved on **1 November 2026**:

- Cloudflare Workers Paid pricing: https://developers.cloudflare.com/workers/platform/pricing/
- Cloudflare D1 pricing: https://developers.cloudflare.com/d1/platform/pricing/
- Cloudflare D1 per-database/storage limits: https://developers.cloudflare.com/d1/platform/limits/
- Cloudflare R2 pricing: https://developers.cloudflare.com/r2/pricing/
- Cloudflare Durable Objects pricing: https://developers.cloudflare.com/durable-objects/platform/pricing/
- Cloudflare Queues pricing: https://developers.cloudflare.com/queues/platform/pricing/
- Firebase Authentication and phone pricing: https://firebase.google.com/pricing
- DigitalOcean Droplet list prices: https://www.digitalocean.com/pricing/droplets
- DigitalOcean managed PostgreSQL pricing and plan caveats: https://docs.digitalocean.com/products/databases/postgresql/details/pricing/
- Razorpay Gateway: https://razorpay.com/pricing/
- Razorpay Subscriptions: https://razorpay.com/subscriptions/
- CBIC IT-services GST rate guidance: https://cbic-gst.gov.in/hindi/sectoral-faq.html
- USD/INR planning reference: `currency_exchange_rate_source` returned 1 USD = ₹94.9125 for 2026-10-31, not guaranteed forward rate.
- Original Kithra proposal: `Kithra_Dual_Deployment_Full_Product_2026/00_CANONICAL_MASTER.md`, Billing-RD and full-product dual-deployment sections.

**Update cadence:** vendor prices monthly or before major purchase; FX monthly; staff/legal quotes before contract; real conversion/retention monthly once live; GST and legal treatment after professional advice; scenario allocations quarterly; authoritative model version and sign-off when changing price entitlements or deployment economics.

---

**Handover instruction:** Give the full-stack developer this FIN-RD **and** the XLSX workbook alongside the dual-deployment master specification. The engineer must implement the instrumentation and budget controls, not treat the workbook as automatic proof that all services can handle a given user count. Finance and legal staff must approve all externally binding financial and tax decisions.
