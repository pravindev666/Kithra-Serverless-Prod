# 2-in-1 deployment contracts (NOT a live application)

## A. Cloudflare

- Build shared apps (`web`, `admin`, `api`) and run domain/contract tests.
- Provision D1 database, private R2 bucket, Queues, Durable Object namespace, route domains and secret bindings **separately per environment**.
- Replace resource IDs and set security policies in `cloudflare/wrangler.*.jsonc`.
- Use Workers Static Assets for new projects; Pages remains a supported static host choice.
- Migrate D1 via a versioned migration job; deploy API and distinct user/admin static origins; smoke test.
- Never expose Firebase or gateway private keys in `vars`; use secret storage.

## B. Docker Compose + Jenkins

- Implement monorepo packages, build scripts and DDL before executing example files.
- Copy `server/.env.example` to a PRIVATE secret-injected environment; do not commit credentials.
- Build OCI images for API/jobs/web/admin and publish with immutable digests to private registry.
- Configure DNS, secure firewall, TLS and backups. Do not expose PG/Redis/Jenkins ports.
- `docker compose --env-file /secure/kithra.env -f deployment/server/compose.yaml config` to inspect safely (note it prints interpolated secrets; avoid logging).
- `docker compose --env-file /secure/kithra.env -f deployment/server/compose.yaml up -d` is meaningful **only after** images and services are built.
- `server/Jenkinsfile` is an approval workflow skeleton, not an already connected deploy.
- A single Compose VM is not highly available. Plan HA if required.

## Migration

A migration from Cloudflare D1 to PG requires actual data export/transform/import, error checks, blocker/consent consistency, persistent messaging and payments reconciliation, privacy retention and an explicit write freeze or reliable outbox. Nothing in this package turns switching between cloud platforms into a dropdown button.

## Security note

Compose examples interpolate DB and Redis credentials into environment variables for **illustration**. Production delivery must move sensitive values into properly scoped secrets (or external manager), enforce secret rotation, audit container environment exposure, isolate build agents, and use private networks and firewall policies. Do not treat these files as production-hardened merely because they are syntactically valid.
