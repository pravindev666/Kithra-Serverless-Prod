# FULL-PRODUCT RELEASE GATES — NEVER CALL AN MVP 'COMPLETE'

The full-product requirement is contractual. Internal sequencing and staged deployment infrastructure do not remove any capability from accepted end-state. Features dependent on legal, scientific or provider authorization must be coded and tested but cannot operate publicly unless their documented conditions are satisfied; report those as a launch blocker, not silently mark them complete.

## Required acceptance evidence for EVERY item in `full_product_coverage.csv`

- Source code path and owner; actual verified data, never static/hardcoded public screens.
- Interactive UI states for desktop, tablet, phone, loading, empty, failure, offline and screen reader.
- API route/schema, validation and negative case tests with sanitized fixtures.
- Cloudflare adapter tests (D1, R2, DO/Queues as required) and server adapter tests (PG, object store, Redis/WS/BullMQ as required).
- Security authorization including direct API call bypass attempts, IDOR, cross-mode privacy leak, rate limit and audit trail.
- Consent/privacy processing inventory, records and deletion/retention implications.
- Moderation, support or admin control where relevant; record policies and operator training.
- Accessible user copy; all speculative scores and AI generated content clearly labeled.
- Monitoring, cost/limit guardrails, backup implications and restoration playbook.
- Production evidence: commit hash, test report, release ticket, compliance/security approval, staging and prod smoke test.

## Go/no-go for the COMPLETE public product

1. 100% mandatory contractual features implemented with production API/provider integrations; no simulated payments, login, matches, conversations or reports.
2. 100% high and critical security bugs fixed; accounts verified; admin MFA enforced; role audit functioning and emergency break-glass test executed.
3. Three relationship modes work independently; cross-mode privacy test suite passes for photos, answer sets, conversation history, history and payments.
4. Exactly 100 validated, publishable questions per released theme set. Placeholder items remain internal only and cannot masquerade as psychological analysis.
5. Matching bands, confidence/limits and AI-twin text comply with evidence-backed claim policy; no guarantee of friendship/marriage or concealed sensitive inference.
6. All Circles, DM, group moderation, reports/appeals and harm escalation accessible without paid safety barriers.
7. All advertised billing plans have signed webhook and refund/cancellation reconciliation tests.
8. Data export, withdrawal and deletion pass actual end-to-end verification, including derived features and backup/legal hold handling.
9. Both Cloudflare and server deployments independently pass acceptance; realistic migration drill performed on staged production-sized synthetic data.
10. Admin dashboard includes case assignment, overdue SLA, appeals, account actions, restricted evidence, staff onboarding/offboarding and reason-audited controls.
11. Observability and budget alerts are exercised; app owner has database restore evidence and current on-call contact rota.
12. Indian counsel approval, psychometric scientific review, payment gateway approval and security sign-off documented with dates and accountable persons.

## Release receipts

For each requirement ID attach: Cloudflare API test, server API test, UI e2e test, security test, support/operator workflow if relevant, accessibility finding, versioned provider policy, final founder signoff. The coverage CSV is a planning register and deliberately leaves all actual evidence fields blank: this package is a specification, not implemented source code.
