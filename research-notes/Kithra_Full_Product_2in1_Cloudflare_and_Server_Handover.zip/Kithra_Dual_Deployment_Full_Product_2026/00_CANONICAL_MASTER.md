# KITHRA — COMPLETE FULL-PRODUCT & DUAL-DEPLOYMENT MASTER SPECIFICATION

**Version:** 2.0 canonical handover | **Date:** 1 November 2026 | **Status:** specification and illustrative infrastructure scaffolds, not a deployed application or legal sign-off.

**Audience:** founder, lead architect, full-stack engineers, DevOps, cloud administrator, UI/UX designers, QA, security, data-protection/legal advisers, psychometric researcher, trust-and-safety operators.

**Controlling instruction:** FULL PRODUCT, NOT MVP. This specification supersedes the earlier version 1 rollout labels (`MVP`, `pilot`, `later`, `post-validation`) wherever they conflict with the founder's commitment to deliver a complete Friendship + Dating + Matrimony product. *Development may be sequenced internally; a feature is not permitted to disappear from the contracted end-state.* Independent legal, security, psychometric and operational approval gates still apply; no founder instruction can make an unsafe or unlawful feature a launch requirement. Placeholder question banks are explicitly permitted until real questions receive expert approval; they cannot be shown as completed psychological instruments.

## 0. The precise handoff contract

**Hand these files to one accountable technical lead:**
1. `Kithra_Complete_Full_Product_Dual_Deployment_Master.docx` (the single controlling specification) and identical editable `.md`.
2. `deployment/` executable-intent scaffolds (not a full implementation): Cloudflare Wrangler templates, Docker Compose, Dockerfiles, Caddy, Jenkins pipeline, environmental contracts, migration runbooks.
3. `reference/` previous BRD/PRD/SRS, UI/UX and India legal sources for traceability; superseded rollout labels are *not* acceptance exceptions.
4. `qa/COMPLETE_PRODUCT_RELEASE_GATES.md` and the release coverage register for no-omission tracking.

**Definition of complete:** every agreed product epic has production implementation, integration tests, negative security tests, responsive and accessible frontends, localized content where selected, admin workflows, observability, support runbooks, authenticated access, and matching feature parity in both deployment modes. If a provider makes a capability impossible on a free tier, the developer must document a *paid-tier requirement or supported alternate*, not remove the feature and declare completion. The launch date and budget must be re-estimated against this definition.

**Do not confuse architectural specification with finished application code.** Original Kithra ZIP is concept only. Auth, quizzes, compatibility scores, chats, admin data, billing and privacy controls must be implemented for real; previous mocked behavior must be deleted before release.

## 1. Immutable product envelope: everything in scope

**Relationship modes** (independent consent, profile, discovery filters, photos, match intent and visibility): (1) Friendship: platonic matching, groups, shared activities; (2) Dating: consenting adult romance with opt-in romantic preferences and mutual requests; (3) Matrimony: serious partnership intention, voluntary practical future-planning prompts and separately opt-in family-assisted introductions. A single user may hold multiple mode personas; NEVER silently cross-post mode-private data, answer sets, relationship history or visibility.

**Accounts and trust:** Email/password and Google sign-in through Firebase; verified email; password reset; trusted sessions and reauthentication; optional phone challenge subject to pricing/abuse; unique Kithra UUID independent of Firebase UID; authenticators and limited visibility; consent dashboard; 18+ policy with age-assurance safeguards; block/mute/report; suspected impersonation and account-takeover workflows; self-service deletion/export/correction; recovery and account appeal; private media scan/quarantine; abuse rate limits.

**Onboarding and profiles:** Three-mode selector with plain-language consequences, separate persona editor, photos, pronouns optional, language, broad location, timezone, goals, boundaries, communication cadence, availability, privacy, verification disclosure, interests, saved searches, profile previews and drafts. No profiling-by-stealth; optional disclosure of any sensitive trait is segregated and purpose-limited.

**Full questionnaire engine:** catalog; themes; 100-question set for every approved theme; subsequent 100-question sets and unlimited version progression; 12 starter themes × two placeholder banks × 100 placeholders = 2,400 placeholders from previous handover; expert-reviewed bank publishing; translated/localized item versions; item types (single choice, Likert, ranking, scenario, sliders, forced choice, text where necessary); question pools, assignments and deterministic shuffle keyed to server seed; item-difficulty, bias checks, quality gates; pause/resume, skip, accessibility, time estimate; change history; revocation; fraud/automation signals without false anti-cheat guarantees; scores and explanations; assessment audit trail. Some users can receive repeated *constructs* with varied questions. Never promise that users can neither coordinate answers nor use AI.

**Psychological model:** dimensions for values, interpersonal communication, conflict repair, emotional regulation *preferences* rather than diagnosis, routines, reciprocal expectations, life goals, lifestyle and interests; missing-data confidence, bounded outcomes, stable scoring versions, cultural validity review, demographic fairness audits. Raw responses are private; derived display traits are disclosure-controlled. No unsupported claims of a brain replica or guaranteed soulmate.

**Discovery and matching:** Opt-in candidate pool, mutual mode-appropriate intent, eligibility, location filters, age policies, blocking, safety/risk, privacy, capacity caps; descriptive alignment bands 100/90/80/70/60/50/40/30/20/10; 'Mirror' (high measured similarity), 'Counterpoint' (measured contrasts), 'Mosaic Fit' (possible complementarity), 'Resonance' (multidimensional descriptive index); confidence and why-match explanation; mutually accepted introduction before DM; saved/bookmarked matches; snooze and hide; reported/disappeared match handling; truthful zero-candidate state. A numeric 100 means maximum measured agreement, NEVER 100% certainty of friendship or marriage.

**AI twin/personality agent** (full product module, only enabled after consent, safety, technical and scientific sign-off): opted-in chat agent representing a *simulation of stated preferences*, not 'copied brain'; provenance/versioned source data; what-it-knows dashboard; editable and deletable memory; model-provider disclosure; opt-in twin-to-twin sandbox comparisons ONLY for recommendation signals, not impersonating users in public conversation; explicit labeling of generated content; spending quotas, inference costs, safety guardrails, hallucination/confabulation logs and review; deletion and retraining limitations. The product must function even if AI feature is disabled by safety or provider outage. Never derive hidden sexual orientation/religion/diagnosis from disguised answers.

**Social:** invitations; mutual DM; groups/Circles (public, private, invite-only); channel threads and replies; member roles; group creation approval limits; group rules; media attachments subject to moderation; message retention; push/email/in-app notifications; optional typing/presence/read controls; discoverable thematic group catalogs; events with safety disclaimers and participant consent; city and Indian/global thematic localization. Real-time safety controls and user context remain enforced in both backends.

**Payments:** free core safety and privacy tools; proposed monthly/quarterly/half-yearly/annual premium offers, feature entitlements by relationship mode, group features where appropriate, trial/grace periods, taxation, invoices, refunds, cancellation, provider payment method availability, webhooks, payment ledger, chargebacks, abuse/risk, reconciliation and support. Plan amounts are business hypotheses to be finalized by pricing research and gateway compliance.

**Support & administration:** Separate admin app on `admin.<domain>`, closed enrollment, authorized verified emails + email/password + mandatory MFA + optional Cloudflare Access; cannot authenticate admin solely by knowing a secret URL; scoped RBAC with multiple overseers and sub-teams (trust, finance, support, compliance, researcher, platform); staff shift and SLA escalation; case queues for reports, appeals, impersonation, fraud, privacy requests, chargebacks and emergency cases; immutable-style audit trail and dual approval for sensitive access; knowledge base and templated replies; review queues, ban/suspend/unban, user appeal, account deletion jobs, legal holds with documented necessity, profile audit, queue and budget health, audit exports, role administration, admin notifications, observability dashboards.

**Information architecture and content:** Desktop and mobile public marketing site (not copied from ZIP), clear mode switching, explanatory score interfaces, Circles and conversations, pricing/settings/help, accessibly designed empty/loading/error/offline states. Motion for React with reduced-motion alternative; theme tokens; responsive navigation and mode-specific layouts. Admin has role-aware sidebar, queue tables, detail panels, keyboard support, accountability and warning on sensitive actions.

**Company operation:** India DPDP staged obligations, IT intermediary duties if applicable, grievance handling, consent, retention, breach handling, CERT-In analysis, terms/privacy/community content and refund policy, customer support, payment compliance, tax/invoicing, disaster recovery, supplier due diligence, budget alerts, software supply-chain controls, vulnerability reporting, release management and data portability.

## 2. One codebase, TWO deployment targets

### 2.1 Architecture invariant: ports/adapters, not provider APIs in business logic

```text
kithra/
  apps/
    web/                     React + Vite SPA / all 3 modes
    admin/                   independent React SPA / closed staff login
    api/                     Hono routes/shared application composition
    realtime-cloudflare/     Durable Object room coordinator
    realtime-server/         Node WS/Socket service + Redis adapter
    jobs-cloudflare/         Cloudflare Queue/Cron consumers
    jobs-server/             Redis-backed workers and scheduler
  packages/
    domain/                  pure TypeScript business rules, matching, identity/mode rules
    application/             command/query use cases; access decisions
    contracts/               Zod, OpenAPI, API error and event envelope versions
    ui/                      reusable accessible React components & design tokens
    scoring/                 deterministic versioned psychometrics; no provider dependencies
    auth/                    AuthVerifier, SessionRevoker interfaces
    db/                      UserRepo, PersonaRepo, QuizRepo, MatchRepo, ChatRepo, CaseRepo
    media/                   ObjectStore interface, upload/retention workflows
    queue/                   JobPublisher + Worker interface
    realtime/                RealtimePublisher + SubscriptionAuthorizer
    payments/                Provider, Ledger, webhook contracts
    auditing/                append-only evidence-aware audit interface
    adapters-cloudflare/     D1, R2 bindings, Queues, DO, local JWT verification
    adapters-server/         PostgreSQL, S3 endpoint, Redis/BullMQ, Node HTTP
  db/
    canonical/               semantic entity definitions + migration change log
    sqlite-d1/               D1 tested migrations and read adapters
    postgres/                PG tested migrations and read adapters
  infra/
    cloudflare/              Wrangler configs, resources, secret setup
    server/                  Compose, Dockerfiles, proxy, Jenkins, backup scripts
  tests/
    contract/ e2e/ integration-cloudflare/ integration-server/ security/
  docs/                     ADR, release evidence, runbooks, compliance & design
```

**Do not pass D1 database bindings, Redis clients, Firebase SDKs or `Request`/`Response` objects into pure domain functions.** They are infrastructure concerns only. `AppContext` carries verified identity and mode, current consent, trace ID and scoped repos. The Hono router can run on Workers and on Node through an adapter: test identical `v1` responses, HTTP status codes and authorization policy. Pin runtime/dependency versions by lockfile and test both targets in CI.

### 2.2 Platform mapping

| Workload | Cloudflare target | Server target | Shared contract |
|---|---|---|---|
| Public SPA | Workers Static Assets (preferred), Pages supported | Caddy static container | same `dist/` assets |
| Admin SPA | separate Worker static assets / Pages | separate Caddy virtual host | same admin build and policies |
| API | Hono on Workers | Hono on Node.js container | OpenAPI v1 and auth middleware |
| Relational DB | D1/SQLite | PostgreSQL 16+ or tested current supported major | repository methods, IDs, migrations |
| Media | R2 private bucket | R2 via S3 API initially; optionally self-host S3-compatible storage | signed object and lifecycle API |
| Real-time | Durable Objects + WebSocket hibernation | Node WebSocket service + Redis pub/sub | persisted message and delivery envelope |
| Job queue | Cloudflare Queues | Redis + BullMQ | idempotent typed jobs + DLQ |
| Scheduled jobs | Cron Triggers | job scheduler container/BullMQ repeatables | same job IDs/semantics |
| Authentication | Firebase identity, verified JWT in Worker | same Firebase identity, verified JWT in Node | Kithra internal user ID and local RBAC |
| Billing | Razorpay + signed webhook in Worker | same Razorpay + signed webhook in Node | payment/event ledger |
| Secrets | Wrangler secret or dedicated secret store | Docker secrets / external manager; never commit | secret names; least privilege |
| Observability | structured Workers logs, traces, alerts | OpenTelemetry, structured logs, optional Loki/Prometheus/Grafana | scrubbed events and SLIs |
| Rate limits | Workers/DO rate rules + Turnstile | Redis token buckets + WAF/proxy | same endpoint-specific policy |
| Backups | D1 Time Travel + exports; R2 retention | PG PITR/WAL + encrypted offsite objects | restore-tested recovery objectives |
| CI/CD | Wrangler builds and deployment promotion | Jenkins-built images, registry, Compose deploy | same unit/e2e and approval gates |

**Note about Cloudflare 2026:** Cloudflare officially recommends **Workers Static Assets** rather than starting a new Pages project, while Pages remains supported. Choose one per environment, do not double-deploy traffic to both without routing policies. Ref: https://developers.cloudflare.com/workers/best-practices/workers-best-practices/ and https://developers.cloudflare.com/workers/static-assets/ .

### 2.3 Runtime architecture diagrams

```mermaid
flowchart TB
  U[User browser React] --> CF[Workers Static Assets or Pages]
  U --> FIRE[Firebase Authentication]
  CF --> API[Hono Worker API]
  ADMIN[Admin SPA separate origin] --> API
  API --> D1[(D1 SQLite)]
  API --> R2[(Private R2)]
  API --> DO[Durable Objects - WebSockets]
  API --> Q[Queues + Cron]
  Q --> D1
  API --> PAY[Razorpay signed webhooks]
  API --> OBS[Logs and Alerts]
```

```mermaid
flowchart TB
  U[User browser] --> PROXY[Caddy/Nginx HTTPS]
  A[Admin browser] --> PROXY
  PROXY --> STATIC[Web + Admin static builds]
  PROXY --> API[Node Hono API]
  API --> PG[(PostgreSQL)]
  API --> REDIS[(Redis)]
  API --> OBJECT[(R2 or S3 object storage)]
  API --> WS[WebSocket coordinator]
  WS --> REDIS
  API --> JOB[Redis/BullMQ jobs]
  JOB --> PG
  API --> FIRE[Firebase JWKS auth verifier]
  API --> PAY[Razorpay]
  CI[Jenkins - isolated deployment] --> REG[Container Registry]
  REG --> PROXY
```

**No architecture diagram overrides authentication, authorization and consent checks.** External browser requests NEVER query D1/PG directly. A web socket is re-authorized when a room is entered, mode visibility changes or account status changes.

### 2.4 Portability is measured, not assumed

- HTTP routes, auth middleware, Zod contracts, score engine and policy engine: exact same implementation and tests in both targets.
- SQL semantics differ: `json_extract` vs JSONB, full-text search, upsert and transaction strategy, timezone, isolation, parameter placeholders, migration DDL. Maintain separate tested migrations/queries at adapter boundaries; never claim D1-to-PostgreSQL is a file copy.
- Cloudflare DO is a single-room coordination model, not drop-in Redis pub/sub. Define reconnect, sequencing, fanout, presence and delivery in shared tests; presence is ephemeral, message history is durable.
- Cloudflare Queues guarantee at-least-once processing; BullMQ also needs retry/idempotency controls. Transactional outbox used for notifications, entitlement changes, data erasure and score recomputation where necessary.
- R2 is S3-compatible *but not identical*; test every used operation against R2 and selected server storage. Never accidentally expose presigned object URLs in logs.
- Firebase remains external in BOTH modes initially. Fully independent server mode requires a *separate identity migration project* (OIDC provider, password reset/reauthentication, verified provider identity mapping, account-recovery testing). No fictitious 'copy user passwords' approach.
- Payment vendor, SMTP, SMS, transactional email, captcha and AI model providers remain external until replaced; server hosting does not automatically eliminate external service bills.

## 3. Detailed deployment A — Cloudflare

**Suggested zones:** `kithra.example` marketing+app, `api.kithra.example` API Worker, `admin.kithra.example` staff SPA behind Cloudflare Access as defense in depth; `assets` remain bucket-private with authorized API-generated access. Domain names illustrative.

**Services:** Worker Static Assets for new Vite app (or legacy Pages), Worker Hono API, D1 (account database with privacy-sensitive tables), R2 (avatars, moderated uploads, export archives), SQLite-backed Durable Objects per chat room/group, Queues (email/match jobs/media scanning/rights), Cron Triggers (billing, retention, breach reporting/SLA, expired tokens), optional Turnstile and WAF.

**Free-tier feasibility vs full product:** Workers Free 100,000 requests/day and 10ms CPU; D1 Free 500MB per database, 5GB total and 10 databases; paid increases constraints; R2 and Queues have usage allowances. A FULL, functioning product with intensive matching, AI calls, real-time group messaging and comprehensive moderation can exceed free quotas. **No 'free forever' guarantee**. Preload and benchmark with 1k/10k/100k synthetic users; enable billing, quotas and alerts deliberately. See: https://developers.cloudflare.com/workers/platform/limits/ ; https://developers.cloudflare.com/d1/platform/limits/ ; https://developers.cloudflare.com/workers/platform/pricing/ .

**Cloudflare production procedure:** provision separate preview/staging/prod accounts or strictly distinct D1/R2/DO/Queues resources; deploy versioned migrations forward; create private buckets; set runtime bindings and secrets; configure route origins/DNS/TLS; enforce CORS origin allowlists; configure rate limits; deploy API and web/admin with build IDs; smoke test auth/mode isolation/messaging/payments/reporting; perform rollback by recorded releases; monitor platform quotas and safety-report channel. Never share live financial/psychological data in previews.

**Load envelope:** Worker CPU must not run extensive LLM tasks or long synchronous batch matching. Split into bounded queue jobs with external model providers and timeout/retry/reconciliation. DO hibernation for WebSockets; write persisted message before acknowledging acceptance; D1 transactions/batches suited to workload. R2 media malware scanning and upload quarantine external worker/scan service as required.

**Wrangler files:** `deployment/cloudflare/wrangler.api.jsonc` and `wrangler.web.jsonc` are templates containing placeholder resource IDs. A developer must provision exact Cloudflare resources and revise routes before deployment. Treat them as scaffolds, not ready-to-run application definitions.

## 4. Detailed deployment B — self-managed server / VPS

### 4.1 Workload and placement

Target minimum: one properly secured Linux VM with Docker Engine/Compose for early traffic, managed firewall and object-store back-end. For availability: at least two app instances and an externally replicated database/backup site; a single VPS is not high availability. Jenkins should run on a separate CI host or trusted managed runner—not publicly accessible alongside the database and app. The example Compose is an *operational skeleton*: it requires implementations of `apps/api`, `apps/jobs-server`, and the two frontend Dockerfiles.

**Services and ports (only proxy is public):** Caddy 80/443 publicly (production TLS and domain); API internally 3000; PostgreSQL internally 5432; Redis internally 6379; worker no public port; WebSocket on API behind proxy `/ws`; web/admin served by proxy. Optionally keep media in R2 (remains external) or provision hardened S3-compatible object service. Do not expose postgres/redis/Jenkins publicly. No SSH password login; SSH key+sudo controls, restricted inbound, security patches and backups.

### 4.2 Docker Compose / Jenkins contracts

- `deployment/server/compose.yaml` models core containers and mounts; `.env.example` documents required names. Runtime secrets must be provided by secret manager or Docker secrets, not a committed `.env` file.
- Production Dockerfiles use multistage builds, non-root Node user, pinned major version + lockfile, small runtime surface, no dev hot reload. Pin image digests during implementation and add SBOM/signature.
- `deployment/server/Jenkinsfile` is a **sample stage contract**, requiring installed plugins/agents and a registry. CI sequence: checkout → dependency audit → lint → typecheck → unit → integration for both targets → build web/admin/API/jobs → SAST and dependency vulnerability gates → container build and image scan → push signed/immutable image digest → staging deploy → migrations → e2e/security+accessibility → manual approval → production deploy → smoke + backout plan. A failure blocks promotion.
- Jenkins organization admin is not a Kithra production app admin; credentials do not grant DB row access by default. Use distinct secrets and jobs per environment. Protect `Jenkinsfile` changes with code review and branch rules.
- Production Compose migration strategy: separately run a one-shot migration job under a lock; backup before backward-incompatible schema changes; expand/contract DDL; then roll image(s). Avoid `docker compose down -v` in production. Versioned rollback is not automatic for lossy schema migrations.
- Server health: `/health/live` process health, `/health/ready` checks *essential* provider dependencies with timeout and safe output; counters for error rate, request latency, open websocket rooms, DB pool, job lag, media scan backlog, report SLA misses, payment webhook age and spend alerts.
- Proxy: enforce HTTPS, HSTS after testing, secure headers, websocket upgrade, request-body limits, rate-limits/WAF; do not treat TLS termination as sufficient app authorization.

### 4.3 Server migration sequence (two-way optionality)

0. **Before launch:** dual adapters and contract test suite exist. Choose one production source of truth and keep the other target *deployable* but not live-writing.
1. **Prepare:** migrate secrets policy, validate auth/session models, duplicate compatible schema, encryption keys/rotation plan, privacy inventory and database volumes, backup and restore evidence.
2. **Historical transfer:** export D1 data using supported API, transform IDs, JSON, time and constraints; re-encrypt if key/domain changes; import into PostgreSQL with referential integrity and mode-specific permissions. Export private R2 metadata and verify object integrity/retention.
3. **Change-data capture:** plan outage or dual-run. D1 lacks ordinary PostgreSQL-style WAL streaming; implement bounded read-only cutover or *application-level event/outbox replay*, never assume zero-downtime.
4. **Validation:** compare per-table count, foreign keys, random/sample checksums of encrypted and plaintext-approved fields, disclosure scopes, consent history, rights requests, block graphs, admin RBAC, payment ledger and moderation case holds.
5. **Cutover:** announce a maintenance window if required; pause write endpoints; replay tail; change ingress and API origin; run private and public smoke tests; open writes on ONE backend; monitor SLOs.
6. **Rollback:** rehearsed traffic switch only if data divergence does not jeopardize correctness. After writes on new DB, a rollback requires reverse data reconciliation or restoration; never claim DNS rollback alone is safe.
7. **Cleanup:** retention-based deletion of unused vendor copies, secret revocation and documented data subject impact.
8. **Reverse move:** follow analogous process from PG → SQLite only after DB-size, SQL-feature and peak write workload checks; such a return is not always possible within D1 limits.

**RPO/RTO targets** (aspirational until tested): paid-critical ledgers RPO ≤15 min, most other data RPO ≤1h, critical service RTO ≤4h; prove in restore drill under realistic workload or publish measured weaker values. DO presence may reset; no unacknowledged message may appear delivered.

## 5. Auth, security, RBAC across both modes

**Recommended:** Firebase Auth email/password + Google for users; verified email required; phone OTP optional and paid/abuse-limited. Admin access only by existing approved verified-email identity, password and MFA, optionally Cloudflare Access. Admin RBAC is stored in Kithra's own DB with scoped role grants, not derived from a frontend nav or an email-domain comparison. Use OIDC/JWKS or Firebase official public keys at Worker edge and official Admin SDK server-side where applicable. Validate signature, issuer, audience, times, subject, and revoked/disabled Kithra session state; token revocation check must be explicitly implemented. Source: https://firebase.google.com/docs/auth/admin/verify-id-tokens .

**Roles:** user; circle-owner/mod; support_agent; trust_moderator; trust_lead; privacy_officer; billing_operator; compliance_reviewer; system_operator; research_analyst; auditor_readonly; superadmin. Capability matrix is server enforced, non-wildcard: `ticket:view`, `ticket:assign`, `case:evidence:view`, `user:suspend`, `billing:refund`, `data_rights:execute`, `admin:invite`, `policy:publish`, `audit:export`, `system:deploy`. Extremely sensitive raw quiz access requires reason code, scoped escalation, dual approval and append-only audit; never broadly accessible just because a user is superadmin.

**Protect identity and minors:** enforce age policy and proportionate verification, safe profile defaults, no mixing minors/adults (launch adults only), encrypted transport and at-rest controls, secrets rotation, CSRF defense when cookies used, CORS strict origins, HMAC raw-body webhook checks, object authorization, egress and AI input filtering, security headers, brute force protection, emergency kill switches, append-only incident log and cross-mode leak tests.

**Legal:** Indian DPDP 2023 Act and 2025 Rules phased commencement, current IT/intermediary rules if applicable, 2011 sensitive personal data framework to applicable scope, CERT-In reporting assessment, payment/consumer disclosure, legal complaints and appeals, cross-border data handling. Generate and maintain data map, record of purposes, consent receipt versions, user-facing rights flows, lawful retention matrix, provider DPAs, grievance officer/public contact as legally applicable. Draft policies are not an exemption or guarantee of compliance. Licensed Indian counsel review is a hard publication gate.

## 6. UX/UI and admin frontend acceptance

User nav: **Discover | My Matches | Quizzes | My Insights | Circles | Messages | Events | Membership | Notifications | Help & Safety | Settings**. Global relationship mode switch clearly distinguishes FRIEND/DATE/MATRIMONY and displays what profile is visible. Match pages explain index and confidence plus Mirror/Counterpoint/Mosaic lenses. Quiz runner navigates 100 items in accessible chunks, shows pause/resume, timer optional, never punitive; shuffle occurs on server. Profile options report/block available from every user surface. Consent/data rights reachable in ≤3 navigation steps.

Admin sidebar (capability-gated): **Overview | Safety Inbox | Reports & Appeals | Accounts | Identity & Verification | Quizzes & Publishing | Match & Fairness Monitoring | Circles & Content | Messages (metadata, restricted evidence access) | Billing & Refunds | Privacy/Data Rights | Grievances/SLA | Legal Holds | Support Templates | Analytics | System Health | Audit Logs | Staff & RBAC | Settings**. Dangerous actions require reason and confirmation; show operator, subject, case number, privacy classification and action event.

Visual language from version 1 design kit is reference, not mandatory source ZIP UI. New design must deliver landing page Framer Motion sequences, responsive tokens/light-dark modes, attention to reduced-motion preferences and page transition budgets; admin density is intentionally higher than consumer app. No animation may conceal status or impede screen readers. Figma component variants, interaction states, keyboard navigation, mobile admin fallback, forms and errors required.

## 7. Delivery definition: complete packaged product, not MVP

**Development sequence can be incremental; scope is not.** The developer estimates and commits to ALL full-product epics in the acceptance register. Payment may be staged by objectively verified milestone; feature removal requires written founder change request with a documented regulatory/safety impact. Production launch is blocked if any contractual feature is absent, fictional, mocked or bypasses safety checks; features whose release is illegal/unvalidated remain implemented behind a documented closed gate until legal/scientific approval rather than deceptively represented as live.

**Acceptance requirements per feature:** user story, UX screens, component spec, API/schema update, end-to-end test, edge and abuse tests, role/consent check, Cloudflare test, Docker/server test, accessibility review, observability alert, backup/restore implications, admin tools, support training, policy disclosure and rollback behavior. No 'complete' state without evidence links and owner signoff.

**Nonfunctional minimum targets to verify:** WCAG 2.2 AA where applicable, p95 endpoint targets by workload after performance benchmarking (not invented SLA), secure TLS, standard logging with PII scrubbing, audited access, offsite encrypted backups, tested recovery, max tolerated user loss from queue retries, rate limiting, audit retention schedule, antivirus/malware handling of uploads, 7/30-day recontact measurement and fraud signals. Extensive quiz and AI cost/load tests at user counts 100/1k/10k/100k; do not imply a single VPS supports an unlimited community.

**Complete launch signoffs:** founder product scope, lead engineering contract parity, security penetration test, India counsel legal readiness, psychometric scientist score interpretation, trust/safety lead moderation capacity, operations restore rehearsal, finance payment reconciliation, QA 100% critical test pass and accessible design review. Human resources and recurring moderation spend are real costs regardless of hosting model.

## 8. Architecture decision log — explicit preferences and tradeoffs

- **ADR-001 (Accepted):** React + TS + Vite UI; same build output in both targets.
- **ADR-002 (Accepted):** Hono HTTP API & pure TS domain; server uses Hono Node adapter.
- **ADR-003 (Accepted conditional):** Firebase identity in BOTH targets. Pluggable OIDC support if future self-hosted auth needed; do not combine Firebase + Supabase for same sign-in.
- **ADR-004 (Accepted):** D1 primary for Cloudflare; PostgreSQL primary on servers. Separate SQL migrations and contract tests.
- **ADR-005 (Accepted):** R2 private media across deployments initially; interchangeable S3 adapter. Avoid old, unsupported MinIO community distributions; production self-host object store requires independent supported software+backup review. Source: https://www.min.io/legal .
- **ADR-006 (Accepted):** DO chat on Cloudflare, WS+Redis on server; durable DB messages in both.
- **ADR-007 (Accepted):** Cloudflare Queues/Cron vs Redis/BullMQ jobs, idempotent outbox.
- **ADR-008 (Accepted):** Jenkins for server deployments on isolated CI host; Wrangler CI workflow for Cloudflare, optionally controlled by the same Jenkins controller with scoped credentials.
- **ADR-009 (Recommended):** Workers Static Assets for NEW Cloudflare SPA; Pages remains an option if existing Pages integration preferred.
- **ADR-010 (Non-negotiable):** raw quiz responses never silently copied to public profiles; blind sensitive inference prohibited.
- **ADR-011 (Non-negotiable):** immutable-style admin action audit and strict capability-based authorization in both deployment modes.
- **ADR-012 (Non-negotiable):** no verified prediction of soulmates, mental diagnosis or replicated brains without appropriately strong evidence and lawful, voluntary use.
- **ADR-013 (Requires spike):** field-level application encryption for psychometric content while retaining deletion and explainability; key management and regional processing claims verified.
- **ADR-014 (Requires launch capacity):** media moderation, incident escalation, report-response staff availability and refunds are ongoing operations, not solely code.

## 9. Developer bidding & handoff checklist

Request a **written technical bid** showing: exact full feature inventory; two independent deployments of the same git commit; deliverable source plus repository ownership; service/API/DB diagrams; secure secrets and DNS; all migration scripts with rollback limits; functional staging data; 100-question set publishing; mode-specific workflows; honest scoring; AI-twin opt-in; user & admin UIs; test coverage and live e2e video; monthly Cloudflare/server/provider cost assumptions; SBOM/license scan; incident runbooks; staff training; docs & credentials transfer; post-launch maintenance obligations and exclusion list explicitly approved by founder. Do not accept a bid described only as 'website' or 'MVP'.

**Delivery format:** (A) full source and lockfile; (B) Cloudflare production workspace and credentials under founder-owned accounts; (C) server Compose & Jenkins pipeline on founder-owned domain/registry; (D) one-click local development and smoke test scripts; (E) sanitized demo seed, no fake production users; (F) migration rehearsal report Cloudflare→server and server→Cloudflare feasibility assessment; (G) external provider account inventory; (H) design tokens/Figma source; (I) legal/privacy documentation; (J) data backups and documented restore; (K) complete acceptance register signed by engineering, QA and founder.

## 10. Verified public references (checked 1 Nov 2026)

- Workers Static Assets/new projects: https://developers.cloudflare.com/workers/best-practices/workers-best-practices/
- Cloudflare Workers limits: https://developers.cloudflare.com/workers/platform/limits/
- Cloudflare pricing: https://developers.cloudflare.com/workers/platform/pricing/
- Cloudflare D1 limits: https://developers.cloudflare.com/d1/platform/limits/
- Cloudflare Durable Objects limits: https://developers.cloudflare.com/durable-objects/platform/limits/
- Cloudflare R2 S3 API: https://developers.cloudflare.com/r2/api/s3/api/
- Cloudflare Queues and pull consumers: https://developers.cloudflare.com/queues/ ; https://developers.cloudflare.com/queues/configuration/pull-consumers/
- Firebase backend identity verification: https://firebase.google.com/docs/auth/admin/verify-id-tokens
- Jenkins Docker Pipeline: https://www.jenkins.io/doc/book/pipeline/docker/
- MinIO open-source lifecycle announcement: https://www.min.io/legal
- Indian DPDP Rules 2025 (official instrument must be consulted): https://egazette.gov.in/ ; https://www.meity.gov.in/

---

# ANNEX — PREVIOUS DEEP-RESEARCH SPECIFICATION (REFERENCE, NOT CONTRADICTORY AUTHORITY)

The following detailed legacy 360° sections are retained for in-depth BRD/PRD/SRS, UI design, rules, pricing, legal templates and data structures. Any `MVP`, `post-validation`, `pilot`, `phase`, `later` or `will not initially` label in the annex refers to the previous *planning order*, **not an approved reduction of the full product end-state**. Where legal/scientific release gates block a function, it must not be represented as live until approved. **This canonical v2 section prevails on delivery scope.**

# KITHRA — MASTER CONSOLIDATED PRODUCT, ENGINEERING, UX & COMPLIANCE SPECIFICATION


**Version 1.0 · 1 November 2026 · Draft for professional review.**

**Do not treat unvalidated questionnaires, fake match scores, "brain replicas," or unaudited security functions as implemented or established science.**


## Contents

- 01 BRD Business Requirements

- 02 PRD Product Requirements

- 03 SRS Functional Nonfunctional

- 04 QRD Questionnaire Psychometrics

- 05 MRD Matching Explainability

- 06 SAD Cloudflare Architecture Migration

- 07 DRD API and Data Dictionary

- 08 Security Threat Model IR

- 09 India Compliance PIA Checklist

- 10 Draft Legal Policies

- 11 UIUX Design System Motion Handover

- 12 Admin Experience RBAC Operations

- 13 Billing Revenue Unit Economics

- 14 Test Analytics Experimentation

- 15 Execution Roadmap Backlog

- 16 Competitors Validation

- 17 References Assumptions Decision Log

- 18 AIR Digital Twins Ethics and Architecture

- 19 Community Growth And Cultural Localization


---


# BRD — Business Requirements Document

**Revision:** 1.0 | **Owner:** Founder | **Status:** proposed, not validated

## 1. Executive definition
Kithra is a consent-based human-connection network with three autonomous intention modes: **Friendship**, **Dating**, and **Matrimony**. Members answer versioned questionnaires to receive evidence-informed *descriptions* of similarities, differences, potential friction and complementary preferences, then mutually opt into introductions, conversations and groups. One login and wallet may serve the modes, but matching eligibility, profile visibility, consent, communications and paywalls must be independently configurable **per mode**. A marriage search must never be inferred from friendship participation.

### North-star outcome
**Mutually confirmed continued connection at day 30**, measured separately by friendship (recontact/shared activity), dating (mutual desire to continue), and matrimony (mutual intentional conversation and appropriate next step). Do not optimize time-on-app, endless swiping or survey completion alone.

### Economic reality
The product is a two-sided local-density network, a moderation service and a high-trust data custodian. A polished algorithm with 100,000 inactive accounts fails if compatible participants are not active in each relevant pool. Indian consumers are price-sensitive and matching promises face substantiation risk; initial revenue assumptions must be validated.

## 2. People and jobs to be done

| Persona | Need | Non-negotiable risk | Core mode |
|---|---|---|---|
| New-to-city adult (23–35) | Reliable hobby companion | unwanted romantic solicitation | Friendship |
| Introverted adult seeking serious friends | Low-pressure, compatible introductions | harassment/ghosting | Friendship |
| Intentional dating adult (21–38) | Mutual values and expectations | stalking/catfishing | Dating |
| Matrimony-seeking adult | Serious shared-life preferences, family involvement only with consent | coercion, dowry, caste discrimination, unverified claims | Matrimony |
| Safety reviewer | Triage credible harm without uncontrolled access to intimate answers | privacy misuse/unsafe content | Operations |
| Support agent | Resolve payments, account access, appeals | excessive privileges | Operations |
| Psychometrics steward | Publish defensible question-bank versions and monitor bias | pseudoscience, overinterpretation | Research |

Age ranges are research cohorts, not hard exclusions. Product enrollment initially **18+**; adults should not be excluded merely by age. Questionnaires should work in English and later Indian languages with tested translations rather than machine-translated psychometric claims.

## 3. Business objectives (provisional gates)
- **B01** Demonstrate sustained connection: at least 20% of consenting introduced pairs mutually confirm a second interaction at day 30 in controlled cohort; threshold is an experiment target, not a market benchmark.
- **B02** Measure matching lift: test deep questionnaire vs interest/availability-only control on 30-day continued connections; launch deep-model differentiation only if measurable net benefit.
- **B03** Establish trust: safety incidents per 1,000 conversations, complaint acknowledgement, resolution times, repeat-offender rate and verified appeal outcomes; zero tolerated unaddressed critical incidents.
- **B04** Maintain economically sustainable operation: positive contribution per paying cohort after payment fees, infrastructure, fraud, refunds, human moderation and support—not just gross subscription receipts.
- **B05** Meet applicable Indian requirements and avoid data overcollection before launch.
- **B06** Preserve provider portability so D1/Workers can eventually be replaced without changing user domain concepts.

## 4. Product strategy: one account, three guarded contexts
- User chooses at least one intention, can change them, and can pause each independently.
- Never expose a friendship profile in the matrimonial pool automatically; no cross-mode message access, recommendations, group auto-enrollment or sensitive-profile reuse without explicit permission.
- Each mode has separate intent, visibility, answer-sharing rules, eligibility, filtering, discovery permissions and communication request workflows.
- Shared immutable identifiers and authentication reduce friction; distinct **mode persona** records reduce accidental exposure.
- No assurances that a user is a spouse, safe, truthful, eligible for marriage or medically/psychologically compatible merely because they complete a quiz.

## 5. Competitive alternatives and differentiated hypothesis
Comparable features exist in **OkCupid** (question compatibility), **We3** (friendship psychographics), **Boo** (personality matching), **Dimensional** (trait profiling), **TrulyMadly**, **Aisle**, **Schmooze**, **Betterhalf**, **Hinge**, plus existing **WhatsApp/Discord/Meetup** communities. AI-twin vendors claim similar avatar matching, but independently validated Indian outcome data is scarce. Kithra's defensible difference, *if proven*, is clearer three-context intent separation, explainable complementarity, practical safety and observed continuation of real relationships. The word "soul twin" is a user-friendly metaphor, not evidence of neurological identity.

## 6. Scope and exclusions

**Initial validated MVP:** account registration, mode consents and personas, limited quiz placeholders backed by versioned definitions, precomputed non-clinical trait summaries, mode-scoped match discovery, mutual requests, basic private chat, blocking/reporting, limited moderated groups, settings/data-rights, administrative triage, paid entitlements only after trust flows.

**MVP+ (after 90 days):** question bank expansions, score-band explainers, friend activities, notification digests, paid tiers, admin quiz publishing and blinded A/B evaluation.

**Later:** optional AI companion that summarizes *only expressly authorized user-provided traits*; supervised community organizers; native mobile apps; deeper matching calibration; multilingual cultural adaptation; family introduction controls in matrimony. Voice/video calls, face recognition, Aadhaar collection, involuntary sensitive trait inference and "AI brain replicas" are **out of MVP**. Persona simulation requires separate research, opt-in, opt-out, retention, guardrails and new privacy assessment.

## 7. Revenue strategy, acquisition and risks
- Free core: taking assessments, seeing basic summaries, discovering a useful number of users, blocking/reporting, deleting account, baseline chat after mutual connection.
- Premium: advanced filters, extended but rate-limited introductions, detailed opt-in comparison reports, private circles, non-safety convenience features; no priority to bypass other users' preferences.
- Matrimony may have separate paid plan later, but **must not bundle guaranteed match or marriage outcomes**.
- Acquisition: city/college-alumni/professional-cohort launches with a local density plan; referrals through genuinely useful shared experiences, not pressure.
- Key risks: adverse selection, ghosting, low women's safety confidence, cultural/marriage coercion, deceptive profiles, privacy catastrophe with intimate data, spurious psychometric certainty, high customer acquisition cost, payment disputes.

## 8. Operating model
Roles: founder/product owner; part-time moderator/on-call safety owner; qualified privacy counsel; independent security reviewer; psychometric advisor; technical owner. An unstaffed complaint channel is not acceptable for a live strangers-connected-to-strangers product. Establish availability and escalation coverage before wide launch.

**Business approvals required:** MVP positioning; allowed age; all three distinct mode eligibility policies; legal entity/contact details; pilot budget; moderation coverage; first price experiment; marketing claims; cancellation/refund policy; decision to permit profile photos and uploads.

## 9. Release/investment gates
**Gate A:** 20–30 interviews, 50+ opted-in adult pilot registrations, evidence of user-need. **Gate B:** controlled cohort with safe introductions and follow-up evidence. **Gate C:** engineer/legal/security sign-off for paid public beta. **Gate D:** expand matching categories only after no worsening in safety and demonstrable improved connection outcome. Each gate has recorded go/no-go decision.



---


# PRD — Product Requirements Document

**Version 1.0 — product specifications, not existing capabilities.** The supplied repository is a visual prototype with simulated auth, reports, matches, messages, billing, security and admin numbers; no mock outputs may be presented as live data.

## 1. Information hierarchy and conceptual vocabulary
- **Account:** authenticating human, internal `user_id`, lifecycle and safety state.
- **Persona:** user's mode-specific public identity: FRIEND, DATE, MATRIMONY. Each mode separately chooses display name, visibility, photos, discovery region, preferences and communication constraints.
- **Assessment:** quiz attempt using a fixed published bank version, unique order seed, explicit consent and response audit trail.
- **Profile vector:** bounded derived dimensions with confidence/coverage, not a physical "brain map".
- **Match candidate:** two eligible consenting personas subject to mutual mode, age, blocks, filters, privacy, location and risk policy.
- **Lens:** similarity/Mirror, difference/Counterpoint, complementarity/Mosaic, overall Resonance. Match score is index-based, not relationship success probability.
- **Introduction:** express mutual opt-in; creates chat authorization only after request accepted.
- **Circle:** user-created topical community with rules and permissions; optional privacy mode.
- **Case:** safety/support complaint with ticket, evidence, timestamps, dispositions, appeal rights and restricted operator access.

## 2. Product-level state machines
**Account:** `invited -> pending_verification -> active -> restricted -> suspended -> deleted` with additional `deletion_pending`. **Mode persona:** `inactive -> onboarding -> ready -> discoverable -> paused -> closed`. **Quiz attempt:** `assigned -> in_progress -> submitted -> scored` or `expired`, `withdrawn`, `invalidated`. **Introduction:** `requested -> accepted -> closed` or `declined`, `expired`, `blocked`. **Message:** `accepted -> persisted -> delivered -> seen` (read-receipt only with user preference). **Report:** `open -> triaged -> investigating -> actioned -> resolved` or `escalated`, `appealed`.

## 3. Journeys
### J01: Arrive and explore
Public landing → transparent how matching works (and its limits) → choose initial mode(s) → sign up via Firebase → verify email → adult age policy → accept current T&C and applicable notices → specify optional psychological profiling consent → choose private display details. No mandatory 100-question wall before the user knows what they will receive.

### J02: Start quiz
Quiz catalog → choose theme and consent scope → estimate time, progress and skipability → backend creates **versioned assignment** → resume across devices → submit subset/full set according to completeness rules → receive self-understanding summary with caveat, examples and score definitions. Quiz cannot claim a diagnosis.

### J03: Discover humans
Mode switcher → eligibility and preference checks → lens toggle (Mirror/Counterpoint/Mosaic) → band filter (100,90,80...10) representing descriptive *index intervals*, not precisely measured probabilities → preview profile with safe shared details → why-you-might-connect/possible friction with confidence → send request (caps and mutual eligibility) → receiver accepts/declines → optional conversation starts.

### J04: Establish trust
Any profile/message/group includes block, mute and report; block suppresses discovery, old requests and messages, without alerting blocked user; report captures safe evidence and case ID, allows immediate preservation where lawful, and acknowledgement. Report is accessible without payment.

### J05: Join/create Circle
Discover themed groups → membership request → accept rules → join thread → moderators manage members/content → creator moderation privileges limited to group, never global admin. Group invites must not expose undisclosed profile or intimate details.

### J06: Upgrade and cancel
Pricing context → clear entitlement list, taxes, renewal amount/date, cancellation → provider checkout → signed webhook to confirm entitlement → invoice and transaction history → cancel future renewal while honoring paid period → downgrade without losing core safety or user data → refund request and manual review.

### J07: Data rights
Settings → privacy control and consent dashboard → download requested structured export → edit/rectify persona → withdraw assessment sharing; delete derived scores or recalculate → request deletion with lawful retention disclosure, non-blocking progress and confirmation.

## 4. Feature epics, requirements and acceptance criteria

| ID | Epic / behavior | Release | Acceptance criteria |
|---|---|---|---|
| P-001 | Create account, verify email and log in | MVP | unverified users cannot enter discovery/chat; audited login; rate limited |
| P-002 | Configure mode personas independently | MVP | all fields/visibility scoped to selected mode; switching mode never leaks details |
| P-003 | Quiz catalog & placeholder themes | MVP | exactly 100 indexed placeholders per published themed set, drafts hidden |
| P-004 | Versioned assessment assignment | MVP | server assigns seed/version; idempotent save; resume across devices |
| P-005 | Consent-aware trait synthesis | MVP | rescoring deterministic; handles missing data; deletes on withdrawal |
| P-006 | Discovery with lens/band controls | MVP | no blocked, ineligible, or non-discoverable users in results |
| P-007 | Explanation and uncertainty | MVP | show evidence dimensions and confidence, not proof of guaranteed outcome |
| P-008 | Mutual connection request | MVP | cannot message until accepted, unless consented group policy allows |
| P-009 | Private text chat | MVP | durable server authorization, moderation triggers, delete/report |
| P-010 | Report, block and support ticket | MVP | reporting works under every paid/free state, admin case visible |
| P-011 | Private/public themed Circles | MVP constrained | creation gated; moderation queue and anti-spam, caps |
| P-012 | Admin RBAC and audit trail | MVP | no admin rights from frontend or client-provided role |
| P-013 | Consent/export/deletion | MVP | API job progresses and returns verifiable results |
| P-014 | Razorpay subscriptions | Pilot+ | signed webhook, idempotency, reconciled entitlements |
| P-015 | Multilingual quiz item bank | Post-validation | expert translation and measurement equivalence studies |
| P-016 | AI persona companion/simulated twin | Research only | separate consent, safety and model validation before shipping |
| P-017 | Voice/video calls | Later | cost, abuse, reporting and recording policies approved |
| P-018 | Family-assist matrimony introductions | Later | explicit per-participant approval; no family access by default |

## 5. Three relationship modes — deliberately different outcomes
- **Friendship:** shared interests, schedule compatibility, local region, platonic boundary, desired contact frequency; romantic approach through friendship is reportable unwanted contact after boundary communicated.
- **Dating:** adult-only, mutual declared dating intent, separate selective preference disclosure, opt-in to photos, romantic interest, family expectations where applicable; never infer sexual orientation from hidden questions.
- **Matrimony:** committed intent, voluntary family involvement, education/employment claims labeled self-declared unless independently verified, shared practical life plans, financial expectations, living arrangements; consent-based and anti-coercion safeguards. Avoid caste/religion as hidden ranking or moral merit measures; if legal counsel approves optional explicitly declared preferences, provide transparent user control and fairness monitoring.

## 6. Grouping taxonomy
Global neutral families **Origin** (introductory), **Currents** (thinking/communication), **Mosaic** (complementary roles), **Horizon** (life direction), **Rhythm** (daily habits), **Compass** (values orientation), **Bridge** (conflict repair), **Orbit** (shared interests). Localized expressions may describe preferences but must not rank communities or label them inferior, defective, high/low worth, alpha/beta. Group names must not imply mental diagnoses.

## 7. Content and notification policy
Preferences: product, safety/transactional, marketing separately; email digests default restrained and opt-out for nonessential notifications; no message-content previews on lock screens by default for dating/matrimony; safety notifications are mandatory where legally required; user can turn off activity indicators; no "your soulmate is waiting" fear-of-missing-out framing.

## 8. Edge cases
- Ambiguous self-report answers produce no definitive trait label; incomplete quizzes reduce confidence.
- Users can have multiple persona modes but must not match themselves or bypass prior blocks.
- Deleting account revokes active sessions, disappears from new discovery, and handles retained moderation/payment evidence by lawful schedule.
- Accepted chat counterpart changes mode or revokes consent → existing chat policy must remain clear; no silent mode conversion.
- Safety report against a match → immediate protection while appeal remains independent.
- Location changes → region updates opt-in, never broadcast exact coordinates.
- User under 18 at enrollment or suspected minor → restricted/closed pending safety review.
- Payment partially succeeds → entitlement only from trusted webhook, not redirect query params.
- Empty local matching pool → show transparent waitlist/interest Circles, not invented candidates.

## 9. Suggested success metrics
Eligible active pool by mode/city, quiz meaningful completion, user-reported comfort/safety, match requests accepted, 7/30-day mutual recontact, group recurring interactions, 1k-chat harm rate, complaint SLA, refund rate, 30-day paid retention, contribution margin. Segregate raw quiz telemetry and restrict analyst access.



---


# SRS / FRS / NFR — System & Software Requirements

Status: design targets; **not guarantees or verified benchmarks**.

## 1. Technical compatibility and environment
Client: semantic HTML, CSS/Tailwind v4, React 19 + TypeScript strict, Vite 8; TanStack Query or equivalent; React Router; `motion/react` (avoid shipping both old `framer-motion` and `motion` without reason), Zod validation. API: TypeScript Cloudflare Workers/Hono, Web Crypto and JOSE JWT verifier, Drizzle or prepared SQL for D1; separate packages for domain, identity, UI and adapters. Deploy via Wrangler, preview environments and GitHub Actions. Respect all platform runtime limitations; no assumption Node APIs work in Workers.

## 2. Functional requirement groups
**Auth:** FR-A01 verified email/password and Google; FR-A02 password reset; FR-A03 refresh token/session expiration; FR-A04 disabled-user revocation; FR-A05 brute-force protection; FR-A06 privileged admin identity plus MFA; FR-A07 data access request after reauth; FR-A08 email change verification.

**Privacy:** FR-P01 opt-in per relationship mode; FR-P02 quiz and analytics data processing notices; FR-P03 profile field-level visibility; FR-P04 redact/share summarized traits only; FR-P05 export; FR-P06 rectify; FR-P07 deletion queue; FR-P08 documented retention; FR-P09 audit consent notice version and timestamps; FR-P10 honor withdrawal and stop future matching.

**Quiz:** FR-Q01 published 100-item theme banks; FR-Q02 finite versioned attempts; FR-Q03 cryptographically random assignment order; FR-Q04 server-controlled item selection; FR-Q05 save/recover; FR-Q06 skip and revoke; FR-Q07 adaptive branching only with model governance; FR-Q08 no raw answer leakage in public APIs; FR-Q09 question localization; FR-Q10 separate quiz-author and publisher approval.

**Matching:** FR-M01 eligibility hard filters; FR-M02 similarity/difference/complementarity lenses; FR-M03 score-band filtering and counts; FR-M04 explanation; FR-M05 confidence and missing-data info; FR-M06 fairness/bias monitor; FR-M07 rate limiting; FR-M08 anti-sybil; FR-M09 respect blocks; FR-M10 opt-out/pausing.

**Social:** FR-S01 mutual request and spam caps; FR-S02 user text chat; FR-S03 moderated group threads; FR-S04 report message/profile/group; FR-S05 block/mute; FR-S06 media upload gated/scanned; FR-S07 admin case evidence; FR-S08 notifications; FR-S09 user-generated content moderation & appeal; FR-S10 anti-impersonation.

**Commercial:** FR-C01 entitlement catalog; FR-C02 billing checkout; FR-C03 signed webhook and idempotent ledger; FR-C04 invoice/receipt; FR-C05 cancellation; FR-C06 refund path; FR-C07 taxation and GST settings; FR-C08 price version immutability; FR-C09 plan expiry grace policy.

**Admin:** FR-O01 invitation-only admin creation; FR-O02 scoped RBAC; FR-O03 least-privilege case access; FR-O04 two-person critical action approval; FR-O05 PII reveal requires justification; FR-O06 write-only action evidence and tamper-evident audit exports; FR-O07 support tickets; FR-O08 report SLAs; FR-O09 analytics coarse/aggregated; FR-O10 emergency stop flag.

## 3. NFR/SLO targets — pilot and growth

| Dimension | Pilot target | How verified |
|---|---|---|
| API latency | p95 ≤ 700ms for simple API (excluding third-party calls), under representative regional traffic | Worker timings/trace |
| Public page UX | Core Web Vitals LCP ≤ 2.5s, CLS ≤ .1, INP ≤ 200ms on tested mid-range phones | Lighthouse + field RUM |
| Reliability | ≥99.5% monthly core API availability target, excluding documented external provider incidents | synthetic checks |
| Message delivery | >99.9% persisted for accepted messages; retriable and deduplicated | chaos and load tests |
| Data safety | automatic backups, recovery drill each quarter | restore tests |
| Encryption | TLS in transit, private media, key management & appropriate at-rest encryption | security review |
| Access | all PII endpoints authenticated and policy tested | automated permissions matrix |
| Accessibility | WCAG 2.2 AA target; reduced motion, keyboard access, contrast and live regions | axe + manual |
| Browser | current Chrome, Firefox, Safari and Edge; mobile responsive | browser matrix |
| Privacy | no raw psychological answers in client analytics or default log payloads | audit and DLP test |
| API abuse | per-route & per-identity token buckets and anomaly rules | abuse simulation |
| Data deletion | operational within published period except lawful holds | reconciliation job |

These are planning targets; calibrate on load tests and available infrastructure. No absolute 100% uptime promise.

## 4. Security acceptance contracts
Every request verifies `Authorization` token signature, issuer, audience, expiry, account active state, mode membership, operation permission, block relation and object ownership. Tokens alone never grant admin role; server DB `admin_memberships` is authoritative. Every PII read is audited at appropriate granularity. Content Security Policy, secure cookies (if session-based), strict CORS, CSRF protection where cookies used, no secrets embedded in bundles, CSP nonces/hashes, and safe HTML sanitization mandatory.

## 5. Operational error taxonomy
Return structured RFC 7807-style error with stable `code`, user-safe `title`, correlation ID, HTTP status and `retry_after` when applicable. No internal stack trace, source, other user's data or unverified probability in error. Frontend maps: invalid input 400, unauthenticated 401, unauthorized 403, invisible target 404, conflict 409, rate-limited 429, unavailable 503.

## 6. Engineering standards and definition of done
- TypeScript `strict=true`; formatting/lint; changes require reviewers, automated PR checks, migrations up/down with tested rollback; no shared production credentials.
- Every feature includes a threat model delta, event instrumentation with privacy review, empty/error/loading states, mobile accessibility, acceptance test, operator documentation.
- Automated unit, integration, contract, end-to-end, authz fuzz tests, webhook replay test and restore test.
- Deployment uses staged rollout, canary flags, documented runbooks, alert owners and incident communication templates.

## 7. Unsupported promises to prohibit
Do not label messages "Signal Protocol E2EE" without independently audited end-to-end key protocol. TLS + server-side encryption ≠ E2EE. Do not claim biometric or government-ID verification until service genuinely performs it with legitimate basis. Do not suggest "brain replica," "exact human twin," "clinical psychometrics," "scientifically guaranteed marriage" or "uncheatable quiz" in production copy.



---


# QRD — Questionnaire, Psychometric Research & Assessment Engineering

**Important:** all 100 items per theme are **placeholders by design**. There is no scientific validation at present. Professional psychometric review, consent and longitudinal validation precede use of high-stakes claims.

## 1. Objectives and risks
Collect only data needed to support user-understandable compatibility, not wholesale replication of a human brain. A psychological questionnaire cannot reconstruct consciousness, predict all behaviors, or truthfully prevent respondents from using AI. No hidden sexual-orientation, religion, caste, disability, trauma or mental-health classifier. If a trait is necessary for an explicitly selected dating/matrimony feature, obtain informed, separate, revocable consent for the exact trait and processing purpose; evaluate fairness and legality.

## 2. Proposed themes, each with 100-item **future** sets

| Theme | Short slug | Intended constructs | Releases |
|---|---|---|---|
| Reasoning & Decision Style | DECIDE | uncertainty tolerance, deliberation, problem approach | later pilot |
| Conversation & Conflict | CONNECT | feedback, repair, listening preference | early pilot |
| Values & Trust | COMPASS | reliability, honesty expectations, boundaries | early pilot |
| Emotional Coping | EQUILIBRIUM | self-reported emotion regulation and reassurance needs | expert-gated |
| Social Rhythm | RHYTHM | solitude, availability, activities, contact cadence | early pilot |
| Growth & Ambition | HORIZON | learning goals, career/life goals | later pilot |
| Family & Long-Term Plans | ROOTS | household/family orientation and life plans | matrimony only |
| Money & Practical Life | GROUND | spending, risk, household financial expectations | matrimony only |
| Interests & Curiosity | SPARK | books, art, technology, adventure, hobbies | early pilot |
| Complementary Collaboration | MOSAIC | negotiation, role preferences, task approach | research |
| Digital Boundaries & Privacy | SHIELD | contact boundaries, sharing and safety preferences | early pilot |
| Future Change & Resilience | TIDE | adaptation, moving cities, changes in commitments | later pilot |

Every theme is a **catalog** of versions: `CONNECT-v1-setA` (100 placeholders), `CONNECT-v1-setB` (100 different placeholders), etc. The user asked to avoid repeated questions: achievable by rotating versioned item banks, but mathematically impossible to promise unique items indefinitely with a finite catalog. Clearly limit re-use within a configurable interval and prioritize psychometric comparability over randomness.

## 3. Question model
Required: `question_id` UUID, `theme_id`, `item_bank_version`, `item_revision`, `locale`, `body_placeholder`, `response_type`, `choices`, `construct_ids`, `weighting_version`, `reverse_coded`, `sensitivity_class`, `consent_purpose`, `estimated_seconds`, `active`, `effective_at`, `retired_at`, `psychometric_review_id`, `experiment_group`, `accessibility_label`, and `display_constraints`. All placeholder text must be rendered with **"Draft item—do not infer psychological meaning"** in nonproduction.

Response forms: forced choice, 5/7 point Likert, situational judgment, ranking, optional open text. Free-text high sensitivity requires separate opt-in, moderation/data-minimization and training-data ban by default. Randomize response-option order only when it cannot change interpretation (e.g. do not shuffle Likert scale endpoints). No deceptive "magic trick" claims.

## 4. Quiz assignment / selection
1. Server authenticates user and confirms relevant mode consent and theme eligibility.
2. Server locks a published quiz version, selects from a sufficiently large pool, uses cryptographically secure randomness to make a stable order seed, and stores an encrypted/opaque assignment ID.
3. Exclude items recently seen within policy window, while preserving required anchor items used for score comparability.
4. Deliver a small batch of signed item IDs (not trait weights); answers posted incrementally with `attempt_id`, `item_id`, `revision`, `answer`, and idempotency key.
5. On submit, server validates assignment completeness, consistency, quotas and selected validity signals. Flag anomalies for **retest**, not automatic accusation.
6. Derive traits server-side using a published scoring version; retain enough audit to reproduce the score while respecting deletion and retention schedules.
7. Recalculate all dependent matches if user withdraws consent or a scoring bug is corrected; queue updates and inform users of material changes.

## 5. Anti-gaming—what is realistic
Question-order randomization, alternate wording, scenario variations, lie/social-desirability scales only if validly assessed, test-retest drift analysis, timing anomaly flags (not simplistic AI detector), response consistency checks, rate limits, batch visibility, soft trust flags, optional corroborating experiences over time, bias review and abuse dispute. **Cannot prevent AI usage, nor prove genuine personality from answers alone**. Do not penalize disabled or slow-reading users for time spent.

## 6. Psychological validity and method
- Pre-register constructs and intended score interpretation before collecting data.
- Use peer-reviewed instruments only with license/attribution, Indian language/cultural validation and professional oversight; no diagnosis.
- Conduct cognitive interviews (what does the question mean), pilot item analysis, reliability and temporal stability, dimensionality, convergent/discriminant validation, measurement invariance across relevant demographics if lawfully collected, and outcome validation.
- Avoid assuming Big Five, MBTI, attachment style, "love languages" or proprietary archetypes are interchangeable; each has a different evidentiary basis.
- Compare extended questionnaire against short baseline; report differential attrition and sample-selection effects.
- No outcome interpretation unless suitable representative holdout validation exists; all percentages labeled index agreement and model version.

## 7. Versioning & scoring integrity
`assessment_attempt` binds one exact `item_bank_version`, `scoring_version`, `consent_receipt_id`, pseudonymous member ID, assignment digest, start/end. `score_snapshot` immutable versioned derivation and optional invalidation cause; never overwrite historical score silently. API does not return weights, sensitive responses, anomaly flags or model internals to other users.

## 8. Sample machine-readable placeholder
See `scaffolds/quiz-placeholder.schema.json`. A seed generator should produce `Q001`–`Q100` for each selected theme and set, all with `status:'placeholder'`. They are **not administered in production** until author, psychometric reviewer, legal/privacy reviewer and publishing admin approve.

## 9. Definition of done for a real quiz bank
All 100 published items have clear constructs, age appropriateness, reasonable answer burden, accessibility, localized wording review, no biased or invasive hidden inference, agreed opt-out/skip behavior, validated scoring parameters, supporting documentation, consent notice, model card, adversarial retest, reproducibility tests, and a signed release approval.



---


# MRD — Matching, Compatibility Lenses, Identity Taxonomy & Model Governance

## 1. Governing principle
Kithra's numerical match measure is a **model-defined agreement index**, not the probability that two humans will have a successful friendship, date or marriage. `100%` means index maximum given measured dimensions with sufficient coverage; `0%` means measured divergence according to index; never "destined" or "perfect soul". Restrict scores when confidence/coverage is too low.

## 2. Proposed categories and user-friendly labels
- **Mirror Twin**: unusually similar measured scores across selected traits; not identical brains.
- **Counterpoint**: unusually different measured traits; could be interesting, not necessarily compatible.
- **Mosaic Fit**: modeled *complementarity* on a defined set of role/behavior preferences, with mandatory shared boundaries and consent.
- **Resonance**: broad mode-specific shared aims and styles.
- **Horizon Match**: shared growth and future-life goals.
- **Circle Match**: shared activity/community interest.
- **Quiet Harmony**: similar communication pace, not an innate personality class.
These are UI labels under test, not clinical diagnoses, personal worth labels or fixed human castes/classes.

## 3. Eligibility precedes scoring
`eligible(u,v,mode)` requires verified-active adult accounts, same consented mode, each discoverable and allowlisted by region/visibility, no blocks/reports requiring hold, compatible disclosed preferences, age policies, no duplicate/self, within request quotas, not fraud-restricted. Dating/matrimony must respect explicit reciprocal orientation and relationship preferences *only if voluntarily provided for that mode*; no inferred sexual orientation. All hard filters are non-negotiable; **no high score may override consent or a block**.

## 4. Example computational framework (hypothesis, not validated)
For two users, normalize psychometric traits `x_i` and `y_i` to [0,1], and derive `w_i >= 0` from mode-specific published model version. Let `present_i` reflect both having sufficient reliable data, and `confidence_i` be trust in measurement.

`similarity = 100 * Σ(w_i * confidence_i * present_i * (1 - |x_i-y_i|)) / Σ(w_i * confidence_i * present_i)`.

`difference = 100 * Σ(w_i * confidence_i * present_i * |x_i-y_i|) / Σ(w_i * confidence_i * present_i)`.

`complementarity` is NOT simply `difference`: it requires an empirically defensible pairing function for particular preference pairs, and must respect shared values and safety boundaries. Example: one prefers planning and the other prefers spontaneous activities; this may cause friction, not balance. Until validated, expose it as *possible complementary preferences* and let both humans decide.

`score_coverage = Σ(w_i * present_i) / Σ(w_i)`; do not show precision/bands when coverage below a predeclared confidence gate (initial proposal: 70%, to validate). Report rounded intervals/bands (90–100,80–89...10–19) with note "model index", not false exact numeric certainty. UI may offer `100 / 90 / ... / 10` filters only if these represent bucket upper endpoints rather than a claim of 100% psychological accuracy.

## 5. Mode-specific weights (provisional; must be tested)

| Dimension | Friendship | Dating | Matrimony |
|---|---:|---:|---:|
| Shared social activities | 20 | 10 | 5 |
| Communication & conflict | 20 | 25 | 20 |
| Values / boundaries | 25 | 25 | 25 |
| Time / geographic availability | 25 | 15 | 10 |
| Future plans / practical life | 5 | 15 | 30 |
| Complementary habits (validated only) | 5 | 10 | 10 |
| **Total** | **100** | **100** | **100** |

Do **not** present these as scientifically established weights. They are initial hypotheses for offline experimentation. No scoring on protected categories as proxy for worth. A user may disclose religion or other preferences voluntarily but any use in rankings must pass counsel/privacy/fairness review.

## 6. Twin, opposite and puzzle fairness
- Mirror: high similarity + adequate reliability and coverage.
- Counterpoint: high difference; the description says "interesting contrast" not "your destined anti-soulmate".
- Mosaic Fit: specific observable complementarity with **mutual confirmation**; never assert that one partner "fixes" another or can repair illness, trauma, abuse or moral deficiency.
- Population sizes: never claim there is a 100% mirror candidate if nobody meets threshold; transparent empty state.
- Avoid exposure amplification: ranking should balance relevance, new users, fairness, safety and available attention; not always promote already-popular profiles.

## 7. Pair outcome feedback and responsible learning
Collect explicit minimal feedback after actual interactions: comfortable?, mutually wish to continue?, met safely?, contact again at D7/D30? No covert analysis of private messages to infer romance/sexuality. Use consented aggregated outcome analysis to test whether scores predict continuation better than simple baseline; account for selection bias and missing responses; do not train AI models on chat content without a fresh, separate opt-in.

## 8. Match explanation design
For each candidate show: compatible mode, explainable top 3 dimensions, 1–2 possible challenges framed neutrally, data confidence, "What we have not measured," quick block/report, a note that humans are more than an index. Never expose the other's raw quiz answers; only share traits each party specifically marked public in that mode. Disabled or privacy-restricted profiles should not be included.

## 9. Offline experiments and model governance
Maintain model registry: `model_id`, `version`, `data lineage`, source questionnaire versions, construct definitions, consent basis, fairness results, holdout methodology, release date, rollback trigger, owner and known limitations. Use deterministic scoring for initial release. LLM may help write explanations from **approved summarized traits**, not decide hidden suitability or infer sensitive classes. Test adversarial manipulations and demographic outcome disparity lawfully. Human override only for safety/remediation, never secretly force romantic matches.

## 10. Latency & scaling
Use batch match generation on quiz submit/consent change with durable queue; indexed candidate retrieval by mode/region/interest; local top-N rerank in Worker CPU budget; materialize top candidates and lens scores in D1 with model version/time-to-live. Cache non-sensitive cohort counts; never cache private scores across users. For 100k+ active users consider dedicated vector DB/Postgres and async scoring service after measurement, not preemptively.



---


# SAD / TAD / ADR — Serverless Architecture, Operations & Server Migration

**Architecture decision:** Cloudflare Pages + Workers + D1 + R2 + Durable Objects + Queues, Firebase Auth, Razorpay (India) for the validated pilot. Workers API can later move to Node.js or container services; D1 can later move to PostgreSQL; R2 uses S3-compatible storage API. This is a target, not a claim that the source ZIP already runs on Cloudflare.

## 1. Current concept ZIP versus target
The ZIP uses Vite/React 19/TypeScript, Tailwind 4, Motion/Framer Motion, component-level `useState` and static data; `src/App.tsx` sets `DEFAULT_REPORT` and mock matches. `src/components/AuthModal.tsx` demo OTP accepts six digits and admin condition accepts any nonempty password. `src/components/AdminView.tsx` displays hardcoded sample cases and metrics. `src/components/SecurityView.tsx` claims Signal E2EE but simulates export. No production database, API, authorized messages, billing webhooks, data-rights service or admin auth is shown. **Retain UI-independent reusable TS components; replace the untrusted interaction and state logic.**

## 2. Context architecture
```mermaid
flowchart LR
  Browser[React/Vite Pages] -->|Firebase ID JWT + TLS| API[Workers / Hono API]
  Browser -->|Firebase login| Firebase[Firebase Authentication]
  API -->|SQL prepared queries| D1[(D1 relational data)]
  API -->|Private media signed access| R2[(R2 objects)]
  API -->|room coordination| DO[Durable Objects / chat]
  API -->|jobs| Q[Cloudflare Queues]
  Q --> D1
  API <-->|signed checkout/webhook| RP[Razorpay]
  API --> OBS[Logs/metrics/error alerts]
  Admin[Admin Pages / Access] -->|strong MFA + RBAC| API
```
Do not allow direct browser D1 access. Auth JWT verification is local at edge with Google public signing keys and verified `aud`, `iss`, `exp`, `sub`; also check the Kithra account's `disabled`, `token_valid_after`/session-revocation state from D1. Cache public keys with HTTP TTL, implement fail-closed validation. This avoids embedding Firebase Admin SDK assumptions in Workers.

## 3. Repos/packages and boundaries
```
apps/web/                 # public app + authenticated user workspace
apps/admin/               # distinct admin frontend / origin
apps/api/                 # Workers entry + routes + Durable Objects
packages/ui/              # accessible token-based components
packages/domain/          # pure TS entities, policies, scoring (no Cloudflare SDK)
packages/contracts/       # Zod + OpenAPI types and events
packages/adapters/        # interfaces + D1/R2/Firebase/Razorpay adapters
packages/observability/   # scrubbed structured logs and tracing
migrations/d1/            # forward/rollback schema migrations
infra/wrangler/           # env-specific deployment, flags
research/quiz-banks/      # non-prod placeholders and review metadata
```
Dependency rule: domain cannot import D1/Cloudflare/Firebase/React. API uses `UserRepository`, `AssessmentRepository`, `ObjectStore`, `AuthVerifier`, `PaymentGateway`, `EventBus`, `RealtimeChannel`, `SecretsProvider` interfaces injected from provider adapters.

## 4. Cloudflare resource decisions
- **Pages:** static Vite bundle; preview branch builds; route fallback for SPA; `Content-Security-Policy` and secure headers. Pages Functions count against Workers usage, so a single Hono API Worker is easier to monitor.
- **Workers:** Hono HTTP routing, validation, authorization, scoring small batches; Free includes 100k requests/day and 10ms CPU per invocation; scheduled/queue and heavy ML tasks must stay within product limits and be offloaded to paid plans or external service.
- **D1:** relational entities and indexes; Free 5 million rows read/day, 100k rows written/day, 5GB account storage but only **500MB maximum per individual Free database**; constraints reset by plan. Favor compact rows, indexes and TTL; store media in R2; do not store entire chat media or raw embeddings in D1. Paid individual DB up to 10GB subject to current docs.
- **R2:** private avatars, consented media, temporary exports with lifecycle deletion; Standard Free 10GB-month, 1M Class A and 10M Class B operations/month. Bucket/private objects require signed APIs; default public bucket disabled; short-lived signed reads, MIME sniffing and malware scan process.
- **Durable Objects:** optional per-room chat coordinator using SQLite backend supported on Free; WebSocket hibernation and persistence. **D1 persists message records** and DO handles presence/fanout; DO isn't a permanent single source of truth for all conversations. Per-room authorization on join and every command; protect against message spoofing.
- **Queues:** welcome notifications, transcript-safe score recompute, email, media scanning, deletion and export jobs; 10,000 free operations/day as checked; DLQ, retry, idempotency. No critical report relying solely on eventually processed queue—immediate case persistence first.
- **Cron:** overdue grievance escalation, retention sweep, billing reconciliation, expired requests, consent revocation cleanup, backup verification and analytics aggregates.
- **Turnstile/WAF/Rate Limits:** bot reduction not security replacement; dedicated token buckets keyed by authenticated ID and risk IP.

**Official verified docs:** https://developers.cloudflare.com/workers/platform/pricing/ ; https://developers.cloudflare.com/d1/platform/pricing/ ; https://developers.cloudflare.com/d1/platform/limits/ ; https://developers.cloudflare.com/r2/pricing/ ; https://developers.cloudflare.com/durable-objects/platform/pricing/ ; https://developers.cloudflare.com/queues/platform/pricing/ . Verified 2026-11-01. Prices and feature limits must be rechecked at implementation time.

## 5. Authentication ADR-001: Firebase Auth or Supabase Auth?
| Decision factor | Firebase Auth | Supabase Auth |
|---|---|---|
| Email/password and Google | supported, recommended initial | supported |
| Phone OTP | available, SMS charged; enable later | phone requires SMS provider and associated charges |
| Cloudflare Worker JWT validation | RSA public keys/JWKS-like Google cert endpoint; manual validation | project JWKS with asymmetric signing keys (check key configuration) |
| Persistence fit | D1 primary, Firebase only for identity | Supabase project introduces idle Postgres if not using it |
| Free allowances | provider-dependent, Identity Platform 50k tier1 MAUs before charges | free 50k MAUs; inactive project may pause |
| Migration | independent Kithra user ID and provider identities | likewise |

**Decision:** Firebase for pilot, with email/password or Google, verified email and no mandatory phone. Future phone must use abuse budgets. Admins use a separately authenticated email/password sign-in with strong MFA (passkey/TOTP as supported by selected provider), server-side role and optionally Cloudflare Access protective layer. A secret URL/email/password **alone is insufficient**. No open admin registration; seed first superadmin through secure audited setup, not frontend.

## 6. Authentication token and session design
`external_identity(provider, subject)` maps to Kithra `users.id` UUID (not the email, phone or Firebase UID as the long-lived domain key). Worker validates issuer/audience/time/signature and retrieves active account. New users require verifiable user/email action; new admin membership requires dual approval for privileged roles. Credential reset and email changes revoke privileged sessions. Sessions expire and are rotated; revocation within bounded window documented. For high-risk admin action demand recent reauthentication and second approver.

## 7. Payments ADR-002
Use Razorpay Checkout/Subscriptions where the merchant account and the exact plan/auto-debit mechanism are approved and live. Browser success redirect is never authority. Verify signed webhook HMAC on raw body, deduplicate provider event IDs, write payment ledger before entitlement change; compare local state against gateway periodically. Do not store card details. Monthly/quarterly/half-yearly/annual offers require clear taxes, renewal, consent and cancellation; review RBI e-mandate support for each method.

## 8. Data location & privacy caveat
Cloudflare D1's default location is automatic; its jurisdiction controls are not equivalent to a guaranteed Indian-only region. Firebase may store/process identity data in chosen provider infrastructure; verify terms, subprocessors, transfers and data residency before using it for intimate data. No unverified claim that all data remains physically in India. Encrypt raw responses at field/application level using audited key management and limit decryption to scoring services; retain keys out of code and source. Revisit localization laws with counsel.

## 9. Cost and failure management
Pilot volume model: 1,000 signups × 3 modes × 2 themes ×100 answer records can create 600k answer rows, quickly stressing DB and writes; use assignment-completion snapshots, compact indexed records and batch API operations, not raw new row per UI keystroke. Chargeable variables: Workers request/CPU, D1 rows and storage, DO message operations, R2 ops/storage, Firebase SMS, email transactional sends, media moderation, payments, support and legal. Set budget alerts and **hard feature-level limits**; avoid runaway async model inference. Do not forecast ₹0 hosting for a real community without traffic tests.

## 10. Server migration blueprint
**Trigger options:** increased active users and writes, D1 query hot spots, requirement for complex vector searches, regulatory hosting commitments, heavy media/ML workloads, or 99.9%+ supported SLA. **Target A:** Cloudflare Pages + API Node.js containers on managed VM/Kubernetes + PostgreSQL + Redis + S3-compatible objects + Firebase or migration to self-owned auth. **Target B:** keep Workers as public API gateway and migrate only matching/SQL to Postgres service. Steps: (1) create repository adapters; (2) shadow reads and reconcile; (3) bulk export and PII-preserving import; (4) dual-write outbox with idempotent replay; (5) read routing feature flag; (6) compare counts/foreign keys/hashes; (7) promote new system; (8) rollback within a test-proven RPO; (9) maintain deletion tombstones across all replicas/backups. Migration requires tested security model parity.

## 11. Operational playbooks
Build + test per pull request, preview deploy, staging smoke tests, signed release, production canary, RUM and alerts, daily encrypted backup verification, monthly manual restore test during pilot, periodic vulnerability scan, quarterly incident tabletop. Keep separate Cloudflare/Firebase/Razorpay administrator accounts with strongest available MFA and at least two emergency authorized owners; secrets rotation documented. Emergency switch disables discovery/chat while still allowing account/data-rights and safety access.

## 12. Architecture decision register (ADRs)
ADR001 Firebase Auth (accepted provisionally). ADR002 Razorpay (pending merchant approval). ADR003 D1 primary relational (pilot only). ADR004 R2 private files (accepted). ADR005 no fabricated E2EE (accepted). ADR006 opaque explainable score bands not probability (accepted). ADR007 18+ pilot (accepted pending legal review). ADR008 separate mode personas (accepted). ADR009 PII/psychometric protection by field-level encryption and service isolation (requires technical spike). ADR010 admin on separate origin with MFA+RBAC+audit (accepted).



---


# DRD / API-RD — Data Model, API Contracts & Events

**Contract principle:** all writes server-validated and idempotent where retries are expected. All selected IDs are opaque, globally unique UUID/ULID; do not expose Firebase UID as primary. Timestamps ISO 8601 UTC. Column and endpoint names are proposals and should be synchronized with migrations / OpenAPI.

## 1. Domain database entities

| Entity | Key data and foreign keys | Important invariants |
|---|---|---|
| users | id, account_status, min_age_verified, created_at, deleted_at | one individual, unique internal ID, deletion holds |
| external_identities | id, user_id, provider, provider_subject, last_verified_at | `(provider,subject)` unique; no trust in client email |
| mode_personas | id, user_id, mode, public_name, visibility, bio, region, status | unique `(user,mode)`, mode-specific fields and blocks |
| mode_consents | id, user_id, mode, notice_version, scope, granted, occurred_at | explicit event history; withdrawal not overwritten |
| profile_fields | id, persona_id, field_key, cipher_value, visibility | privacy tiers; encrypt sensitive values |
| question_themes | id, slug, locale, status | theme is neutral and configurable |
| question_banks | id, theme_id, version, locale, publish_state | immutable after publication |
| questions | id, bank_id, ordinal, text, response_schema, construct_mapping_ref | public API strips traits/weights |
| quiz_attempts | id, user_id, bank_id, seed_ref, status, assigned_at, submitted_at | cannot switch version mid-attempt |
| quiz_assignments | id, attempt_id, question_id, sequence | stable assigned order; unique question/attempt |
| quiz_answers | id, attempt_id, question_id, encrypted_value, updated_at | at-rest application encryption, personal data |
| trait_snapshots | id, user_id, mode, model_version, coverage, encrypted_vector | private by default, immutable version |
| match_snapshots | id, source_persona, target_persona, mode, lens, score_band, model_version | server eligibility verified on retrieval |
| requests | id, from_persona, to_persona, mode, status, expires_at | idempotent duplicate handling; blocked no access |
| conversations | id, mode, membership_version, status | no cross-mode chat accidentally |
| conversation_members | conversation_id, user_id, joined_at, muted | authorized participants only |
| messages | id, conversation_id, sender_id, body_cipher_or_ref, created_at | immutable sender, per-convo sequence |
| circles | id, mode_scope, name, rules_version, visibility, moderation_status | includes privacy and admin policy |
| circle_members | circle_id, user_id, role, state | group roles not platform admin |
| circle_posts | id, circle_id, author_id, body_ref, moderation_state | reports and retention rules |
| blocks | blocker_id, blocked_id, mode_scope, created_at | immediate bilateral discovery suppression |
| reports | id, reporter_id, subject_type, subject_id, category, severity, created_at | reports retained confidentially |
| moderation_cases | id, report_id, assigned_team, priority, state, due_at | appeal and evidence trace |
| case_actions | id, case_id, actor_id, action, rationale, at | immutable-style append-only log |
| support_tickets | id, requester_id, category, state, assignee_id | minimized PII; service SLA |
| admin_memberships | admin_user_id, role_id, state, mfa_verified_at | superadmin grant only via approved workflow |
| roles, permissions, role_permissions | normalized scope, action | capability matrix centrally enforced |
| audit_events | id, actor_id, target_ref, action, metadata_redacted, at, hash_chain | no raw sensitive answers/log payloads |
| payment_customers | user_id, gateway_customer_id | provider ref only; no card data |
| plan_catalog | id, code, price_minor, currency, term_days, visibility | versioned prices/taxes |
| subscriptions | id, user_id, gateway_sub_id, plan_version, state, period_end | webhooks authoritative |
| payments | id, provider_event_id, amount_minor, currency, result | unique provider event ID |
| entitlement_grants | user_id, feature, quota, expires_at, source | no safety features gated |
| rights_requests | id, user_id, type, status, deadline, completed_at | auditable export/erasure |
| export_jobs | id, user_id, object_key, expires_at, state | expiring signed link in private bucket |
| retention_holds | id, subject_id, legal_basis, expiry, approvers | access-controlled, lawful only |
| feature_flags | id, audience, flag_key, enabled, version | no hardcoded toggles |
| notification_jobs | id, user_id, kind, state, attempts | channel preference respected |

**Data domains:** (1) identity (Firebase), (2) social/personas (D1), (3) derived assessments (D1 encrypted fields), (4) media/exports (R2 private), (5) support/audit (restricted D1 or isolated DB). Avoid exposing admin to raw quizzes in normal views; provide redacted summaries when appropriate.

## 2. Index and retention design
High-value indexes: `mode_personas(mode,status,region)`, `external_identities(provider,subject)`, `questions(bank_id,ordinal)`, `quiz_answers(attempt_id,question_id)`, `requests(to_persona,status,created_at)`, `messages(conversation_id,created_at)`, `reports(status,created_at)`, `moderation_cases(state,due_at)`, `subscriptions(user_id,state)`, `payments(provider_event_id)`, `audit_events(target_ref,at)`. Every dataset has classification, declared purpose, retention trigger, deletion mode, processor and access role. Do not add broad PII indexes without need.

## 3. REST API v1 (representative)

| Method | Endpoint | Permission / behavior |
|---|---|---|
| GET | `/v1/me` | logged-in profile and consent state |
| PATCH | `/v1/me` | self only, permitted fields, reauth if sensitive |
| POST | `/v1/me/modes` | activate one mode with appropriate notice |
| PATCH | `/v1/personas/{id}` | owner and matching mode only |
| GET | `/v1/quiz/themes` | public approved catalog; localization |
| POST | `/v1/quiz/attempts` | assign versioned question bank; auth |
| GET | `/v1/quiz/attempts/{id}` | owner only, no trait weights |
| PUT | `/v1/quiz/attempts/{id}/answers` | idempotent upsert; ownership + schema |
| POST | `/v1/quiz/attempts/{id}/submit` | score async and return job/status |
| GET | `/v1/reports/me?mode=friend` | own derived report only |
| GET | `/v1/discovery?mode=friend&lens=mirror&band=80` | enforce consent, blocks, fraud gate |
| POST | `/v1/introductions` | one-user request with quota |
| POST | `/v1/introductions/{id}/respond` | receiver action only |
| GET | `/v1/conversations` | members only |
| POST | `/v1/conversations/{id}/messages` | member, rate/abuse gated |
| POST | `/v1/blocks` | immediate user protection |
| POST | `/v1/reports` | reporting works free and after block |
| GET/POST | `/v1/circles`, `/v1/circles/{id}/join` | contextual membership |
| POST | `/v1/payments/checkout` | entitlement catalog + provider checkout |
| POST | `/v1/webhooks/razorpay` | signed raw body, not user-auth |
| POST | `/v1/rights/exports` | self + reauth, rate-limited |
| POST | `/v1/rights/deletion` | self + reauth + retention explanation |
| GET | `/v1/admin/cases` | admin claim + case read capability + MFA |
| POST | `/v1/admin/cases/{id}/actions` | permission, reason, audit and double-check |
| POST | `/v1/admin/invitations` | admin-management grant only; never client role |
| GET | `/v1/admin/audit` | security auditor or superadmin scoped |

See `scaffolds/routes.openapi.yaml` as minimal machine-readable skeleton; developer must expand every endpoint and generate typed clients.

## 4. Example API payloads
```json
{"mode":"friend","lens":"mirror","band":{"min":80,"max":89},"limit":20,"cursor":"opaque"}
```
```json
{"candidate_id":"p_opaque","lens":"mirror","index_band":"80-89","coverage":0.84,"explanations":["similar communication pace","shared preferred activities"],"caveat":"Compatibility index, not a relationship prediction"}
```
```json
{"question_id":"q_opaque","answer":{"choice_id":"a3"},"assignment_revision":1,"idempotency_key":"client-generated-unique"}
```
Responses must never include raw hidden item-trait weights, nonconsented protected characteristics, other users' private answers, service secrets, internal audit logs or unapproved verification artifacts.

## 5. Events, retries, eventual consistency
Events: `UserVerified`, `ModeConsentGranted`, `ModeConsentWithdrawn`, `QuizAttemptSubmitted`, `TraitSnapshotComputed`, `MatchCacheInvalidated`, `IntroductionAccepted`, `MessageSent`, `UserBlocked`, `ReportCreated`, `CaseEscalated`, `SubscriptionPaymentSettled`, `RefundIssued`, `AccountDeletionRequested`, `AccountErased`. Carry `event_id`, `schema_version`, actor, minimized payload, timestamp, aggregate ID, idempotency key. Use transactional outbox where possible; worker retries never double-charge, re-send abusive content or re-grant access. Consent withdrawal and blocks are synchronous in access policy even if cached matches update later.

## 6. D1 SQL scaffold caveat
`scaffolds/schema.sql` is only a core baseline for implementation and performance tests. It does not cover every table or encryption model described above. Security-sensitive and legal-retention behaviors must have migration review and explicit integration tests before deployment.



---


# Security-RD — Threat Model, Control Requirements, Incident Response

## 1. Highest-value assets
Real identities, addresses/regions, psychological responses, inferred traits, preferences across friendship/dating/matrimony, private messages, reports, intimate media, payment entitlements, administrator tools and security evidence. Breaches may cause stalking, coercion, discrimination, extortion or reputational harm: classify assessment data as highly confidential even where statute classifications differ.

## 2. Trust boundaries and critical threats
- Browser → API: JWT theft, CSRF/cookie misuse, forged identities, IDOR/BOLA, object injection, credential stuffing.
- User → matching pool: profile scraping, mass requests, catfishing, minors, harassment, hidden dating solicitation, deanonymization through score queries.
- Chat/groups → moderators: unsolicited sexual content, grooming, fraud, deepfakes, unlawful media, violent threats, doxxing; malicious report floods.
- Workers → D1/R2/DO: public object URLs, malformed SQL, stale permissions, insecure signed upload, message replay, unbounded cost.
- Payments → entitlements: webhook forgery, duplicate callbacks, stale subscription/grant, refunds not reflected, client-side checkout tampering.
- Admin → private data: insider overreach, mass export, privilege escalation, stolen admin session, unsupported account intervention, audit modification.
- AI/model → data: model prompt injection, exfiltration to third-party API, memorization, discriminatory profiling, unverified trait reconstruction.

## 3. Mandatory controls (MUST)
- **Auth:** Firebase verified JWT server-side, email verification, rotation/revocation model, rate limits, password recovery, admin MFA. Eliminate mock OTP/password gate entirely.
- **Authorization:** deny-by-default per action + object, persona/mode boundary; OWASP ASVS 5.0 controls; automated cross-tenant IDOR tests.
- **Admin:** invitation-only authorized identity, device/session policies, no solely client-side role checks, dual approval for mass data export/role grant/permanent ban; comprehensive append-only audit.
- **PII encryption:** TLS, service-managed encryption at rest plus envelope/field-level protection for raw answers, derived sensitive traits and report evidence; keys rotated via secrets management, access recorded; cache plaintext only transiently.
- **Messaging:** choose candid **server-accessible encrypted-at-rest messaging** for moderation-capable MVP and inform users. End-to-end encryption is later optional and requires a separate safety design and real cryptographic implementation; no "Signal" badge by analogy.
- **Uploads:** only allowlisted MIME+magic bytes, randomized opaque object key, antivirus scanning, stripping dangerous EXIF where appropriate, size/quota cap, thumbnail generation only in approved pipeline, signed downloads, no direct public media bucket.
- **Abuse controls:** rate limit login/OTP/introductions/chat/uploads; slow mode for new accounts; bot challenge after anomaly; confidence-based trust review without public social scores.
- **Logging:** redact answers, secrets, tokens, private message bodies, government IDs and exact region; append audit state transitions, correlation ID and actor.
- **Data rights:** deletion propagation to DB, caches, R2, queues, exports and analytics with retained-lawful-hold exception; backups lifecycle and expiry policy.
- **Supply chain:** dependency scanning, lockfile pinning, secret scanning, IaC review, signed deploy artifacts, minimal service accounts, staging/prod key segregation.

## 4. Security test cases
S01 unauthenticated read to every private endpoint →401. S02 valid user A attempts user B's quiz answers, export and chat →403/404. S03 user changes from friendship to dating and requests nonconsented private fields →forbidden. S04 blocked user continues websocket and sends messages →revoked immediately. S05 operator without `safety.evidence.read` opens intimate media →deny, audit. S06 replay signed payment event →no duplicated entitlement. S07 malformed signed upload or HTML masquerading as image →reject/quarantine. S08 disable account mid-session →existing credential invalidated by local state check. S09 CSRF/cross-origin post →reject. S10 simulated mass-match scraping →limiter, anomaly flag. S11 consent withdrawal removes recommendations regardless of stale cached scores. S12 malicious LLM output includes prompt-injected commands →never executes data-modifying actions.

## 5. Incident severity / response
- **SEV-0:** active intimate-data exfiltration, large breach, child exploitation emergency, confirmed admin compromise; immediate containment/on-call and counsel/regulatory escalation.
- **SEV-1:** credible severe harassment/stalking threat, major auth bypass, payment compromise; urgent investigator assignment and targeted protective suspension.
- **SEV-2:** user data export issue, moderate service disruption, repeated abusive content; bounded SLA, remediation and lessons learned.
- **SEV-3:** cosmetic defects, low severity false positives; planned fix.

Response sequence: detect → open case and immutable timeline → contain accounts/keys/routes → preserve needed evidence lawfully → assess impact and notification obligations → remediate → restore → validate → postmortem. Run tabletop exercises before launch. **CERT-In reportable incidents can trigger six-hour reporting**; future DPDP Rule 7 can require without-delay affected-person/Board notice plus a 72h detailed Board report; exact current effective dates and jurisdiction confirmed with counsel. Prewrite templates in admin console, never auto-send inaccurate claims.

## 6. Safety-policy fundamentals
Prohibit threats, fraud, impersonation, minors, nonconsensual intimate imagery, doxxing, stalking, sexual pressure after an explicit boundary, solicitation of money, hate/harassment and cheating/forced matrimonial practices where unlawful. Offer in-product block/report at all conversation touchpoints; optional mutual silence modes. Know limitations of self-report "verified" badge. For urgent threats present local emergency services instructions; Kithra is not a 24/7 emergency responder unless it truly staffs one.

## 7. Before launch sign-off
Independent application penetration test including admin, chat, D1 object IDOR and payment callbacks; evidence of restore drill; provider data processing contracts, admin permission audit, encryption key handling documentation, secure secret rotation, privacy impact assessment, live incident contacts and clear public security claims.



---


# Compliance-RD / PIA — India Data Protection, Platform Operations & Legal Readiness

**As of 1 November 2026. Legal drafting aid only; not legal advice or legal immunity.** India-specific status must be reverified immediately before launch. The platform cannot contract out of statutory duties. Build policies and controls around actual deployment and actual corporate entity.

## 1. Timeline you must not confuse
- **DPDP Act, 2023** notified staged commencement on **13 November 2025** under G.S.R. 843(E). Initial institutional/other provisions commenced then.
- Provisions scheduled **13 November 2026**: one-year items including Act s6(9) and specified rule(s) regarding consent managers. This does not itself force every ordinary startup to register as a consent manager.
- Major substantive processing/rights/security/breach provisions scheduled **13 May 2027** (18 months from 13 November 2025) under Act and DPDP Rules, 2025, G.S.R. 846(E). Compliance program should be ready before that date, not deferred until after.
- Existing **IT Act / 2011 SPDI rules**, where applicable, cover sensitive personal data categories including sexual orientation and mental health; exact transitional status/overlap requires counsel.
- **IT Intermediary Guidelines 2021 as amended 2026**, including February 2026 corrigendum, may govern Kithra if it qualifies as an intermediary hosting user content. Duties differ by classification and facts; do not label every platform a "significant social media intermediary" without threshold analysis.
- **CERT-In Directions dated 28 April 2022:** report specified cyber incidents within 6 hours, with additional requirements for certain entities/logs and applicable retention; implement reporting readiness. Other legal obligations may apply (consumer protection, payments, intellectual property, Indian criminal laws regarding stalking, obscenity, impersonation, dowry, etc.).
- **Consumer Protection (E-Commerce) Amendment Rules 2026**, as announced 10 September 2026, have an intended 1 January 2027 start; scope/application to Kithra subscriptions must be assessed.

## 2. Primary official evidence
DPDP commencement Gazette: https://egazette.gov.in/WriteReadData/2025/267647.pdf ; DPDP Rules text indexed: https://indiacode.ecourtsindia.com/rules/digital-personal-data-protection-dpdp-rules-2025-fe07b131/ ; MeitY/PIB explanatory release: https://www.pib.gov.in/PressReleasePage.aspx?PRID=2190014 ; Consolidated IT Intermediary 2026: https://master-meity.digifootprint.gov.in/documents/act-and-policies/information-technology-intermediary-guidelines-and-digital-media-ethics-code-rules-2021-it-rules-2021-IjM5QjMtQWa ; CERT-In https://www.cert-in.org.in/Directions70B.jsp ; E-commerce updates: https://www.pib.gov.in/PressReleasePage.aspx?PRID=2308759 .

## 3. Privacy impact assessment: map every processing purpose

| Collection | Purpose | Access | Sharing | Default retention idea (NOT legal conclusion) |
|---|---|---|---|---|
| Email, provider UID | account and recovery | identity service + restricted support | Firebase and transactional provider | while account + lawful records |
| Adult age confirmation | enforce 18+ enrollment | automated safety | no public display | minimum evidence necessary |
| Mode-specific display profile | chosen discovery | matched viewers per field policy | consented other users | active mode + deletion grace |
| Quiz raw answers | derive assessments | scoring service only | **never by default to another user** | until purpose fulfilled/withdrawal + lawful holds |
| Derived traits/model scores | matching | scoring service and owner | consented trait summaries only | current version; retire superseded snapshots |
| Exact location | not required for MVP | none | none | **do not collect** |
| City/region | local relevance | discovery service | coarse region if opted in | mode active |
| Chat messages | agreed correspondence, abuse evidence | participants; limited escalation staff | participants / specific legal process | published configurable schedule |
| Reports and case evidence | safety grievance, lawful evidence | assigned moderation team | required authorities where applicable | proportionate incident retention |
| Device/IP/rate-limit data | anti-fraud and security | security staff | hosting providers | necessity-based; counsel-reviewed |
| Subscription references | billing/legal audit | finance support | payment gateway | tax/accounting legal minimum |
| AI persona training | **off by default** | none until opt-in | approved processor only | separately documented, revocable |

## 4. DPDP control-by-control rollout
**Notice** clear, accessible, standalone explanation of personal data and purpose before consent; multilingual/localized variants and link to rights/contact. **Consent** freely given, specific, informed, unambiguous affirmative action; separate from T&C and granular by mode/quiz, AI, notifications, public trait sharing; withdrawal as easy as giving consent. **Purpose limitation** no resale of quiz answers to advertisers or covert inference. **Data minimization** no mandatory religion/caste/sexuality details or biometric scans for friendship, no hidden classifier. **Accuracy and rights** allow editing and complaint handling; score recomputation when changed. **Security** measures per Rule 6, including encryption, access, monitoring, backups, vendor contracts and appropriate logs. **Breach** draft ready-made notices and decision tree for Rule 7 from its effective date: notify affected individuals/Board without delay, detailed Board information within 72h unless extended; CERT-In separately as applicable. **Children** begin 18+; consider proportionate age assurance and a response procedure when minor detected; if minors allowed later, parent-consent and restrictions substantially increase complexity. **Retention** document schedules and apply applicable Rule 8 statutory retention/erasure provisions, with potential lawful holds and back-up limits. **International processors** keep data maps and contract protections; legal restrictions and transfers are jurisdiction- and future-notification-sensitive.

## 5. Sensitive inference: special design rule
User's concept includes indirect assessment to predict intimate matters. Do **not** covertly infer sexual orientation, mental health, religion or comparable intimate categories from innocuous answers. Assessment data can be sensitive even if the final UI omits the inferred label. For any optional disclosed characteristic, require clear consent, justifiable necessity, use limitation and fairness review; never reveal to family, group admins or other members without explicit setting. An AI-generated "brain twin" is a separate processing purpose with elevated disclosure/retention/impersonation requirements.

## 6. Intermediary / user-generated content duties
Counsel must classify whether/how Rule 3 obligations apply, establish grievance officer details where required, operational routes for unlawful-content orders and notices, complaint SLAs by category under amended law, evidence preservation only as permitted/required, user policies, periodic updates and appeals. Internal proposed targets deliberately stricter than needed until confirmed: **acknowledge grievances within 24h**, general resolution **≤7 days**, specialized takedown **≤36h**, intimate-image/impersonation **≤2h when provision applies**. These are contingent category timelines; do not promise all tickets a two-hour resolution. Escalate severe child safety and imminent threats urgently irrespective of user plan.

## 7. Identity and matrimonial responsibility
Kithra is NOT a licensed match guarantee, a clinical diagnosis provider or a marriage registrar. State plainly that members' claims are self-reported unless independently verified. Do not indiscriminately demand Aadhaar or store government ID scans. Marriage eligibility (age, current marital status, individual consent, permitted age/legal limits, prohibited relationships) requires carefully worded declarations and potentially documentary review with consent and counsel, never an algorithmic guarantee. Do not allow family profiles to control adults without the adult's authorization, or publish protected characteristics in discriminatory hierarchies.

## 8. Payments and consumer rights
Show complete price, GST/taxes and renewal terms before payment; explicit auto-renew consent where applicable; easily accessible cancellation and refund policy; no dark patterns (prechecked renewal/hidden terms); actual payment processor handles cards/UPI; invoices and dispute records; respond to grievances and charges fairly. Merchant/provider policies and RBI card/UPI e-mandate requirements can change; confirm with provider before publishing pricing.

## 9. Privacy risk scoring (illustrative)

| Risk | Impact | Likelihood if uncontrolled | Mitigation and owner |
|---|---|---|---|
| Raw quiz response leak | Critical | high in insecure prototype | encrypt, access checks, vault, security lead |
| Admin insider profiling | Critical | medium | per-case access, dual approval, audit |
| Stalking through discovery | High | medium/high | coarse location, blocking, ratelimits, safety owner |
| Involuntary orientation inference | Critical | high if designed | ban hidden inference, consent review, privacy lead |
| Matrimony coercion/fraud | High | medium | separate mode, reporting, warnings, human moderation |
| Fake user verification claims | High | high in prototype | remove false UI badges, truthful statements |
| Payment/renewal complaints | Medium | medium | webhooks/reconciliation, visible cancellation |

## 10. Launch compliance checklist with evidence
- [ ] Legal entity name, registered address, official grievance/business contacts and principal controller established.
- [ ] Counsel-signed data map, current-law applicability, DPDP launch-gap register, vendor contracts and international transfer review.
- [ ] Per-mode/quiz consent versioning and logs tested; default most-private settings.
- [ ] Privacy/T&C/community/payment/refund/cookie notices reviewed, versions recorded and localized.
- [ ] Data export, correction, withdrawal, deletion and retention-hold workflows function end-to-end.
- [ ] No hidden trait inference, fabricated claims, unauthorized media publication or unmoderated public stranger chat.
- [ ] Moderator staff availability, emergency escalation, grievance processes and appeal paths staffed/tested.
- [ ] Threat model, pentest, incident tabletop, backups and recovery drills completed.
- [ ] Payment gateway and e-mandate technical/legal verification; actual cancellation and invoices tested.
- [ ] All vendor and cloud free-tier limits reviewed for release date; alert budget and failure responses configured.

## 11. Counsel decision log to complete
C01 intermediary status and significant threshold; C02 scope of 2011 SPDI rules and DPDP transition; C03 consent design for assessment/matching modes; C04 retention + compelled disclosure policy; C05 moderation response duties; C06 cross-border data transfer/cloud hosting; C07 matrimony representation and minimum age checks; C08 tax/invoice and renewals; C09 synthetic-avatar handling under 2026 IT Rules; C10 user-generated media safety and law-enforcement protocol. Each requires owner, date, written opinion and revised product behavior.



---


# Draft Legal and User-Facing Policies — Counsel Review Mandatory

**Templates, not production-ready legal advice.** These drafts deliberately contain `[LEGAL_ENTITY]`, `[REGISTERED_ADDRESS]`, `[CONTACT_EMAIL]`, `[GRIEVANCE_EMAIL]`, `[EFFECTIVE_DATE]`, `[AGE_POLICY]`, `[RETENTION_SCHEDULE]`, `[PRIVACY_PROCESSORS]`, `[REFUND_WINDOW]`, `[APPLICABLE_FORUM]` etc. Fill only with verified operational facts after counsel review. They do not shield Kithra from law, negligent conduct or unfair terms. Every notice must match the actual product and effective Indian requirements.

---

## A. Terms of Service — draft
**1. Contracting party and service.** These Terms govern use of Kithra operated by `[LEGAL_ENTITY]`, `[REGISTERED_ADDRESS]`, `[CONTACT_EMAIL]`. Kithra provides optional friendship, dating and matrimony discovery, questionnaires, introductions, communities and communications. Kithra does **not** promise a match, friendship, romance, marriage or psychological accuracy. Our index scores are descriptive tools, not clinical assessment or guarantees.

**2. Eligibility.** You must be at least `[AGE_POLICY: initially 18 years]` and legally capable of agreement. You must provide accurate and current personal information, keep credentials private, and not use an account for another individual without permission. Users pursuing matrimony are responsible for any additional marriage-law eligibility and accurate self-disclosure; Kithra's self-report is not official verification.

**3. Separate intent modes.** Friendship, Dating and Matrimony are voluntary and separate. Activation of one does not automatically enroll you in another. You can pause or close a mode, restrict who sees each profile and withdraw optional questionnaire sharing according to the Privacy Notice.

**4. Assessments and model limits.** Questionnaires may be incomplete, culturally imperfect or updated. Scores reflect disclosed model rules and measured responses at the relevant time. They cannot reconstruct a brain or prove the future quality of a relationship. You may decline optional questions and assess match recommendations with independent judgment.

**5. Conduct.** You must not impersonate others, harass, stalk, threaten, cheat, coerce, solicit illegal payments, publish nonconsensual images, target minors, or circumvent blocks or restrictions. In friendship mode respect platonic boundaries; dating/matrimony interactions require mutual intent and respect. Kithra may restrict access, remove content, investigate reports and cooperate with authorities consistent with law and fair procedure.

**6. User content and license.** You retain your rights in your uploaded original content. You provide a nonexclusive, purpose-limited license necessary to host and display content to audiences you select, operate messaging and enforce community safety. This does not authorize selling your private quiz answers or training third-party AI models without separate consent.

**7. Paid features.** Prices and applicable taxes are displayed before checkout. Digital entitlements, renewal dates, cancellation, refunds, errors and disputes are explained in the Billing Policy. Safety, blocking, reports, core data rights and account deletion are never paywalled. Refund rights granted by law cannot be waived through these Terms.

**8. Communication and meeting safety.** Users are strangers and can misrepresent themselves. Exercise judgment, meet initially in public, never transfer money to an unknown person, and use in-product reports for abuse. Kithra does not conduct comprehensive criminal/background checks unless a specific feature truthfully says otherwise.

**9. Suspension, appeals, termination.** We may restrict an account for credible abuse or legal compliance while offering a documented review/appeal path where appropriate. You may delete your account; data handling follows the Privacy Notice and legally necessary retention.

**10. Liability and disputes.** To the extent legally permissible, Kithra does not guarantee outcomes or uninterrupted availability. Nothing here excludes liability, consumer protection rights or remedies that applicable law prohibits limiting. Dispute forum, governing law, contact and required processes: `[COUNSEL_APPROVED_TERMS]`.

**11. Changes.** Notify users of material changes in accessible language; secure new consent when required for a materially new processing purpose. **Effective date:** `[EFFECTIVE_DATE]`.

---

## B. Privacy Notice — draft
**Controller/fiduciary:** `[LEGAL_ENTITY, CONTACT, PRIVACY_OFFICER]`. **What we collect:** identity email/provider subject, chosen mode and persona information, voluntarily submitted quiz answers, derived trait descriptors, voluntary connection requests, messages, groups, abuse reports, operational security events, payment references and preferences. We do **not** need exact home addresses, government IDs or biometric scans for normal signup.

**Purposes and grounds:** (1) account, identity and service delivery; (2) your chosen mode's discovery and mutual messaging; (3) optional questionnaire scoring and explanations; (4) safety, fraud prevention, complaints and legal compliance; (5) optional notifications/marketing where separately selected; (6) optional AI simulation only under a separate, independently explained opt-in not enabled by default. List precise applicable legal bases when counsel finalizes this Notice.

**Mode separation:** Each friendship, dating and matrimony persona has separate visibility and opt-in. Questionnaire raw answers are private by default; other members see only expressly shareable trait summaries or public profile fields. No data sale or targeted ad use of intimate questionnaire records.

**Sensitive inferences:** Kithra does not covertly infer sexual orientation, caste, religion, health or similar personal attributes from ordinary quiz answers. If any optional disclosed sensitive category becomes relevant to a clearly selected mode, it will have explicit controls and separate review.

**Who may receive data:** authorized service processors `[PRIVACY_PROCESSORS]` such as authentication, hosting, email, payments and security; your opted-in recipients; lawful authorities if valid and necessary. List countries/data locations/transfer safeguards accurately—do not state "India-only" unless technically verified.

**Security and retention:** Describe actual access controls, encryption, audit logs, incident handling, backups and retention schedule `[RETENTION_SCHEDULE]`. A badge saying "end-to-end encrypted" must only appear if actual verified E2EE is deployed; otherwise explain transport and storage protections truthfully.

**Rights and control:** contact `[PRIVACY_EMAIL]` to request access, correction, consent withdrawal, export, erasure and grievance resolution as applicable. Disclose retention exceptions, processor effects and required identification/reauthentication. User can pause discovery and independently remove each mode. Explain response timelines only after counsel confirms obligations.

**Breach notifications:** Provide legally required notices if a personal data breach occurs. **Policy changes:** timestamp, version history and material-change notice. **Contact:** `[PRIVACY_EMAIL]` and grievance information.

---

## C. Community Standards & Safety Policy — draft
**Values:** dignity, autonomy, truthful self-presentation and mutual consent. **Prohibited:** bullying, sexual pressure, hate, misrepresentation, trafficking or sex-for-money solicitation, financial scams, nonconsensual sexual imagery, doxxing, threats, impersonation, child exploitation, circumventing blocks, spam, attempts to harvest quiz/identity data and coercion into marriage. **Mode etiquette:** no unsolicited romance in friendship mode after a boundary is expressed; no matrimonial family pressure or dowry promotion; clear consent in dating. **Reporting:** profile, message, group and help-center paths; emergency risks directed to local authorities. **Actions:** warning, content removal, limited reach, suspension, permanent ban, authority referral when legally required; proportionality, documentation and appeals. **Enforcement:** human review for high-severity cases; automated classifiers assist but never override due process for ambiguous ordinary disagreements.

---

## D. Consent text inventory — interface drafts
**Mode selection:** "I want to participate in [Friendship/Dating/Matrimony] discovery. I understand that people in this mode can see the profile fields I make visible." Each mode requires its own checkbox/toggle, unchecked initially.

**Quiz:** "I agree to the processing of my selected quiz answers to generate a personal trait summary and matching recommendations. Other users will not see my raw answers. I can stop participating or withdraw this optional consent in Settings. See details." Unchecked initially; show theme and purpose.

**Expanded sharing:** "Show these selected trait summaries to eligible connections in [mode]." Off until opted in. **AI twin (future):** "Allow Kithra to create an optional simulated conversation profile using the selected data shown here. This is not a replica of my mind. I can deactivate and request deletion." Off and independently consented.

**Transactional email:** service required; **marketing:** optional and independently controlled. **Activity indicators/read receipts:** optional settings with clear reciprocal expectation.

---

## E. Billing, Refund & Cancellation Policy — draft
Subscriptions provide only the features listed at checkout. Before authorization show gross amount, taxable portion/GST treatment, period, renewal status, grace policy, renewal reminder policy, cancellation path and customer support contact. Users may cancel renewal in Account > Billing without contacting support; cancellation normally stops future billing while granting already purchased entitlement until the paid period ends unless an exception applies. Refund requests use `[REFUND_WINDOW]`/`[GRIEVANCE_EMAIL]`, the actual payment provider workflow and applicable legal consumer protections. Refund timing depends on payment rail; avoid guaranteeing instant reversal. Price changes require notice and lawful authorization. Downgrade cannot remove essential safety tools or prevent export/deletion. Auto-renewal must never be hidden, prechecked or misrepresented. **Finalized by counsel and payment gateway before accepting funds.**

---

## F. Data Retention Schedule and Deletion Policy — template
Each dataset entry must specify owner, collection reason, lawful basis, active retention, inactivity trigger, backup expiry, approved legal hold, processor deletion, encrypted key erasure and verification artifact. Suggested implementation lifecycle: user request → mark `deletion_pending` and revoke discovery/session → prevent new writes → allow lawful short cancellation window if transparent → purge active D1/R2/DO and caches → queue linked processor instructions → retain only narrowly legally required case/payment/security records → document completion and backup expiry. Do not promise literal instantaneous erasure from immutable disaster backups.

---

## G. Grievance and Appeals Policy — draft
`[GRIEVANCE_OFFICER_NAME, ADDRESS, EMAIL, WORKING_HOURS]`. Every report receives case ID and acknowledgement; user receives category-appropriate status without disclosing private investigation materials. Team prioritizes imminent harm, sexualized harassment/impersonation and legal takedowns; deadlines follow applicable IT Rules classification and current amendment. Appeals are reviewed by someone other than original decision maker when feasible. Government/legal requests require validation, minimization and documentation, except secrecy requirements. Kithra cannot promise a 24/7 human helpline unless one operates.

---

## H. Cookie / Tracking Notice — draft
List strictly necessary authentication/security cookies separately from optional analytics/marketing cookies. No tracking embedded in quiz answers by default. Provide preference controls appropriate to current law and chosen analytics SDK. Document retention, provider and opt-out behavior; honor browser privacy protections where supported.

## Legal sign-off sheet (fill before production)
`document name | version | last verified law | owner | lawyer name | lawyer approval date | translated variants | public URL | product control tests | change-monitor cadence`.



---


# UXR / UID / Design-RD — Kithra Complete UI/UX & Motion Handover

**Audience:** UI/UX designers, design system engineer, front-end developer, accessibility reviewer. **Source ZIP is a product concept only**. Do not inherit its design uncritically; all colors, type, layout and interactions below are a fresh coherent recommendation. Deliver high-fidelity Figma responsive prototypes and implementable components with explicit states.

## 1. Product experience principles
1. **Human first, not algorithm first.** Display a human profile before an invented perfection badge. Use compatibility as an explanation, not value ranking.
2. **One identity, three quiet worlds.** Intent-specific Friendship, Dating and Matrimony contexts, visually distinct only where it clarifies context; never leak one persona into another.
3. **Discovery through mutual choice.** Avoid swipe-addiction, infinite scarcity/fear framing and fake urgency.
4. **Trust without surveillance theater.** Explain exactly what has and has not been verified, security implemented and user visibility.
5. **Respect highly private data.** Reveal only summaries the member chose; privacy controls next to disclosure, not buried.
6. **Friction where it protects.** Slow down intimate consent, public sharing, privilege grants and risky actions; reduce friction for routine browsing.
7. **A calm living experience.** Tactile microinteraction, not screenfuls of continuous motion. Reduced-motion accessible parity.

## 2. Brand territories and visual concept
**Positioning:** modern, insightful, warm and trustworthy; avoid occult/soulmate certainty, clinical diagnosis, cosmic mysticism too strongly or matrimonial stereotypes. Visual metaphor: **connecting facets**—slightly asymmetrical geometric shapes, which align through deliberate choices, not a literal brain scan. Use soft field gradients and editorial portraits only when appropriately licensed and consented; no AI-generated member photos falsely presented as real.

### Color tokens

| Token | Light | Dark | Usage |
|---|---|---|---|
| background | `#F7F7F3` | `#0F1822` | neutral canvas |
| surface | `#FFFFFF` | `#182430` | cards and sheets |
| surface-muted | `#EEF0EE` | `#22313D` | secondary panels |
| ink | `#18252A` | `#F2F5F2` | primary text |
| ink-muted | `#56636B` | `#ACB7BE` | secondary text |
| brand-deep | `#264D56` | `#8FD0CC` | headings/logo accent |
| teal-action | `#147C82` | `#57BCC0` | primary CTA |
| teal-hover | `#105E64` | `#8DD6D8` | interaction |
| coral-soft | `#D99683` | `#E5AB98` | warm human accent |
| lilac | `#9389BF` | `#B0A5DB` | alternate visual lens |
| positive | `#207D62` | `#74C9A4` | successful controlled states |
| warning | `#AA6B20` | `#F2C070` | caution notices |
| danger | `#B73C4A` | `#FF8A94` | abuse/confirmation destructive |
| border | `#D9E0DF` | `#34444B` | hairline separators |

Accent palettes for **mode identification**: Friendship teal `#147C82`, Dating rose `#B75D77`, Matrimony indigo `#655AA9` (with accessible text variants on respective themes). Colors identify the current mode but never indicate caste, gender, attractiveness or psychological worth.

### Typography, icons and layout
Use **Manrope** (display), **Inter** (body/interface), optional **Newsreader** italic for 1–2 editorial hero words (do not overdo). Fallback system fonts. Display 64/72 desktop, 38/44 mobile; H1 48/56 desktop; H2 36/44; H3 24/32; body 16/26; compact UI 14/20; captions ≥12/18 sparingly. Use a consistent 8pt spacing grid with 4pt increments; radii 12/16/24/32; 1px borders; subtle non-colored shadows, not neon glows everywhere. Icons Lucide or custom 24px stroke with semantic labels. User photos are circular/soft-square; no fake verified marks. Max readable text width 70ch. Public page grid 12 columns, max 1280px, 24–48px gutter. Workspace desktop sidebar 252px; contextual details panel 320px; content max 1180px. Mobile 360px baseline and 44px minimum targets; use bottom nav for 4–5 high-frequency destinations.

### Implementation tokens
Use `scaffolds/design-tokens.json` as the source for CSS custom properties, Figma variables, theme switch and component states. Include focus ring, breakpoint and motion primitives. Never derive contrast from a hue without testing WCAG 2.2 AA.

## 3. Public landing page — art direction and scroll narrative
**Section L1 / first fold:** minimalist navigation left Kithra wordmark; right "How it works", "Safety", "Our approach", "Pricing", "Log in"; CTA "Explore connections". Hero line **"People are more than profiles."** secondary "Discover friends, dates and potential life partners through thoughtful questions and mutual choice." Three mode chips displayed as clearly different intents. Hero illustration: four subtle translucent tessellated facets approach one another and form a flexible whole; **not brains, souls or medical imagery**. On mobile replace with simple static/low-motion graphic. Public hero does not claim X% success.

**L2 / Explain the three worlds:** Friendship / Dating / Matrimony cards, each with expectations and an independently opt-in selector; a mode focus toggle updates copy, does not autoplay huge transitions.

**L3 / How it works:** Choose intention → Answer optional questions → View clear compatibility lens → Make mutual connection → Build real relationship. Animated path with descriptive relationship connectors only, scrolling under reduced motion static.

**L4 / Compatibility lens demo:** sample fictional match report with switcher `Mirror / Counterpoint / Mosaic`, human-friendly explanation and caveat "Scores summarize answers, not certainty." No fabricated testimonials.

**L5 / Privacy promise:** transparent raw-answer privacy, opt-in sharing, boundaries, blocking, report, human moderation. Badges only for implemented audited features. Link to legal center.

**L6 / Circle communities:** small facilitated topic-focused groups; screenshots/mockups explicitly labeled illustrative until real.

**L7 / Pricing:** Free + optional upgrades, month/quarter/half-year/year toggle, full GST and auto-renew clarity, cancel anytime meaning explained.

**L8 / Frequently asked:** is Kithra dating? do I need 100 questions? can I skip? are scores guaranteed? can I hide myself? can I delete? which data other users see? can admin see chats? who handles reports?

**L9 / Footer:** official entity, contact, legal, privacy, data rights, community guidelines, help, accessibility, security disclosures and status page.

## 4. Motion system (Framer Motion / `motion/react`)
**Motion goal:** purposeful, calm, performant and accessible; use CSS transforms and opacity, never scroll-jacking.

| Motion token | Parameters | Where |
|---|---|---|
| enter | 260ms, ease `[0.22,1,0.36,1]`, `y: 12 → 0`, opacity `0 → 1` | card entrance |
| appear | 180ms ease-out, opacity only | dialogs and data updates |
| softSpring | `type:'spring', stiffness:260, damping:28` | tab indicator / small affordance |
| pageTransition | 220ms crossfade, `y:6 → 0` | workspace panes |
| hoverScale | 120ms, scale to 1.015 max | CTA/cards |
| reducedMotion | all nonessential transform animations disabled, opacity short or instant | accessibility |

Suggested snippets (pseudocode, confirm installed version):
```tsx
import { motion, AnimatePresence, useReducedMotion } from 'motion/react';
const reduced = useReducedMotion();
<motion.section initial={reduced ? false : {opacity:0,y:12}} whileInView={{opacity:1,y:0}}
 viewport={{once:true,amount:0.15}} transition={{duration:0.26,ease:[0.22,1,0.36,1]}} />
```
Hero facets animate **once** with 350–600ms sequence stagger, then remain still. Focus changes by reduced-motion-safe crossfade. Hero load must not be blocked by large video/WebGL; no particles that increase GPU cost. Avoid infinite shimmering 3D "soul twin" animation, 100 parallax layers, forced scroll snapping, content that moves while typing, layout shifts or distraction in admin. Use `LazyMotion` and bundle splitting; test 30fps+ mid-tier mobile and preserve full function with JavaScript animation disabled.

## 5. App-wide information architecture
### Desktop sidebar
```
[Logo] Kithra
[Intent switcher: Friendship ▾]      (always visible)

DISCOVER
  Overview
  Discover People
  Match Lenses (Mirror / Counterpoint / Mosaic)
  Connections & Requests
  Circles

CONNECT
  Messages
  Notifications
  Saved Profiles

DISCOVER YOURSELF
  Quiz Library
  My Assessments
  My Compatibility Profile
  Growth Notes (optional, private)

ACCOUNT
  My Mode Profiles
  Membership & Billing
  Privacy & Consent
  Safety & Help
  Settings
```
On narrow tablet: compact icon rail with tooltips and accessible labels. Mobile: bottom nav **Discover / Connections / Circles / Messages / Me**; quiz library via Me/discover prominent banner; switch intent via top-bar pill; prevent accidental cross-mode switch by clearly changing header/canvas marker. Do not force all destinations as 14 visible mobile tabs.

## 6. End-to-end user screen inventory & edge states
**U01 Landing:** interactive hero, scroll narrative, copy and CTA; disclose limits.
**U02 Sign-up/log-in:** email & password, Google, forgot password, confirm email, terms/age separate; loading/error/rate limit states; no silent account linking by email.
**U03 Intent onboarding:** choose one or more, explain visibility boundaries; empty selection cannot proceed to discovery.
**U04 Create mode persona:** display name, age validation, coarse city, interests, pronouns optional, photos optional, audience/visibility, safety preference; preview as another user.
**U05 Privacy & consent:** consent cards by mode/quiz, data sharing diagram, toggle explanation, consent history and withdraw all; no hidden default consent.
**U06 Quiz library:** category tiles by theme, number of valid published item sets, estimated duration, relevance by mode and progress.
**U07 Quiz run:** one question at a time, question `x/100`, save indicator, back/skip/quit, keyboard radio navigation, edit response, context tooltip and sensitive-question warning where relevant; mobile sticky Next; no timer penalties.
**U08 Quiz resume/error:** previously saved partial, pending sync, offline, recovered attempts, locked published version; recovery path.
**U09 My psychological profile:** plain-language traits and coverage/confidence, adjustable visibility, evidence explanation, no clinical diagnosis or surveillance implication.
**U10 Discover people:** list/grid/mapless city pool, mode/lens/band controls; truthful pool count; minimal filters; reasons + risks; skeleton/empty/blocked/restricted states.
**U11 Detailed match profile:** public photo optional, mode, human story, consented compatibility highlights, mutual interest, report/block shortcuts, non-scientific caveats; avoid "opposite fixes you".
**U12 Connection inbox:** pending incoming/outgoing, accepted, expired, declined; reject without penalty or disclosure; manage request volume.
**U13 Messages:** desktop split conversation list/main thread/optional details; mobile single chat view; ability to block/report from header, message action and profile; text first, attachments later; clear transport security disclosure, no fake E2E.
**U14 Circles index:** themes, local/remote, public/private, member counts, moderation rules, filter by mode.
**U15 Circle detail:** feed, conversation, rules, moderators, invitations, report, leave, member role; no unsolicited mode transfer.
**U16 Create a Circle:** name/description/topic/moderation setting/location scope, member admissions, creator responsibilities, permissions.
**U17 Activity events (later):** participant cap, public location guidance, RSVP, cancellation and safety review.
**U18 Membership:** available plans, entitlement comparison, GST/renewal rules, gateway redirect, receipts/cancel/refund.
**U19 Account settings:** notifications, region and language, account, security/session log, connected identity, delete/export/consent.
**U20 Safety Center:** transparent verified security features, report tracker, help desk, appeals, safety guides, legal requests contact.
**U21 Support ticket:** category, problem description, optional attachments, attachments privacy disclosure, ticket status.
**U22 System states:** blocked/suspended/quiz-version-deprecated/score-incomplete/empty local pool/internet failure/consent withdrawn; each has a constructive next step.

## 7. Component catalog
Button (primary, secondary, quiet, danger), IconButton, Tabs, SegmentedControl, IntentModeSwitcher, AccessiblePopover, DropdownMenu, ProfileCard, MatchLensCard, TrustBadge (strict criteria), ScoreBandBadge with help, ConfidenceIndicator (when supported), ConsentToggle, QuizChoiceGroup, QuizProgress, ResumeCard, MemberAvatar, ConnectionRequest, MessageBubble, ReportDialog, NotificationToast, InfoDisclosure, AlertBanner, SkeletonCard, EmptyState, ConfirmationDialog, Pagination, FilterSheet, SearchAutocomplete, Date/LocationInput, AdminRiskPill, AuditEventRow, CaseTimeline, RoleMatrix. For each Figma component define variants, interaction, error, focus, disabled, high-contrast and dark state, screen-reader output and motion specification.

## 8. Core screen specs for UX handoff
### Discovery list
Header mode switch and large human-focused heading, visible lens explanation, small live list and deferred filters. On card show name, general city, chosen public interests, *descriptive* band, explanation; request action not available until eligible. 100/90/80...10 bands are optional advanced filter and refer to index ranges; do not show "100% chance".

### Match detailed panel
Split: left human story/intent, right `Why you might connect`, `How you differ`, `What the model doesn't know`, confidence and mutual contact CTA. On mobile stack, persistent CTA only after reading essential boundaries. Raw answers never displayed without separate sender approval.

### Quiz 100-question journey
Question progress must be honest: `18 of 100`, ability to finish later. 100 continuous questions can cause fatigue; design checkpoints every 20, transparent skip policy, summary after completion or after validated short subset, no false gamification streak. Zero items production ready until vetted. Keep completion autosave even on network disruptions.

### Messaging
Request gate before conversation; unread, sending, failed/retry, deleted, reported, blocked states. Provide easy exit, plain content warnings, media safety controls and limitations of moderation privacy; do not design fake voice-call buttons for unbuilt features.

### Matrimony context
Sober copy, serious intent, voluntary family visibility, separate sensitive preference consent, clear marital status self-report vs verified. No dowry filters or discriminatory psychological type names. Add explicit mismatch/boundary disclosures; family contact cannot appear unless both persons independently authorize.

## 9. Microcopy and accessibility
Never say "100% perfect person", "clinically verified soulmate", "brain replica", "Aadhaar verified" without a real legal process. Prefer "Strong measured alignment in 5 shared areas" with model explanation. Errors are specific and respectful; avoid blaming users who skip personal questions. All controls keyboard accessible, form labels real, logical focus restoration, visible indicators, alt text for meaningful imagery, AA contrast, no information purely color-coded, 200% zoom and reduced motion tested. Maintain layouts under English plus Hindi/Tamil string expansion; do not localize official scoring labels without expert review.

## 10. Figma handover checklist
Deliver `00 Foundations`, `01 Components`, `02 Public Landing`, `03 Onboarding`, `04 Friendship`, `05 Dating`, `06 Matrimony`, `07 Quiz`, `08 Discovery & Matching`, `09 Messaging & Groups`, `10 Safety & Billing`, `11 Admin Console`, `12 Responsive/States`, `13 Prototype Motion`, `14 Content & Translations`; light/dark as applicable. Name variants consistently; include token export and motion specs, component interaction matrices, annotated error/empty/privacy states, 360/768/1024/1440px breakpoints. For development: Storybook (optional), Chromatic visual regression, automated a11y tests, performance budget and no unbuilt feature decoration.

## 11. Design acceptance criteria
A first-time user understands mode separation within 20s; all flows have privacy explanation and easy cancel; every matching explanation shows uncertainty; a report/block reachable in ≤2 interactions from chat and profile; data deletion available without payment; no navigation dead ends; admin safety functions visually distinguish urgency; test on lower-end Android, keyboard-only, screen reader, reduced-motion and low bandwidth.



---


# Admin-RD — Mission Control, RBAC, Support, Moderation and Admin UX

**Product rule:** The admin dashboard is a separate privileged product, not a hidden tab accessible with a static secret. Frontend visibility is convenience; security is enforced at the Worker/API and on data access. Its scope is incident response, customer support, trust/safety, billing review, score bank governance and privacy rights—not casually reading members' personal stories.

## 1. Admin authentication and provisioning
Use `admin.kithra.[tld]` as a distinct origin (or separate `/admin` deployment behind Cloudflare Access if domain constraints), not linked in public nav. Allowed admin identities use **specific verified email accounts plus password and MFA**, backed by Firebase provider identity plus Kithra server-side allowlist and privileges. Require elevated MFA/passkey or TOTP for all admin access; if provider limitations affect this, choose a supported dedicated MFA/auth solution before launch. Restrict admin membership to invite-only, verified by superadmin with reason, expiry and approval. Admin email domain allowlist is defense-in-depth, not identity proof by itself. Optionally Cloudflare Access adds a second identity/device gate. No plain-text passwords in database/code, no common admin shared account, no default secret. Read-only auditors and safety agents have individual accounts.

## 2. RBAC permission matrix

| Action | Owner/Superadmin | Trust & Safety Lead | Safety Reviewer | Support Agent | Finance | Quiz Publisher | Analyst | Auditor |
|---|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| Dashboard aggregate KPI | Y | Y | Y | Y | Y | Y | Y | Y |
| View user public account metadata | Y | Y | case only | ticket only | masked | N | aggregate | metadata only |
| Read reported chat excerpt | approval | assigned | assigned | N | N | N | N | audit ref only |
| Full raw quiz answers | N by default | N | N | N | N | N | N | N |
| Restrict account temporary | Y | Y | request | N | N | N | N | N |
| Permanent ban | dual approval | dual approval | N | N | N | N | N | N |
| View payment references | masked | N | N | masked | Y | N | aggregate | audit only |
| Refund request approval | approved threshold | N | N | create request | Y | N | N | log only |
| Publish quiz bank | Y via approval | N | N | N | N | propose/approve split | N | log only |
| Configure public feature flag | Y | limited safety | N | N | N | quiz only | N | N |
| Invite/revoke admin | dual approval | N | N | N | N | N | N | audit |
| Audit-log export | Y + justification | restricted | N | N | N | N | N | approved |
| Deletion/legal hold exception | dual approval + counsel | request | N | N | N | N | N | evidence only |

`Y` authorizes only permitted scope. Separate role and capability from organizational titles. Every capability checked per case/tenant, not just route level. Reviews require step-up authentication for high-risk actions. Data-access "break glass" logs reason, reviewer, duration and recipient alerts; default disabled.

## 3. Information architecture / admin sidebar
```
KITHRA | MISSION CONTROL
[Global case search — restricted] [Alerts] [Admin identity + MFA status]

OVERVIEW
  Operations Dashboard
  Safety Command Center
  Live Incident Alerts

TRUST & SAFETY
  Reports Queue
  Case Investigations
  Appeals
  User Restrictions
  Group Moderation
  Verification Requests (only if implemented)

SUPPORT
  Tickets Inbox
  Billing & Refunds
  Account Recovery
  Data Rights / Deletion

MATCHING & RESEARCH
  Quiz Theme Catalog
  Question Bank Review
  Scoring Model Registry
  Fairness/Outcome Monitoring

FINANCE & GROWTH
  Plans & Entitlements
  Payment Ledger (scoped)
  Acquisition/Retention (aggregated)

SYSTEM
  Feature Flags & Emergency Controls
  Roles & Invitations
  Audit Logs
  Incident Runbooks
  Settings / Provider Status
```
No direct "psychometric dossier" item. If cases require access, show narrow redacted evidence only with case justification. Admin responsive design primarily desktop 1280/1440+; tablet read-only triage; destructive actions disabled on mobile or require full reauth.

## 4. Admin visual guidance
Different from public Kithra's welcoming canvas, but related token system: deep slate `#111B24`, surface `#1C2A35`, ink `#F3F7F7`, teal action `#6DBFC2`, amber `#F1BB68`, red `#F28C93`; case badges neutral unless genuine urgency. Left rail 248px, top bar 68px, central table with filter/search, right 360px context drawer with evidence timelines and policy guidance. Dense but legible: body 14/20, 12px metadata, 32px data figures. Motions limited to 160ms drawer crossfade and table row highlights; no attention-grabbing landing effects. All audit actions show plain-language consequence and undo only when genuinely reversible.

## 5. Dashboard metrics
Queue backlog by priority/category, time to first response, time to investigation/resolution, emergency breach warnings, appeal overturn, repeat offenders, review staff available, unreconciled payments, user support CSAT, deleted-account backlog, matching fairness tests status, current free-tier usage/budget, last backup and restore test, system health. Metrics must come from actual persisted data and freshness timestamp, not fake counts.

## 6. Moderation case runbook
**Report creation:** write immutable report and state synchronously; assign `case_id`, hold relevant evidence only lawfully, anonymize reporter information from subject. **Triage:** severity based on specific harm, age, ongoing exposure, repeat pattern. **Investigate:** redact defaults, open only scoped excerpts, record each evidence access and reason, corroborate before punitive action. **Action:** educate/warn, remove content, restrict features, suspend, ban, refer to authorities where required; avoid automatic global punishments without review. **Notify:** give reporter meaningful safety update, avoid exposing private investigation; provide subject accessible reasons and appeal path where feasible and lawful. **Appeal:** reviewer not original investigator, record rationale. **Close:** documented final state, scheduled evidence disposal or justified retention.

### SLA engine
At minimum implement category-aware deadlines and escalations, not one global timer. Contingent internal schedule: immediate `critical` handoff and emergency policy, specialized intimate-image/impersonation cases as legally applicable within 2h, content grievances 36h where applicable, general acknowledgements 24h and general resolutions 7d where applicable (verify current consolidated 2026 IT Rules with counsel). Show colored state only after precise deadline type and on-call capacity are known. Automatic overdue escalation via cron/queue with backup recipient, no false claim of resolution if case is simply marked read.

## 7. Support case UX
Inbox queues `New / Assigned / Waiting for user / Escalated / Resolved / Appeal`; category filters, severity, mode, age of ticket; keyboard shortcuts available but dangerous actions always explicit. Conversation history redacts identity and notifies agent when private material accessed. Suggested macros are human-reviewed, not auto-sent for legal/security harms. Support agent can request proof of account ownership using secure channel but never ask for password or full card number. Evidence attachments quarantined and object-scoped.

## 8. Admin roles and invite lifecycle
First trusted superadmin created out-of-band via setup script or privileged audited migration. Addition requires existing superadmin plus reviewer approval for elevated roles. Invite token one-time and short-lived, bound to verified email address; account enrolls MFA before privilege activation. Remove/revoke token on suspension, employment termination, expiration, account compromise; session revocation at API boundary. Roles are capability sets, nonrecursive; `owner` role is not a wildcard bypass of privacy safeguards.

## 9. Admin UX flows and acceptance
- **A01 access:** non-admin trying admin host → generic unauthorized, no information leakage; even successful Firebase login not enough.
- **A02 case report:** support can open and assign own tickets but not read unreported messages.
- **A03 ban:** moderator recommends, safety lead approves, system logs two distinct human identities.
- **A04 sensitive export:** only permitted auditor, step-up auth, documented reason, time-limited result, alert owner.
- **A05 quiz publication:** draft → independent science reviewer → privacy reviewer → publisher → canary; trace revisions; rollback.
- **A06 feature flag:** disable discovery/chat immediately while leaving help, safety and data-rights accessible.
- **A07 admin offboarding:** revoked role reflected across fresh requests and socket sessions; signed action logs retained.
- **A08 payment case:** finance refunds only through signed gateway API with two-person approval above threshold; ledger reconciliation.

## 10. Operational staffing requirement
An owner must be reachable for urgent law/safety cases at all times the public platform operates, or product scope (uploads/public messaging) must be limited accordingly. Cloud services cannot substitute for human investigation. Staffing, duty rotation, vendor/legal escalation and incident tabletop are launch dependencies rather than optional polish.



---


# Billing-RD / Financial Model — Pricing, Entitlements, and Economics

Prices below are **proposed validation hypotheses**, not competitor-derived willingness to pay or profit forecasts. Use user interviews and live gateway/tax rates before publication. Legal and safety controls remain free.

## 1. Proposed plans (pilot)

| Tier | Monthly | 3 months | 6 months | 12 months | Primary entitlements |
|---|---:|---:|---:|---:|---|
| Free | ₹0 | ₹0 | ₹0 | ₹0 | basic quiz, profile, useful discovery, limited requests, mutual chat, groups, report/block, full privacy controls |
| Plus | ₹149 | ₹399 | ₹749 | ₹1,399 | extra monthly introductions, multi-lens deeper explanations, advanced search, saved profiles |
| Connect | ₹299 | ₹799 | ₹1,499 | ₹2,799 | higher but capped intro quota, curated group features, additional filters and report comparisons |
| Matrimony Intent (later, optional) | ₹399 | ₹1,099 | ₹2,099 | ₹3,899 | serious-intent tools, opt-in life-planning comparison and guided introductions, no guarantees |

**Important:** initial MVP should launch Free only or test a clearly disclosed nominal paid pilot; do not commit engineering to all four tiers before demand exists. All above prices are illustrative *before final GST handling*, discounts relative to monthly are not implied auto-renew consent. The user may purchase one shared subscription with per-mode entitlements later, or separate modes, but never silently activate a different relationship mode when upgrading.

## 2. Never paywall
Blocking, reporting, privacy and consent withdrawal, access/correction/export/deletion where rights apply, basic interaction after mutual acceptance, emergency help, abuse appeal and complaint responses. Avoid paid bypass of someone's preferences, "priority access" to people who opted out, or refunds withheld for unsafe service.

## 3. Billing lifecycle
`draft_checkout -> pending_gateway -> payment_confirmed -> entitlement_granted -> active -> renewal_pending -> renewed/grace/past_due -> cancelled/expired/refunded`. Upgrade/downgrade proration and refund policies must be decided and disclosed. Gateway failure must not strip user privacy/safety or existing paid access prematurely. Persist `price_version`, `tax_calculation`, consent timestamp, renewal election, provider refs and finalized invoice metadata. User can download invoice and cancel future renewals without agent intervention.

## 4. Razorpay engineering requirements
Payment methods/recurring constraints depend on actual merchant setup and live Indian rails. Use subscription mandates only with required informed consent, pre-debit communications and legal compliance. Stripe-like instant card recurring assumptions may not apply to UPI/card mandates. Razorpay signed webhook verification on raw body, event ID unique index, idempotent ledger, server-confirmed payment status, reconciliation, retry/outbox, back-office refund approvals and masked details. Do not store PAN, CVV or UPI credentials.

## 5. Illustrative unit economics (not forecasts)
Assume Registered → MAU = 30%, Paid conversion of MAU = 3%, subscription realized ARPPU ₹149/month, gateway+indirect processing allowance 3% (placeholder), monthly fixed ops ₹7,500 baseline, variable support/moderation ₹1.5 per MAU, variable infra/email ₹0.4 per MAU. Gross margin before paid acquisition and tax = revenue − gateway − fixed − variable.

| Registrations | MAU | Paying | Gross ₹/mo | Approx modeled contribution ₹/mo |
|---:|---:|---:|---:|---:|
| 100 | 30 | 1 | 149 | -7,412 |
| 1,000 | 300 | 9 | 1,341 | -6,769 |
| 5,000 | 1,500 | 45 | 6,705 | -3,846 |
| 10,000 | 3,000 | 90 | 13,410 | -192 |
| 100,000 | 30,000 | 900 | 134,100 | 65,577 |

**Formula** `gross = paying × 149`; `fees = 0.03 × gross`; `variable = 1.9 × MAU`; `contribution = gross − fees − variable − 7500`. Above rounded to nearest rupee. Actual realized subscription prices vary by plan, discounts, GST, refunds, plan churn and processor costs. This model explicitly does **not** include founder salary, paid marketing CAC, capital expenditure, independent audits, lawyers, significant media moderation, staff coverage, nontrivial AI inference or taxes. Long-term cost may be far higher; observe paid cohort and incidents per active member.

## 6. Cohort and pricing experiments
Experiment price versus conversion ethically through clearly disclosed offers: Plus ₹99/149/199; no dark pattern, fake scarcity, deceptive fake charges, or incompatible payment mandates. Collect willingness-to-pay before checkout; measure refund complaints and 30/90-day retention. Pricing roadmap requires segment-specific India evidence and competition validation.

## 7. Cost guardrails
Feature flags for photo uploads, AI models, large answer-set retention, group/member quotas. Approx average 10 profile photos × 300KB × 5,000 accounts ≈15GB before versions/backups; R2 Standard 10GB-month free allowance would be exceeded. Even compressed images and read operations incur resource use; script quota alerts. Long conversations/media and identity/SMS cost can dominate modest subscription revenue. Human support at 24/7 scale cannot be assumed free. Set monthly spend thresholds with graceful degradation of nonessential features, not safety.

## 8. Subscription edge cases
Refund granted after entitlement expiration; duplicate payment webhook; subscription payment success but email failed; wrong price version; gift/referral fraud; user banned with paid time; deceased user account; cancellation near renewal boundary; tax invoice correction; expired mandate; payment dispute; deletion request with financial retention. Each gets deterministic state machine and reconciled audit record.



---


# QA-RD / Analytics-RD — Acceptance, Test Strategy, Instrumentation & Experiments

## 1. Quality architecture
**Unit:** scoring weights/coverage/bands, consent state transitions, eligibility predicates, billing entitlements, moderation deadlines. **Integration:** Firebase JWT verification, D1 migrations/transactions, R2 private upload, DO message state, Queue retries, Razorpay webhook. **Contract:** OpenAPI schema and generated TS client matches server on every release. **E2E:** sign-up, independent mode onboarding, quiz resume, discovery, mutual request/chat, block/report, case action, cancellation/export/delete. **Security:** IDOR/authorization and admin privilege adversarial matrix; device and browser matrix; limited load tests on paid sandbox budgets.

## 2. Prioritized full scenario matrix
| ID | Test | Required outcome |
|---|---|---|
| T01 | Fresh unauthenticated user opens `/api/v1/me` | 401, no private data |
| T02 | User activates friend only and tries matrimony discovery | empty/403 with explanation |
| T03 | Complete quiz after random order and resume from device B | stable assignment and saved response accuracy |
| T04 | Two users share 100% measured index but one blocked the other | not discoverable / cannot chat |
| T05 | Score insufficient coverage | no misleading 90% confidence outcome |
| T06 | User changes answer then recalculates | new score version, match cache invalidated |
| T07 | User withdraws profiling consent | discoverability disabled for that inference, prior cache unreadable |
| T08 | User uses AI to answer quiz | no "undetectable proof" claim; retest policy transparent |
| T09 | Message sent with expired or forged token | deny, no persistence |
| T10 | Report from free/expired/banned plan | protected reporting remains accessible through policy-safe channel |
| T11 | Admin support agent guesses moderation evidence URL | 403 + audited failed access |
| T12 | Admin role client spoof and forged email | deny via verified server permissions |
| T13 | Risky admin ban requires 2 approvals | cannot commit with one account |
| T14 | Payment webhook repeated 20 times | exactly one ledger credit and entitlement |
| T15 | Cancel subscription | no future renewal from platform while core data remains |
| T16 | Erase personal data with lawful hold | purge eligible records, retain only documented hold with restricted access |
| T17 | D1 free read limit reached | graceful nonessential throttling, alert; safety case still available via contingency |
| T18 | R2 object URL leaked | expired scoped signed URL cannot reveal other objects |
| T19 | Worker deployment rollback | previous version restores, schema forward compatibility |
| T20 | Low-end mobile + reduced motion | full functionality, no excessive animation |

## 3. Events and privacy taxonomy
Store consented, minimized aggregate usage metadata, not raw answers, private texts, mental-health labels or sexual preference as marketing analytics. Example events: `onboarding_started`, `mode_activated`, `quiz_attempt_started`, `quiz_progress_checkpoint` (counts, no answers), `quiz_submitted`, `score_viewed`, `discovery_viewed`, `connection_requested`, `connection_accepted`, `report_opened`, `report_submitted`, `block_applied`, `second_contact_confirmed_day7`, `continued_connection_confirmed_day30`, `subscription_started`, `renewal_cancelled`, `support_sla_breached`, `case_closed`. Each event includes schema version, timestamp, coarse mode, experiment variant if consented, anonymized cohort and correlation ID; never user plaintext in third-party analytics.

## 4. Primary outcomes
**North star:** day-30 mutual continuity rate = pairs with two-sided affirmative follow-up / eligible introduced pairs, with transparent missing-data denominator. Secondary: completed meaningful introductions per active local cohort, day7 repeat contact, user safety comfort score, actual group repeat participation, subscription retention, complaints/1,000 active conversations, median and p95 response/resolution time, fairness across tested groups (only where lawful and proportionate).

## 5. Scientific matching experiments
A/B design: baseline interest/availability matching vs deeper consented trait matching, randomize qualified users where ethically feasible, report cohort sizes and confidence intervals, pre-register success measure, monitor differential dropoff and harm. Avoid sending someone to an unsafe or incompatible match as a "control"; all arms use identical hard safety filters. Assess matching explainability and human agency. Do not use AI-generated simulated conversations as evidence of real compatibility.

## 6. Release quality gates
No P0 security issue; full authz suite and admin MFA passed; no false copy; accessibility AA targeted; critical routes load tested, backup/restore verified, 30-day retention and abuse cases tested, legal/privacy reviewed, on-call acknowledged, monitoring dashboards and rollback rehearsed. Test artifacts stored with release SHA.

## 7. Reporting dashboards
Public product dashboard aggregates by city/mode and hides small counts to prevent reidentification. Admin views segmented by duty; no casual raw quiz exports. Executive weekly report: activated users per pool, qualified introductions, continued connections, conversion, safety incidents and SLA, net cash burn. Matching science report: score calibration, holdout lift, attrition, bias and caveat compliance. Finance report: settled payments, refunds/chargebacks, realized ARPPU, gross margin and spend versus ceilings.



---


# Delivery-RD — Dependency-aware Delivery, Roadmap & Developer Backlog

**This is a recommended phased roadmap, not an estimate that one person can complete all of it in 90 days.** Three relationship modes, psychometrics, chat, public groups and an operating moderation console are a multi-disciplinary product; avoid committing to a calendar that substitutes for staff/clinical/legal work.

## 1. Workstream dependencies
1. Product/legal gates and safety policy before collecting intimate answers.
2. Auth/identity, consent, mode persona and admin roles before quizzes/discovery/chat.
3. Question bank review/permissioning before psychological scoring can represent anything meaningful.
4. Matching policy and score contract before candidate discovery.
5. Report/block/moderation capacity before stranger chat/groups/media.
6. Billing ledger and cancellation tested before paid plans.
7. App metrics and safety analytics before feature expansion.
8. Migration abstraction before major DB growth, not after vendor lock-in.

## 2. Planning calendar for a small team
**Phase 0 — 0–30 days: research and controlled validation.** 20–30 interviews per initial segment, safe concierge matching, separate positioning tests for three modes, opinionated legality/data map, architecture spike, brand prototype. **Exit:** evidence of repeat contact and trust with consenting adults; no full public launch.

**Phase 1 — 30–60 days: secure skeleton.** Monorepo, design tokens/story components, CI/CD, identity/JWT verification, mode-scoped personas, D1 migrations, admin invitation + MFA, consent log, rights request scaffold, private R2 upload, safety report pipeline, worker observability and audit logging. **Exit:** demonstrated deny-by-default auth and data boundaries.

**Phase 2 — 60–90 days: restricted experience.** Approved limited theme quiz, server-side scoring with transparent caveat, match candidate batch, discovery, requests, text chat, blocks/reports, moderated private Circles, admin case triage, consent withdrawal and data export/deletion end-to-end. Security review and pilot readiness gate. **Exit:** approved adult invite-only pilot with staff safety coverage.

**Phase 3 — 90–150 days: validate and harden.** cohort science, accessibility/bias/security fixes, stable messaging and SLA alerts, backup/restore, full customer support, moderation staff training and billing gateway test. Only then consider subscriptions, public Circles, staged cities, additional themed banks.

**Phase 4 — 150–270 days: optional scale.** localized question research and translations, matrimony-specific controls, multiple quiz versions, advanced lens experiments, curated activity loops, B2B partnerships and server migration if performance/legality requires it. AI twins and media-heavy calls remain separate later research tracks.

## 3. Developer sprint epics / estimation units

| Epic ID | Scope | Dependency | Relative size | Release acceptance |
|---|---|---|---|---|
| E00 | repo assessment, remove simulated claims, architecture setup | none | M | no demo auth in production |
| E01 | Firebase identity + JWT and account mapping | E00 | L | all invalid tokens rejected |
| E02 | mode consent, profiles & field ACL | E01 | XL | cross-mode isolation tested |
| E03 | public UX and component design | E00 | L | responsive, WCAG tests |
| E04 | question catalog/banks/attempts | E01,E02 | XL | deterministic versioning and resume |
| E05 | scoring engine + explanations | E04 + scientific approval | XL | reproduce all scores; caveats |
| E06 | matching discovery + cache + consent | E05,E02 | XL | hard safety filters enforced |
| E07 | connection requests + text chat | E06,E08 | XL | mutual consent and report tools |
| E08 | moderator/admin cases, roles, complaints | E01,E02 | XL | first/second-line safety flows |
| E09 | Circles & group controls | E07,E08 | XL | group-specific moderation |
| E10 | data rights, deletion and retention | E02,E04,E08 | XL | verified end-to-end erasure jobs |
| E11 | payment entitlements + renewals | E08,E10 | L | reconciled webhook/cancel |
| E12 | security/observability/backup | all | XL | incident drill and pentest |
| E13 | outcome analytics & experiments | E06,E07 | M | 7/30-day outcome reports |
| E14 | multilanguage, AI twin, video | evidence gates | XXL | research-only until new approval |

Relative sizes XS/S/M/L/XL/XXL represent comparative effort, not person-day promises. Milestone timing must be re-estimated after staffing and prototype tests.

## 4. Full feature priority table
**MUST before public launch:** authenticated accounts, verified adult eligibility policy, profile privacy by mode, opt-in quiz consent, scoring caveat, discovery hard filters, mutual request, text-only safe chat, block/report, support desk, basic moderation + on-call, admin MFA/RBAC, consent rights, accurate terms/privacy, backup/restore, operational logs, security audit, error handling and accessibility.

**SHOULD after pilot:** varied question sets, natural-language score explanations from approved traits, moderated Circles and meetups, payment plans, in-app notifications, user feedback, better insight graphs, verified claimed facts with provider-approved flow.

**COULD after evidence:** verified organizers, official curated group sessions, discovery quality learning, long-term compatibility research, advanced conversation prompts, localized cohorts, optional family-assisted matrimony.

**WON'T initially:** full AI mind replicas, predicting protected traits secretly, public sharing of raw quizzes, video calls, on-device face biometrics, mandatory Aadhaar, open adult+minor matching, unmoderated anonymous groups, paid bypass of user consent, guaranteed soulmates.

## 5. Cost-aware feature flags and graceful modes
- `public_discovery_enabled`, `new_signups_enabled`, `media_upload_enabled`, `private_groups_enabled`, `matching_compute_enabled`, `payments_enabled`, `ai_simulation_enabled=false`, `read_only_mode`.
- On Cloudflare limit exhaustion protect help and reporting via alternative documented contact; do not hide safety system behind rate limit. Offline/retry states must not create duplicate payments or messages.
- Configure per-month spend caps/alerts for R2/Worker/DO, account creation SMS email and moderation time.

## 6. Deliverables for each discipline
**Founder:** persona interview log, revenue assumptions, acceptance and risk signoffs. **Psychology:** construct map, survey licenses, item validation, model card and unfairness tests. **Designer:** all Figma screens, tokens, responsive prototypes and content guidance. **Engineer:** tested code, API spec, migration scripts, ops dashboards, secrets, CI and runbooks. **Security:** threat model, pentest, checklist, incident tabletop. **Legal:** signed policies, data map, record of applicability, grievance procedures. **Moderator:** documented queue, escalation, appeals and training simulations. **QA:** traceability matrix and defect severity ledger.

## 7. Definition of a shippable vertical slice
A real authorized user (not mocked) activates friendship mode, completes a **valid published** safe assessment, receives a clearly caveated index, sees only eligible and opt-in candidate(s), sends/receives a request, exchanges a persisted text message, reports abuse, has a human respond via authenticated case handling, and withdraws profiling consent such that further matching ceases; all actions audited/tested and legal review complete.

## 8. Explicit next decisions
D01 city/cohort for launch; D02 invitation-only vs open beta; D03 timeline and staff coverage; D04 science advisor and research protocol; D05 first published theme approval; D06 starting plan price research; D07 host region/vendor contracts; D08 moderated image capability; D09 identity verification policy; D10 whether any paid/matrimonial family tools are delayed; D11 brand/domain clearance and Indian company identity; D12 responsible officer contact.



---


# Competitive-RD / Market Validation — Product Reality in India and Abroad

**Research status 1 November 2026.** Available downloads/revenue claims do not prove psychological matching efficacy. Kithra's overlap is strong; AI-persona matching is not new. Always separate self-reported figures, public marketing, verified financial results and independent outcomes.

## 1. Competitors with clear functional overlap

| Competitor | Overlap with Kithra | Evidence and interpretation |
|---|---|---|
| OkCupid | deep questionnaire + match percentages | established questionnaire compatibility; not guaranteed success; https://www.okcupid.com/ |
| We3 | psychographic questions, friendship groups and explanations | site describes hundreds of factors and triadic introduction; reported >1M tribes and 50k+ in-person meetups **self-reported**, not independently audited: https://www.we3app.com/how-it-works/ |
| Boo | personality-based friends + dating with communities | official FAQ says 30-question test, personality matches and friend/date modes; https://boo.world/faq |
| Dimensional | >200 psychological traits, compare relationship dimensions | official site reports 200+ traits; https://www.dimensional.me/ |
| TrulyMadly | Indian dating, compatibility and verification | Inc42 financial breakdown FY25 approx revenue ₹12.3 crore and net loss ₹1 crore; source is third-party financial compilation, not outcomes: https://inc42.com/company/trulymadly/financials/ |
| Aisle | India-focused serious dating, curated discovery | current features/revenue/scale should be rechecked from company and filings, no high-certainty psychological claim; https://www.aisle.co/ |
| Schmooze | indirect preference inference from memes, Indian product | Business Standard Sep 2024: company reported 1M Indian users in 10 months, raised $4M; not proven relationship outcomes: https://www.business-standard.com/companies/start-ups/ai-led-dating-platform-schmooze-raises-4-million-series-a-round-124091701179_1.html |
| Konvo | **AI twins** converse and preview potential matches | site advertises AI twin chats/virtual dates and made-for-India positioning; claims have not been independently validated: https://konvo.space/ |
| Betterhalf | India-oriented matrimony with algorithmic claims | adjacent paid serious-intent audience; https://www.betterhalf.ai/ |
| Hinge | prompt-driven relationship discovery | broader intent-based discovery; https://hinge.co/ |
| Meetup | activity-led friendships | actual group activities, no long psychometrics; https://www.meetup.com/ |
| Discord / WhatsApp | organic communities and conversations | substitute for social infrastructure; https://discord.com/ and https://www.whatsapp.com/ |

## 2. Relevant competitor counterstrategies
- **Against OkCupid:** show why a score is meaningful, mode separation, consent and real continuation, not merely more questions.
- **Against We3:** explore one-to-one and group friendship formats with actual 7/30-day mutual outcomes, friend boundaries, local density and better privacy clarity.
- **Against Boo:** clear choice of friendship/dating/matrimony and measurable connection quality, not personality type stereotypes.
- **Against Dimensional:** practical voluntary introductions and safety rather than just a dashboard of traits.
- **Against Konvo:** avoid premature AI replica promise, provide validated consented behavioral insights and a transparent data-governance advantage.
- **Against Indian dating incumbents:** build trust and resolve safety issues operationally, without pretending algorithmic compatibility removes human uncertainty.

## 3. India readiness and true success test
Evidence of downloads/registrations is **not** evidence of active compatible matches. For each operator evaluate: India monthly active users in target city and mode, gender/intent composition where publicly verified, 30-day retention, share of mutual conversations, repeat contact and outcomes, subscription conversion/paid refunds, user complaints and moderation capacity. Most private startups do not publish reliable causal success data; label unknown rather than estimate a number.

## 4. Field validation program
Week 1: interview at least 20–30 per one target cohort (not necessarily all three modes), log current alternatives and genuine frustrations, avoid leading/"would you use AI twin" questions. Week 2: present three positionings and a simple legal/privacy prototype; measure real opt-ins and privacy concern. Week 3: invite adult volunteers, assign a short transparent matching task with human safety screening, consented mutual introductions; avoid asking 1,200 questions before showing any value. Week 4+: at day7/30 independently ask both members about continued contact, quality and safety; report missing/negative answers, not just testimonials. Use simple interest/availability baseline comparison. Only retain consented outcome data in minimal form.

## 5. Falsifiable go / change / stop rules
**GO to secure beta:** user demand plus positive evidence of safe repeat interactions and willingness to participate without exaggerated claims. **CHANGE matching:** questionnaire burden increases abandonment with no credible lift over simple interests. **CHANGE niche:** no local active compatible density despite reasonable acquisition; move to narrower age/community/language pool. **STOP or pause:** unmanaged abuse, inability to staff legal safety response, high privacy risks that cannot be mitigated, deceptive model explanation dependence, unsustainable per-active-member economics. These are decision rules, not predictions.

## 6. What cannot honestly be claimed
No proven competitor was identified with independently verified "100% brain replication", "90% relationship success" or certainty of opposite/puzzle-fit marriage outcome in India. Commercial marketing may use soulmate language; Kithra must not equate such claims with science.



---


# Evidence Register, Assumptions, Open Decisions & Source Traceability

**Checked:** 1 November 2026. Search results and product/vendor prices may change after that. URLs are starting points; official text and signed legal opinion outrank this report. This register clearly separates primary source evidence, concept ZIP, recommended design decisions and unvalidated assumptions.

## A. Uploaded source evidence
`Kithra-main.zip` extracted and inspected by file path:
- `package.json`: React 19, TypeScript, Vite 8, Tailwind 4, `framer-motion`, `motion`, `@google/genai`, Express dependency. This is the current concept stack, not proof of backend deployment.
- `src/App.tsx`: default mocked psychometric report and matches, stateful view navigation.
- `src/components/AssessmentView.tsx`: localStorage answers and `DEFAULT_REPORT` on completion.
- `src/data/questions.ts`: current template bank with 100 questions distributed over eight domains and ad-hoc weighting; **future question banks are new specification**.
- `src/data/mockMatches.ts`: fictional candidates and percentages.
- `src/components/AuthModal.tsx`: mock six-digit OTP and admin password condition accepting any nonempty value; not secure.
- `src/components/AdminView.tsx`: static sample metrics, verification and navigation tabs.
- `src/components/MessagingView.tsx`: simulated conversation features and unverified encryption imagery.
- `src/components/SecurityView.tsx`: simulated export and misleading E2EE copy.
- `src/components/BillingView.tsx`: plan visual design, not actual payment processing.
- `WORK_DONE.md`: self-described UI work, not independently verified production feature completion.
- `README.md`, `.env.example`: generic app notes and Gemini/APP_URL placeholders; no evidence of functional Worker/D1/R2 infrastructure.
- User-supplied ChatGPT shared link: https://chatgpt.com/share/6ae65881-aae0-83e8-b306-4fc4a1e96887 had a title only and **no readable page lines**; not used as a substantive source.

## B. Official provider technical source links (verified)
1. Cloudflare Workers pricing: https://developers.cloudflare.com/workers/platform/pricing/ — 100k requests/day and 10ms CPU Free; min $5/mo Workers Paid as of check.
2. Cloudflare Workers limits: https://developers.cloudflare.com/workers/platform/limits/ — runtime/resource constraints.
3. Cloudflare D1 pricing: https://developers.cloudflare.com/d1/platform/pricing/ — 5M rows read/day, 100k written/day, 5GB total Free storage.
4. Cloudflare D1 limits: https://developers.cloudflare.com/d1/platform/limits/ — **500MB max per database Free**, 10GB paid individual DB.
5. Cloudflare R2 pricing: https://developers.cloudflare.com/r2/pricing/ — 10GB-month Standard free, Class A/B operations.
6. Cloudflare Durable Objects pricing: https://developers.cloudflare.com/durable-objects/platform/pricing/ — SQLite DO Free availability.
7. Cloudflare Queues pricing: https://developers.cloudflare.com/queues/platform/pricing/ — Free 10k ops/day, retention limits.
8. Firebase pricing: https://firebase.google.com/pricing — phone SMS billed, identity billing tiers.
9. Identity Platform pricing: https://cloud.google.com/identity-platform/pricing — Tier 1 first 50k MAU free if using Identity Platform pricing structure; inspect SKU/plan.
10. Firebase server-side token verification: https://firebase.google.com/docs/auth/admin/verify-id-tokens — validate public certificate, issuer/audience/expiry.
11. Supabase pricing: https://supabase.com/pricing — 50k MAU on Free; Free project paused after inactivity, 500MB DB.
12. Supabase JWT: https://supabase.com/docs/guides/auth/jwts — asymmetric JWKS verification.
13. Motion for React: https://motion.dev/docs/react — preferred `motion/react` API.
14. OWASP ASVS 5.0: https://asvs.owasp.org/ — authentication/access control testing baseline.
15. Cloudflare D1 data location: https://developers.cloudflare.com/d1/configuration/data-location/ — default automatic location, jurisdiction controls not an India-localization guarantee.

## C. India laws and official information
1. DPDP Act commencement Gazette G.S.R. 843(E): https://egazette.gov.in/WriteReadData/2025/267647.pdf ; inspected English second page screenshot and text. 13 Nov 2025 initial, 13 Nov 2026 one-year, 13 May 2027 eighteen-month provisions.
2. DPDP Rules 2025 Gazette G.S.R. 846(E), reproduced text: https://indiacode.ecourtsindia.com/rules/digital-personal-data-protection-dpdp-rules-2025-fe07b131/ ; use official eGazette canonical PDF before counsel approval.
3. MeitY DPDP rules overview (PIB): https://www.pib.gov.in/PressReleasePage.aspx?PRID=2190014
4. IT Intermediary Guidelines 2021, amended Feb 2026 consolidated MeitY link: https://master-meity.digifootprint.gov.in/documents/act-and-policies/information-technology-intermediary-guidelines-and-digital-media-ethics-code-rules-2021-it-rules-2021-IjM5QjMtQWa
5. 2026 synthetic-media duty overview: https://www.pib.gov.in/PressReleasePage.aspx?PRID=2245053
6. CERT-In directions: https://www.cert-in.org.in/Directions70B.jsp
7. CERT-In 6h FAQs: https://www.cert-in.org.in/PDF/FAQs_on_CyberSecurityDirections_May2022.pdf
8. Consumer Protection e-commerce law portal: https://consumeraffairs.gov.in/pages/consumer-protection-acts
9. Consumer Protection E-Commerce 2026 changes: https://www.pib.gov.in/PressReleasePage.aspx?PRID=2308759 — announced effective 1 Jan 2027; ask counsel applicability.

## D. Competitor primary/recent sources
- https://www.we3app.com/how-it-works/ ; https://www.we3app.com/faq/
- https://boo.world/faq ; https://www.dimensional.me/
- https://konvo.space/ ; https://www.okcupid.com/
- https://schmooze.in/ ; https://www.aisle.co/ ; https://www.betterhalf.ai/
- https://www.business-standard.com/companies/start-ups/ai-led-dating-platform-schmooze-raises-4-million-series-a-round-124091701179_1.html
- https://inc42.com/company/trulymadly/financials/

## E. Assumptions needing founder approval
`A01` Kithra is 18+ only initially. `A02` three relationship modes share identity but not visibility. `A03` Cloudflare primary storage acceptable after cross-border/data residency review. `A04` Firebase auth instead of Supabase. `A05` email/password+Google first; phone optional later. `A06` admin managed by named email/password + strong MFA + deny-by-default RBAC. `A07` score bands measure index agreement, not probability. `A08` "AI twin" disabled until separately consented and validated. `A09` first validated quiz bank only after specialist review; rest placeholders. `A10` Free-first pilot before paid subscriptions. `A11` limited text chat and private moderated groups. `A12` price ladder illustrative. `A13` no mandatory Aadhaar/biometric or exact coordinates. `A14` no true E2EE claim until audited implementation. `A15` chat/group access not public during unstaffed pilot.

## F. Open decisions / decision rights
**Founder:** market segment/launch city, intended modes and rollout order, investment/ads goals, acceptable quiz length, pricing structure, product naming and brand IP. **Psychometrics advisor:** trait constructs, question permissions, scoring, model validation and honest claims. **Counsel:** Indian DPDP/IT Rules, user policies, privacy basis, cross-border, matrimonial obligations, payment/regulatory conditions. **Engineering lead:** Worker data architecture, R2 encryption, JWT verification, DB migration, backups, error budget, app security. **Trust lead:** staffing, report categories, escalation, evidence retention, appeals. **Designer:** user tests, brand, responsive and accessible prototypes. None may unilaterally bypass a legal/safety gate.

## G. Recommendation versus verification
**Verified from ZIP:** UI prototypes and insecure mocked logic. **Verified from public current docs:** provider allowances, regulatory commencement instruments, competitor descriptions and some company-reported metrics. **Recommended architecture:** not implemented or load-tested. **Mathematical examples:** not psychometrically validated. **Pricing and operating costs:** hypothetical; require testing. **Legal drafts:** placeholders; not airtight and cannot substitute legal advice.



---


# AI-RD — Optional Digital Personality Twin: Research Specification, Safety & Evaluation

**Status:** FUTURE RESEARCH; disabled by default. This document intentionally does not claim Kithra will copy a person's brain, create a sentient replica, infer intimate identities secretly, or reliably predict marriage or friendship outcomes. It defines a possible *consent-based model of the user's explicitly disclosed communication preferences* and a set of gating requirements before even a small controlled experiment.

## 1. What is actually feasible?
- **Persona summary:** a user-reviewed, editable representation of self-described preferences and questionnaire-based bounded traits.
- **AI simulation:** an LLM configured to respond as a *hypothetical agent* according to that summary. It may generate plausible dialogue, but it is **not** the user and does not reliably reproduce future beliefs, emotions, actions or consent.
- **Two-agent rehearsal:** opted-in agents can simulate introductory scenarios to offer conversation-starting topics or areas for discussion; this is **not a real human chemistry test**, cannot replace actual mutual consent, and cannot be used as factual proof of compatibility.
- **Behavior-over-time improvement:** only consented, user-confirmed feedback updates the summary; avoid covert scraping of private messages, journals or off-platform data.

## 2. Separate opt-in and revocation
Consent step clearly states source datasets (selected quiz dimensions, written self-description, optional specifically selected past messages if ever supported), intended outputs, third-party processors, retention, deletion, impersonation limits, model fallibility, costs and users' ability to preview/edit/revoke. Opt-in is **per person**, per source category and per mode; two agents may not communicate unless both owners opted in to that pairing/use. Revocation immediately stops new generations, marks prior simulation unshareable and launches documented deletion cleanup where lawful.

## 3. Data processing pipeline
```
Consent registry → minimal approved trait summary → user review/approval
→ policy scrubber and mode scoping → LLM prompt template → guarded simulation
→ clear "AI-generated hypothetical" label → user correction/approval
→ optional human-human introduction only after fresh mutual consent
```
Never give a model unrestricted access to D1, private messages, admin tooling or payments. No personal address, government ID, medical history, raw sexual orientation inference or trauma narrative in the prompt. Persona ID and pseudonym separate from account identifiers. Third-party inference endpoints receive the minimum authorized, redacted information.

## 4. Agent representation (example, not clinical)
`agent_version`, `user_id`, `mode`, `user_approved_summary`, `trait_model_version`, `declared_interests`, `communication_preferences`, `unshareable_boundaries`, `prompt_template_version`, `consent_id`, `expires_at`, `provider`, `output_disclaimer`, `reviewed_at`, `revoked_at`. Do not store secret prompts as proof of safety; actual policy enforcement lives in service code.

## 5. Why simulation should not score human relationships directly
Agents may amplify stereotypes, hallucinate confidence, answer in ways the underlying user never would, and optimize for pleasing dialogue. Simulations across agents have correlated biases and can make incompatible people look compatible. If used experimentally, treat outputs as **conversation suggestions**, not a component of 100%/90% match score without independent human-outcome validation. Allow both participants to reject simulated summaries without penalty.

## 6. Technical evaluation before enabling
- Consent and processor agreement verified.
- Privacy red-team: prompt injection, secrets exfiltration, cross-user leak, jailbreaking, identity spoofing.
- Test mismatched/missing questionnaire coverage and adversarial prompt manipulation.
- Human validation: does each owner accurately endorse what the model says? Report confidence/uncertainty.
- Comparative outcome trial: optional agent interaction vs no agent, measuring safety and **actual** continued contact, not simulated applause.
- Cost caps per invocation, token budgets, strict timeout, content moderation, model version pinning and trace IDs with **no raw sensitive content in logs**.
- Affected-person deletion and processor purge contract tested before production.
- Regulatory classification of synthetic output under applicable 2026 IT intermediary rules and consumer protection reviewed by counsel; AI outputs clearly labeled.

## 7. Product UX for future agent mode
Dedicated "Explore your preferences with AI" workspace, explicit account of what is and is not used, data preview, simulated transcript with persistent **AI simulation — not a real conversation** watermark, user corrections, privacy pause, delete-agent button, processor info and cost/use notices. No "your brain was replicated" copy, no making commitments or sending actual human messages without direct fresh approval.

## 8. Release gate
Separate security review, psychological-accuracy claims review, measurable human benefit, positive informed consent comprehension test, vendor contract/legal approval, acceptable cost model and staffed abuse response. Until then show no AI Twin button or waitlist that falsely implies functioning brain simulation.



---


# Community-RD / Growth-RD — Circles, Social Graph, Regionalization & Healthy Network Effects

## 1. The cold-start problem
Kithra can contain hundreds of thousands of inactive accounts yet provide no useful matches in a specific gender/intent/region/age/interest pool. Report **eligible active candidate density** by selected mode, city and broad interests, not raw registration count; expose truthful waitlists. Prefer one tested launch cohort and 2–3 scheduled activities to shallow national expansion. Group programming should create a reason to return that is not an engagement addiction loop.

## 2. Independent social surfaces
- **Member social graph:** voluntary mutual connection edge; block relation overrides any edge.
- **Mode persona graph:** public discovery edge scoped by selected mode; a friendship connection does not imply dating availability.
- **Circle graph:** group membership and moderation role not proof of off-platform compatibility.
- **Quiz graph:** index derived privately, never display other users' undisclosed raw answers.
- **Offline event graph:** consent-based RSVP; default public location only, no home/real-time tracking.

## 3. Circle feature specification
`Circle` has ID, neutral name, description, primary theme, optional mode restriction, coarse location, language(s), visibility (`public_listed`, `private_unlisted`, `invite_only`), membership rules, owner, moderators, max members, creation review status, content policy version. User actions: explore, request join, accept rules, view posts, mute, leave, block member, report content, create restricted circle with quotas. Circle admin actions: approve membership, pin rules, remove content, temporarily mute, send membership announcements subject to policy. Platform admins retain safety oversight; group managers cannot see intimate quiz data or global case records.

## 4. Region-neutral personality naming
Do not categorize people into alpha/beta, high/low status, superior/inferior, religion/caste-based "types". **Universal labels** for interpretive dimensions: `Compass`, `Rhythm`, `Mosaic`, `Horizon`, `Current`, `Bridge`, `Spark`, `Anchor`. **Optional India-oriented expressive aliases** for community themes (not immutable psychological classifications): `Sangam` (confluence), `Setu` (bridge), `Lehar` (wave), `Aangan` (shared gathering place), `Udaan` (aspiration). Indian language professionals should assess meanings and accessibility; English, Hindi and Tamil expressions cannot be assumed culturally interchangeable. These names describe communities and preferences, **not ethnicity, caste, religion, worth or destiny**. All members can browse or opt out; no identity-based assignment.

## 5. More features that fit this universe (prioritized by outcome)

| Experience | User need | Phase | Safety and cost caveat |
|---|---|---|---|
| Small-group icebreaker Circles | avoid awkward one-to-one beginnings | MVP after moderation | group reporting & boundaries |
| Mutual conversation starters | help first meaningful dialogue | MVP | optional, not auto-sent AI |
| Shared reading/learning challenge | repeat organic contact | post-pilot | avoid leaderboard pressure |
| City newcomers board | discover local safe groups | post-pilot | coarse location only |
| Co-working/creator collaborations | productive friendship | post-pilot | anti-scam and IP policy |
| Quiet affinity groups | accessible low-pressure friendships | post-pilot | privacy, member choice |
| Intent-specific date planning | safer date logistics | later | venue info, no live tracking |
| Shared-life-planning conversation guide | matrimony mutual expectations | later | self-declared, no guarantee |
| Community-host toolkit | partnerships and repeat meetups | later | host identity and liability review |
| Conversation follow-up reminder | reduce ghosting with consent | post-pilot | no spam or guilt prompts |
| Compatibility change tracker | self-reflection over time | later | privacy and scoring drift |
| AI-summarized preference card | opt-in clarity | research | third-party data processing |
| Video/voice groups | online social presence | much later | high moderation/media costs |
| Moderated real-world events | strengthen ties | later | event safety and organizer vetting |
| Professional peer circles | founder and tech collaborations | post-pilot | job/scam solicitation checks |

## 6. Gamification limits
Reward *mutual, useful outcomes* like attending agreed small groups or completing a conversation guide, not message volume, streaks, harmful self-disclosure, desirability ranking or coercive endorsements. No visible scores that indicate higher personal value. Referral campaigns must be opt-in, anti-spam, without revealing who uses matrimonial mode. Every new social mechanic must report harassment and exclusion risks.

## 7. Messaging and notifications economics
Allow member-generated invitations only within quotas; message dispatch via DO and persistence in D1; attachment lifecycle to R2; opt-in email summaries, low-frequency suggestions and a single configurable quiet-hours setting. No paid unlock for receiving basic messages from a mutual consented match. If push notifications are eventually built, respect mode concealment on lock screens.

## 8. Localization and inclusion
Support multilingual UI separately from psychometric translation: UI labels can be translated with ordinary QA; psychological questions require cognitive interviews and item-level measurement equivalence analysis. Right-to-left ready components if expanding internationally; avoid culturally biased labels, no photographs of fictitious people labeled as current members, avoid assumptions of family authority in matrimony. Regional data retention/sharing assessed for all chosen providers.

## 9. Growth experiments
Test: `city-newcomer circles`, `interest cohort`, `founder/learning club`, `serious relationship conversation prompts` as separate cohorts. Measure invite→active conversion, safe mutual introductions, repeat contact, circle active member concentration, moderation cost per 100 active participants. Partner with clubs only when a real co-host and safety point of contact exists; never claim vendor endorsement without contract.
