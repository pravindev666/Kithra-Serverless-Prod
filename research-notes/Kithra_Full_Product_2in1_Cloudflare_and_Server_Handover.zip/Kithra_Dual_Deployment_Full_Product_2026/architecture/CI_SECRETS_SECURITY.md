# DevSecOps/security handoff

## CI/CD and permissions

Use protected main branch and environment-specific rules. GitOps-style Jenkins job with 2-person approval for prod and OCI registry images identified by digest. Build manifests include dependency lockfile hashes, code signing, SBOM and vulnerability results. Jenkins should live off public internet (VPN or restricted identity gate), with isolated build agents and Docker access strictly restricted. Store Firebase/Gateway/S3/Cloudflare keys in Jenkins Credentials Store or external secret manager and never echo them to console.

Deploy Cloudflare with narrowly scoped API tokens and explicit environment bindings; deploy containers through a limited remote runner. CI should *not* have superadmin application rights or unrestricted production DB read access.

## Auth

Separate all 3 user personas; identity provider is not authorization. Firebase UID mapped to internal UUID, JWT verified with issuer, audience, signature, expiry and local account policy. Human admin must have email/password+MFA, verified email, roster allowlist, step-up reauth and RBAC. Add a firewall/Cloudflare Access as extra protection not as sole access policy. Recovery, session revocation, offboarding and dual-approval are mandatory.

## Defense in depth

- CSP, HSTS once TLS proven, secure cookies, CSRF mitigations, CORS allowlist, XSS sanitization, SQL parameterization, object access checks.
- Rate limits for email registration, quizzes, discovery, conversations, uploads, refunds and staff endpoints; spam and scraping signals.
- Server-side scopes on every request and room event; test blocked users cannot see presence or consume unread content.
- Never claim end-to-end encryption when moderation/server decryption is possible; document transport, disk and field-level encryption separately.
- Immutable-style audit trail with remote/cross-account retention and alerting for privileged access.
- Operational emergency switches for messaging/registration/AI while help, legal contact and reporting remain accessible.
- Retention and evidence preservation independent from commercial account cancellation.
- Keep a bug bounty/security contact policy, breach report playbook, CERT-In reporting assessment and specialist legal advice.

## Dual-target attack tests

Against BOTH Cloudflare and server: token-forgery, access token stale/revoked, abuse by another user's mode profile, quiz assignment tampering, answer scraping, IDOR on media, double spending via webhook replay, shadow admin login, direct admin endpoint access, websocket group membership after blocking, queue duplicate causing double billing, user deletion while backup restore and consent withdrawal while AI twin inference queued.
