# Database-portability policy and migration protocol

- Primary data model: user, identity provider, mode persona, mode consent, profile visibility, question bank, item revision, assessment assignment, answer set, dimensional score, explanation, match candidate, intro request, conversations, message, blocks, group, group role, report, evidence, case, audit log, billing ledger, entitlements, retention job, export job, deletion, incident, admin role grants.
- **No shared production schema file is promised to work for BOTH SQLite/D1 and PostgreSQL.** Maintain two migration families, named in paired change log. Each migration has tested seed, precondition, postcondition and rollback/reconciliation notes.
- Use time-independent identifiers (UUIDv7/ULID with stable representation), UTC timestamps stored unambiguously; do not use DB-specific serial primary keys in shared domains.
- Use repositories that expose business operations and transactions rather than unbounded free-form SQL. Avoid N+1 queries, test indexed match filtering and participant-specific chat ownership.
- D1 SQLite has different JSON, FTS and transaction/DDL behavior from PG. Test correctness not just syntax. Use outbox/event sequencing and idempotency when queue publish cannot atomically commit with DB.
- Raw psychological responses: encrypted at application level if approved by key and threat model; minimize storage. Do not store full raw data in free-form log bodies or user search indexes.
- Backups: server PostgreSQL WAL/PITR with offsite encrypted copies; D1 Time Travel and scheduled exports; R2 backup/lifecycle, key recovery; data subject deletion applies to replicas and backups consistent with law and retention.

## Practice cutover rehearsal

1. Provision clean PG schema, reconcile entity mapping and indexes.
2. Create D1 consistent export point or maintenance write freeze; make snapshot manifest.
3. Transform field representations using versioned migrations; import PG; validate all counts and integrity.
4. Compare encrypted answer metadata, consenting modes, block graph, active conversations, payment ledger, case and grievance deadlines.
5. Replay application outbox, reject duplicates and verify pending events match.
6. Benchmark target under production-like loads.
7. Demonstrate request/API contract parity and staff console parity.
8. Simulate server failure and restore using documented RPO/RTO.
9. Cut over via DNS/gateway with rollback defined; no automatic reverse switch after target starts accumulating new writes.
10. Keep deletion and consent withdrawal mechanisms active during any maintenance window via a reliable alternative contact channel.

**The reverse direction is not guaranteed:** PG datasets can exceed D1 capacity or rely on unsupported SQL. Reverse-migration feasibility must be evaluated; do not promise seamless one-click switching.
